<?php
//error_reporting(E_ALL) ;
/************************************************************************
Empresa: Net4U Solu��es Internet e Intranet

Descri��o: Classe Operadores
	
Releases (Data, respons�vel e descri��o [�ltimo release primeiro]):
	01/08/2005 (Rafael C�cero) 
		Inclu�do este cabe�alho descrevendo a funcionalidade da classe
						
************************************************************************/
class Operadores {

	//PROPRIEDADES DO OPERADOR
    private $numgOperador;
	private $nomeOperador;
    private $nomeCompleto;
    private $descTipo;
    private $descSenha;
    private $descEmail;
    private $dataCadastro;
    private $nomeOperadorCad;
    private $dataUltimaAlt;
    private $nomeOperadorAlt;
    private $dataBloqueio;
    private $nomeOperadorBloq;
    private $dataUltimoAcesso;
    private $flagEmailPendencia;
	private $flagEmailDiario;
	
	private $nomeMunicipio;
	private $siglUf;

	private $oResult, $sSql, $sErr;
	
	function __construct()
	{
	
	}
	
	function __destruct()
	{
	
	}
	
	function setNumgOperador($valor){ 
		if (is_numeric($valor)){
			$this->numgOperador = $valor;
		}else{
			Erros::addErro("N� identificador do operador inv�lido.�");
		}
	}
	
	function getNumgOperador(){ return $this->numgOperador;}

	
	function setNomeOperador($valor){ 
		if (trim($valor) != ""){
			$this->nomeOperador = $valor;
		}else{
			Erros::addErro("Login de acesso do operador inv�lido.�");
		}
	}
	
	function getNomeOperador(){ return $this->nomeOperador;}
	
	function setNomeCompleto($valor){ 
		if (trim($valor) != ""){
			$this->nomeCompleto = $valor;
		}else{
			Erros::addErro("Nome completo do operador inv�lido.�");
		}
	}
	
	function getNomeCompleto(){ return $this->nomeCompleto;}
	
	function setDescSenha($valor){ 
		if (strlen($valor) >= 4){
			$this->descSenha = $valor;
		}else{
			Erros::addErro("Senha do operador inv�lida. Digite uma senha com no m�nimo 4 d�gitos.�");
		}
	}
	
	function getDescSenha(){ return $this->descSenha;}
	
	function setDescEmail($valor){ $this->descEmail = $valor;}
	function getDescEmail(){ return $this->descEmail;}
	
	function setDataCadastro($valor){ $this->dataCadastro = $valor;}
	function getDataCadastro(){ return $this->dataCadastro;}
	
	function setNumgOperadorCad($valor){ $this->numgOperadorCad = $valor;}
	function getNumgOperadorCad(){ return $this->numgOperadorCad;}

	function setNomeOperadorCad($valor){ $this->nomeOperadorCad = $valor;}
	function getNomeOperadorCad(){ return $this->nomeOperadorCad;}
	
	function setDataUltimaAlt($valor){ $this->dataUltimaAlt = $valor;}
	function getDataUltimaAlt(){ return $this->dataUltimaAlt;}

	function setNumgOperadorAlt($valor){ $this->numgOperadorAlt = $valor;}
	function getNumgOperadorAlt(){ return $this->numgOperadorAlt;}
	
	function setNomeOperadorAlt($valor){ $this->nomeOperadorAlt = $valor;}
	function getNomeOperadorAlt(){ return $this->nomeOperadorAlt;}
	
	function setDataBloqueio($valor){ $this->dataBloqueio = $valor;}
	function getDataBloqueio(){ return $this->dataBloqueio;}
	
	function setNomeOperadorBloq($valor){ $this->nomeOperadorBloq = $valor;}
	function getNomeOperadorBloq(){ return $this->nomeOperadorBloq;}
	
	function setDataUltimoAcesso($valor){ $this->dataUltimoAcesso = $valor;}
	function getDataUltimoAcesso(){ return $this->dataUltimoAcesso;}

	function setDescTipo($valor){ 
		if (strlen($valor) >= 4){
			$this->descTipo = $valor;
		}else{
			Erros::addErro("Tipo do operador Inv�lido.�");
		}
	}
	
	function getDescTipo(){ return $this->descTipo;}

	function setFlagEmailDiario($valor){ 
		if($valor == 1){
			$this->flagEmailDiario = true;
		}else{
			$this->flagEmailDiario = false;	
		}
	}
	function getFlagEmailDiario(){ return $this->flagEmailDiario;}
	
	
	function setFlagEmailPendencia($valor){ 
		if($valor == 1){
			$this->flagEmailPendencia = true;
		}else{
			$this->flagEmailPendencia = false;	
		}
	}
	function getFlagEmailPendencia(){ return $this->flagEmailPendencia;}
	
	/******************************************************************
	 Data     : 11/04/2008
	 Autor    : Danilo Fernandes 
	 Descri��o: seta os dados de um operador pelo seu n� identificador
				ou pelo seu login.
	******************************************************************/
	public function setarDadosOperador($vDados){

		if(Erros::isError()) {
			
			return false;
	
		} else {
	
			try	{
			
				if ($vDados != "" || is_array($vDados)) {
				
					$sSql =  " select ope.numg_operador,ope.desc_tipo, ope.nome_operador, ope.nome_completo, ope.desc_senha, ope.desc_email, ope.data_cadastro, ope1.nome_operador as nome_operadorcad, ope.data_ultimaalt, ope2.nome_operador as nome_operadoralt, ope.data_bloqueio, ope3.nome_operador as nome_operadorbloq, ope.data_ultimoAcesso, ope.flag_emaildiario, ope.flag_emailpendencia";
					$sSql .= " from se_operadores ope";
					$sSql .= " inner join se_operadores ope1 on ope1.numg_operador = ope.numg_operadorCad";
					$sSql .= " left join se_operadores ope2 on ope2.numg_operador = ope.numg_operadorAlt";
					$sSql .= " left join se_operadores ope3 on ope3.numg_operador = ope.numg_operadorBloq";
					if (is_array($vDados)){
						if ($vDados[0] != ""){
							$sSql .= " where ope.numg_operador = " . $vDados[0];
						}else{
							$sSql .= " where  ope.nome_operador = '" . addslashes($vDados[1]) . "'";
						}
					}else{
						$sSql .= " where ope.numg_operador = " . $vDados;
					}
					
					Oad::conectar();
					$oResult = Oad::consultar($sSql);
					Oad::desconectar();
					
					if ($oResult->getCount() > 0){
						$this->numgOperador = $oResult->getValores(0,"numg_operador");
						$this->nomeOperador = $oResult->getValores(0,"nome_operador");
						$this->nomeCompleto = $oResult->getValores(0,"nome_completo");
						$this->descSenha = Descriptografa($oResult->getValores(0,"desc_senha"));
						$this->descTipo = $oResult->getValores(0,"desc_tipo");
						$this->descEmail = $oResult->getValores(0,"desc_email");
						$this->dataCadastro = FormataDataHora($oResult->getValores(0,"data_cadastro"));
						$this->nomeOperadorCad = $oResult->getValores(0,"nome_operadorcad");
						$this->dataUltimaAlt = FormataDataHora($oResult->getValores(0,"data_ultimaalt"));
						$this->nomeOperadorAlt = $oResult->getValores(0,"nome_operadoralt");
						$this->dataBloqueio = FormataDataHora($oResult->getValores(0,"data_bloqueio"));
						$this->nomeOperadorBloq = $oResult->getValores(0,"nome_operadorbloq");
						$this->dataUltimoAcesso = FormataDataHora($oResult->getValores(0,"data_ultimoacesso"));
						$this->flagEmailDiario = FormataBool($oResult->getValores(0,"flag_emaildiario"));
						$this->flagEmailPendencia = FormataBool($oResult->getValores(0,"flag_emailpendencia"));
					}
				}
								
				return true;
				
			} catch(Exception $e) {
			
				Erros::addErro("Fonte: SIGO.Operadores.setarDadosOperador(); Descri��o: ".$e->getMessage()."�");
				return false;
				
			}
		}	
	}


	/******************************************************************
	 Data     : 17/03/2008
	 Autor    : Thales A. Salvador
	 Descri��o: cadastra os dados de um operador.
	******************************************************************/
	public function cadastrar(){

		if(Erros::isError()) {
			
			return false;
	
		} else {
	
			Oad::conectar();
				
			$this->pValidaGravacao();
	
			if (Erros::isError()){
				Oad::desconectar();
				return false;
			}else{
	
				try	{
				
					$sSql =  " INSERT INTO se_operadores (nome_operador, nome_completo, desc_senha, ";
					$sSql .= " desc_email, desc_tipo, flag_emaildiario, flag_emailpendencia, data_cadastro, numg_operadorCad)";
					$sSql .= " values (";
					$sSql .= FormataStr($this->getNomeOperador()) . ",";
					$sSql .= FormataStr($this->getNomeCompleto()) . ",";
					$sSql .= FormataStr(Criptografa($this->getDescSenha())) . ",";
					$sSql .= FormataStr($this->getDescEmail()) . ",";
					$sSql .= FormataStr($this->getDescTipo()) . ",";
					$sSql .= FormataBool($this->getFlagEmailDiario()) . ",";
					$sSql .= FormataBool($this->getFlagEmailPendencia()) . ",";
					$sSql .= "CURRENT_TIMESTAMP,";
					$sSql .= $this->getNumgOperadorCad() . ")";
	
					Oad::executar($sSql);
					$oResult = Oad::consultar("select max(numg_operador) from se_operadores");
					$this->setNumgOperador($oResult->getValores(0,0));
				
				} catch(Exception $e) {
				
					Erros::addErro("Fonte: SIGO.Operadores.cadastrar(); Descri��o: ".$e->getMessage()."�");
					return false;

				}
				
			}
			Oad::desconectar();
			return true;
		}		
	}
	

	/******************************************************************
	 Data     : 17/03/2008
	 Autor    : Thales A. Salvador
	 Descri��o: edita os dados de um operador.
	******************************************************************/
	public function editar(){			

		if(Erros::isError()) {
			
			return false;
	
		} else {
	
			Oad::conectar();
				
			$this->pValidaGravacao();
	
			if (Erros::isError()){
				Oad::desconectar();
				return false;
			}else{
	
				try	{
				
					$sSql = "UPDATE se_operadores SET";
					$sSql .= " nome_operador=" . FormataStr($this->getNomeOperador()) . ",";
					$sSql .= " nome_completo=" . FormataStr($this->getNomeCompleto()) . ",";
					$sSql .= " desc_tipo=" . FormataStr($this->getDescTipo()) . ",";
					$sSql .= " desc_senha=" . FormataStr(Criptografa($this->getDescSenha())) . ",";
					$sSql .= " desc_email=" . FormataStr($this->getDescEmail()) . ",";
					$sSql .= " flag_emaildiario=" . FormataBool($this->getFlagEmailDiario()) . ",";
					$sSql .= " flag_emailpendencia=" . FormataBool($this->getFlagEmailPendencia()) . ",";
					$sSql .= " data_ultimaalt=CURRENT_TIMESTAMP,";
					$sSql .= " numg_operadorAlt=" . $this->getNumgOperadorAlt();
					$sSql .= " WHERE numg_operador = " . $this->getNumgOperador();
	
					Oad::executar($sSql);
				
				} catch(Exception $e) {
				
					Erros::addErro("Fonte: SIGO.Operadores.editar(); Descri��o: ".$e->getMessage()."�");
					return false;

				}
			}
			Oad::desconectar();
			return true;
		}		
	}


	/******************************************************************
	 Data     : 17/03/2008
	 Autor    : Thales A. Salvador
	 Descri��o: exclui os dados de um operador.
	******************************************************************/
	public function excluir($nNumgOperador){

		if(Erros::isError()) {
			
			return false;
	
		} else {
	
			Oad::conectar();
				
			$this->pValidaExclusao($nNumgOperador);
	
			if (Erros::isError()){
				Oad::desconectar();
				return false;
			}else{
	
				try	{
				
					$sSql = "DELETE FROM se_operadores WHERE numg_operador = " . $nNumgOperador;
						
					Oad::executar($sSql);
				
				} catch(Exception $e) {
				
					Erros::addErro("Fonte: SIGO.Operadores.excluir(); Descri��o: ".$e->getMessage()."�");
					return false;

				}
			}		
			Oad::desconectar();
			return true;
		}		
	}


	/******************************************************************
	 Data     : 17/03/2008
	 Autor    : Thales A. Salvador
	 Descri��o: bloqueia um operador, seta a data de bloqueio e o 
			    respons�vel.
	******************************************************************/
	public function bloquear($vDados){

		if(Erros::isError()) {
			
			return false;
	
		} else {
	
			Oad::conectar();
				
			$this->pValidaBloqueio($vDados[0]);
	
			if (Erros::isError()){
				Oad::desconectar();
				return false;
			}else{
				
				try	{
				
					$sSql =  " UPDATE se_operadores SET";
					$sSql .= " data_bloqueio = CURRENT_TIMESTAMP,";
					$sSql .= " numg_operadorBloq =" . $vDados[1];
					$sSql .= " WHERE numg_operador=" . $vDados[0];
	
					Oad::executar($sSql);
				
				} catch(Exception $e) {
				
					Erros::addErro("Fonte: SIGO.Operadores.bloquear(); Descri��o: ".$e->getMessage()."�");
					return false;

				}
			}
		
			Oad::desconectar();
			return true;
		}		
	}

					
	/******************************************************************
	 Data     : 17/03/2008
	 Autor    : Thales A. Salvador
	 Descri��o: desbloqueia um operador.
	******************************************************************/
	public function desbloquear($nNumgOperador){

		if(Erros::isError()) {
			
			return false;
	
		} else {
	
			try	{
			
				$sSql = "UPDATE se_operadores SET";
				$sSql .= " data_bloqueio = null,";
				$sSql .= " numg_operadorBloq = null";
				$sSql .= " WHERE numg_operador=" . $nNumgOperador;
				
				Oad::conectar();
				Oad::executar($sSql);
				Oad::desconectar();
				return true;
			
			} catch(Exception $e) {
			
				Erros::addErro("Fonte: SIGO.Operadores.desbloquear(); Descri��o: ".$e->getMessage()."�");
				return false;

			}
		}		
	}


	/******************************************************************
	 Data     : 17/03/2008
	 Autor    : Thales A. Salvador
	 Descri��o: atualiza o �ltimo acesso do operador ao sistema.
	******************************************************************/
	public function editarUltimoAcesso($nNumgOperador){
	
		if(Erros::isError()) {
			
			return false;
	
		} else {

			try {

				$sSql =  " UPDATE se_operadores SET";
				$sSql .= " data_ultimoAcesso = CURRENT_TIMESTAMP";
				$sSql .= " WHERE numg_operador=" . $nNumgOperador;
	
				Oad::conectar();
				Oad::executar($sSql);
				Oad::desconectar();
				return true;
				
			} catch(Exception $e) {
	
				Erros::addErro("Fonte: SIGO.Operadores.editarUltimoAcesso(); Descri��o: ".$e->getMessage()."�");
				return false;
	
			}
		}
	}


	/******************************************************************
	 Data     : 17/03/2008
	 Autor    : Thales A. Salvador
	 Descri��o: busca os dados de um operador pelo seu login.
	******************************************************************/
	public function consultarPorNomeOperador($sNomeOperador){
	
		if(Erros::isError()) {
			
			return false;
	
		} else {

			try {
	
				$sSql =  " select numg_operador, nome_completo, data_bloqueio, desc_senha, data_ultimoacesso ";
				$sSql .= " from se_operadores where lower(nome_operador) = lower('" . $sNomeOperador . "')";
				
				Oad::conectar();
				$oResult = Oad::consultar($sSql);
				Oad::desconectar();
				
			} catch(Exception $e) {
	
				Erros::addErro("Fonte: SIGO.Operadores.consultarPorNomeOperador(); Descri��o: ".$e->getMessage()."�");
				return false;
	
			}
			return $oResult;
		}
	}
	
	/******************************************************************
	 Data     : 11/08/2008
	 Autor    : Thales A. Salvador
	 Descri��o: busca os dados dos supervisores
	******************************************************************/
	public function consultarSupervisoresDesbl(){
	
		if(Erros::isError()) {
			
			return false;
	
		} else {

			try {
	
				$sSql =  " select numg_operador, nome_completo, data_bloqueio, desc_senha, data_ultimoacesso ";
				$sSql .= " from se_operadores where lower(desc_tipo) = 'supervisor'";
				$sSql .= " and data_bloqueio is null";
				
				Oad::conectar();
				$oResult = Oad::consultar($sSql);
				Oad::desconectar();
				
			} catch(Exception $e) {
	
				Erros::addErro("Fonte: SIGO.Operadores.consultarSupervisoresDesbl(); Descri��o: ".$e->getMessage()."�");
				return false;
	
			}
			return $oResult;
		}
	}


	
	/******************************************************************
	 Data     : 17/03/2008
	 Autor    : Thales A. Salvador
	 Descri��o: busca os operadores bloqueados.
	******************************************************************/
	public function consultarBloqueados(){

		if(Erros::isError()) {
			
			return false;
	
		} else {
	
			try	{
			
				$sSql =  " select ope.numg_operador, ope.nome_completo, ope.data_cadastro";
				$sSql .= " from se_operadores ope";
				$sSql .= " where not data_bloqueio is null";
				$sSql .= " order by nome_operador";
	
				Oad::conectar();
				$oResult = Oad::consultar($sSql);
				Oad::desconectar();
			
			} catch(Exception $e) {
			
				Erros::addErro("Fonte: SIGO.Operadores.consultarBloqueados(); Descri��o: ".$e->getMessage()."�");
				return false;

			}
			return $oResult;
		}		
	}


	/******************************************************************
	 Data     : 17/03/2008
	 Autor    : Thales A. Salvador
	 Descri��o: busca os operadores n�o bloqueados.
	******************************************************************/
	public function consultarNaoBloqueados(){

		if(Erros::isError()) {
			
			return false;
	
		} else {

			try	{
			
				$sSql = "select ope.numg_operador, ope.nome_completo, ope.data_cadastro";
				$sSql .= " from se_operadores ope";
				$sSql .= " where data_bloqueio is null";
				$sSql .= " order by nome_operador";
	
				Oad::conectar();
				$oResult = Oad::consultar($sSql);
				Oad::desconectar();
			
			} catch(Exception $e) {
			
				Erros::addErro("Fonte: SIGO.Operadores.consultarNaoBloqueados(); Descri��o: ".$e->getMessage()."�");
				return false;

			}
			return $oResult;
		}		
	}


	/******************************************************************
	 Data     : 17/03/2008
	 Autor    : Thales A. Salvador
	 Descri��o: busca os dados de um operador pelo seu login.
	******************************************************************/
	public function consultarOperadores($vDados){

		if(Erros::isError()) {
			
			return false;
	
		} else {
	
			try	{
			
				$sSql = "select ope.numg_operador, ope.nome_completo, ope.data_cadastro";
				$sSql .= " from se_operadores ope where";
				if (!empty($vDados)){
					if ($vDados[0] != ""){
						$sSql .= " (lower(ope.nome_completo) like lower('%" . $vDados[1] . "%')) and";
					}
					if ($vDados[1] != "" && $vDados[5] != ""){
						$sSql .= " (ope.data_cadastro between " . FormataDataConsulta($vDados[4] . " 00:00:00") . " and " . FormataDataConsulta($vDados[5] . " 23:59:59") . ") and";
					}
				}
				$sSql .= " 1=1";
				$sSql .= " order by ope.nome_completo";
	
				//echo $sSql;
				//exit;
				
				Oad::conectar();
				$oResult = Oad::consultar($sSql);
				Oad::desconectar();
			
			} catch(Exception $e) {
			
				Erros::addErro("Fonte: SIGO.Operadores.consultarOperadores(); Descri��o: ".$e->getMessage()."�");
				return false;

			}
			return $oResult;
		}		
	}


	/******************************************************************
	 Data     : 17/03/2006
	 Autor    : Thales A. Salvador
	 Descri��o: envia a senha de acesso (e nome de usu�rio) para o 
				operador via e-mail.
	******************************************************************/
	public function enviarSenha($nNumgOperador){

		if(Erros::isError()) {
			
			return false;
	
		} else {

			try	{
			
				$sSql =  " select nome_operador, desc_senha, nome_completo, desc_email ";
				$sSql .= " from se_operadores where numg_operador = " . $nNumgOperador;
				
				Oad::conectar();
				$oResult = Oad::consultar($sSql);
				Oad::desconectar();
				
				if (!empty($oResult)){
					
					$sMens = "Voc� est� recebendo este e-mail porque voc� � um operador do SIGO." . chr(13) . chr(13);
					$sMens .= "Abaixo seguem os dados para acesso ao sistema:" . chr(13) ;
					$sMens .= "Operador: " . $oResult->getValores(0,0) . chr(13) ;
					$sMens .= "Senha: " . Descriptografa($oResult->getValores(0,1)) . chr(13);
					$sMens .= "Atenciosamente," . chr(13) . chr(13) ;
					$sMens .= "Equipe Interagi Tecnologia" . chr(13) ;
					$sMens .= "interagi@interagi.com.br" . chr(13) ;
					$sMens .= "www.interagi.com.br";
								
					//ENVIA E-MAIL COM OS DADOS DE ACESSO AO SISTEMA
					//EnviaEmail $oResult[0][2],$oResult[0][3],"SBS - Envio de Senha",$sMens
				}					
			
			} catch(Exception $e) {
			
				Erros::addErro("Fonte: SIGO.Operadores.enviarSenha(); Descri��o: ".$e->getMessage()."�");
				return false;

			}
		}
	}
	/******************************************************************
	 Data     : 17/03/2008
	 Autor    : Thales A. Salvador
	 Descri��o: valida os dados de um operador antes de cadastr�-lo ou
				edit�-lo.
	******************************************************************/
	private function pValidaGravacao(){
	
		//VERIFICA SE ALGUM OPERADOR EST� TENTANDO ALTERAR OS DADOS DO 
		//ADMINISTRADOR GERAL OU DO OPERADOR INTERNET
		if ($this->numgOperador == 1 && $this->numgOperadorAlt != 1){
			Erros::addErro("Somente o Administrador Geral do Sistema tem permiss�o para alterar seus dados e do operador Internet.�");
		}
		
	    //NOME_operador
	    if (trim($this->nomeOperador) != ""){
			
			//SE FOR UMA INCLUS�O
			if ($this->numgOperador == 0){
					
				//VERIFICA SE J� EXISTE ALGUM REGISTRO CADASTRADO COM O NOME INFORMADO
				if (Oad::consultar("select numg_operador from se_operadores where  lower(nome_operador) = lower('" . trim($this->nomeOperador) . "')")->getCount() > 0){
					Erros::addErro("J� existe um Operador cadastrado com o nome " . $this->nomeOperador . ".�");
				}
					
			}else{
					
				$oResult = Oad::consultar("select numg_operador from se_operadores where lower(nome_operador) = lower('" . trim($this->nomeOperador) . "')");
					
				if ($oResult->getCount() > 0){
							
					//SE O N� IDENTIFICADOR FOR DIFERENTE, SIGNIFICA QUE J� EXISTE UM REGISTRO 
					//COM NOME INFORMADO PARA EDI��O
					if ($oResult->getValores(0,0) != $this->numgOperador){
						Erros::addErro("J� existe um Operador cadastrado com o nome " . $this->nomeOperador . ".�");
					}
				}
									
			}
		}

	    
	
	}


	/******************************************************************
	 Data     : 17/03/2008
	 Autor    : Thales A. Salvador
	 Descri��o: valida os dados de um operador antes de exclu�-lo.
	******************************************************************/
	private function pValidaExclusao($nNumgOperador){
	
		if ($nNumgOperador == 1){
			Erros::addErro("N�o � permitido excluir o Administrador Geral do sistema.�");
		}
		
		if (Oad::consultar("SELECT numg_site, numg_operadorcad, numg_operadoralt from ob_sites  where numg_operadorcad = " .$nNumgOperador . " or numg_operadoralt = " . $nNumgOperador)->getCount() > 0){
		    
			Erros::addErro("Este operador � respons�vel pelo cadastro ou bloqueio de algum formul�rio do sistema. N�o � poss�vel exclu�-lo.�");
		}

		if (Oad::consultar("select numg_fase from ob_fases where numg_operadorbloq = " . $nNumgOperador )->getCount() > 0){
		    Erros::addErro("Este operador � respons�vel pelo cadastro ou bloqueio de alguma fun��o do sistema. N�o � poss�vel exclu�-lo.�");
		}

		if (Oad::consultar("select numg_grupo from se_grupos where numg_operadorcad = " . $nNumgOperador . " or numg_operadorbloq = " . $nNumgOperador)->getCount() > 0){
		    Erros::addErro("Este operador � respons�vel pelo cadastro ou bloqueio de algum grupo de acesso. N�o � poss�vel exclu�-lo.�");
		}

		if (Oad::consultar("select numg_grupo from se_operadoresgrupos where numg_operador = " . $nNumgOperador)->getCount() > 0){
		    Erros::addErro("Este operador est� vinculado a algum grupo de acesso. N�o � poss�vel exclu�-lo.�");
		}
		if (Oad::consultar("select numg_diario from ob_diarios where numg_operadorcad =". $nNumgOperador)->getCount() > 0){
			Erros::addErro("Este operador � respons�vel pelo cadastro de algum di�rio. N�o � poss�vel exclu�-lo.�");
		}
		if (Oad::consultar("select numg_pendencia from ob_pendencias where numg_operadorcad =". $nNumgOperador . " or numg_operadoralt = " . $nNumgOperador)->getCount() > 0){
			Erros::addErro("Este operador � respons�vel pelo cadastro, baixa ou edi��o de alguma pend�ncia. N�o � poss�vel exclu�-lo.�");
		}
	}


	/******************************************************************
	 Data     : 17/03/2008
	 Autor    : Thales A. Salvador
	 Descri��o: valida os dados do operador antes de bloque�-lo.
	******************************************************************/
	private function pValidaBloqueio($nNumgOperador){
	
		if ($nNumgOperador == 1){
			Erros::addErro("N�o � permitido bloquear o Administrador Geral do Sistema.�");
		}

	}


	/******************************************************************
	 Data     : 17/03/2008
	 Autor    : Thales A. Salvador
	 Descri��o: altera a senha de um operador
	******************************************************************/
	public function editarSenha($vDados){
	
		if(Erros::isError()) {
			
			return false;
	
		} else {

			try {

				$sSql =  " UPDATE se_operadores SET";
				$sSql .= " desc_senha = " . FormataStr(Criptografa($vDados[1]));
				$sSql .= " WHERE numg_operador=" . $vDados[0];
	
				Oad::conectar();
				Oad::executar($sSql);
				Oad::desconectar();
				return true;
				
			} catch(Exception $e) {
	
				Erros::addErro("Fonte: SIGO.Operadores.editarSenha(); Descri��o: ".$e->getMessage()."�");
				return false;
	
			}
		}
	}

}

?>