<?php
/******************************************************
 Empresa: Net4U Solu��es Internet e Intranet

 Descricao: Classe respons�vel pelo controle de Municipios
 Autor    Desenvolvedor
 
 Releases (Data, respons�vel e descri��o [�ltimo release primeiro]):
	29-07-2005 (Silas Junior) [Cria��o da Classe]
*******************************************************/

class Municipios {

	//PROPRIEDADES DO OPERADOR
	protected $numgMunicipio;
	protected $nomeMunicipio;
	protected $siglUf;
	protected $flagCapital;
	
    private $sErros =  null;
	private $vAux, $sSql, $Oad;
	

	function __construct() {
	
		$this->numgMunicipio = null;
		$this->nomeMunicipio = "";
		$this->siglUf = "";
		$this->flagCapital = 'f';

	}

	function setNumgMunicipio($numgMunicipio) {
		if (is_numeric($numgMunicipio)) {
			$this->numgMunicipio = $numgMunicipio;
		} else {
			Erros::addErro("C�digo de Munic�pio Inv�lido.�");
		}
	}
	
	function getNumgMunicipio() {
		return $this->numgMunicipio;
	}

	function setNomeMunicipio($nomeMunicipio) {
		if ($nomeMunicipio == "") {
				Erros::addErro("Nome de Munic�pio Inv�lido.�");
		} else {
			$this->nomeMunicipio = $nomeMunicipio;
		}
	}
	
	function getNomeMunicipio() {
		return $this->nomeMunicipio;
	}

	function setSiglUf($siglUf) {

		if (($siglUf == "")||(strlen($siglUf) > 2)) {
				Erros::addErro("Unidade Federativa inv�lida.�");
		} else {
			$this->siglUf = $siglUf;
		}

	}
	
	function getSiglUf() {
		return $this->siglUf;
	}

	function setFlagCapital($valor){
		if ($valor == "")
			$this->flagCapital = 'f';
		else
			$this->flagCapital = $valor;
	}
	
	function getFlagCapital(){ return $this->flagCapital;}

	
	/******************************************************************
	 Data     : 05/08/2005
	 Autor    : Silas Junior
	 Descri��o: preenche os atributos da classe com os valores obtidos 
	 na busca.
	******************************************************************/
	function setarDadosMunicipio($nNumgMunicipio){
	
		if(Erros::isError()) {
			
			return false;
	
		} else {
		
			$sSql  = "SELECT";
			$sSql .= " numg_municipio, nome_municipio, sigl_uf, flag_capital";
			$sSql .= " FROM ob_municipios";
			$sSql .= " WHERE";
			$sSql .= " numg_municipio = " . $nNumgMunicipio;
			
			try {
	
				Oad::conectar();
				$result = Oad::consultar($sSql);
				
			} catch(Exception $e) {
	
				Erros::addErro("Fonte: SIGO.Municipios.setarDadosMunicipio()".$e->getMessage()."�");
				Oad::desconectar();
				return false;
	
			}
			Oad::desconectar();
		}
	
		$this->numgMunicipio = $nNumgMunicipio;
		$this->nomeMunicipio = $result->getValores(0,"nome_municipio");
		$this->siglUf = $result->getValores(0,"sigl_uf");
		$this->flagCapital = $result->getValores(0,"flag_capital");
		
		return true;
	}



	/******************************************************************
	 Data     : 05/08/2005
	 Autor    : Silas Junior
	 Descri��o: armazena os dados do municipio no banco de dados 
	******************************************************************/
    function cadastrar () {
	
		if(Erros::isError()) {
			
			return false;
	
		} else {
	
			$sSql  = " INSERT INTO ob_municipios";
			$sSql .= " (nome_municipio, sigl_uf, flag_capital)";
			$sSql .= " VALUES (";
			$sSql .= FormataStr($this->nomeMunicipio) . ",";
			$sSql .= FormataStr($this->siglUf) . ",";
			$sSql .= FormataBool($this->flagCapital) . ")";
			
			try {

				Oad::conectar();
				Oad::executar($sSql);
				$this->numgMunicipio = Oad::consultar("select max(numg_municipio) from ob_municipios")->getValores(0,0);
				Oad::desconectar();
				
			} catch(Exception $e) {
	
				Erros::addErro("Fonte: SIGO.Municipios.cadastrar()".$e->getMessage()."�");
				Oad::desconectar();				
				return false;	
			}
		}
	return true;
	}
	
	/******************************************************************
	 Data     : 05/08/2005
	 Autor    : Silas Junior
	 Descri��o: atualiza os dados de um dado municipio no banco de 
	 			dados.
	******************************************************************/
    function editar () {

		if (Erros::isError()) {
			
			return false;
	
		} else {

			$sSql  = " UPDATE ob_municipios SET";			
			$sSql .= " nome_municipio = " . FormataStr($this->nomeMunicipio) . ",";
			$sSql .= " sigl_uf = " . FormataStr($this->siglUf) . ",";
			$sSql .= " flag_capital = " . FormataBool($this->flagCapital);
			$sSql .= " WHERE numg_municipio = " . $this->numgMunicipio;			
			
			try {
	
				Oad::conectar();
				Oad::executar($sSql);
				Oad::desconectar();
				
			} catch(Exception $e) {
	
				Erros::addErro("Fonte: SIGO.Municipios.editar()".$e->getMessage()."�");
				Oad::desconectar();				
				return false;
	
			}
		}
	return true;	
    }

	/******************************************************************
	 Data     : 05/08/2005
	 Autor    : Silas Junior
	 Descri��o: exclui um municipio no banco de dados.
	******************************************************************/
    function excluir($numgMunicipio) {

		if(Erros::isError()) {
			
			return false;
	
		} else {
			Oad::conectar();
			
			$this->pValidaExclusao($numgMunicipio);
			if (Erros::isError()){
				Oad::desconectar();
				return false;
			}
			else{
			$sSql  = "DELETE FROM ob_municipios";
			$sSql .= " WHERE";
			$sSql .= " numg_municipio = ".$numgMunicipio;

			try {
	
				
				Oad::executar($sSql);
				Oad::desconectar();
				
			} catch(Exception $e) {
	
				Erros::addErro("Fonte: SIGO.Municipios.excluir()".$e->getMessage()."�");
				Oad::desconectar();				
				return false;
			}
		}
		}
		return true;
    }
	
	/******************************************************************
	 Data     : 05/08/2005
	 Autor    : Silas Junior
	 Descri��o: retorna um Resultset contendo os dados encontrados na 
	 			busca.
	******************************************************************/
    function consultarPorUf ($siglUf) {
 
		if(Erros::isError()) {
			
			return false;
	
		} else {

	 		$sSql  = "SELECT ";
			$sSql .= " numg_municipio, nome_municipio, sigl_uf, flag_capital";
			$sSql .= " FROM ob_municipios";
			$sSql .= " WHERE lower(sigl_uf) = lower(" . FormataStr($siglUf) . ")";
			$sSql .= " ORDER BY flag_capital desc, nome_municipio";		
			
			try {
				Oad::conectar();
				$result = Oad::consultar($sSql);
				Oad::desconectar();
				
			} catch(Exception $e) {
	
				Erros::addErro("Fonte: SIGO.Municipios.consultarPorUf()".$e->getMessage()."�");
				Oad::desconectar();				
				return false;
	
			}
			return $result;
		}
    }

	/******************************************************************
	 Data     : 05/08/2005
	 Autor    : Silas Junior
	 Descri��o: retorna um Resultset contendo os dados encontrados na 
	 busca.
	******************************************************************/
    function consultarPorNome ($nomeMunicipio) {

		if(Erros::isError()) {
			
			return false;
	
		} else {

			$sSql  = "SELECT";
			$sSql .= " numg_municipio, nome_municipio, sigl_uf";
			$sSql .= " FROM ob_municipios";
			$sSql .= " WHERE";
			$sSql .= " lower(nome_municipio) LIKE lower('%".addslashes($nomeMunicipio)."%')";
			$sSql .= " ORDER BY nome_municipio";		

			try {
	
				Oad::conectar();
				$result = Oad::consultar($sSql);
				Oad::desconectar();
				
			} catch(Exception $e) {
	
				Erros::addErro("Fonte: SIGO.Municipios.consultarPorNome()".$e->getMessage()."�");
				Oad::desconectar();				
				return false;
	
			}
			return $result;
		}
    }

	/******************************************************************
	 Data     : 05/09/2005
	 Autor    : Rafael C�cero
	 Descri��o: busca os munic�pios pelo nome e uf informados.
	******************************************************************/
    function consultarPorNomeUf ($sNomeMunicipio, $sSiglUf) {

		if(Erros::isError()) {
			
			return false;
	
		} else {

			$sSql  = "SELECT numg_municipio, nome_municipio, sigl_uf";
			$sSql .= " FROM ob_municipios";
			$sSql .= " WHERE lower(nome_municipio) LIKE lower('%".addslashes($sNomeMunicipio)."%') and lower(sigl_uf) = lower('" . $sSiglUf . "')";
			$sSql .= " ORDER BY nome_municipio";		

			try {
	
				Oad::conectar();
				$result = Oad::consultar($sSql);
				Oad::desconectar();
				
			} catch(Exception $e) {
	
				Erros::addErro("Fonte: SIGO.Municipios.consultarPorNomeUf()".$e->getMessage()."�");
				Oad::desconectar();				
				return false;
	
			}
			return $result;
		}
    }

	/******************************************************************
	 Data     : 06/09/2005
	 Autor    : Rafael C�cero
	 Descri��o: busca os munic�pios cadastrados
	******************************************************************/
    function consultarMunicipios () {

		if(Erros::isError()) {
			
			return false;
	
		} else {

			$sSql  = " SELECT numg_municipio, nome_municipio, sigl_uf, flag_capital";
			$sSql .= " FROM ob_municipios";
			$sSql .= " ORDER BY flag_capital desc, nome_municipio";		
			
			try {
	
				Oad::conectar();
				$result = Oad::consultar($sSql);
				Oad::desconectar();
				
			} catch(Exception $e) {
	
				Erros::addErro("Fonte: SIGO.Municipios.consultarMunicipios()".$e->getMessage()."�");
				Oad::desconectar();				
				return false;
	
			}
			return $result;
		}
    }


	/******************************************************************
	 Data     : 06/09/2005
	 Autor    : Rafael C�cero
	 Descri��o: busca os munic�pios que s�o capitais
	******************************************************************/
    public function consultarCapitais () {

		if(Erros::isError()) {
			
			return false;
	
		} else {

			$sSql  = " SELECT numg_municipio, nome_municipio, sigl_uf";
			$sSql .= " FROM ob_municipios";
			$sSql .= " WHERE flag_capital = 't'";
			$sSql .= " ORDER BY sigl_uf, nome_municipio";		
			
			try {
	
				Oad::conectar();
				$result = Oad::consultar($sSql);
				Oad::desconectar();
				
			} catch(Exception $e) {
	
				Erros::addErro("Fonte: SIGO.Municipios.consultarCapitais()".$e->getMessage()."�");
				Oad::desconectar();				
				return false;
	
			}
			return $result;
		}
    }


	/******************************************************************
	 Data     : 01/08/2005
	 Autor    : Silas Junior
	 Descri��o: valida os dados de um municipio antes de cadastr�-lo ou
				edit�-lo.
	******************************************************************/
	private function pValidaGravacao(){

	    //'NOME_municipio
	    if (trim($this->nomeMunicipio) != ""){
			
			//SE FOR UMA INCLUS�O
			if ($this->numgMunicipio == 0){
					
				//VERIFICA SE J� EXISTE ALGUM REGISTRO CADASTRADO COM O NOME INFORMADO
				if (Oad::consultar("select numg_municipio from ob_municipios where lower(nome_municipio) = lower('" . trim($this->nomeMunicipio) . "')")->getCount() > 0){
					Erros::addErro("J� existe um Municipio cadastrado com o nome " . $this->nomeMunicipio . ".�");
				}
					
			}else{
					
				$oResAux = Oad::consultar("select numg_municipio from ob_municipios where lower(nome_municipio) = lower('" . trim($this->nomeMunicipio) . "')");
					
				if ($oResAux->getCount() > 0){
							
					//SE O N� IDENTifICADOR FOR DifERENTE, SIGNifICA QUE J� EXISTE UM REGISTRO 
					//COM NOME INFORMADO PARA EDI��O
					if ($oResAux->getValores(0,0) != $this->numgMunicipio){
						Erros::addErro("J� existe um Grupo de Acesso cadastrado com o nome " . $this->nomeMunicipio . ".�");
					}
				}									
			}			
	    }

	}
	
	
	/******************************************************************
	 Data     : 01/08/2005
	 Autor    : Silas Junior
	 Descri��o: valida um grupo de acesso antes de exclu�-lo.
	******************************************************************/
	private function pValidaExclusao($nNumgMunicipio){

		if (Oad::consultar("select numg_municipio from ob_municipios where numg_municipio = " . $nNumgMunicipio)->getCount() > 0){
		    Erros::addErro("Este munic�pio est� vinculado � um site. N�o � poss�vel exclu�-lo.�");
		}
	    
	}	
	
}
?>