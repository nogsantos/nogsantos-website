<?php
/************************************************************************
 Empresa: Net4U Solu��es Internet e Intranet

 Descri��o: Classe Funcoes
	
 Releases (Data, respons�vel e descri��o [�ltimo release primeiro]):
	 01/08/2005 (Rafael C�cero) 
		 Inclu�do este cabe�alho descrevendo a funcionalidade da p�gina
************************************************************************/
class Funcoes
{
	//PROPRIEDADES DAS FUN��ES
	private $numgFuncao;
	private $numgFormulario;
	private $codgFuncao;
	private $nomeFuncao;
	private $descFuncao;
	private $nomeIcone;
	private $numrOrdem;
	private $flagNovoRegistro;
	private $flagPublica;
	private $dataCadastro;
	private $numgOperadorCad;
	private $nomeOperadorCad;
	private $dataBloqueio;
	private $nomeOperadorBloq;
	
	private $vAux, $sSql, $oOad, $sErr;
	 
	
	function __construct()
	{
	
	}
	
	function __destruct()
	{
	
	}
	
	function setNumgFuncao($valor){ 
		if (is_numeric($valor)){
			$this->numgFuncao = $valor;
		}else{
			Erros::addErro("N� identificador da fun��o inv�lido.�");
		}
	}
	
	function getNumgFuncao(){ return $this->numgFuncao;}
	
	function setNumgFormulario($valor){ 
		if (is_numeric($valor)){
			$this->numgFormulario = $valor;
		}else{
			Erros::addErro("Formul�rio da fun��o inv�lido.�");
		}
	}
	
	function getNumgFormulario(){ return $this->numgFormulario;}
	
	function setCodgFuncao($valor){ 
		if (trim($valor) != ""){
			$this->codgFuncao = $valor;
		}else{
			Erros::addErro("C�digo da fun��o inv�lido.�");
		}
	}
	
	function getCodgFuncao(){ return $this->codgFuncao;}
	
	function setNomeFuncao($valor){ 
		if (trim($valor) != ""){
			$this->nomeFuncao = $valor;
		}else{
			Erros::addErro("Nome da fun��o inv�lido.�");
		}
	}
	
	function getNomeFuncao(){ return $this->nomeFuncao;}
	
	function setDescFuncao($valor){ 
		if (trim($valor) != ""){
			$this->descFuncao = $valor;
		}else{
			Erros::addErro("Descri��o da fun��o inv�lida.�");
		}
	}
	
	function getDescFuncao(){ return $this->descFuncao;}
	
	function setNomeIcone($valor){ 
		if (trim($valor) != ""){
			$this->nomeIcone = $valor;
		}else{
			Erros::addErro("Nome do �cone da fun��o inv�lido.�");
		}
	}
	
	function getNomeIcone(){ return $this->nomeIcone;}
	
	function setNumrOrdem($valor){ 
		if (is_numeric($valor)){
			$this->numrOrdem = $valor;
		}else{
			Erros::addErro("Ordem de apresenta��o da fun��o inv�lida.�");
		}
	}
	
	function getNumrOrdem(){ return $this->numrOrdem;}
	
	function setFlagNovoRegistro($valor){ $this->flagNovoRegistro = $valor;}
	function getFlagNovoRegistro(){ return $this->flagNovoRegistro;}
	
	function setFlagPublica($valor){ $this->flagPublica = $valor;}
	function getFlagPublica(){ return $this->flagPublica;}
	
	function setDataCadastro($valor){ $this->dataCadastro = $valor;}
	function getDataCadastro(){ return $this->dataCadastro;}

	function setNumgOperadorCad($valor){ $this->numgOperadorCad = $valor;}
	function getNumgOperadorCad(){ return $this->numgOperadorCad;}
	
	function setNomeOperadorCad($valor){ $this->nomeOperadorCad = $valor;}
	function getNomeOperadorCad(){ return $this->nomeOperadorCad;}
	
	function setDataBloqueio($valor){ $this->dataBloqueio = $valor;}
	function getDataBloqueio(){ return $this->dataBloqueio;}
	
	function setNomeOperadorBloq($valor){ $this->nomeOperadorBloq = $valor;}
	function getNomeOperadorBloq(){ return $this->nomeOperadorBloq;}
	
	/******************************************************************
	 Data     : 01/08/2005
	 Autor    : Rafael C�cero
	 Descri��o: seta os dados de uma fun��o pelo seu n� identificador.
	******************************************************************/
	public function setarDadosFuncao($nNumgFuncao){		
	
		if(Erros::isError()) {
			
			return false;
	
		} else {
		
			try {
	
				$sSql =  " select numg_formulario, codg_funcao, nome_funcao, desc_funcao, nome_icone, numr_ordem, flag_novoRegistro, flag_publica, func.data_cadastro as data_cadastro, ope1.nome_operador as nome_operadorcad, func.data_bloqueio as data_bloqueio, ope2.nome_operador as nome_operadorbloq";
				$sSql .= " from se_funcoes func";
				$sSql .= " inner join se_operadores ope1 on ope1.numg_operador = func.numg_operadorCad";
				$sSql .= " left join se_operadores ope2 on ope2.numg_operador = func.numg_operadorBloq";
				$sSql .= " where numg_funcao = " . $nNumgFuncao;
				
				Oad::conectar();
				$oResult = Oad::consultar($sSql);
				Oad::desconectar();
				
				if ($oResult->getCount() > 0){
					$this->numgFuncao = $nNumgFuncao;
					$this->numgFormulario = $oResult->getValores(0,"numg_formulario");
					$this->codgFuncao = $oResult->getValores(0,"codg_funcao");
					$this->nomeFuncao = $oResult->getValores(0,"nome_funcao");
					$this->descFuncao = $oResult->getValores(0,"desc_funcao");
					$this->nomeIcone = $oResult->getValores(0,"nome_icone");
					$this->numrOrdem = $oResult->getValores(0,"numr_ordem");
					$this->flagNovoRegistro = $oResult->getValores(0,"flag_novoregistro");
					$this->flagPublica = $oResult->getValores(0,"flag_publica");
					$this->dataCadastro = FormataDataHora($oResult->getValores(0,"data_cadastro"));
					$this->nomeOperadorCad  = $oResult->getValores(0,"nome_operadorcad");
					$this->dataBloqueio = FormataDataHora($oResult->getValores(0,"data_bloqueio"));
					$this->nomeOperadorBloq = $oResult->getValores(0,"nome_operadorbloq");
				}
								
			} catch(Exception $e) {
	
				Erros::addErro("Fonte: SIGO.Funcoes.setarDadosFuncao(); Descri��o: ".$e->getMessage()."�");
				Oad::desconectar();
				return false;
	
			}
		}
		return true;	
			
	}


	/******************************************************************
	 Data     : 01/08/2005
	 Autor    : Rafael C�cero
	 Descri��o: cadastra os dados de uma fun��o.
	******************************************************************/
	public function cadastrar(){		

		if(Erros::isError()) {
			
			return false;
	
		} else {
	
			Oad::conectar();
				
			$this->pValidaGravacao();
	
			if (Erros::isError()){
				Oad::desconectar();
				return false;
			}else{
	
				try	{
				
					$sSql =  " INSERT INTO se_funcoes (numg_formulario, codg_funcao, nome_funcao, desc_funcao, nome_icone, numr_ordem, flag_novoregistro, flag_publica, data_cadastro, numg_operadorCad) values (";
					$sSql .= $this->getNumgFormulario() . ",";
					$sSql .= FormataStr($this->getCodgFuncao()) . ",";
					$sSql .= FormataStr($this->getNomeFuncao()) . ",";
					$sSql .= FormataStr($this->getDescFuncao()) . ",";
					$sSql .= FormataStr($this->getNomeIcone()) . ",";
					$sSql .= $this->getNumrOrdem() . ",";
					$sSql .= FormataBool($this->getFlagNovoRegistro()) . ",";
					$sSql .= FormataBool($this->getFlagPublica()) . ",";
					$sSql .= "CURRENT_TIMESTAMP,";
					$sSql .= $this->getNumgOperadorCad() . ")";
					
					//Response.Write $sSql
					//Response.End
					
					Oad::executar($sSql);
		
					$vAux = Oad::consultar("select max(numg_funcao) from se_funcoes");
						
					$this->setNumgFuncao($vAux->getValores(0,0));
	
				} catch(Exception $e) {			
				
					Erros::addErro("Fonte: SIGO.Funcoes.cadastrar(); Descri��o: ".$e->getMessage()."�");
					Oad::desconectar();
					return false;
				
				}
			}
			Oad::desconectar();
			return true;
		}	
	}
	

	/******************************************************************
	 Data     : 01/08/2005
	 Autor    : Rafael C�cero
	 Descri��o: edita os dados de uma fun��o.
	******************************************************************/
	public function editar(){		

		if(Erros::isError()) {
			
			return false;
	
		} else {
	
			Oad::conectar();
				
			$this->pValidaGravacao();
	
			if (Erros::isError()){
				Oad::desconectar();
				return false;
			}else{
	
				try	{
				
					$sSql =  " UPDATE se_funcoes SET";
					$sSql .= " codg_funcao=" . FormataStr($this->getCodgFuncao()) . ",";
					$sSql .= " nome_funcao=" . FormataStr($this->getNomeFuncao()) . ",";
					$sSql .= " desc_funcao=" . FormataStr($this->getDescFuncao()) . ",";
					$sSql .= " nome_icone=" . FormataStr($this->getNomeIcone()) . ",";
					$sSql .= " numr_ordem=" . $this->getNumrOrdem() . ",";
					$sSql .= " flag_novoregistro=" . FormataBool($this->getFlagNovoRegistro()) . ",";
					$sSql .= " flag_publica=" . FormataBool($this->getFlagPublica());
					$sSql .= " WHERE numg_funcao = " . $this->getNumgFuncao();
						
					Oad::executar($sSql);
	
				} catch(Exception $e) {			
				
					Erros::addErro("Fonte: SIGO.Funcoes.editar(); Descri��o: ".$e->getMessage()."�");
					Oad::desconectar();
					return false;
				
				}
			}
			Oad::desconectar();
			return true;
		}		
		
	}
	

	/******************************************************************
	 Data     : 01/08/2005
	 Autor    : Rafael C�cero
	 Descri��o: exclui os dados de uma fun��o.
	******************************************************************/
	public function excluir($nNumgFuncao){		

		if(Erros::isError()) {
			
			return false;
	
		} else {
	
			Oad::conectar();
				
			$this->pValidaExclusao($nNumgFuncao);
	
			if (Erros::isError()){
				Oad::desconectar();
				return false;
			}else{
	
				try	{
				
					$sSql = "DELETE FROM se_Funcoes WHERE numg_funcao = " . $nNumgFuncao;
					
					Oad::executar($sSql);

				} catch(Exception $e) {			

					Erros::addErro("Fonte: SIGO.Funcoes.excluir(); Descri��o: ".$e->getMessage()."�");
					Oad::desconectar();
					return false;

				}
			}
			Oad::desconectar();
			return true;
		}		
	}
	

	/******************************************************************
	 Data     : 01/08/2005
	 Autor    : Rafael C�cero
	 Descri��o: bloqueia uma fun��o, setando a data de bloqueio e o 
				respons�vel
	******************************************************************/
	public function bloquear($vDados){		

		if(Erros::isError()) {
			
			return false;
	
		} else {
	
			try	{				
				
				$sSql =  " UPDATE se_funcoes SET";
				$sSql .= " data_bloqueio = CURRENT_TIMESTAMP,";
				$sSql .= " numg_operadorBloq =" . $vDados[1];
				$sSql .= " WHERE numg_funcao=" . $vDados[0];
					
				Oad::conectar();
				Oad::executar($sSql);
				Oad::desconectar();
				return true;
			
			} catch(Exception $e) {			
			
				Erros::addErro("Fonte: SIGO.Funcoes.bloquear(); Descri��o: ".$e->getMessage()."�");
				Oad::desconectar();
				return false;
			
			}
		}		
	}
	

	/******************************************************************
	 Data     : 01/08/2005
	 Autor    : Rafael C�cero
	 Descri��o: desbloqueia uma fun��o.
	******************************************************************/
	public function desbloquear($nNumgFuncao){		

		if(Erros::isError()) {
			
			return false;
	
		} else {
			
			try	{
			
				$sSql =  " UPDATE se_funcoes SET";
				$sSql .= " data_bloqueio=null,";
				$sSql .= " numg_operadorBloq=null";
				$sSql .= " WHERE numg_funcao=" . $nNumgFuncao;
					
				Oad::conectar();
				Oad::executar($sSql);
				Oad::desconectar();
				return true;
			
			} catch(Exception $e) {			
			
				Erros::addErro("Fonte: SIGO.Funcoes.desbloquear(); Descri��o: ".$e->getMessage()."�");
				Oad::desconectar();
				return false;
			
			}
		}		
	}
	

	/******************************************************************
	 Data     : 01/08/2005
	 Autor    : Rafael C�cero
	 Descri��o: busca as fun��es vinculadas a um formul�rio.
	******************************************************************/
	public function consultarFuncoesForm($nNumgFormulario){		

		if(Erros::isError()) {
			
			return false;
	
		} else {
	
			try	{
			
				Oad::conectar();
				$oResult = Oad::consultar("select numg_funcao, numr_ordem, codg_funcao, nome_funcao, flag_novoregistro, flag_publica, data_bloqueio from se_funcoes where numg_formulario = " . $nNumgFormulario . " order by numr_ordem");
				Oad::desconectar();
			
			} catch(Exception $e) {			
			
				Erros::addErro("Fonte: SIGO.Funcoes.consultarFuncoesForm() � Descri��o: ".$e->getMessage()."�");
				Oad::desconectar();
				return false;
			
			}
			return $oResult;
		}		
	}


	/******************************************************************
	 Data     : 08/04/2005
	 Autor    : Rafael C�cero
	 Descri��o: busca as fun��es de um formul�rio dispon�veis para um
			    operador (fun��es n�o bloqueadas ou p�blicas).
	******************************************************************/
	public function consultarFuncoesFormOperador($vDados){		

		if(Erros::isError()) {
			
			return false;
	
		} else {
	
			try	{
			
				$sSql =  " select func.codg_funcao, func.nome_funcao, func.nome_icone, func.flag_novoRegistro, func.desc_funcao ";
				$sSql .= " from se_funcoes func";
				$sSql .= " inner join se_formularios form on form.numg_formulario = func.numg_formulario";
				$sSql .= " where ";
				$sSql .= " func.data_bloqueio is null and lower(form.codg_formulario) = lower('" . $vDados[0] . "')";
				$sSql .= " and ((func.numg_funcao in (select tgf.numg_funcao from se_gruposFuncoes tgf where tgf.numg_grupo in (select tog.numg_grupo from se_operadoresGrupos tog where tog.numg_operador= " . $vDados[1] . "))) or flag_publica = 't')";
				$sSql .= " order by func.numr_ordem";
		
				Oad::conectar();
				$oResult = Oad::consultar($sSql);
				Oad::desconectar();
			
			} catch(Exception $e) {			
			
				Erros::addErro("Fonte: SIGO.Funcoes.consultarFuncoesFormOperador() � Descri��o: ".$e->getMessage()."�");
				Oad::desconectar();
				return false;
			
			}
			return $oResult;
		}
	}


	/******************************************************************
	 Data     : 08/04/2005
	 Autor    : Rafael C�cero
	 Descri��o: busca as fun��es de um formul�rio para apresenta��o ao
				Administrador do Sistema (todas as fun��es).
	******************************************************************/
	public function consultarFuncoesFormAdministrador($sCodgFormulario){		
	
		if(Erros::isError()) {
			
			return false;
	
		} else {

			try {
	
				$sSql =  " select func.codg_funcao, func.nome_funcao, func.nome_icone, func.flag_novoRegistro, func.desc_funcao ";
				$sSql .= " from se_funcoes func";
				$sSql .= " inner join se_formularios form on form.numg_formulario = func.numg_formulario";
				$sSql .= " where lower(form.codg_formulario) = lower('" . $sCodgFormulario . "')";
				$sSql .= " order by func.numr_ordem";
				
				Oad::conectar();
				$oResult = Oad::consultar($sSql);
				Oad::desconectar();
				
			} catch(Exception $e) {
			
				Erros::addErro("Fonte: SIGO.Funcoes.consultarFuncoesFormAdministrador() � Descri��o: ".$e->getMessage()."�");
				Oad::desconectar();
				return false;
			
			}
			return $oResult;
		}
	}


	/******************************************************************
	 Data     : 01/08/2005
	 Autor    : Rafael C�cero
	 Descri��o: valida os dados da fun��o antes de cadastr�-la ou 
				edit�-la.
	******************************************************************/
	private function pValidaGravacao(){
	
	    //'CODG_funcao
	    if (trim($this->codgFuncao) != ""){
			
			//SE FOR UMA INCLUS�O
			if ($this->numgFuncao == 0){
					
				//VERIFICA SE J� EXISTE ALGUM REGISTRO CADASTRADO COM O NOME INFORMADO
				if (Oad::consultar("select numg_funcao from se_funcoes where lower(codg_funcao) = lower('" . trim($this->codgFuncao) . "')")->getCount() > 0){
					Erros::addErro("J� existe uma Fun��o cadastrado com o c�digo " . $this->codgFuncao . ".�");
				}
					
			}else{
					
				$oResAux = Oad::consultar("select numg_funcao from se_funcoes where lower(codg_funcao) = lower('" . trim($this->codgFuncao) . "')");
					
				if ($oResAux->getCount() > 0){
							
					//SE O N� IDENTifICADOR FOR DifERENTE, SIGNifICA QUE J� EXISTE UM REGISTRO 
					//COM NOME INFORMADO PARA EDI��O
					if ($oResAux->getValores(0,0) != $this->numgFuncao){
						Erros::addErro("J� existe uma Fun��o cadastrada com o c�digo " . $this->codgFuncao . ".�");
					}
				}									
			}			
	    }
		    
	}


	/******************************************************************
	 Data     : 01/08/2005
	 Autor    : Rafael C�cero
	 Descri��o: valida os dados da fun��o antes de exclu�-la.
	******************************************************************/
	private function pValidaExclusao($nNumgFuncao){
	
		if (Oad::consultar("select numg_grupo from se_gruposfuncoes where numg_funcao = " . $nNumgFuncao)->getCount() > 0){
		    Erros::addErro("Esta fun��o est� vinculada a algum grupo de acesso. N�o � poss�vel exclu�-la.�");
		}
	    
	}

}
?>