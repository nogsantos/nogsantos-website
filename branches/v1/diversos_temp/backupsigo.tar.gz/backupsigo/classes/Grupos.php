<?php
/************************************************************************
 Empresa: Net4U Solu��es Internet e Intranet

 Descri��o: Classe Grupos (Grupos de Acesso)
	
 Releases (Data, respons�vel e descri��o [�ltimo release primeiro]):
	 01/08/2005 (Thales A. Salvador) 
		 Inclu�do este cabe�alho descrevendo a funcionalidade da p�gina
*************************************************************************/
class Grupos
{
	//PROPRIEDADES DOS GRUPOS
	private $numgGrupo;
	private $nomeGrupo;
	private $descGrupo;
	private $dataCadastro;
	private $nomeOperadorCad;
	private $dataBloqueio;
	private $nomeOperadorBloq;

	private $oResult, $sSql, $sErr;
	
	function __construct()
	{
	
	}
	
	function __destruct()
	{
	
	}

	function setNumgGrupo($valor){ 
		if (is_numeric($valor)){
			$this->numgGrupo = $valor;
		}else{
			Erros::addErro("N� identificador do grupo inv�lido.�");
		}
	}
	
	function getNumgGrupo(){ return $this->numgGrupo;}

	function setNumgMunOrigem($valor){ 
		if (is_numeric($valor)){
			$this->numgMunOrigem = $valor;
		}else{
			Erros::addErro("Munic�pio de origem do grupo inv�lido.�");
		}
	}
	
	function getNumgMunOrigem(){ return $this->numgMunOrigem;}
	
	function setNomeGrupo($valor){ 
		if (trim($valor) != ""){
			$this->nomeGrupo = $valor;
		}else{
			Erros::addErro("Nome do grupo inv�lido.�");
		}
	}
	
	function getNomeGrupo(){ return $this->nomeGrupo;}
	
	function setDescGrupo($valor){ 
		if (trim($valor) != ""){
			$this->descGrupo = $valor;
		}else{
			Erros::addErro("Descri��o do grupo inv�lida.�");
		}
	}
	
	function getDescGrupo(){ return $this->descGrupo;}
	
	function setDataCadastro($valor){ $this->dataCadastro = $valor;}
	function getDataCadastro(){ return $this->dataCadastro;}
	
	function setNumgOperadorCad($valor){ $this->numgOperadorCad = $valor;}
	function getNumgOperadorCad(){ return $this->numgOperadorCad;}

	function setNomeOperadorCad($valor){ $this->nomeOperadorCad = $valor;}
	function getNomeOperadorCad(){ return $this->nomeOperadorCad;}
	
	function setDataBloqueio($valor){ $this->dataBloqueio = $valor;}
	function getDataBloqueio(){ return $this->dataBloqueio;}
	
	function setNumgOperadorBloq($valor){ $this->numgOperadorBloq = $valor;}
	function getNumgOperadorBloq(){ return $this->numgOperadorBloq;}

	function setNomeOperadorBloq($valor){ $this->nomeOperadorBloq = $valor;}
	function getNomeOperadorBloq(){ return $this->nomeOperadorBloq;}


	/******************************************************************
	 Data     : 18/03/2008
	 Autor    : Thales A. Salvador
	 Descri��o: seta os dados do grupo pelo seu n� identificador.
	******************************************************************/
	public function setarDadosGrupo($nNumgGrupo){

		if(Erros::isError()) {
			
			return false;
	
		} else {
		
			try	{
			
				$sSql =  "select gru.nome_grupo, gru.desc_grupo, gru.data_cadastro, ope1.nome_operador, gru.data_bloqueio, ope2.nome_operador";
				$sSql .= " from se_grupos gru";
				$sSql .= " inner join se_operadores ope1 on ope1.numg_operador = gru.numg_operadorCad";
				$sSql .= " left join se_operadores ope2 on ope2.numg_operador = gru.numg_operadorBloq";
				$sSql .= " where numg_grupo = " . $nNumgGrupo;
				
				Oad::conectar();
				$oResult = Oad::consultar($sSql);
				Oad::desconectar();
				
				if ($oResult->getCount() > 0){
					$this->numgGrupo = $nNumgGrupo;
					$this->nomeGrupo = $oResult->getValores(0,0);
					$this->descGrupo = $oResult->getValores(0,1);
					$this->dataCadastro = FormataDataHora($oResult->getValores(0,2));
					$this->nomeOperadorCad  = $oResult->getValores(0,3);
					$this->dataBloqueio = FormataDataHora($oResult->getValores(0,4));
					$this->nomeOperadorBloq = $oResult->getValores(0,5);
				}
				
			} catch(Exception $e) {			
			
				Erros::addErro("Fonte: SIGO.Grupos.setarDadosGrupo(); Descri��o: ".$e->getMessage()."�");
				Oad::desconectar();
				return false;
			
			}
		}
	}


	/******************************************************************
	 Data     : 18/03/2008
	 Autor    : Thales A. Salvador
	 Descri��o: cadastra os dados de um grupo de acesso.
	******************************************************************/
	public function cadastrar(){

		if(Erros::isError()) {
			
			return false;
	
		} else {
	
			Oad::conectar();
			
			$this->pValidaGravacao();
			
			if (Erros::isError()){
				Oad::desconectar();
				return false;
			}
			else{
	
				try	{
				
					$sSql =  " INSERT INTO se_grupos ( nome_grupo, desc_grupo, data_cadastro, numg_operadorCad) values (";
					$sSql .= FormataStr($this->getNomeGrupo()) . ",";
					$sSql .= FormataStr($this->getDescGrupo()) . ",";
					$sSql .= "CURRENT_TIMESTAMP,";
					$sSql .= $this->getNumgOperadorCad() . ")";
					
					//echo $sSql;
					//exit;
					
					Oad::executar($sSql);
		
					$oResult = Oad::consultar("select max(numg_grupo) from se_grupos");
					
					$this->setNumgGrupo($oResult->getValores(0,0));
				
				} catch(Exception $e) {			
				
					Erros::addErro("Fonte: SIGO.Grupos.cadastrar(); Descri��o: ".$e->getMessage()."�");
					Oad::desconectar();
					return false;
				
				}
			}
			Oad::desconectar();
			return true;
		}		
	}
	

	/******************************************************************
	 Data     : 18/03/2008
	 Autor    : Thales A. Salvador
	 Descri��o: edita os dados de um grupo de acesso.
	******************************************************************/
	public function editar(){

		if(Erros::isError()) {
			
			return false;
	
		} else {
		
			Oad::conectar();
				
			$this->pValidaGravacao();
	
			if (Erros::isError()){
				Oad::desconectar();
				return false;
			}
			else{
			
				try	{
				
					$sSql =  " UPDATE se_grupos SET";
					$sSql .= " nome_grupo=" . FormataStr($this->getNomeGrupo()) . ",";
					$sSql .= " desc_grupo=" . FormataStr($this->getDescGrupo());
					$sSql .= " WHERE numg_grupo = " . $this->getNumgGrupo();
						
					Oad::executar($sSql);
				
				} catch(Exception $e) {			
				
					Erros::addErro("Fonte: SIGO.Grupos.editar(); Descri��o: ".$e->getMessage()."�");
					Oad::desconectar();
					return false;
				
				}
			}
			Oad::desconectar();
			return true;
		}		
	}
	

	/******************************************************************
	 Data     : 18/03/2008
	 Autor    : Thales A. Salvador
	 Descri��o: exclui os dados de um grupo de acesso.
	******************************************************************/
	public function excluir($nNumgGrupo){

		if(Erros::isError()) {
			
			return false;
	
		} else {
	
			Oad::conectar();
				
			$this->pValidaExclusao($nNumgGrupo);
	
			if (Erros::isError()){
				Oad::desconectar();
				return false;
			}
			else{
	
				try	{
				
					$sSql = "DELETE FROM se_grupos WHERE numg_grupo = " . $nNumgGrupo;
					
					Oad::executar($sSql);
				
				} catch(Exception $e) {			
				
					Erros::addErro("Fonte: SIGO.Grupos.excluir(); Descri��o: ".$e->getMessage()."�");
					Oad::desconectar();
					return false;
				
				}
			}
			Oad::desconectar();
			return true;
		}
	}
	

	/******************************************************************
	 Data     : 18/03/2008
	 Autor    : Thales A. Salvador
	 Descri��o: bloqueia um grupo de acesso, setando a data de bloqueio
				e o respons�vel.
	******************************************************************/
	public function bloquear($vDados){

		if(Erros::isError()) {
			
			return false;
	
		} else {
				
			try	{
				$sSql =  " UPDATE se_grupos SET";
				$sSql .= " data_bloqueio = CURRENT_TIMESTAMP,";
				$sSql .= " numg_operadorBloq = " . $vDados[1];
				$sSql .= " WHERE numg_grupo=" . $vDados[0];
					
				Oad::conectar();
				Oad::executar($sSql);
				Oad::desconectar();
				return true;
			
			} catch(Exception $e) {			
			
				Erros::addErro("Fonte: SIGO.Grupos.bloquear(); Descri��o: ".$e->getMessage()."�");
				Oad::desconectar();
				return false;
			
			}
		}		
	}
	

	/******************************************************************
	 Data     : 18/03/2008
	 Autor    : Thales A. Salvador
	 Descri��o: desbloqueia um grupo de acesso.
	******************************************************************/
	public function desbloquear($nNumgGrupo){

		if(Erros::isError()) {
			
			return false;
	
		} else {
			
			try	{
			
				$sSql =  " UPDATE se_grupos SET";
				$sSql .= " data_bloqueio = null,";
				$sSql .= " numg_operadorBloq = null";
				$sSql .= " WHERE numg_grupo=" . $nNumgGrupo;
					
				Oad::conectar();
				Oad::executar($sSql);
				Oad::desconectar();
				return true;
				
			} catch(Exception $e) {			
			
				Erros::addErro("Fonte: SIGO.Grupos.desbloquear(); Descri��o: ".$e->getMessage()."�");
				Oad::desconectar();
				return false;
			
			}
		}
	}
	

	/******************************************************************
	 Data     : 18/03/2008
	 Autor    : Thales A. Salvador
	 Descri��o: cadastra um operador para um grupo de acesso.
	******************************************************************/
	public function cadastrarOperadorGrupo($vDados){

		if(Erros::isError()) {
			
			return false;
	
		} else {
		
			try	{
			
				Oad::conectar();
				Oad::executar("INSERT INTO se_operadoresgrupos (numg_operador, numg_grupo) values (" . $vDados[0] . "," . $vDados[1] . ")");
				Oad::desconectar();
				return true;
			
			} catch(Exception $e) {			
			
				Erros::addErro("Fonte: SIGO.Grupos.cadastrarOperadorGrupo(); Descri��o: ".$e->getMessage()."�");
				Oad::desconectar();
				return false;
			
			}
		}		
	}
	

	/******************************************************************
	 Data     : 18/03/2008
	 Autor    : Thales A. Salvador
	 Descri��o: exclui um operador de um grupo de acesso.
	******************************************************************/
	public function excluirOperadorGrupo($vDados){

		if(Erros::isError()) {
			
			return false;
	
		} else {
	
			try	{
			
				Oad::conectar();
				Oad::executar("DELETE FROM se_operadoresgrupos WHERE numg_operador = " . $vDados[0] . " and numg_grupo = " . $vDados[1]);
				Oad::desconectar();
				return true;
			
			} catch(Exception $e) {			
			
				Erros::addErro("Fonte: SIGO.Grupos.excluirOperadorGrupo(); Descri��o: ".$e->getMessage()."�");
				Oad::desconectar();
				return false;
			
			}
		}
	}
	

	/******************************************************************
	 Data     : 18/03/2008
	 Autor    : Thales A. Salvador
	 Descri��o: cadastra um grupo de acesso para um fun��o do sistema.
	******************************************************************/
	public function cadastrarGrupoFuncao($vDados){

		if(Erros::isError()) {
			
			return false;
	
		} else {
			
			try	{
			
				Oad::conectar();
				Oad::executar("INSERT INTO se_gruposfuncoes (numg_grupo, numg_funcao) values (" . $vDados[0] . "," . $vDados[1] . ")");
				Oad::desconectar();
				return true;
			
			} catch(Exception $e) {			
			
				Erros::addErro("Fonte: SIGO.Grupos.cadastrarGrupoFuncao(); Descri��o: ".$e->getMessage()."�");
				Oad::desconectar();
				return false;
			
			}
		}
	}
	

	/******************************************************************
	 Data     : 18/03/2008
	 Autor    : Thales A. Salvador
	 Descri��o: exclui um grupo de acesso de um fun��o do sistema.
	******************************************************************/
	public function excluirGrupoFuncao($vDados){

		if(Erros::isError()) {
			
			return false;
	
		} else {
	
			try	{
			
				Oad::conectar();
				Oad::executar("DELETE FROM se_gruposfuncoes WHERE numg_grupo = " . $vDados[0] . " and numg_funcao = " . $vDados[1]);
				Oad::desconectar();
				return true;
			
			} catch(Exception $e) {
						
				Erros::addErro("Fonte: SIGO.Grupos.excluirGrupoFuncao(); Descri��o: ".$e->getMessage()."�");
				Oad::desconectar();
				return false;
			
			}
		}
	}


	/******************************************************************
	 Data     : 18/03/2008
	 Autor    : Thales A. Salvador
	 Descri��o: busca os grupos de acesso aos quais o operador pertence
	******************************************************************/
	public function consultarGruposOperador($nNumgOperador){

		if(Erros::isError()) {
			
			return false;
	
		} else {

			try	{
			
				Oad::conectar();
				$oResult = Oad::consultar("select numg_grupo, nome_grupo from se_grupos where numg_grupo in (select numg_grupo from se_operadoresGrupos where numg_operador = " . $nNumgOperador . ")");
				Oad::desconectar();
			
			} catch(Exception $e) {			
			
				Erros::addErro("Fonte: SIGO.Grupos.consultarGruposOperador(); Descri��o: ".$e->getMessage()."�");
				Oad::desconectar();
				return false;
			
			}
			return $oResult;
		}		
	}


	/******************************************************************
	 Data     : 18/03/2008
	 Autor    : Thales A. Salvador
	 Descri��o: busca os grupos de acesso de um munic�pio aos quais 
	 			o operador n�o pertence
	******************************************************************/
	public function consultarGruposNaoOperador($nNumgOperador){

		if(Erros::isError()) {
			
			return false;
	
		} else {

			try	{
			
				Oad::conectar();
				$oResult = Oad::consultar("select numg_grupo, nome_grupo from se_grupos where numg_grupo not in (select numg_grupo from se_operadoresGrupos where numg_operador = " . $nNumgOperador . ")");
				Oad::desconectar();
			
			} catch(Exception $e) {			
			
				Erros::addErro("Fonte: SIGO.Grupos.consultarGruposNaoOperador(); Descri��o: ".$e->getMessage()."�");
				Oad::desconectar();
				return false;
			
			}
			return $oResult;
		}						
	}


	/******************************************************************
	 Data     : 18/03/2008
	 Autor    : Thales A. Salvador
	 Descri��o: busca os grupos de acesso cadastrados para um 
	 			munic�pio.
	******************************************************************/
	public function consultarGrupos(){

		if(Erros::isError()) {
			
			return false;
	
		} else {
	
			try	{
			
				Oad::conectar();
				$oResult = Oad::consultar("select numg_grupo, nome_grupo, desc_grupo, data_bloqueio from se_grupos order by nome_grupo");
				Oad::desconectar();
			
			} catch(Exception $e) {			
			
				Erros::addErro("Fonte: SIGO.Grupos.consultarGrupos(); Descri��o: ".$e->getMessage()."�");
				Oad::desconectar();
				return false;

			}
			return $oResult;
		}				
	}


	/******************************************************************
	 Data     : 18/03/2008
	 Autor    : Thales A. Salvador
	 Descri��o: busca os grupos que tem acesso a uma fun��o.
	******************************************************************/
	public function consultarGruposFuncao($nNumgFuncao){

		if(Erros::isError()) {
			
			return false;
	
		} else {
	
			try	{
			
				Oad::conectar();
				$oResult = Oad::consultar("select numg_grupo, nome_grupo from se_grupos where numg_grupo in (select numg_grupo from se_gruposFuncoes where numg_funcao = " . $nNumgFuncao . ")");
				Oad::desconectar();
			
			} catch(Exception $e) {			
			
				Erros::addErro("Fonte: SIGO.Grupos.consultarGruposFuncao(); Descri��o: ".$e->getMessage()."�");
				Oad::desconectar();
				return false;

			}
			return $oResult;
		}				
	}


	/******************************************************************
	 Data     : 18/03/2008
	 Autor    : Thales A. Salvador
	 Descri��o: busca os grupos de acesso que n�o tem acesso a fun��o.
	******************************************************************/
	public function consultarGruposNaoFuncao($nNumgFuncao){

		if(Erros::isError()) {
			
			return false;
	
		} else {
			
			try	{
			
				Oad::conectar();
				$oResult = Oad::consultar("select numg_grupo, nome_grupo from se_grupos where numg_grupo not in (select numg_grupo from se_gruposFuncoes where numg_funcao = " . $nNumgFuncao . ")");
				Oad::desconectar();
				
			} catch(Exception $e) {			
			
				Erros::addErro("Fonte: SIGO.Grupos.consultarGruposNaoFuncao(); Descri��o: ".$e->getMessage()."�");
				Oad::desconectar();
				return false;

			}
			return $oResult;
		}
	}

	
	/******************************************************************
	 Data     : 18/03/2008
	 Autor    : Thales A. Salvador
	 Descri��o: valida os dados de um grupo antes de cadastr�-lo ou
				edit�-lo.
	******************************************************************/
	private function pValidaGravacao(){

	    //'NOME_grupo
	    if (trim($this->numgMunOrigem) != "" && trim($this->nomeGrupo) != ""){
			
			//SE FOR UMA INCLUS�O
			if ($this->numgGrupo == 0){
					
				//VERIFICA SE J� EXISTE ALGUM REGISTRO CADASTRADO COM O NOME INFORMADO
				if (Oad::consultar("select numg_grupo from se_grupos where numg_munOrigem = " . $this->numgMunOrigem . " and nome_grupo = '" . trim($this->nomeGrupo) . "'")->getCount() > 0){
					Erros::addErro("J� existe um Grupo de Acesso cadastrado com o nome " . $this->nomeGrupo . " para este munic�pio.�");
				}
					
			}else{
					
				$oResAux = Oad::consultar("select numg_grupo from se_grupos where numg_munOrigem = " . $this->numgMunOrigem . " and nome_grupo = '" . trim($this->nomeGrupo) . "'");
					
				if ($oResAux->getCount() > 0){
							
					//SE O N� IDENTifICADOR FOR DifERENTE, SIGNifICA QUE J� EXISTE UM REGISTRO 
					//COM NOME INFORMADO PARA EDI��O
					if ($oResAux->getValores(0,0) != $this->numgGrupo){
						Erros::addErro("J� existe um Grupo de Acesso cadastrado com o nome " . $this->nomeGrupo . " para este munic�pio.�");
					}
				}									
			}			
	    }

	}


	/******************************************************************
	 Data     : 18/03/2008
	 Autor    : Thales A. Salvador
	 Descri��o: valida um grupo de acesso antes de exclu�-lo.
	******************************************************************/
	private function pValidaExclusao($nNumgGrupo){

		if (Oad::consultar("select numg_funcao from se_gruposfuncoes where numg_grupo = " . $nNumgGrupo)->getCount() > 0){
		    Erros::addErro("Este grupo est� vinculado a algum fun��o. N�o � poss�vel exclu�-lo.�");
		}
	    
	}

}
?>