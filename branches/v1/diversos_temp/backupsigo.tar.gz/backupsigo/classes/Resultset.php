<?php
//error_reporting(E_ALL);
/**************************************************************************
 Empresa: Net4U Solu��es Internet e Intranet

 Descri��o: objeto com as rotinas de armazenamento de dados resultantes de 
 consultas ao banco de dados PostgreSQL.
	
 Releases (Data, respons�vel e descri��o [�ltimo release primeiro]):
	04/08/2005 (Silas Junior)
		Cria��o dessa classe
						
**************************************************************************/
class Resultset {

	private $registros;
	private $linhas;
	private $colunas;
	private $resultados;
	
	
	function setValores ($linhas,$colunas,$vRegistro){
		$this->resultados = $linhas;
		$this->linhas = $linhas;
		$this->colunas = $colunas;
		$this->registros = $vRegistro;
	}


	function getValores($linha,$coluna) {
		
		return $this->registros[$linha][$coluna];
	
	}
	
	function getRegistros(){
		return $this->registros;
	}
	
	function getCount() {
		return $this->resultados;
	}

}
?>