<?php
/******************************************************
* Empresa: Interagi Tecnologia
*
* descricao: Classe responsavel por manter as imagens
* Autor    Desenvolvedor
*	03/10/2005	Jean Moreira
*MOdifica��es		
* 	31/03/2008   Danilo Fernandes
* Releases (Data, respons�vel e descri��o [�ltimo release primeiro]):
*******************************************************/
	define("CAMINHO_IMAGEM","imagens/upload/" . $_POST["numgSite"]."/");
	define("CAMINHO_THUMBNAIL","imagens/thumbnail/". $_POST["numgSite"]."/");
class Imagens {
		

	//obtem os dados da imagem
	private $numgFoto;
	protected $numgSite;
	private $nomeArquivo;
	private $numgAtrativo;	
	private $numrTamanho;
	private $nomeTmpImagem;
	private $numrSize;
	private $numrLargura;
	private $numrAltura;
	private $descFoto;
	private $caminhoImagem = CAMINHO_IMAGEM;
	private $caminhoThumbnail = CAMINHO_THUMBNAIL;
	private $tipoArquivo;

	
	function setNumgFoto($valor) {
       if ($valor != "") {
          $this->numgFoto = $valor;
       } else {
          Erros::addErro("Campo Id da Foto Inv�lido.�");
       }
    }
	function getNumgFoto() { return $this->numgFoto;}
	
	function setNumgSite($valor) {
       if ($valor != "") {
          $this->numgSite = $valor;
       } else {
          Erros::addErro("Campo Site Inv�lido.�");
       }
    }
	function getNumgSite() { return $this->numgSite;}
	
	function setNomeArquivo($valor) {$this->nomeArquivo = $valor;}
	function getNomeArquivo() { return $this->nomeArquivo;}
	
	/*function setNumgAtrativo($valor) {
	   if ($valor != "") {
		  $this->numgAtrativo = $valor;
	   } else {
		  Erros::addErro("N� identificador do Atrativo inv�lido.�");
	   }
	}
	
	function getNumgAtrativo() { return $this->numgAtrativo;}*/
	
	function setNumrTamanho($valor) { $this->numrTamanho = $valor;}	
	function getNumrTamanho() { return $this->numrTamanho;}
	
	function setNomeTmpImagem($valor) { $this->nomeTmpImagem = $valor;}	
	function getNomeTmpImagem() { return $this->nomeTmpImagem;}
	
	function setNumrSize($valor) { $this->numrSize = $valor;}	
	function getNumrSize($indice) { return $this->numrSize[$indice];}
	
	function setNumrLargura($valor) { $this->numrLargura = $valor;}	
	function getNumrLargura() { return $this->numrLargura;}
	
	function setNumrAltura($valor) { $this->numrAltura = $valor;}	
	function getNumrAltura() { return $this->numrAltura;}
	
	function setDescFoto($valor) {
       if ($valor != "") {
          $this->descFoto = $valor;
       } else {
          Erros::addErro("Campo Descri��o Inv�lido.�");
       }
    }

    function getDescFoto() { return $this->descFoto;}
	
	function setCaminhoImagem($valor) { $this->caminhoImagem = $valor;}	
	function getCaminhoImagem() { return $this->caminhoImagem;}
	
	function setcaminhoThumbnail($valor) { $this->caminhoThumbnail = $valor;}	
	function getCaminhoThumbnail() { return $this->caminhoThumbnail;}
	
	function setTipoArquivo($valor) { $this->tipoArquivo = $valor;}	
	function getTipoArquivo() { return $this->tipoArquivo;}
	
	/******************************************************************
	 Data     : 04/10/2005
	 Autor    : Jean Moreira
	 Descri��o: seta os dados da imagem pelo seu n� identificador.
	******************************************************************/	
	
	function setarDadosImagem($nNumgFoto) {
	
		if(Erros::isError()) {
			
			return false;
	
		} else {
		
			try	{
			
				
				$sSql = "select numg_foto,numg_site,nome_arquivo,desc_foto from ob_fotos where numg_foto =" . $nNumgFoto;
				
				Oad::conectar();
				$oResult = Oad::consultar($sSql);
				Oad::desconectar();	

				if ($oResult->getCount() > 0){
					$this->numgFoto = $oResult->getValores(0,"numg_foto");
					$this->numgSite = $oResult->getValores(0,"numg_site");
					$this->nomeArquivo = $oResult->getValores(0,"nome_arquivo");
					$this->descFoto = $oResult->getValores(0,"desc_foto");
									
				}
				return true;
				
			} catch(Exception $e) {
			
				Erros::addErro("Fonte: SIGO.TranspAtrat.setarDadosImagem(); Descri��o: ".$e->getMessage()."�");
				return false;
			
			}
		}
	}

	/******************************************************************
	 Data     : 04/10/2005
	 Autor    : Jean Moreira
	 Descri��o: cadastra os dados do tipo de transporte do atrativo.
	******************************************************************/
    function cadastrar()  {
    
		if(Erros::isError()) {
			
			return false;
	
		} else {
	
			Oad::conectar();
				
			$this->pValidaGravacao();
				
			if (Erros::isError()){
				Oad::desconectar();
				return false;
			} else {
	
				try	{
					Oad::conectar();
					Oad::begin();				
						
					if ($this->uploadFile()) {
					
						//grava na se_imagens 
						$sSql = " INSERT INTO ob_fotos (";
						$sSql .= "nome_arquivo,numg_site,desc_foto";					
						$sSql .= ") VALUES (";
						$sSql .= FormataStr($this->nomeArquivo).",".FormataNumeroGravacao($this->numgSite).",".FormataStr($this->descFoto);
						$sSql .= " )";
							
						Oad::executar($sSql);
						
						$oResult = Oad::consultar("select max(numg_foto) from ob_fotos");
						
						$this->numgFoto = $oResult->getValores(0,0);
	
						Oad::commit();
						
					}
					
				} catch(Exception $e) {			
					Oad::rollback();
					Erros::addErro("Fonte: SIGO.Imagens.cadastrar(); Descri��o: ".$e->getMessage()."�");
					Oad::desconectar();
					return false;
				
				}
			}
			Oad::desconectar();
			return true;
		}		
	
	}

	/******************************************************************
	 Data     : 03/09/2005
	 Autor    : Jea Moreira
	 Descri��o: edita os dados do tipo de transporte do atrativo.
	******************************************************************/
    function editar (){
	
		if(Erros::isError()) {
			
			return false;
	
		} else {
		
			Oad::conectar();
			
				try	{				
					$sSql = "UPDATE ob_fotos SET";
					$sSql .= " desc_foto = " . FormataStr($this->descFoto);
					$sSql .= " WHERE numg_foto =" . $this->numgFoto;

					Oad::executar($sSql);
				
				} catch(Exception $e) {			
				
					Erros::addErro("Fonte: SIGO.Imagens.editar(); Descri��o: ".$e->getMessage()."�");
					Oad::desconectar();
					return false;
				
				}
			
			Oad::desconectar();
			return true;
		}		
	
    }
	
	/******************************************************************
	 Data     : 03/09/2005
	 Autor    : Jean Moreira
	 Descri��o: exclui um tipo de transporte do atrativo.
	******************************************************************/
    function excluir($nNumgFoto){
		
		if(Erros::isError()) {
			
			return false;
	
		} else {
	
			Oad::conectar();
				
			$this->pValidaExclusao($nNumgFoto);
	
			if (Erros::isError()){
				Oad::desconectar();
				return false;
			}
			else{
	
				try	{
					
					Oad::begin();
										
					$sSql = "DELETE FROM ob_fotos where numg_foto = " . $nNumgFoto;
					Oad::executar($sSql);
					
					$this->deleteFile();
					
					Oad::commit();
					Oad::desconectar();
					return true;	
					
				} catch(Exception $e) {			
				
					Erros::addErro("Fonte: SIGO.Imagens.excluir(); Descri��o: ".$e->getMessage()."�");
					Oad::rollback();
					Oad::desconectar();
					return false;
				
				}
			}
		}
    }

    function adequarTam($arquivo,$maxwidth,$maxheight,$numgSite) {
		
		$patch = "imagens/upload/".$numgSite."/";
		
		//comentado at� o pessoal do sebrae liberar a biblioteca de jpeg
		if (stristr($arquivo,'jpg')) $srcimage = imagecreatefromjpeg($patch.$arquivo);
		if (stristr($arquivo,'jpeg')) $srcimage = imagecreatefromjpeg($patch.$arquivo);	
		if (stristr($arquivo,'gif')) $srcimage = imagecreatefromgif($patch.$arquivo);
		if (stristr($arquivo,'png')) $srcimage = imagecreatefrompng($patch.$arquivo);
		
		$srcW = ImagesX($srcimage);
		$srcH = ImagesY($srcimage);
		$wdiff = $srcW - $maxwidth;
		$hdiff = $srcH - $maxheight;
		
		if ($wdiff > $hdiff) {
		 $newW = $maxwidth;
		  $aspect = ($newW/$srcW);
		  $newH = (int)($srcH * $aspect);
		} else {
		  $newH = $maxheight;
		  $aspect = ($newH/$srcH);
		  $newW = (int)($srcW * $aspect);
		}
		
		//$newimage = imagecreatetruecolor($newW,$newH);
		//$newimage = imagecreate($newW,$newH);
		
		//ImageCopyResampled($newimage,$srcimage,0,0,0,0,$newW,$newH,$srcW,$srcH);
		
		if (stristr($arquivo,'jpg') or stristr($arquivo,'jpeg')) {		
			$newimage = imagecreatetruecolor($newW,$newH);
			
			ImageCopyResampled($newimage,$srcimage,0,0,0,0,$newW,$newH,$srcW,$srcH);
	
			imagejpeg($newimage,$patch."p_".$arquivo);
		}
		
		if (stristr($arquivo,'gif')) {
			$newimage = imagecreate($newW,$newH);
		
			ImageCopyResampled($newimage,$srcimage,0,0,0,0,$newW,$newH,$srcW,$srcH);
	
			imagegif($newimage,$patch."p_".$arquivo);
		}
		
		if (stristr($arquivo,'png')) {
			$newimage = imagecreatetruecolor($newW,$newH);
			
			ImageCopyResampled($newimage,$srcimage,0,0,0,0,$newW,$newH,$srcW,$srcH);		
	
			imagegif($newimage,$patch."p_".$arquivo);
		}
		
		imagedestroy($newimage);
		unlink($patch.$arquivo);
		rename  ($patch."p_".$arquivo ,$patch.$arquivo);
	}
    
	//metodo para gerar um thumbnail
	function geraThumbnail($nomeImagem) {

		//define a imagem a partir da qual ser� gerada a miniatura
		$imagem = $this->caminhoImagem . $nomeImagem;
		
		// **** configura��es da miniatura ************************
		$tamanho_fixo = "S"; 	// S ou N
		$largura_fixa = 100; 	// usado somento com tamanho_fixo=S
		$altura_fixa = 60; 		// usado somento com tamanho_fixo=S
		$percentual = 40; 		// usado somento com tamanho_fixo=N
		// ********************************************************
		
		if(!file_exists($imagem))
		{			
			Erros::addErro("Arquivo da imagem n�o encontrado!�");	
			if (Erros::isError()) MostraErros();			
		}
		
		if($tamanho_fixo=="N" && ($percentual<1 || $percentual>100))
		{
			$_SESSION["erros"] = "O percentual deve ser um n�mero entre 1 e 100!";
			header("Location:erros.php");
			exit;
		}
		
		// monta o nome do arquivo resultante
		$arquivo_mini = explode(".",$nomeImagem);
		
		if ($arquivo_mini[1] == "JPG" || $arquivo_mini[1] == "jpg" || $arquivo_mini[1] == "JPEG" || $arquivo_mini[1] == "jpeg") 
		{
			$arquivo_miniatura = $this->caminhoThumbnail . "mini_".$nomeImagem;
		}
		
		if ($arquivo_mini[1] == "GIF" || $arquivo_mini[1] == "gif") 
		{
			$arquivo_miniatura = $this->caminhoThumbnail . "mini_".$nomeImagem;
		}
		if ($arquivo_mini[1] == "PNG" || $arquivo_mini[1] == "png") 
		{
			$arquivo_miniatura = $this->caminhoThumbnail . "mini_".$nomeImagem;
		}
		
		// verifica se o arquivo existe		
		if(!file_exists($arquivo_miniatura))
		{
			// verifica qual extens�o da imagem
			if ($arquivo_mini[1] == "JPG" || $arquivo_mini[1] == "jpg" || $arquivo_mini[1] == "JPEG" || $arquivo_mini[1] == "jpeg") 
			{
				// l� a imagem de origeme obt�m suas dimens�es
				$img_origem = imagecreatefromjpeg($imagem);
				$origem_x = ImagesX($img_origem);
				$origem_y = ImagesY($img_origem);
			}
			
			if ($arquivo_mini[1] == "GIF" || $arquivo_mini[1] == "gif") 
			{
				// l� a imagem de origeme obt�m suas dimens�es
				$img_origem = imagecreatefromgif($imagem);
				$origem_x = ImagesX($img_origem);
				$origem_y = ImagesY($img_origem);
			}
			if ($arquivo_mini[1] == "PNG" || $arquivo_mini[1] == "png") 
			{
				// l� a imagem de origeme obt�m suas dimens�es
				$img_origem = imagecreatefrompng($imagem);
				$origem_x = ImagesX($img_origem);
				$origem_y = ImagesY($img_origem);
			}
			// se n�o for tamanho fixo, calcula as dimens�es da miniatura
			if($tamanho_fixo=="S")
			{
				$x = $largura_fixa;
				$y = $altura_fixa;
			}
			else 
			{
				$x = intval ($origem_x * $percentual/100);
				$y = intval ($origem_y * $percentual/100);
			}
		
			// cria a imagem final, que ir� conter a miniatura
			$img_final = imagecreatetruecolor($x,$y);	
			
			// copia a imagem original redimensionada para dentro da imagem final
			ImageCopyResampled($img_final, $img_origem, 0, 0, 0, 0, $x+1, $y+1, $origem_x, $origem_y);
			
			// salva o arquivo 
			if ($arquivo_mini[1] == "JPG" || $arquivo_mini[1] == "jpg" || $arquivo_mini[1] == "JPEG" || $arquivo_mini[1] == "jpeg") 
			{
				imagejpeg($img_final,$arquivo_miniatura);
			}
			
			if ($arquivo_mini[1] == "GIF" || $arquivo_mini[1] == "gif") 
			{
				imagegif($img_final,$arquivo_miniatura);
			}
			if ($arquivo_mini[1] == "PNG" || $arquivo_mini[1] == "png") 
			{
				imagepng($img_final,$arquivo_miniatura);
			}
					
			// libera a mem�ria alocada para as duas imagens
			ImageDestroy($img_origem);
			ImageDestroy($img_final);
			return $arquivo_miniatura;
		}	
		return $arquivo_miniatura;

	}

	//metodo para enviar arquivo para o servidor	
	function uploadFile(){
		//elimina o limite de tempo de execucao
		set_time_limit(0);
			
		$upload = move_uploaded_file($this->nomeTmpImagem, $this->caminhoImagem . $this->nomeArquivo);
		
		if (!$upload) {
			throw new Exception("Erro ao enviar arquivo para o servidor.�");
			return false;
		}
		$this->adequarTam($this->nomeArquivo,450,300,$this->numgSite);
		//move_uploaded_file(
		/*
		if(!$this->adequarTam($this->nomeArquivo,450,300,$this->numgSite)){
			throw new Exception("Erro ao enviar arquivo para o servidor.�");
			return false;
		}*/
		return true;					
	}

	//metodo para excluir um arquivo do servidor	
	function deleteFile(){
		
		if (!unlink($this->caminhoImagem . $this->nomeArquivo)) {
			throw new Exception("Erro ao excluir arquivo do servidor.�");
		}
			
		if (file_exists($this->caminhoThumbnail . "mini_".$this->nomeArquivo)) {
			if (!unlink($this->caminhoThumbnail . "mini_".$this->nomeArquivo)) {
				throw new Exception("Erro ao excluir thumbnail do servidor.�");
			}
		}
	}//fim uploadFile()
	
	
	/******************************************************************
	 Data     : 04/10/2005
	 Autor    : Jean Moreira
	 Descri��o: consulta por atrativo.
	******************************************************************/
	function consultarPorSite($nSite) {

		if(Erros::isError()) {
			
			return false;
	
		} else {
			
			try	{
				
				Oad::conectar();
								
				$sSql = "select numg_foto,nome_arquivo,desc_fot,numg_site from ob_fotos where numg_foto = " . $nSite . " order by nome_arquivo";					
						
				$oResult = Oad::consultar($sSql);
				Oad::desconectar();					
					
			} catch(Exception $e) {			
				
					Erros::addErro("Fonte: SIGO.Imagens.consultarPorSite(); Descri��o: ".$e->getMessage()."�");
					return false;
				
			}
		}		
		return $oResult;					
    }
	
	
	/******************************************************************
	 Data     : 31/03/2008
	 Autor    : Danilo Fernandes 
	 Descri��o: busca as imagens vinculadas ao site
	******************************************************************/
    function consultarImagensVinculadas($nNumgSite) {
				
		if(Erros::isError()) {
			
			return false;
	
		} else {
	
			try	{
			
				$sSql  = " select numg_foto,nome_arquivo,numg_site,desc_foto";
				$sSql .= " from ob_fotos ";
				$sSql .= " where numg_site =".$nNumgSite;
				$sSql .= " order by numg_foto desc";
				
				Oad::conectar();
				$oResult = Oad::consultar($sSql);
				Oad::desconectar();
			
			} catch(Exception $e) {			
			
				Erros::addErro("Fonte: Sigo.Imagens.consultarImagensVinculadas(); Descri��o: ".$e->getMessage()."�");
				return false;

			}
			return $oResult;
		} 	
    }


    /******************************************************************
	 Data     : 31/03/2008
	 Autor    : Danilo Fernandes
	 Descri��o: busca as imagens vinculadas ao site
	******************************************************************/
    function consultarImagensNaoVinculadas($nNumgSite) {
				
		if(Erros::isError()) {
			
			return false;
	
		} else {
	
			try	{
			
				$sSql  = " select numg_foto,numg_site,nome_arquivo,desc_foto ";
				$sSql .= " from ob_fotos ";
				$sSql .= " where numg_site <>".$nNumgSite;
				$sSql .= " order by numg_foto desc";
				
								
				Oad::conectar();
				$oResult = Oad::consultar($sSql);
				Oad::desconectar();
			
			} catch(Exception $e) {			
			
				Erros::addErro("Fonte: Sigo.Imagens.consultarImagensNaoVinculadas(); Descri��o: ".$e->getMessage()."�");
				return false;

			}
			return $oResult;
		} 	
    }
	function dimPopup() {
		
		if (file_exists($this->getCaminhoImagem().$this->getNomeImagem())){
		
			$this->setNumrSize(getimagesize($this->getCaminhoImagem().$this->getNomeImagem()));
			$this->setNumrLargura($this->getNumrSize(0));
			$this->setNumrAltura($this->getNumrSize(1));
			
			$maxwidth = 500;
			$maxheight = 500;
			
			$srcW = $this->getNumrSize(0);
			$srcH = $this->getNumrSize(1);
			$wdiff = $srcW - $maxwidth;
			$hdiff = $srcH - $maxheight;
			
			if ($wdiff > $hdiff) {
			 $newW = $maxwidth;
			  $aspect = ($newW/$srcW);
			  $newH = (int)($srcH * $aspect);
			} else {
			  $newH = $maxheight;
			  $aspect = ($newH/$srcH);
			  $newW = (int)($srcW * $aspect);
			}
			//$newH = $newH + 25;
			//$newW = $newW + 25;
			
			$res = array($newW,$newH);
			return $res;
		} else {
			$res = array(0,0);
			return $res;
		}
	}
	
	
	/******************************************************************
	 Data     : 17/04/2008
	 Autor    : Thales A. Salvador
	 Descri��o: valida os dados de uma imagem antes de cadastr�-la ou
				edit�-la.
	******************************************************************/
	private function pValidaGravacao(){
		
		//SE FOR UMA INCLUS�O
		if ($this->numgFoto == 0){			

			//VERIFICA SE J� EXISTE ALGUMA IMAGEM CADASTRADA COM O NOME INFORMADO
			if (Oad::consultar("select nome_arquivo from ob_fotos where nome_arquivo = '" . trim($this->nomeArquivo) . "' and numg_site=" . $this->numgSite)->getCount() > 0){					
				Erros::addErro("J� existe uma imagem cadastrada com o nome: " . $this->nomeArquivo . " para este site.�");
			}
				
		}else{
				
			$oResAux = Oad::consultar("select numg_foto from ob_fotos where nome_arquivo = '" . trim($this->nomeArquivo) . "' and numg_site = " . $this->numgSite);
				
			if ($oResAux->getCount() > 0){
						
				//SE O N� IDENTifICADOR FOR DifERENTE, SIGNifICA QUE J� EXISTE UM REGISTRO 
				//COM NOME INFORMADO PARA EDI��O
				if ($oResAux->getValores(0,0) != $this->numgAtrativo){
					Erros::addErro("J� existe uma imagem cadastrada com o nome: " . $this->nomeImagem . " para este site.�");
				}
			}									
		}	
		
		$vTiposPermitidos = array("image/png","image/x-png","image/gif","image/pjpeg","image/jpeg");
		if(!in_array($this->tipoArquivo,$vTiposPermitidos)){
			Erros::addErro('Tipo do arquivo inv�lido. Arquivos permitidos "gif, jpeg e png".�');
		}		
		
		//tamanho
		if( (int) $this->numrTamanho > 2097152){
			Erros::addErro('Tamanho deve ser inferior a 2 MB.' . $this->numrTamanho .'�');
		}
	
	}//fim da funcao pVAlidaGravacao()
	
	/******************************************************************
	 Data     : 17/04/2008
	 Autor    : Thales A. Salvador
	 Descri��o: valida os dados de uma imagem antes de exclu�-la 				
	******************************************************************/
	private function pValidaExclusao($nNumgFoto){
		
		if (Oad::consultar("select numg_foto from ob_fotosatividiarios where numg_foto = " . $nNumgFoto)->getCount() > 0)	
			Erros::addErro("Esta Imagem est� vinculada a algum Di�rio.�");

		if (Oad::consultar("select numg_foto from ob_fotospendencias where numg_foto = " . $nNumgFoto)->getCount() > 0)	
			Erros::addErro("Esta Imagem est� vinculada a alguma Pend�ncia.�");

		
	}

}
?>