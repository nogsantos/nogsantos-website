<?php
/************************************************************************
 Empresa: Interagi Tecnologia

 Descri��o: Classe ImagensDiarios
	
 Releases (Data, respons�vel e descri��o [�ltimo release primeiro]):
	 16/04/2008 (Thales A. Salvador) 
		 Inclu�do este cabe�alho descrevendo a funcionalidade da p�gina
*************************************************************************/
include_once ('Imagens.php');

class ImagensDiarios extends Imagens {
	
	private $oResult, $sSql, $sErr;	

	//PROPRIEDADES
	private $numgDiario;
	private $numgSubatividade;
	
	function setNumgDiario($valor){ $this->numgDiario = $valor;}
	function getNumgDiario(){ return $this->numgDiario; }
	
	function setNumgSubatividade($valor){ $this->numgSubatividade = $valor;}
	function getNumgSubatividade(){ return $this->numgSubatividade; }
	
    /******************************************************************
	 Data     : 16/04/2008
	 Autor    : Thales A. Salvador
	 Descri��o: seta os dados da imagem do diario.
	******************************************************************/	
	function setarDadosImagem($nNumgFoto) {
	
		if(Erros::isError()) {
			
			return false;
	
		} else {
		
			try	{
			
				parent::setarDadosImagem($nNumgFoto);

				return true;
				
			} catch(Exception $e) {
			
				Erros::addErro("Fonte: SIGO.ImagensDiarios.setarDadosImagem(); Descri��o: ".$e->getMessage()."�");
				return false;
			
			}
		}
	}

    /******************************************************************
	 Data     : 16/04/2008
	 Autor    : Thales A. Salvador
	 Descri��o: cadastra os dados da imagem do di�rio.
	******************************************************************/
    function cadastrar()  {
    
		if(Erros::isError()) {
			
			return false;
	
		} else {
	
			Oad::conectar();
				
			$this->pValidaGravacao();
				
			if (Erros::isError()){
				Oad::desconectar();
				return false;
			} else {
	
				try	{

					Oad::begin();
					parent::cadastrar();
				
					$sSql  = "INSERT INTO ob_fotosatividiarios (numg_foto,numg_diario,numg_subatividade) ";
					$sSql .= "VALUES (" . FormataNumeroGravacao($this->numgFoto) . "," . FormataNumeroGravacao($this->numgDiario) . "," . FormataNumeroGravacao($this->numgSubatividade).")";
					
					Oad::executar($sSql);
		
					Oad::commit();
				
				} catch(Exception $e) {			
				
					Erros::addErro("Fonte: SIGO.ImagensDiarios.cadastrar(); Descri��o: ".$e->getMessage()."�");
					Oad::rollback();
					Oad::desconectar();
					return false;
				
				}
			}
			Oad::desconectar();
			return true;
		}		
	
	}

   
	/******************************************************************
	 Data     : 16/04/2008
	 Autor    : Thales A. Salvador
	 Descri��o: vincula uma imagem cadastrada a uma subatividade do di�rio.
	******************************************************************/
	public function vincular(){

		
		if(Erros::isError()) {
			
			return false;
	
		} else {
			
			try	{

				$sSql =  " INSERT INTO ob_fotosatividiarios(numg_foto, numg_diario,numg_subatividade) ";
				$sSql .= "VALUES (" . FormataNumeroGravacao($this->getNumgFoto()) . "," . FormataNumeroGravacao($this->numgDiario) . "," . FormataNumeroGravacao($this->numgSubatividade).")";
				
				Oad::conectar();
				Oad::executar($sSql);
				Oad::desconectar();
				return true;
			
			} catch(Exception $e) {			
			
				Erros::addErro("Fonte: SIGO.ImagensDiarios.vincular(); Descri��o: ".$e->getMessage()."�");
				Oad::desconectar();
				return false;
			
			}
		}		
	}


	/******************************************************************
	 Data     : 16/04/2008
	 Autor    : Thales A. Salvador
	 Descri��o: desvincula uma imagem cadastrada de uma subatividade de di�rio.
	******************************************************************/
	public function desvincular(){

		if(Erros::isError()) {
			
			return false;
	
		} else {
			
			try	{

				$sSql =  " delete from ob_fotosatividiarios";
				$sSql .= " where numg_foto = " . FormataNumeroGravacao($this->getNumgFoto());
				$sSql .= " and numg_diario = " . FormataNumeroGravacao($this->getNumgDiario());
				$sSql .= " and numg_subatividade = " . FormataNumeroGravacao($this->getNumgSubatividade());
				
				Oad::conectar();
				Oad::executar($sSql);
				Oad::desconectar();
				return true;
			
			} catch(Exception $e) {			
			
				Erros::addErro("Fonte: SIGO.ImagensDiarios.desvincular(); Descri��o: ".$e->getMessage()."�");
				Oad::desconectar();
				return false;
			
			}
		}		
	}

	
    /******************************************************************
	 Data     : 16/04/2008
	 Autor    : Thales A. Salvador
	 Descri��o: busca as imagens vinculadas a subatividade do di�rio
	******************************************************************/
    function consultarImagensVinculadas($nNumgDiarioSubatividade) {
		
    	$vNumg = split("-",$nNumgDiarioSubatividade);//indice 0 = numg_diario  indice 1 = numg_subatividade
    	$nNumgDiario = $vNumg[0];
    	$nNumgSubatividade = $vNumg[1];
    		
		if(Erros::isError()) {
			
			return false;
	
		} else {
	
			try	{
			
				$sSql  = " select numg_foto,nome_arquivo,desc_foto,numg_site";
				$sSql .= " from ob_fotos fot ";
				$sSql .= " where numg_foto in (select numg_foto from ob_fotosatividiarios where numg_diario = ".$nNumgDiario." and numg_subatividade=".$nNumgSubatividade.")";
				$sSql .= " order by numg_foto desc";
				
				Oad::conectar();
				$oResult = Oad::consultar($sSql);
				Oad::desconectar();
			
			} catch(Exception $e) {			
			
				Erros::addErro("Fonte: SIGO.ImagensDiarios.consultarImagensVinculadas(); Descri��o: ".$e->getMessage()."�");
				return false;

			}
			return $oResult;
		} 	
    }


    /******************************************************************
	 Data     : 16/04/2008
	 Autor    : Thales A. Salvador
	 Descri��o: busca as imagens n�o vinculadas a subatividade de di�rio
	******************************************************************/
    function consultarImagensNaoVinculadas($nNumgDiarioSubatividade) {

    	$vNumg = split("-",$nNumgDiarioSubatividade);//indice 0 = numg_diario  indice 1 = numg_subatividade  indice 2 = numg_site
    	$nNumgDiario = $vNumg[0];
    	$nNumgSubatividade = $vNumg[1];
    	$nNumgSite = $vNumg[2];
    		
		if(Erros::isError()) {
			
			return false;
	
		} else {
	
			try	{
			
				$sSql  = " select fot.numg_foto,fot.nome_arquivo,fot.desc_foto,fot.numg_site";
				$sSql .= " from ob_fotos fot ";
				$sSql .= " where fot.numg_foto not in (select fd.numg_foto from ob_fotosatividiarios fd where fd.numg_diario = ".$nNumgDiario." and fd.numg_subatividade=".$nNumgSubatividade.")";
				$sSql .= " and numg_site = " . $nNumgSite;
				$sSql .= " order by numg_foto desc";
				
				Oad::conectar();
				$oResult = Oad::consultar($sSql);
				Oad::desconectar();
			
			} catch(Exception $e) {			
			
				Erros::addErro("Fonte: SIGO.ImagensDiario.consultarImagensNaoVinculadas(); Descri��o: ".$e->getMessage()."�");
				return false;

			}
			return $oResult;
		} 	
    }


    /************************************************
	 Data     : 16/04/2008
	 Autor    : Thales A. Salvador
	 Descri��o: 
    ************************************************/
    function pValidaGravacao (  )
    {
						
    }

    /************************************************
	 Data     : 16/04/2008
	 Autor    : Thales A. Salvador
	 Descri��o: 
    ************************************************/
    function pValidaExclusao (  )
    {
    
	}
}
?>