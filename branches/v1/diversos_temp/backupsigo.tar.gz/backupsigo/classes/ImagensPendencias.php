<?php
/************************************************************************
 Empresa: Interagi Tecnologia

 Descri��o: Classe ImagensPendencias
	
 Releases (Data, respons�vel e descri��o [�ltimo release primeiro]):
	 14/04/2008 (Danilo Fernandes) 
		 Inclu�do este cabe�alho descrevendo a funcionalidade da p�gina
*************************************************************************/
include_once ('Imagens.php');

class ImagensPendencias extends Imagens {
	
	private $oResult, $sSql, $sErr;	
	private $numgPendencia;
	
	function setNumgPendencia($valor){ $this->numgPendencia = $valor;}
	function getNumgPendencia(){ return $this->numgPendencia; }
	
    /******************************************************************
	 Data     : 14/04/2008
	 Autor    : Danilo Fernandes
	 Descri��o: seta os dados da imagem da pend�ncia.
	******************************************************************/	
	function setarDadosImagem($nNumgImagem) {
	
		if(Erros::isError()) {
			
			return false;
	
		} else {
		
			try	{
			
				parent::setarDadosImagem($nNumgImagem);

				return true;
				
			} catch(Exception $e) {
			
				Erros::addErro("Fonte: Sigo.ImagensPendencias.setarDadosImagem(); Descri��o: ".$e->getMessage()."�");
				return false;
			
			}
		}
	}

    /******************************************************************
	 Data     : 14/04/2008
	 Autor    : Danilo Fernandes
	 Descri��o: cadastra os dados da imagem .
	******************************************************************/
    function cadastrar()  {
    
		if(Erros::isError()) {
			
			return false;
	
		} else {
	
			Oad::conectar();
				
			$this->pValidaGravacao();
				
			if (Erros::isError()){
				Oad::desconectar();
				return false;
			} else {
	
				try	{

					Oad::begin();
					parent::cadastrar();
				
					$sSql  = "INSERT INTO tb_fotospendencias (numg_foto,numg_pendencia) ";
					$sSql .= "VALUES (" . FormataNumeroGravacao($this->numgFoto) . "," . FormataNumeroGravacao($this->numgPendencia) . ")";
					
					Oad::executar($sSql);
		
					Oad::commit();
				
				} catch(Exception $e) {			
				
					Erros::addErro("Fonte: Sigo.ImagensPendencias.cadastrar(); Descri��o: ".$e->getMessage()."�");
					Oad::rollback();
					Oad::desconectar();
					return false;
				
				}
			}
			Oad::desconectar();
			return true;
		}		
	
	}


  

	/******************************************************************
	 Data     : 14/04/2008
	 Autor    : Danilo Fernandes
	 Descri��o: vincula uma imagem cadastrada a uma pendencia.
	******************************************************************/
	public function vincular(){

		if(Erros::isError()) {
			
			return false;
	
		} else {
			
			try	{

				$sSql =  " INSERT INTO ob_fotospendencias(numg_foto, numg_pendencia) ";
				$sSql .= " values (" . FormataNumeroGravacao($this->getNumgFoto()) . "," . FormataNumeroGravacao($this->getNumgPendencia()) . ")";
				
				Oad::conectar();
				Oad::executar($sSql);
				Oad::desconectar();
				return true;
			
			} catch(Exception $e) {			
			
					Erros::addErro("Fonte: Sigo.ImagensPendencias.vincular(); Descri��o: ".$e->getMessage()."�");
				Oad::desconectar();
				return false;
			
			}
		}		
	}


	/******************************************************************
	 Data     : 14/04/2008
	 Autor    : Danilo Fernandes 
	 Descri��o: desvincula uma imagem cadastrada de uma pendencia.
	******************************************************************/
	public function desvincular(){

		if(Erros::isError()) {
			
			return false;
	
		} else {
			
			try	{

				$sSql =  " delete from ob_fotospendencias";
				$sSql .= " where numg_foto = " . FormataNumeroGravacao($this->getNumgFoto());
				$sSql .= " and numg_pendencia = " . FormataNumeroGravacao($this->getNumgPendencia());
				
				Oad::conectar();
				Oad::executar($sSql);
				Oad::desconectar();
				return true;
			
			} catch(Exception $e) {			
			
				Erros::addErro("Fonte: Sigo.ImagensPendencias.desvincular(); Descri��o: ".$e->getMessage()."�");
				Oad::desconectar();
				return false;
			
			}
		}		
	}

	  /******************************************************************
	 Data     : 14/04/2008
	 Autor    : Danilo Fernandes
	 Descri��o: busca os dados de acorodo com a imagem
	******************************************************************/
    function consultarImagem($nNumgImagem) {
				
		if(Erros::isError()) {
			
			return false;
	
		} else {
	
			try	{
			
				$sSql  = " select ftp.numg_foto,ft.nome_arquivo,ftp.numg_pendencia";
				$sSql .= " from ob_fotos ft ";
				$sSql .= " inner join ob_fotospendencias ftp on ftp.numg_foto = ft.numg_foto";
				$sSql .= " where ftp.numg_foto = ".$nNumgImagem;
				$sSql .= " order by ft.nome_arquivo";
				
				Oad::conectar();
				$oResult = Oad::consultar($sSql);
				Oad::desconectar();
			
			} catch(Exception $e) {			
			
				Erros::addErro("Fonte: Sigo.ImagensPendencias.consultarImagemPorPendencia(); Descri��o: ".$e->getMessage()."�");
				return false;

			}
			return $oResult;
		} 	
    }
    /******************************************************************
	 Data     : 14/04/2008
	 Autor    : Danilo Fernandes
	 Descri��o: busca as imagens vinculadas a uma pendencia
	******************************************************************/
    function consultarImagensVinculadas($nNumgPendencia) {
			
    	$vNumg = split("-",$nNumgPendencia);//indice 0 = numg_pendencia 
    	$nNumgPendencia = $vNumg[0];
    	
		if(Erros::isError()) {
			
			return false;
	
		} else {
	
			try	{
			
				$sSql  = " select numg_foto,nome_arquivo,desc_foto,numg_site";
				$sSql .= " from ob_fotos ft ";
				$sSql .= " where numg_foto in (select numg_foto from ob_fotospendencias where numg_pendencia = ".$nNumgPendencia.")";
				
				
				Oad::conectar();
				$oResult = Oad::consultar($sSql);
				Oad::desconectar();
			
			} catch(Exception $e) {			
			
				Erros::addErro("Fonte: Sigo.ImagensPendencias.consultarImagensVinculadas(); Descri��o: ".$e->getMessage()."�");
				return false;

			}
			return $oResult;
		} 	
    }


    /******************************************************************
	 Data     : 14/04/2008
	 Autor    : Danilo Fernandes
	 Descri��o: busca as imagens n�o vinculadas a uma pendencia
	******************************************************************/
    function consultarImagensNaoVinculadas($nNumgPendencia,$nNumgSite) {
		
    	$vNumg = split("-",$nNumgPendencia);//indice 0 = numg_pendencia 
    	$nNumgPendencia = $vNumg[0];		
		if(Erros::isError()) {
			
			return false;
	
		} else {
	
			try	{
			
				$sSql  = " select numg_foto,nome_arquivo,desc_foto,numg_site ";
				$sSql .= " from ob_fotos ft ";
				$sSql .= " where numg_site =".$nNumgSite." and numg_foto not in (select numg_foto from ob_fotospendencias where numg_pendencia = ".$nNumgPendencia.")";
				
				
				Oad::conectar();
				$oResult = Oad::consultar($sSql);
				Oad::desconectar();
			
			} catch(Exception $e) {			
			
				Erros::addErro("Fonte: Sigo.ImagensPendencias.consultarImagensNaoVinculadas(); Descri��o: ".$e->getMessage()."�");
				return false;

			}
			return $oResult;
		} 	
    }


    /************************************************
	 Data     : 01/12/2005
	 Autor    : Rafael C�cero
	 Descri��o: 
    ************************************************/
    function pValidaGravacao (  )
    {
						
    }

    /************************************************
	 Data     : 01/12/2005
	 Autor    : Rafael C�cero
	 Descri��o: 
    ************************************************/
    function pValidaExclusao (  ){
    }
}
?>