<?php
/******************************************************
Empresa: Interagi Tecnologia

Descricao: Classe respons�vel pelo controle de Di�rios

Releases (Data, respons�vel e descri��o [�ltimo release primeiro]):
02-04-2008 (Thales A. Salvador) [Cria��o da Classe]
*******************************************************/
include "mime/htmlMimeMail.php";

class Diarios {

	//PROPRIEDADES
	protected $numgDiario;
	private $numgSite;
	private $numgFase;
	private $dataDiario;
	private $numgOperadorcad;
	private $vSubatividades;
	private $dataCadastro;
	private $dataUltimaalt;
	private $numgOperadoralt;
	private $numgOperadorlib;
	private $dataLiberacao;


	function setNumgDiario($valor) {
		if ($valor != "") {
			$this->numgDiario = $valor;
		} else {
			Erros::addErro("Campo numgDiario Inv�lido.�");
		}
	}

	function getNumgDiario() { return $this->numgDiario;}


	function setNumgSite($valor) {
		if ($valor != "") {
			$this->numgSite = $valor;
		} else {
			Erros::addErro("Campo numgSite Inv�lido.�");
		}
	}

	function getNumgSite() { return $this->numgSite;}

	function setNumgFase($valor) {
		if ($valor != "") {
			$this->numgFase = $valor;
		} else {
			Erros::addErro("Campo numgFase Inv�lido.�");
		}
	}

	function getNumgFase() { return $this->numgFase;}


	function setDataDiario($valor) {
		if ($valor != "") {
			$this->dataDiario = $valor;
		} else {
			Erros::addErro("Data de dataDiario Inv�lida.�");
		}
	}

	function getDataDiario() { return $this->dataDiario;}


	function setNumgOperadorcad($valor) {
		if ($valor != "") {
			$this->numgOperadorcad = $valor;
		} else {
			Erros::addErro("Campo numgOperadorcad Inv�lido.�");
		}
	}

	function getNumgOperadorcad() { return $this->numgOperadorcad;}


	function setVSubatividades($valor) {
		if ($valor != "") {
			$this->vSubatividades = $valor;
		} else {
			Erros::addErro("Atividades do Di�rio Inv�lidas.�");
		}
	}

	function getVSubatividades() { return $this->vSubatividades;}

	function setDataCadastro($valor) {
		if ($valor != "") {
			$this->dataCadastro = $valor;
		} else {
			Erros::addErro("Data de dataCadastro Inv�lida.�");
		}
	}

	function getDataCadastro() { return $this->dataCadastro;}


	function setDataUltimaalt($valor) {
		if ($valor != "") {
			$this->dataUltimaalt = $valor;
		} else {
			Erros::addErro("Data de dataUltimaalt Inv�lida.�");
		}
	}

	function getDataUltimaalt() { return $this->dataUltimaalt;}


	function setNumgOperadoralt($valor) {
		if ($valor != "") {
			$this->numgOperadoralt = $valor;
		} else {
			Erros::addErro("Campo numgOperadoralt Inv�lido.�");
		}
	}

	function getNumgOperadoralt() { return $this->numgOperadoralt;}

	function setDataLiberacao($valor) {
		if ($valor != "") {
			$this->dataLiberacao = $valor;
		} else {
			Erros::addErro("Data de dataLiberacao Inv�lida.�");
		}
	}

	function getDataLiberacao() { return $this->dataLiberacao;}


	function setNumgOperadorlib($valor) {
		if ($valor != "") {
			$this->numgOperadorlib = $valor;
		} else {
			Erros::addErro("Campo numgOperadorlib Inv�lido.�");
		}
	}

	function getNumgOperadorlib() { return $this->numgOperadorlib;}

	/******************************************************************
	Data     : 02/04/2008
	Autor    : Thales A. Salvador
	Descri��o: preenche os atributos da classe com os valores obtidos
	na busca.
	******************************************************************/
	function setarDados($nNumgDiario){

		if(Erros::isError()) {

			return false;

		} else {

			$sSql = "SELECT ";
			$sSql .= "numg_diario,numg_site,numg_fase,data_diario,numg_operadorcad,data_cadastro,numg_operadoralt,data_ultimaalt,data_liberacao,numg_operadorlib";
			$sSql .= " FROM ob_diarios";
			$sSql .= " WHERE numg_diario = ".$nNumgDiario;


			try {

				Oad::conectar();
				$oResult = Oad::consultar($sSql);

				if ($oResult->getCount() > 0){
					$this->numgDiario = $oResult->getValores(0,"numg_diario");
					$this->numgSite = $oResult->getValores(0,"numg_site");
					$this->numgFase = $oResult->getValores(0,"numg_fase");
					$this->dataDiario = $oResult->getValores(0,"data_diario");
					$this->dataCadastro = $oResult->getValores(0,"data_cadastro");
					$this->numgOperadorcad = $oResult->getValores(0,"numg_operadorcad");
					$this->dataUltimaalt = $oResult->getValores(0,"data_ultimaalt");
					$this->numgOperadoralt = $oResult->getValores(0,"numg_operadoralt");
					$this->dataLiberacao = $oResult->getValores(0,"data_liberacao");
					$this->numgOperadorlib = $oResult->getValores(0,"numg_operadorlib");
				}


			} catch(Exception $e) {

				Erros::addErro("Fonte: SIGO.Diarios.setarDados()".$e->getMessage()."�");
				Oad::desconectar();
				return false;

			}
			Oad::desconectar();
		}

		return true;
	}



	/******************************************************************
	Data     : 02/04/2008
	Autor    : Thales A. Salvador
	Descri��o: armazena os dados do di�rio no banco de dados
	******************************************************************/
	function cadastrar(){
		if(Erros::isError()) {

			return false;

		} else {

			Oad::conectar();

			$this->pValidaGravacao();

			if (Erros::isError()){
				Oad::desconectar();
				return false;
			} else {

				try	{

					Oad::begin();

					$sSql = "INSERT INTO ob_diarios (";
					$sSql .= "numg_site,numg_fase,data_diario,numg_operadorcad,data_cadastro";
					$sSql .= " ) VALUES ( ";
					$sSql .= FormataNumeroGravacao($this->numgSite).",".FormataNumeroGravacao($this->numgFase).",";
					$sSql .= FormataDataGravacao($this->dataDiario).",".FormataNumeroGravacao($this->numgOperadorcad).",";
					$sSql .= "CURRENT_TIMESTAMP";
					$sSql .= ")";

					Oad::executar($sSql);

					$oResult = Oad::consultar("select max(numg_diario) from ob_diarios");
					$this->setNumgDiario($oResult->getValores(0,0));

					$oSubativ = Oad::consultar("select numg_subatividade from ob_subatividades");

					for($i=0;$i<$oSubativ->getCount();$i++){

						//incluir
						$sSql = "INSERT INTO ob_ativdiarios (";
						$sSql .= "numg_diario,numg_subatividade,numr_status";
						$sSql .= " ) VALUES ( ";
						$sSql .= FormataNumeroGravacao($this->numgDiario).",".FormataNumeroGravacao($oSubativ->getValores($i,"numg_subatividade")).",";
						$sSql .= "1";//NA
						$sSql .= ")";

						Oad::executar($sSql);

					}

					Oad::commit();

				} catch(Exception $e) {

					Erros::addErro("Fonte: SIGO.Diarios.cadastrar(); Descri��o: ".$e->getMessage()."�");
					Oad::rollback();
					Oad::desconectar();
					return false;

				}
			}
			Oad::desconectar();
			return true;
		}
	}

	/******************************************************************
	Data     : 02/04/2008
	Autor    : Thales A. Salvador
	Descri��o: atualiza os dados de um di�rio no banco de
	dados.
	******************************************************************/
	function editar () {

		if(Erros::isError()) {

			return false;

		} else {

			Oad::conectar();

			$this->pValidaGravacao();

			if (Erros::isError()){
				Oad::desconectar();
				return false;
			}
			else{

				try	{

					Oad::begin();

					$sSql = "UPDATE ob_diarios SET ";
					$sSql .= "numg_site = ".FormataNumeroGravacao($this->numgSite).",";
					$sSql .= "numg_fase = ".FormataNumeroGravacao($this->numgFase).",";
					$sSql .= "data_diario = ".FormataDataGravacao($this->dataDiario).",";
					$sSql .= "data_ultimaalt = CURRENT_TIMESTAMP,";
					$sSql .= "numg_operadoralt = ".FormataNumeroGravacao($this->numgOperadoralt);
					$sSql .= " WHERE numg_diario = ".$this->numgDiario;

					Oad::executar($sSql);

					for($i=0;$i<count($this->vSubatividades);$i++){
						//Verifica se a atividade do di�rio j� existe
						if (Oad::consultar("select numg_subatividade from ob_ativdiarios where numg_diario =". $this->numgDiario . " and numg_subatividade =". $this->vSubatividades[$i][0])->getCount() > 0){
							//editar
							$sSql = "UPDATE ob_ativdiarios SET ";
							$sSql .= "numg_subatividade = ".FormataNumeroGravacao($this->vSubatividades[$i][0]).",";
							$sSql .= "numr_status = ".FormataNumeroGravacao($this->vSubatividades[$i][1]).",";
							$sSql .= "desc_comentario = ".FormataStr($this->vSubatividades[$i][2]);
							$sSql .= " WHERE numg_diario = ".$this->numgDiario . " and numg_subatividade =". $this->vSubatividades[$i][0];

						}else{
							//incluir
							$sSql = "INSERT INTO ob_ativdiarios (";
							$sSql .= "numg_diario,numg_subatividade,numr_status,desc_comentario";
							$sSql .= " ) VALUES ( ";
							$sSql .= FormataNumeroGravacao($this->numgDiario).",".FormataNumeroGravacao($this->vSubatividades[$i][0]).",";
							$sSql .= FormataNumeroGravacao($this->vSubatividades[$i][1]).",".FormataStr($this->vSubatividades[$i][2]);
							$sSql .= ")";
						}

						Oad::executar($sSql);

					}

					Oad::commit();

				} catch(Exception $e) {

					Erros::addErro("Fonte: SIGO.Diarios.editar(); Descri��o: ".$e->getMessage()."�");
					Oad::rollback();
					Oad::desconectar();
					return false;

				}
			}
			Oad::desconectar();
			return true;
		}
	}

	/******************************************************************
	Data     : 25/04/2008
	Autor    : Thales A. Salvador
	Descri��o: libera o diario para aparecer no relat�rio da Operadora.
	******************************************************************/
	function liberar () {

		if(Erros::isError()) {

			return false;

		} else {

			Oad::conectar();

			$this->pValidaGravacao();

			if (Erros::isError()){
				Oad::desconectar();
				return false;
			}
			else{

				try	{


					$sSql = "UPDATE ob_diarios SET ";
					$sSql .= "data_liberacao = CURRENT_TIMESTAMP,";
					$sSql .= "numg_operadorlib = ".FormataNumeroGravacao($this->numgOperadorlib);
					$sSql .= " WHERE numg_diario = ".$this->numgDiario;

					Oad::executar($sSql);
					
					$sSql =  " select nome_operador, desc_senha, nome_completo, desc_email ";
					$sSql .= " from se_operadores where flag_emaildiario=true";
										
					$oResult = Oad::consultar($sSql);
					
					for ($i=0; $i<$oResult->getCount(); $i++){
						$email[$i] = $oResult->getValores($i,"desc_email");	
					}
					
					
					if (!empty($oResult)){
						
						$sSql =  " select s.nome_site, f.nome_fase ";
						$sSql .= " from ob_diarios d inner join ob_sites s on d.numg_site=s.numg_site";
						$sSql .= " inner join ob_fases f on s.numg_site=f.numg_site";
						$sSql .= " WHERE numg_diario = ".$this->numgDiario;
						
						
						$oDetalhesDiario = Oad::consultar($sSql);
						
						$mail = new htmlMimeMail();
						$mail->setFrom("Elo Telecom<lluciano@elotelecom.com.br>");
						$mail->setSubject("SIGO - Di�rio Liberado Para Consulta");
						$mail->setReturnPath("lluciano@elotelecom.com.br");
											
						$sMens = "<b>Di�rio Liberado no Sistema SIGO.</b><br>";
						$sMens .= "<a href='http://www.elotelecom.com.br/sigo'>http://www.elotelecom.com.br/sigo</a><br>";
						$sMens .= "<br><b>Abaixo seguem os dados do di�rio: </b>";
						$sMens .= "<br><b>Data do Di�rio: </b>" . $this->dataDiario;
						$sMens .= "<br><b>Site: </b>" . $oDetalhesDiario->getValores(0,"nome_site");
						$sMens .= "<br><b>Fase: </b>" . $oDetalhesDiario->getValores(0,"nome_fase");
						
						$mail->setHtml($sMens);	
						$result = $mail->send($email);
						
						
												
					}	


				} catch(Exception $e) {

					Erros::addErro("Fonte: SIGO.Diarios.liberar(); Descri��o: ".$e->getMessage()."�");
					Oad::desconectar();
					return false;

				}
			}
			Oad::desconectar();
			return true;
		}
	}

	/******************************************************************
	Data     : 02/04/2008
	Autor    : Thales A. Salvador
	Descri��o: exclui um di�rio no banco de dados.
	******************************************************************/
	function excluir($numgDiario) {

		if(Erros::isError()) {

			return false;

		} else {

			Oad::conectar();

			$this->pValidaExclusao($numgDiario);

			if (Erros::isError()){
				Oad::desconectar();
				return false;
			}
			else{

				try	{
					Oad::begin();

					$sSql  = "DELETE FROM ob_ativdiarios";
					$sSql .= " WHERE";
					$sSql .= " numg_diario = ".$numgDiario;

					Oad::executar($sSql);

					$sSql  = "DELETE FROM ob_diarios";
					$sSql .= " WHERE";
					$sSql .= " numg_diario = ".$numgDiario;

					Oad::executar($sSql);

					Oad::commit();

				} catch(Exception $e) {

					Erros::addErro("Fonte: SIGO.Diarios.excluir(); Descri��o: ".$e->getMessage()."�");
					Oad::rollback();
					Oad::desconectar();
					return false;

				}
			}
			Oad::desconectar();
			return true;
		}


	}

	/******************************************************************
	Data     : 02/04/2008
	Autor    : Thales A. Salvador
	Descri��o: consulta di�rios por data
	******************************************************************/
	function consultarPorData($dataInicio,$dataFim){

		if(Erros::isError()) {

			return false;

		} else {

			$sSql = "SELECT ";
			$sSql .= "numg_diario,numg_site,numg_fase,data_diario,numg_operadorcad,data_cadastro,numg_operadoralt,data_ultimaalt";
			$sSql .= " FROM ob_diarios";
			$sSql .= " WHERE data_diario BETWEEN '".$dataInicio."' AND '".$dataFim."'";

			try {

				Oad::conectar();
				$result = Oad::consultar($sSql);

				return $result;

			} catch(Exception $e) {

				Erros::addErro("Fonte: SIGO.Diarios.consultarPorData()".$e->getMessage()."�");
				Oad::desconectar();
				return false;

			}
			Oad::desconectar();
		}


	}

	/******************************************************************
	Data     : 17/12/2008
	Autor    : Thales A. Salvador
	Descri��o: consulta subatividades de di�rios sem se preocupar com NOKs anteriores
	******************************************************************/
	function consultarSubativSimples($numgDiario){

		if(Erros::isError()) {

			return false;

		} else {
			Oad::conectar();

			if (Oad::consultar("select numg_diario from ob_ativdiarios where numg_diario =". $numgDiario)->getCount() > 0){

					$sSql = "SELECT";
					$sSql .= " s.numg_subatividade, s.nome_subatividade, a.numg_atividade, a.nome_atividade, ad.numr_status, ad.desc_comentario";
					$sSql .= " ,(";
					$sSql .= " select count(fd.numg_foto) from ob_fotosatividiarios fd";
					$sSql .= " where fd.numg_diario = d.numg_diario and fd.numg_subatividade = s.numg_subatividade";
					$sSql .= " )as numr_fotos,s.data_bloqueio";
					$sSql .= " FROM";
					$sSql .= " 	ob_subatividades s ";
					$sSql .= " 	inner join ob_atividades a on s.numg_atividade = a.numg_atividade";
					$sSql .= " 	left join ob_ativdiarios ad on s.numg_subatividade = ad.numg_subatividade";
					$sSql .= " 	left join ob_diarios d on d.numg_diario = ad.numg_diario";
					//$sSql .= " 	left join ob_fotosatividiarios fd on fd.numg_diario = d.numg_diario and s.numg_subatividade = fd.numg_subatividade";
					$sSql .= " WHERE";
					$sSql .= " 	d.numg_diario = ".$numgDiario;
					$sSql .= " ORDER BY";
					$sSql .= " 	a.nome_atividade, s.nome_subatividade";

			

			}else{
			$sSql = "SELECT ";
			$sSql .= "numg_subatividade,nome_subatividade,s.numg_atividade,nome_atividade,s.data_bloqueio";
			$sSql .= " FROM ob_subatividades s inner join ob_atividades a on a.numg_atividade=s.numg_atividade";
			$sSql .= " ORDER BY nome_atividade,nome_subatividade";
			}


			try {

				Oad::conectar();
				$result = Oad::consultar($sSql);

				return $result;

			} catch(Exception $e) {

				Erros::addErro("Fonte: SIGO.Diarios.consultarSubativ()".$e->getMessage()."�");
				Oad::desconectar();
				return false;

			}
			Oad::desconectar();
		}


	}
	
	/******************************************************************
	Data     : 14/04/2008
	Autor    : Thales A. Salvador
	Descri��o: consulta subatividades de di�rios
	******************************************************************/
	function consultarSubativ($numgDiario){

		if(Erros::isError()) {

			return false;

		} else {
			Oad::conectar();

			//if (Oad::consultar("select numg_diario from ob_ativdiarios where numg_diario =". $numgDiario)->getCount() > 0){

					$sSql = "SELECT";
					$sSql .= " s.numg_subatividade, s.nome_subatividade, a.numg_atividade, a.nome_atividade, ad.numr_status, ad.desc_comentario";
					$sSql .= " ,";
					$sSql .= " (";
					$sSql .= " select";
					$sSql .= "	count(ad1.numg_subatividade)";
					$sSql .= " from";
					$sSql .= "	ob_ativdiarios ad1";
					$sSql .= "	inner join ob_diarios d1 on d1.numg_diario = ad1.numg_diario";
					$sSql .= " where";
					$sSql .= "	ad1.numg_subatividade = ad.numg_subatividade";
					$sSql .= "	and ad1.numr_status = 2";
					$sSql .= "	and d1.numg_site=d.numg_site";
					$sSql .= "	and d1.numg_fase=d.numg_fase";
					$sSql .= "	and d1.data_diario between (";
					$sSql .= "					select max(d2.data_diario)"; 
					$sSql .= "					from ob_ativdiarios ad2";
					$sSql .= "					inner join ob_diarios d2 on d2.numg_diario = ad2.numg_diario";
					$sSql .= "					where";
					$sSql .= "					ad2.numg_subatividade = ad.numg_subatividade";
					$sSql .= "					and d2.data_diario < d.data_diario";
					$sSql .= "					and ad2.numr_status = 3";
					$sSql .= "					) and d.data_diario";
					$sSql .= " )as count_ok,";
					$sSql .= " (select max(d2.data_diario)";
					$sSql .= " from ob_ativdiarios ad2";
					$sSql .= " inner join ob_diarios d2 on d2.numg_diario = ad2.numg_diario";
					$sSql .= " where ";
					$sSql .= " ad2.numg_subatividade = ad.numg_subatividade";
					$sSql .= " and d2.data_diario < d.data_diario";
					$sSql .= " and ad2.numr_status = 3";
					$sSql .= " and d2.numg_site=d.numg_site";
					$sSql .= " and d2.numg_fase=d.numg_fase";
					$sSql .= " )as data_nok";
					
					$sSql .= ",(select ad3.desc_comentario";
					$sSql .= " from ob_ativdiarios ad3";
					$sSql .= " inner join ob_diarios d3 on d3.numg_diario = ad3.numg_diario";
					$sSql .= " where ";
					$sSql .= " ad3.numg_subatividade = ad.numg_subatividade";
					$sSql .= " and d3.data_diario < d.data_diario";
					$sSql .= " and ad3.numr_status = 3";
					$sSql .= " and d3.numg_site=d.numg_site";
					$sSql .= " and d3.numg_fase=d.numg_fase";
					$sSql .= " and d3.data_diario=";
					
					$sSql .= " (select max(d4.data_diario)";
					$sSql .= " from ob_ativdiarios ad4";
					$sSql .= " inner join ob_diarios d4 on d4.numg_diario = ad4.numg_diario";
					$sSql .= " where ";
					$sSql .= " ad4.numg_subatividade = ad.numg_subatividade";
					$sSql .= " and d4.data_diario < d.data_diario";
					$sSql .= " and ad4.numr_status = 3";
					$sSql .= " and d4.numg_site=d.numg_site";
					$sSql .= " and d4.numg_fase=d.numg_fase";
					$sSql .= " )";
					
					$sSql .= " )as desc_nok";
					
					$sSql .= " ,(";
					$sSql .= " select count(fd.numg_foto) from ob_fotosatividiarios fd";
					$sSql .= " where fd.numg_diario = d.numg_diario and fd.numg_subatividade = s.numg_subatividade";
					$sSql .= " )as numr_fotos,s.data_bloqueio";
					$sSql .= " FROM";
					$sSql .= " 	ob_subatividades s ";
					$sSql .= " 	inner join ob_atividades a on s.numg_atividade = a.numg_atividade";
					$sSql .= " 	left join ob_ativdiarios ad on s.numg_subatividade = ad.numg_subatividade";
					$sSql .= " 	left join ob_diarios d on d.numg_diario = ad.numg_diario";
					//$sSql .= " 	left join ob_fotosatividiarios fd on fd.numg_diario = d.numg_diario and s.numg_subatividade = fd.numg_subatividade";
					$sSql .= " WHERE";
					$sSql .= " 	d.numg_diario = ".$numgDiario;
					$sSql .= " ORDER BY";
					$sSql .= " 	a.nome_atividade, s.nome_subatividade";

			

			/*}else{
			$sSql = "SELECT ";
			$sSql .= "numg_subatividade,nome_subatividade,s.numg_atividade,nome_atividade";
			$sSql .= " FROM ob_subatividades s inner join ob_atividades a on a.numg_atividade=s.numg_atividade";
			$sSql .= " ORDER BY nome_atividade,nome_subatividade";
			}*/


			try {

				Oad::conectar();
				$result = Oad::consultar($sSql);

				return $result;

			} catch(Exception $e) {

				Erros::addErro("Fonte: SIGO.Diarios.consultarSubativ()".$e->getMessage()."�");
				Oad::desconectar();
				return false;

			}
			Oad::desconectar();
		}


	}

	/******************************************************************
	Data     : 16/04/2008
	Autor    : Thales A. Salvador
	Descri��o: consulta se existem subatividades de di�rios cadastradas
	******************************************************************/
	function existemSubativCadastradas($numgDiario){

		if(Erros::isError()) {

			return false;

		} else {

			Oad::conectar();

			if (Oad::consultar("select numg_diario from ob_ativdiarios where numg_diario =". $numgDiario)->getCount() > 0){
				Oad::desconectar();
				return true;
			}else{
				Oad::desconectar();
				return false;
			}

		}


	}

	/******************************************************************
	Data     : 02/04/2008
	Autor    : Thales A. Salvador
	Descri��o: consulta di�rios por site
	******************************************************************/
	function consultarPorSite($nNumgSite){

		if(Erros::isError()) {

			return false;

		} else {

			$sSql = "SELECT ";
			$sSql .= "numg_diario,numg_site,numg_fase,data_diario,numg_operadorcad,data_cadastro,numg_operadoralt,data_ultimaalt";
			$sSql .= " FROM ob_diarios";
			$sSql .= " WHERE numg_site=".$nNumgSite;

			try {

				Oad::conectar();
				$result = Oad::consultar($sSql);

				return $result;

			} catch(Exception $e) {

				Erros::addErro("Fonte: SIGO.Diarios.consultarPorSite()".$e->getMessage()."�");
				Oad::desconectar();
				return false;

			}
			Oad::desconectar();
		}


	}

	/******************************************************************
	Data     : 02/04/2008
	Autor    : Thales A. Salvador
	Descri��o: consulta di�rios por site e fase
	******************************************************************/
	function consultarPorSiteFase($nNumgSite,$nNumgFase){

		if(Erros::isError()) {

			return false;

		} else {

			$sSql = "SELECT ";
			$sSql .= "numg_diario,numg_site,numg_fase,data_diario,numg_operadorcad,data_cadastro,numg_operadoralt,data_ultimaalt";
			$sSql .= " FROM ob_diarios";
			$sSql .= " WHERE numg_site=".$nNumgSite;
			$sSql .= " AND numg_fase=".$nNumgFase;


			try {

				Oad::conectar();
				$result = Oad::consultar($sSql);

				return $result;

			} catch(Exception $e) {

				Erros::addErro("Fonte: SIGO.Diarios.consultarPorSiteFase()".$e->getMessage()."�");
				Oad::desconectar();
				return false;

			}
			Oad::desconectar();
		}


	}

	/******************************************************************
	Data     : 02/04/2008
	Autor    : Thales A. Salvador
	Descri��o: consulta di�rios por site e fase
	******************************************************************/
	function consultarPorSiteFaseData($nNumgSite,$nNumgFase,$sDataDiario){

		if(Erros::isError()) {

			return false;

		} else {

			$sSql = "  SELECT ";
			$sSql .= " numg_diario,numg_site,numg_fase,data_diario,numg_operadorcad,data_cadastro,numg_operadoralt,data_ultimaalt";
			$sSql .= " FROM ob_diarios";
			$sSql .= " WHERE numg_site=".$nNumgSite;
			$sSql .= " AND numg_fase=".$nNumgFase;
			$sSql .= " AND data_diario=".FormataDataConsulta($sDataDiario);

			try {

				Oad::conectar();
				$oResult = Oad::consultar($sSql);

				if ($oResult->getCount() > 0){
					$this->numgDiario = $oResult->getValores(0,"numg_diario");
					$this->numgSite = $oResult->getValores(0,"numg_site");
					$this->numgFase = $oResult->getValores(0,"numg_fase");
					$this->dataDiario = $oResult->getValores(0,"data_diario");
					$this->dataCadastro = $oResult->getValores(0,"data_cadastro");
					$this->numgOperadorcad = $oResult->getValores(0,"numg_operadorcad");
					$this->dataUltimaalt = $oResult->getValores(0,"data_ultimaalt");
					$this->numgOperadoralt = $oResult->getValores(0,"numg_operadoralt");
				}

			} catch(Exception $e) {

				Erros::addErro("Fonte: SIGO.Diarios.consultarPorSiteFaseData()".$e->getMessage()."�");
				Oad::desconectar();
				return false;

			}
			Oad::desconectar();
		}


	}

	/**
	 * Data     : 16/04/2008
	 * Autor    : Rafael Santana
	 * Descri��o: busca os di�rios de acordo com os par�metros informados
	 */
	function consultarDiarios($numgSite = "", $numgFase = "", $dataDiarioIni = "", $dataDiarioFim = "",$descSituacao = "",$numrStatus="", $numgSubatividade="",$numgEmpresa ="",$numrRegiao = ""){

		if(Erros::isError()) {

			return false;

		} else {

			$sSql .= " SELECT Distinct di.numg_diario, di.data_diario, si.nome_site, fa.nome_fase,op.nome_operador";
			$sSql .= " FROM ob_diarios di";
			$sSql .= " INNER JOIN se_operadores op on di.numg_operadorcad = op.numg_operador";
			$sSql .= " LEFT JOIN ob_sites si on si.numg_site = di.numg_site";
			$sSql .= " LEFT JOIN ob_fases fa on fa.numg_fase = di.numg_fase";
			if( $numgSubatividade != ""){
			$sSql .= " LEFT JOIN ob_ativdiarios atdi on atdi.numg_diario = di.numg_diario ";
			$sSql .= " LEFT JOIN ob_executores ex on ex.numg_fase = di.numg_fase";
			}
			$sSql .= " WHERE (1=1)";
			if ($numgSite != "") { $sSql .= " AND di.numg_site=".$numgSite; }
			if ($numgFase != "") { $sSql .= " AND di.numg_fase=".$numgFase; }
			if ($dataDiarioIni != "" && $dataDiarioFim != "") {	$sSql .= " and di.data_diario between " . FormataDataConsulta($dataDiarioIni . " 00:00:00"). " and " . FormataDataConsulta($dataDiarioFim . " 23:59:59");	}
			if ($descSituacao == "L") { $sSql .= " AND not di.data_liberacao is null"; }elseif ($descSituacao == "N") { $sSql .= " AND di.data_liberacao is null"; }
			if( $numgSubatividade != ""){
				if($numrStatus != "" ){ $sSql .= " AND atdi.numg_subatividade=".$numgSubatividade." and atdi.numr_status =".$numrStatus;}
				if($numgEmpresa != "" ){ $sSql .= " AND ex.numg_subatividade=".$numgSubatividade." and numg_empresa =".$numgEmpresa;}
			}
			if ($numrRegiao != "") { $sSql .= " AND si.numr_regiao=".$numrRegiao; }
			$sSql .= " order by 2,3,4";
			//echo $sSql;
			//exit();
			try {
				

				Oad::conectar();
				$result = Oad::consultar($sSql);

				return $result;

			} catch(Exception $e) {

				Erros::addErro("Fonte: SIGO.Diarios.consultarDiarios()".$e->getMessage()."�");
				Oad::desconectar();
				return false;

			}
			Oad::desconectar();
		}


	}
	
	/**
	 * Data     : 11/08/2008
	 * Autor    : Thales A. Salvador
	 * Descri��o: busca os di�rios de acordo com os par�metros informados
	 */
	function consultarNumDiariosPorDia($numgSupervisor,$dataDiarioIni, $dataDiarioFim){

		if(Erros::isError()) {

			return false;

		} else {

			$sSql .= " SELECT di.data_diario,count(numg_diario) as count_diarios";
			$sSql .= " FROM ob_diarios di";
			$sSql .= " WHERE di.data_diario between " . FormataDataConsulta($dataDiarioIni . " 00:00:00"). " and " . FormataDataConsulta($dataDiarioFim . " 23:59:59");
			$sSql .= " and di.numg_operadorcad = ".$numgSupervisor;
			$sSql .= " GROUP BY di.data_diario";
			$sSql .= " order by 1,2";
			//echo $sSql;
			//exit();
			try {
				

				Oad::conectar();
				$result = Oad::consultar($sSql);

				return $result;

			} catch(Exception $e) {

				Erros::addErro("Fonte: SIGO.Diarios.consultarDiarios()".$e->getMessage()."�");
				Oad::desconectar();
				return false;

			}
			Oad::desconectar();
		}


	}	
	/******************************************************************
	Data     : 02/04/2008
	Autor    : Thales A. Salvador
	Descri��o: valida os dados de um di�rio antes da grava��o ou
	edi��o.
	******************************************************************/
	private function pValidaGravacao(){
		//'NOME_municipio
		if (trim($this->numgSite) != "" && trim($this->numgFase) != "" && trim($this->dataDiario) != ""){

			//SE FOR UMA INCLUS�O
			if ($this->numgDiario == 0){

				//VERIFICA SE J� EXISTE ALGUM REGISTRO CADASTRADO COM O NOME INFORMADO
				if (Oad::consultar("select numg_diario from ob_diarios where numg_site =". $this->numgSite . " and numg_fase =". $this->numgFase . " and data_diario =". FormataDataConsulta($this->dataDiario))->getCount() > 0){
					Erros::addErro("J� existe um di�rio para esta fase do site neste dia.�");
				}

			}else{

				$oResAux = Oad::consultar("select numg_diario from ob_diarios where numg_site =". $this->numgSite . " and numg_fase =". $this->numgFase . " and data_diario =". FormataDataConsulta($this->dataDiario));

				if ($oResAux->getCount() > 0){

					//SE O N� IDENTifICADOR FOR DifERENTE, SIGNifICA QUE J� EXISTE UM REGISTRO
					//COM NOME INFORMADO PARA EDI��O
					if ($oResAux->getValores(0,0) != $this->numgDiario){
						Erros::addErro("J� existe um di�rio para esta fase do site neste dia.�");
					}
				}
			}
		}

	}


	/******************************************************************
	Data     : 02/04/2008
	Autor    : Thales A. Salvador
	Descri��o: valida um di�rio antes de exclu�-lo.
	******************************************************************/
	private function pValidaExclusao($nNumgDiario){

		if (Oad::consultar("select numg_diario,numg_foto,numg_subatividade from ob_fotosatividiarios where numg_diario =". $nNumgDiario)->getCount() > 0){
			Erros::addErro("Existem fotos cadastradas para este di�rio. Para exclu�-lo, remova antes as fotos.�");
		}

	}

}
?>