<?php
/******************************************************
 Empresa: Interagi Tecnologia LTDA

 Descricao: Classe respons�vel pelo controle de Empresas
 Autor    Desenvolvedor
 
 Releases (Data, respons�vel e descri��o [�ltimo release primeiro]):
	24-03-2008 (Thales A. Salvador) [Cria��o da Classe]
*******************************************************/
include "mime/htmlMimeMail.php";

class Pendencias {

//Atributos

    protected $numgPendencia;
    private $numgSite;
    private $numgSubatividade;
    private $descProblema;
    private $descCausa;
    private $descSolucao1;
    private $descSolucao2;
    private $descSolucao3;
    private $numrSolucaoindic;
    private $numgEmpresaresp;
    private $numgEmpresaexec;
    private $descSolucaoimpl;
    private $dataSolucao;
    private $dataCadastro;
    private $numgOperadorcad;
    private $dataUltimaalt;
    private $numgOperadoralt;
    private $numgFase;
	private $numgOperadorbaixa;
	private $dataBaixa;
	private $numgOperadorlib;
	private $dataLiberacao;


//Fun��es:

    function setNumgPendencia($valor) {
       if ($valor != "") {
          $this->numgPendencia = $valor;
       } else {
          Erros::addErro("Campo Pendencia Inv�lido.�");
       }
    }

    function getNumgFase() { return $this->numgFase;}

     function setNumgFase($valor) {
       if ($valor != "") {
          $this->numgFase = $valor;
       } else {
          Erros::addErro("Campo Fase Inv�lido.�");
       }
    }

    function getNumgPendencia() { return $this->numgPendencia;}

    function setNumgSite($valor) {
       if ($valor != "") {
          $this->numgSite = $valor;
       } else {
          Erros::addErro("Campo Site Inv�lido.�");
       }
    }

    function getNumgSite() { return $this->numgSite;}


    function setNumgSubatividade($valor) {
       if ($valor != "") {
          $this->numgSubatividade = $valor;
       } else {
          Erros::addErro("Campo Atividade Inv�lido.�");
       }
    }

    function getNumgSubatividade() { return $this->numgSubatividade;}


    function setDescProblema($valor) {
       if ($valor != "") {
          $this->descProblema = $valor;
       } else {
          Erros::addErro("Campo descProblema Inv�lido.�");
       }
    }

    function getDescProblema() { return $this->descProblema;}


    function setDescCausa($valor) {
       if ($valor != "") {
          $this->descCausa = $valor;
       } else {
          Erros::addErro("Campo descCausa Inv�lido.�");
       }
    }

    function getDescCausa() { return $this->descCausa;}


    function setDescSolucao1($valor) {
       if ($valor != "") {
          $this->descSolucao1 = $valor;
       } else {
          Erros::addErro("Campo descSolucao1 Inv�lido.�");
       }
    }

    function getDescSolucao1() { return $this->descSolucao1;}


    function setDescSolucao2($valor) {
       if ($valor != "") {
          $this->descSolucao2 = $valor;
       }
    }

    function getDescSolucao2() { return $this->descSolucao2;}


    function setDescSolucao3($valor) {
       if ($valor != "") {
          $this->descSolucao3 = $valor;
       
       }
    }

    function getDescSolucao3() { return $this->descSolucao3;}


    function setNumrSolucaoindic($valor) {
       if (is_numeric($valor)) {
          $this->numrSolucaoindic = $valor;
       } else {
          Erros::addErro("N�mero de numrSolucaoindic Inv�lido.�");
       }
    }

    function getNumrSolucaoindic() { return $this->numrSolucaoindic;}


    function setNumgEmpresaresp($valor) {
       if ($valor != "") {
          $this->numgEmpresaresp = $valor;
       } else {
          Erros::addErro("Campo numgEmpresaresp Inv�lido.�");
       }
    }

    function getNumgEmpresaresp() { return $this->numgEmpresaresp;}


    function setNumgEmpresaexec($valor) {
       if ($valor != "") {
          $this->numgEmpresaexec = $valor;
       } else {
          Erros::addErro("Campo numgEmpresaexec Inv�lido.�");
       }
    }

    function getNumgEmpresaexec() { return $this->numgEmpresaexec;}


    function setDescSolucaoimpl($valor) {
       if ($valor != "") {
          $this->descSolucaoimpl = $valor;
       } else {
          Erros::addErro("Campo descSolucaoimpl Inv�lido.�");
       }
    }

    function getDescSolucaoimpl() { return $this->descSolucaoimpl;}


    function setDataSolucao($valor) {
       if ($valor != "") {
          $this->dataSolucao = $valor;
       } else {
          Erros::addErro("Data de dataSolucao Inv�lida.�");
       }
    }

    function getDataSolucao() { return $this->dataSolucao;}


    function setDataCadastro($valor) {
       if ($valor != "") {
          $this->dataCadastro = $valor;
       } else {
          Erros::addErro("Data de dataCadastro Inv�lida.�");
       }
    }

    function getDataCadastro() { return $this->dataCadastro;}


    function setNumgOperadorcad($valor) {
       if ($valor != "") {
          $this->numgOperadorcad = $valor;
       } else {
          Erros::addErro("Campo numgOperadorcad Inv�lido.�");
       }
    }

    function getNumgOperadorcad() { return $this->numgOperadorcad;}


    function setDataUltimaalt($valor) {
       if ($valor != "") {
          $this->dataUltimaalt = $valor;
       } else {
          Erros::addErro("Data de dataUltimaalt Inv�lida.�");
       }
    }

    function getDataUltimaalt() { return $this->dataUltimaalt;}


    function setNumgOperadoralt($valor) {
       if ($valor != "") {
          $this->numgOperadoralt = $valor;
       } else {
          Erros::addErro("Campo numgOperadoralt Inv�lido.�");
       }
    }

    function getNumgOperadoralt() { return $this->numgOperadoralt;}
	
	 function setDataBaixa($valor) {
       if ($valor != "") {
          $this->dataBaixa = $valor;
       } else {
          Erros::addErro("Data de dataBaixa Inv�lida.�");
       }
    }

    function getDataBaixa() { return $this->dataBaixa;}


    function setNumgOperadorbaixa($valor) {
       if ($valor != "") {
          $this->numgOperadorbaixa = $valor;
       } else {
          Erros::addErro("Campo numgOperadorbaixa Inv�lido.�");
       }
    }

    function getNumgOperadorbaixa() { return $this->numgOperadorbaixa;}

 	function setDataLiberacao($valor) {
       if ($valor != "") {
          $this->dataLiberacao = $valor;
       } else {
          Erros::addErro("Data de dataLiberacao Inv�lida.�");
       }
    }

    function getDataLiberacao() { return $this->dataLiberacao;}


    function setNumgOperadorlib($valor) {
       if ($valor != "") {
          $this->numgOperadorlib = $valor;
       } else {
          Erros::addErro("Campo numgOperadorlib Inv�lido.�");
       }
    }

    function getNumgOperadorlib() { return $this->numgOperadorlib;}


	
	/******************************************************************
	 Data     : 24/03/2008
	 Autor    : Thales A. Salvador	
	 Descri��o: preenche os atributos da classe com os valores obtidos 
	 na busca.
	******************************************************************/
	function setarDados($nNumgPendencia){
	
		if(Erros::isError()) {
			
			return false;
	
		} else {
		
			$sSql = "SELECT ";
			$sSql .= "numg_pendencia,numg_site,numg_fase,numg_subatividade,desc_problema,desc_causa,";
			$sSql .= "desc_solucao1,desc_solucao2,desc_solucao3,numr_solucaoindic,numg_empresaresp,";
			$sSql .= "numg_empresaexec,desc_solucaoimpl,data_solucao,data_cadastro,numg_operadorcad,";
			$sSql .= "data_ultimaalt,numg_operadoralt,data_baixa,numg_operadorbaixa,data_liberacao,numg_operadorlib";
			$sSql .= " FROM ob_pendencias";
			$sSql .= " WHERE numg_pendencia = ".$nNumgPendencia;
						
			try {
	
				Oad::conectar();
				$oResult = Oad::consultar($sSql);
				
			} catch(Exception $e) {
	
				Erros::addErro("Fonte: SIGO.Pendencias.setarDados()".$e->getMessage()."�");
				Oad::desconectar();
				return false;
	
			}
			Oad::desconectar();
		}
		//echo $oResult->getValores(0,"numg_subatividade");
		//exit();
		$this->numgPendencia = $oResult->getValores(0,"numg_pendencia");
		$this->numgFase = $oResult->getValores(0,"numg_fase");
		$this->numgSite = $oResult->getValores(0,"numg_site");
		$this->numgSubatividade = $oResult->getValores(0,"numg_subatividade");
		$this->descProblema = $oResult->getValores(0,"desc_problema");
		$this->descCausa = $oResult->getValores(0,"desc_causa");
		$this->descSolucao1 = $oResult->getValores(0,"desc_solucao1");
		$this->descSolucao2 = $oResult->getValores(0,"desc_solucao2");
		$this->descSolucao3 = $oResult->getValores(0,"desc_solucao3");
		$this->numrSolucaoindic = $oResult->getValores(0,"numr_solucaoindic");
		$this->numgEmpresaresp = $oResult->getValores(0,"numg_empresaresp");
		$this->numgEmpresaexec = $oResult->getValores(0,"numg_empresaexec");
		$this->descSolucaoimpl = $oResult->getValores(0,"desc_solucaoimpl");
		$this->dataSolucao = $oResult->getValores(0,"data_solucao");
		$this->dataCadastro = $oResult->getValores(0,"data_cadastro");
		$this->numgOperadorcad = $oResult->getValores(0,"numg_operadorcad");
		$this->dataUltimaalt = $oResult->getValores(0,"data_ultimaalt");
		$this->numgOperadoralt = $oResult->getValores(0,"numg_operadoralt");
		$this->dataBaixa = $oResult->getValores(0,"data_baixa");
		$this->numgOperadorBaixa = $oResult->getValores(0,"numg_operadorbaixa");
		$this->dataLiberacao = $oResult->getValores(0,"data_liberacao");
		$this->numgOperadorlib = $oResult->getValores(0,"numg_operadorlib");
				
		return true;
	}



	/******************************************************************
	 Data     : 24/03/2008
	 Autor    : Thales A. Salvador
	 Descri��o: armazena os dados da empresa no banco de dados 
	******************************************************************/
    function cadastrar(){
		if(Erros::isError()) {
			
			return false;
	
		} else {
	
			Oad::conectar();
				
			$this->pValidaGravacao();
				
			if (Erros::isError()){
				Oad::desconectar();
				return false;
			} else {
	
				try	{
				
					Oad::begin();
									
					$sSql = "INSERT INTO ob_pendencias (";
					$sSql .= "numg_site,numg_subatividade,desc_problema,desc_causa,";
					$sSql .= "desc_solucao1,desc_solucao2,desc_solucao3,numr_solucaoindic,numg_empresaresp,";
					$sSql .= "numg_operadorcad,numg_fase,data_cadastro";
					$sSql .= " ) VALUES ( ";
					$sSql .= FormataStr($this->numgSite).",".FormataNumeroGravacao($this->numgSubatividade).",";
					$sSql .= FormataStr($this->descProblema).",";
					$sSql .= FormataStr($this->descCausa).",".FormataStr($this->descSolucao1).",";
					$sSql .= FormataStr($this->descSolucao2).",".FormataStr($this->descSolucao3).",";
					$sSql .= FormataNumeroGravacao($this->numrSolucaoindic).",".FormataNumeroGravacao($this->numgEmpresaresp).",";
					$sSql .= FormataNumeroGravacao($this->numgOperadorcad).",". FormataNumeroGravacao($this->numgFase).",";
					$sSql .= "CURRENT_TIMESTAMP)";
					
					Oad::executar($sSql);
					
					$oResult = Oad::consultar("select max(numg_pendencia) from ob_pendencias");
					$this->setNumgPendencia($oResult->getValores(0,0));				
					
					Oad::commit();
				
				} catch(Exception $e) {			
				
					Erros::addErro("Fonte: SIGO.Pendencias.cadastrar(); Descri��o: ".$e->getMessage()."�");
					Oad::rollback();
					Oad::desconectar();
					return false;
				
				}
			}
			Oad::desconectar();
			return true;
		}		
    }
			
	/******************************************************************
	 Data     : 24/03/2008
	 Autor    : Thales A. Salvador
	 Descri��o: atualiza os dados de uma empresa no banco de 
	 			dados.
	******************************************************************/
    function editar(){
		if(Erros::isError()) {
			
			return false;
	
		} else {
		
			Oad::conectar();
				
			$this->pValidaGravacao();
	
			if (Erros::isError()){
				Oad::desconectar();
				return false;
			}
			else{
			
				try	{
								
					
					$sSql = "UPDATE ob_pendencias SET ";
					$sSql .= " numg_site = ".FormataStr($this->numgSite).",";
					$sSql .= " numg_fase = ".FormataNumeroGravacao($this->numgFase).",";
					$sSql .= " desc_problema = ".FormataStr($this->descProblema).",";
					$sSql .= " desc_causa = ".FormataStr($this->descCausa).",";
					$sSql .= " numg_subatividade = ".FormataNumeroGravacao($this->numgSubatividade).",";
					$sSql .= " desc_solucao1 = ".FormataStr($this->descSolucao1).",";
					$sSql .= " desc_solucao2 = ".FormataStr($this->descSolucao2).",";
					$sSql .= " desc_solucao3 = ".FormataStr($this->descSolucao3).",";
					$sSql .= " numg_empresaexec = ".FormataNumeroGravacao($this->numgEmpresaexec).",";
					$sSql .= " desc_solucaoimpl = ".FormataStr($this->descSolucaoimpl).",";
					$sSql .= " data_solucao = ".FormataDataGravacao($this->dataSolucao).",";
					$sSql .= " numg_empresaresp = ".FormataStr($this->numgEmpresaresp).",";
					$sSql .= " numr_solucaoindic = ".FormataNumeroGravacao($this->numrSolucaoindic).",";
					$sSql .= " numg_operadoralt = ".FormataStr($this->numgOperadoralt).",";
					$sSql .= " data_ultimaalt = CURRENT_TIMESTAMP";
					$sSql .= " WHERE numg_pendencia = ". FormataNumeroGravacao($this->numgPendencia);
					
					Oad::executar($sSql);
					
				} catch(Exception $e) {			
				
					Erros::addErro("Fonte: SIGO.Pendencias.editar(); Descri��o: ".$e->getMessage()."�");
					Oad::desconectar();
					return false;
				
				}
			}
			Oad::desconectar();
			return true;
		}	
	
    }
	

	/******************************************************************
	 Data     : 24/03/2008
	 Autor    : Thales A. Salvador
	 Descri��o: exclui uma empresa do banco de dados.
	******************************************************************/
    
	function excluir ($numgPendencia){
	
    	if(Erros::isError()) {
			
			return false;
	
		} else {
	
			Oad::conectar();
				
			$this->pValidaExclusao($numgPendencia);
	
			if (Erros::isError()){
				Oad::desconectar();
				return false;
			}
			else{
	
				try	{
					
							
					$sSql  = "DELETE FROM ob_pendencias";
					$sSql .= " WHERE numg_pendencia = ". FormataNumeroGravacao($numgPendencia);
					
					
					Oad::executar($sSql);
				
					
				} catch(Exception $e) {			
				
					Erros::addErro("Fonte: SIGO.Pendencias.excluir(); Descri��o: ".$e->getMessage()."�");
					Oad::desconectar();
					return false;
				
				}
			}
			Oad::desconectar();
			return true;
		}

	}
	

	/******************************************************************
	 Data     : 14/04/2008
	 Autor    : Danilo Fernandes
	 Descri��o: atualiza os dados de baixar pend�ncia 
	******************************************************************/
    function baixarPendencia(){
		if(Erros::isError()) {
			
			return false;
	
		} else {
		
			Oad::conectar();
				
			$this->pValidaGravacao();
	
			if (Erros::isError()){
				Oad::desconectar();
				return false;
			}
			else{
			
				try	{
								
					
					$sSql = "UPDATE ob_pendencias SET ";
					$sSql .= " numg_empresaexec = ".FormataNumeroGravacao($this->numgEmpresaexec).",";
					$sSql .= " desc_solucaoimpl = ".FormataStr($this->descSolucaoimpl).",";
					$sSql .= " data_solucao = ".FormataDataGravacao($this->dataSolucao).",";
					$sSql .= " numg_operadorbaixa = ".FormataNumeroGravacao($this->numgOperadorbaixa).",";
					$sSql .= " data_baixa = CURRENT_TIMESTAMP";
					$sSql .= " WHERE numg_pendencia = ". FormataNumeroGravacao($this->numgPendencia);
					
					Oad::executar($sSql);
					
				} catch(Exception $e) {			
				
					Erros::addErro("Fonte: SIGO.Pendencias.baixarPendencia(); Descri��o: ".$e->getMessage()."�");
					Oad::desconectar();
					return false;
				
				}
			}
			Oad::desconectar();
			return true;
		}	
	
    }
    
    /******************************************************************
	 Data     : 25/04/2008
	 Autor    : Thales A. Salvador
	 Descri��o: libera a pend�ncia para aparecer no relat�rio da Operadora 
	******************************************************************/
    function liberar(){
		if(Erros::isError()) {
			
			return false;
	
		} else {
		
			Oad::conectar();
				
			$this->pValidaGravacao();
	
			if (Erros::isError()){
				Oad::desconectar();
				return false;
			}
			else{
			
				try	{
								
					
					$sSql = "UPDATE ob_pendencias SET ";
					$sSql .= " numg_operadorlib = ".FormataNumeroGravacao($this->numgOperadorlib).",";
					$sSql .= " data_liberacao = CURRENT_TIMESTAMP";
					$sSql .= " WHERE numg_pendencia = ". FormataNumeroGravacao($this->numgPendencia);
					
					Oad::executar($sSql);
					
					$sSql =  " select nome_operador, desc_senha, nome_completo, desc_email ";
					$sSql .= " from se_operadores where flag_emailpendencia=true";
										
					$oResult = Oad::consultar($sSql);
					
					for ($i=0; $i<$oResult->getCount(); $i++){
						$email[$i] = $oResult->getValores($i,"desc_email");	
					}
					
					if (!empty($oResult)){
						
						$sSql =  " select s.nome_site, f.nome_fase,p.data_cadastro ";
						$sSql .= " from ob_pendencias p inner join ob_sites s on p.numg_site=s.numg_site";
						$sSql .= " inner join ob_fases f on s.numg_site=f.numg_site";
						$sSql .= " WHERE numg_pendencia = ".$this->numgPendencia;
						
						
						$oDetalhesPendencia = Oad::consultar($sSql);
						
						$mail = new htmlMimeMail();
						$mail->setFrom("Elo Telecom<lluciano@elotelecom.com.br>");
						$mail->setSubject("SIGO - Pend�ncia Liberada Para Consulta");
						$mail->setReturnPath("lluciano@elotelecom.com.br");
					
						$sMens .= "<b>Pend�ncia Liberada no Sistema SIGO.</b><br>";
						$sMens .= "<a href='http://www.elotelecom.com.br/sigo'>http://www.elotelecom.com.br/sigo</a><br>";
						$sMens .= "<br><b>Abaixo seguem os dados da pend�ncia:</b>";
						$sMens .= "<br><b>Data da Pend�ncia:</b> " . $oDetalhesPendencia->getValores(0,"data_cadastro");
						$sMens .= "<br><b>Site:</b> " . $oDetalhesPendencia->getValores(0,"nome_site");
						$sMens .= "<br><b>Fase:</b> " . $oDetalhesPendencia->getValores(0,"nome_fase");
						$sMens .= "<br><b>N�mero:</b> " . $this->numgPendencia;
						
						
						$mail->setHtml($sMens);	
						$result = $mail->send($email);
						
						
					}	
					
				} catch(Exception $e) {			
				
					Erros::addErro("Fonte: SIGO.Pendencias.liberar(); Descri��o: ".$e->getMessage()."�");
					Oad::desconectar();
					return false;
				
				}
			}
			Oad::desconectar();
			return true;
		}	
	
    }
    
	/******************************************************************
	 Data     : 24/03/2008
	 Autor    : Thales A. Salvador
	 Descri��o: retorna um Resultset contendo os dados encontrados na 
	 busca.
	******************************************************************/
    function consultarPorData ($dataInicio, $dataFim) {

		if(Erros::isError()) {
			
			return false;
	
		} else {

			$sSql = "SELECT ";
			$sSql .= "numg_pendencia,numg_site,numg_subatividade,desc_problema,desc_causa,";
			$sSql .= "desc_solucao1,desc_solucao2,desc_solucao3,numr_solucaoindic,numg_empresaresp,";
			$sSql .= "numg_empresaexec,desc_solucaoimpl,data_solucao,data_cadastro,numg_operadorcad,";
			$sSql .= "data_ultimaalt,numg_operadoralt";
			$sSql .= " FROM ob_pendencias";
			$sSql .= " WHERE data_cadastro BETWEEN '" . $dataInicio . "' AND '" . $dataFim . "'";	

			try {
	
				Oad::conectar();
				$result = Oad::consultar($sSql);
				Oad::desconectar();
				
			} catch(Exception $e) {
	
				Erros::addErro("Fonte: SIGO.Pendencias.consultarPorData()".$e->getMessage()."�");
				Oad::desconectar();				
				return false;
	
			}
			return $result;
		}
    }

    /******************************************************************
	 Data     : 24/03/2008
	 Autor    : Thales A. Salvador
	 Descri��o: retorna um Resultset contendo os dados encontrados na 
	 busca.
	******************************************************************/
    function consultarEmAberto () {

		if(Erros::isError()) {
			
			return false;
	
		} else {

			$sSql = "SELECT ";
			$sSql .= "numg_pendencia,numg_site,numg_subatividade,desc_problema,desc_causa,";
			$sSql .= "desc_solucao1,desc_solucao2,desc_solucao3,numr_solucaoindic,numg_empresaresp,";
			$sSql .= "numg_empresaexec,desc_solucaoimpl,data_solucao,data_cadastro,numg_operadorcad,";
			$sSql .= "data_ultimaalt,numg_operadoralt";
			$sSql .= " FROM ob_pendencias";
			$sSql .= " WHERE data_solucao is null";	

			try {
	
				Oad::conectar();
				$result = Oad::consultar($sSql);
				Oad::desconectar();
				
			} catch(Exception $e) {
	
				Erros::addErro("Fonte: SIGO.Pendencias.consultarEmAberto()".$e->getMessage()."�");
				Oad::desconectar();				
				return false;
	
			}
			return $result;
		}
    }

    /******************************************************************
	 Data     : 24/03/2008
	 Autor    : Thales A. Salvador
	 Descri��o: retorna um Resultset contendo os dados encontrados na 
	 busca.
	******************************************************************/
    function consultarConcluidas () {

		if(Erros::isError()) {
			
			return false;
	
		} else {

			$sSql = "SELECT ";
			$sSql .= "numg_pendencia,numg_site,numg_subatividade,desc_problema,desc_causa,";
			$sSql .= "desc_solucao1,desc_solucao2,desc_solucao3,numr_solucaoindic,numg_empresaresp,";
			$sSql .= "numg_empresaexec,desc_solucaoimpl,data_solucao,data_cadastro,numg_operadorcad,";
			$sSql .= "data_ultimaalt,numg_operadoralt";
			$sSql .= " FROM ob_pendencias";
			$sSql .= " WHERE not data_solucao is null";	

			try {
	
				Oad::conectar();
				$result = Oad::consultar($sSql);
				Oad::desconectar();
				
			} catch(Exception $e) {
	
				Erros::addErro("Fonte: SIGO.Pendencias.consultarConcluidas()".$e->getMessage()."�");
				Oad::desconectar();				
				return false;
	
			}
			return $result;
		}
    }
   
	/******************************************************************
	 Data     : 24/03/2008
	 Autor    : Thales A. Salvador
	 Descri��o: busca as pendencias cadastrados
	******************************************************************/
    function consultarTodas () {

		if(Erros::isError()) {
			
			return false;
	
		} else {

			
			$sSql = "SELECT ";
			$sSql .= "numg_pendencia,p.numg_site,p.numg_fase,p.numg_subatividade,desc_problema,desc_causa,";
			$sSql .= "desc_solucao1,desc_solucao2,desc_solucao3,numr_solucaoindic,numg_empresaresp,";
			$sSql .= "numg_empresaexec,desc_solucaoimpl,data_solucao,p.data_cadastro,p.numg_operadorcad,";
			$sSql .= "p.data_ultimaalt,p.numg_operadoralt, s.nome_site, f.nome_fase";
			$sSql .= " FROM ob_pendencias p";
			$sSql .= " INNER JOIN ob_sites s ON p.numg_site=s.numg_site";
			$sSql .= " INNER JOIN ob_fases f ON f.numg_fase=p.numg_fase";
			$sSql .= " ORDER BY p.data_cadastro";		
			
			try {
	
				Oad::conectar();
				$result = Oad::consultar($sSql);
				Oad::desconectar();
				
			} catch(Exception $e) {
	
				Erros::addErro("Fonte: SIGO.Pendencias.consultarTodas()".$e->getMessage()."�");
				Oad::desconectar();				
				return false;
	
			}
			return $result;
		}
    }
	
    /******************************************************************
	 Data     : 11/04/2008
	 Autor    : Danilo Fernandes
	 Descri��o: busca as pendencias de acordo com o site e com a fase
	******************************************************************/
    function consultarPorSiteFase ($numgSite,$numgFase) {

		if(Erros::isError()) {
			
			return false;
	
		} else {

			
			$sSql = "SELECT ";
			$sSql .= "numg_pendencia,p.numg_site,p.numg_fase,p.numg_subatividade,desc_problema,desc_causa,";
			$sSql .= "desc_solucao1,desc_solucao2,desc_solucao3,numr_solucaoindic,numg_empresaresp,";
			$sSql .= "numg_empresaexec,desc_solucaoimpl,data_solucao,p.data_cadastro,p.numg_operadorcad,";
			$sSql .= "p.data_ultimaalt,p.numg_operadoralt, s.nome_site, f.nome_fase";
			$sSql .= " FROM ob_pendencias p";
			$sSql .= " INNER JOIN ob_sites s ON p.numg_site=s.numg_site";
			$sSql .= " INNER JOIN ob_fases f ON f.numg_fase=p.numg_fase";
			$sSql .= " WHERE p.numg_site=".$numgSite." and p.numg_fase=".$numgFase;
			$sSql .= " ORDER BY p.data_cadastro";		
			
			try {
	
				Oad::conectar();
				$result = Oad::consultar($sSql);
				Oad::desconectar();
				
			} catch(Exception $e) {
	
				Erros::addErro("Fonte: SIGO.Pendencias.consultarPorSiteFase()".$e->getMessage()."�");
				Oad::desconectar();				
				return false;
	
			}
			return $result;
		}
    }

    /**
     * Data     : 16/04/2008
     * Autor    : Rafael Santana
     * Descri��o: busca as pendencias de acordo com os crit�rios informados
     */
    function consultarPendencias($numgSite = "", $numgFase = "", $numrStatus = "", $dataCadastroIni = "", $dataCadastroFim = "",$descSituacao = "",$numrRegiao = ""){

		if(Erros::isError()) {
			
			return false;
	
		} else {

			
			$sSql = "SELECT p.numg_pendencia, s.nome_site, f.nome_fase, p.data_cadastro, p.data_solucao";
			$sSql .= " FROM ob_pendencias p";
			$sSql .= " LEFT JOIN ob_sites s ON p.numg_site=s.numg_site";
			$sSql .= " LEFT JOIN ob_fases f ON f.numg_fase=p.numg_fase";
			$sSql .= " WHERE (1=1)";
			if ($numgSite != "") { $sSql .= " AND p.numg_site=".$numgSite; }
			if ($numrRegiao != "") { $sSql .= " AND s.numr_regiao=".$numrRegiao; }
			if ($numgFase != "") { $sSql .= " AND p.numg_fase=".$numgFase; }
			if ($numrStatus == "A") { $sSql .= " AND p.data_solucao is null"; } elseif ($numrStatus == "F") { $sSql .= " AND NOT p.data_solucao is null"; }
			if ($dataCadastroIni != "" && $dataCadastroFim != "") {	$sSql .= " and p.data_cadastro between " . FormataDataConsulta($dataCadastroIni . " 00:00:00"). " and " . FormataDataConsulta($dataCadastroFim . " 23:59:59");	}
			if ($descSituacao == "L") { $sSql .= " AND not p.data_liberacao is null"; }elseif ($descSituacao == "N") { $sSql .= " AND p.data_liberacao is null"; }
			$sSql .= " ORDER BY p.data_cadastro";		
			
			try {
	
				Oad::conectar();
				$result = Oad::consultar($sSql);
				Oad::desconectar();
				
			} catch(Exception $e) {
	
				Erros::addErro("Fonte: SIGO.Pendencias.consultarPendencias()".$e->getMessage()."�");
				Oad::desconectar();				
				return false;
	
			}
			return $result;
		}
    }


	/******************************************************************
	 Data     : 24/03/2008
	 Autor    : Thales A. Salvador
	 Descri��o: valida os dados de uma pend�ncia antes de cadastr�-lo ou
				edit�-lo.
	******************************************************************/
	private function pValidaGravacao(){

	    

	}
	
	
	/******************************************************************
	 Data     : 24/03/2008
	 Autor    : Thales A. Salvador
	 Descri��o: valida uma empresa antes de exclu�-lo.
	******************************************************************/
	private function pValidaExclusao($nNumgPendencia){

		if (Oad::consultar("select numg_foto from ob_fotospendencias where numg_pendencia= " . $nNumgPendencia)->getCount() > 0)	
			Erros::addErro("Esta pend�ncia possui fotos vinculadas.�");
	    
	}	
	
}
?>