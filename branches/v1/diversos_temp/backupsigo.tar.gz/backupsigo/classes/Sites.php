<?php
/******************************************************
Empresa: Interagi Tecnologia LTDA

Descricao: Classe respons�vel pelo controle de Empresas
Autor    Desenvolvedor

Releases (Data, respons�vel e descri��o [�ltimo release primeiro]):
24-03-2008 (Thales A. Salvador) [Cria��o da Classe]
*******************************************************/

class Sites {

	//Atributos

	protected $numgSite;
	private $nomeSite;
	private $numrConstrucao;
	private $siglUf;
	private $numgMunicipio;
	private $descEndereco;
	private $descLatitude;
	private $descLongitude;
	private $numrDetentora;
	private $numrTipo;
	private $numrTipotorre;
	private $numrTipobts;
	private $descPericulosidade;
	private $descPontoRef;
	private $numgOperadorcad;
	private $dataCadastro;
	private $numgOperadoralt;
	private $dataUltimaalt;
	private $numrIddetentora;
	private $numrLigacao;
	private $numrAlturaTorre;
	private $numrUndConsumidora;
	private $numrTecnologia;
	private $numrRegiao;


	//Fun��es:

	function setNumgSite($valor) {
		if ($valor != "") {
			$this->numgSite = $valor;
		} else {
			Erros::addErro("Campo numgSite Inv�lido.�");
		}
	}

	function getNumgSite() { return $this->numgSite;}


	function setNomeSite($valor) {
		if ($valor != "") {
			$this->nomeSite = $valor;
		} else {
			Erros::addErro("Campo nomeSite Inv�lido.�");
		}
	}

	function getNomeSite() { return $this->nomeSite;}


	function setNumrConstrucao($valor) {
		if (is_numeric($valor)) {
			$this->numrConstrucao = $valor;
		}
	}

	function getNumrConstrucao() { return $this->numrConstrucao;}

	function setSiglUf($valor) {
		if ($valor != "") {
			$this->siglUf = $valor;
		} else {
			Erros::addErro("Campo Estado Inv�lido.�");
		}
	}

	function getSiglUf() { return $this->siglUf;}


	function setNumgMunicipio($valor) {
		if ($valor != "") {
			$this->numgMunicipio = $valor;
		} else {
			Erros::addErro("Campo Municipio Inv�lido.�");
		}
	}

	function getNumgMunicipio() { return $this->numgMunicipio;}


	function setDescEndereco($valor) {
		if ($valor != "") {
			$this->descEndereco = $valor;
		}
	}

	function getDescEndereco() { return $this->descEndereco;}


	function setDescLatitude($valor) {
		if ($valor != "") {
			$this->descLatitude = $valor;
		}
	}

	function getDescLatitude() { return $this->descLatitude;}

	function setDescLongitude($valor) {
		if ($valor != "") {
			$this->descLongitude = $valor;
		}
	}

	function getDescLongitude() { return $this->descLongitude;}


	function setNumrDetentora($valor) {
		if ($valor != "") {
			$this->numrDetentora = $valor;
		}
	}

	function getNumrDetentora() { return $this->numrDetentora;}


	function setNumrTipo($valor) {
		if (is_numeric($valor)) {
			$this->numrTipo = $valor;
		}
	}

	function getNumrTipo() { return $this->numrTipo;}


	function setNumrTipotorre($valor) {
		if (is_numeric($valor)) {
			$this->numrTipotorre = $valor;
		}
	}

	function getNumrTipotorre() { return $this->numrTipotorre;}


	function setNumrTipobts($valor) {
		if (is_numeric($valor)) {
			$this->numrTipobts = $valor;
		}
	}

	function getNumrTipobts() { return $this->numrTipobts;}


	function setDescPericulosidade($valor) {
		if ($valor != "") {
			$this->descPericulosidade = $valor;
		}
	}

	function getDescPericulosidade() { return $this->descPericulosidade;}


	function setDescPontoRef($valor) {
		if ($valor != "") {
			$this->descPontoRef = $valor;
		}
	}

	function getDescPontoRef() { return $this->descPontoRef;}


	function setNumgOperadorcad($valor) {
		if ($valor != "") {
			$this->numgOperadorcad = $valor;
		} else {
			Erros::addErro("Campo numgOperadorcad Inv�lido.�");
		}
	}

	function getNumgOperadorcad() { return $this->numgOperadorcad;}


	function setDataCadastro($valor) {
		if ($valor != "") {
			$this->dataCadastro = $valor;
		} else {
			Erros::addErro("Data de dataCadastro Inv�lida.�");
		}
	}

	function getDataCadastro() { return $this->dataCadastro;}


	function setNumgOperadoralt($valor) {
		if ($valor != "") {
			$this->numgOperadoralt = $valor;
		} else {
			Erros::addErro("Campo numgOperadoralt Inv�lido.�");
		}
	}

	function getNumgOperadoralt() { return $this->numgOperadoralt;}


	function setDataUltimaalt($valor) {
		if ($valor != "") {
			$this->dataUltimaalt = $valor;
		} else {
			Erros::addErro("Data de dataUltimaalt Inv�lida.�");
		}
	}

	function getDataUltimaalt(){ return $this->dataUltimaalt;}
	
	function getNumrIdDetentora() { return $this->numrIddetentora;}

	function setNumrIdDetentora($valor) {
		if ($valor != "") {
			$this->numrIddetentora = $valor;
		}
	}
	
	function getNumrLigacao() { return $this->numrLigacao;}

	function setNumrLigacao($valor) {
		if ($valor != "") {
			$this->numrLigacao = $valor;
		}
	}
	
	function getNumrUndConsumidora() { return $this->numrUndConsumidora;}

	function setNumrUndConsumidora($valor) {
		if ($valor != "") {
			$this->numrUndConsumidora = $valor;
		}
	}
	
	function getNumrAlturaTorre() { return $this->numrAlturaTorre;}

	function setNumrAlturaTorre($valor) {
		if ($valor != "") {
			$this->numrAlturaTorre = $valor;
		}
	}

	function getNumrTecnologia() { return $this->numrTecnologia;}

	function setNumrTecnologia($valor) {
		if ($valor != "") {
			$this->numrTecnologia = $valor;
		}
	}
	
	function getNumrRegiao() { return $this->numrRegiao;}

	function setNumrRegiao($valor) {
		if ($valor != "") {
			$this->numrRegiao = $valor;
		}
	}
	/******************************************************************
	Data     : 24/03/2008
	Autor    : Thales A. Salvador
	Descri��o: preenche os atributos da classe com os valores obtidos
	na busca.
	******************************************************************/
	function setarDados($numgSite){

		if(Erros::isError()) {

			return false;

		} else {

			$sSql = "SELECT ";
			$sSql .= " numg_site, nome_site, numg_fase, sigl_uf, numg_municipio, ";
			$sSql .= " desc_endereco, desc_latitude,desc_longitude, numr_detentora, numr_tipo, numr_tipotorre, ";
			$sSql .= " numr_tipobts, desc_periculosidade, desc_pontoref, numg_operadorcad, data_cadastro, ";
			$sSql .= " numg_operadoralt, data_ultimaalt,numr_construcao,numr_id_detentora,numr_ligacao,numr_undconsumidora,numr_alturatorre,numr_tecnologia,numr_regiao";
			$sSql .= " FROM ob_sites";
			$sSql .= " WHERE numg_site = ".$numgSite;


			try {

				Oad::conectar();
				$vResult = Oad::consultar($sSql);

				if ($vResult->getCount() > 0){
					$this->numgSite = $numgSite;
					$this->nomeSite = $vResult->getValores(0,"nome_site");
					$this->numgFase = $vResult->getValores(0,"numg_fase");
					$this->siglUf = $vResult->getValores(0,"sigl_uf");
					$this->numgMunicipio = $vResult->getValores(0,"numg_municipio");
					$this->descEndereco = $vResult->getValores(0,"desc_endereco");
					$this->descLatitude = $vResult->getValores(0,"desc_latitude");
					$this->descLongitude= $vResult->getValores(0,"desc_longitude");
					$this->numrDetentora = $vResult->getValores(0,"numr_detentora");
					$this->numrTipo = $vResult->getValores(0,"numr_tipo");
					$this->numrTipotorre = $vResult->getValores(0,"numr_tipotorre");
					$this->numrTipobts = $vResult->getValores(0,"numr_tipobts");
					$this->descPericulosidade = $vResult->getValores(0,"desc_periculosidade");
					$this->descPontoRef = $vResult->getValores(0,"desc_pontoref");
					$this->numgOperadorcad  = $vResult->getValores(0,"numg_operadorcad");
					$this->dataCadastro = FormataDataHora($vResult->getValores(0,"data_cadastro"));
					$this->numgOperadoralt = $vResult->getValores(0,"numg_operadoralt");
					$this->dataUltimaalt = FormataDataHora($vResult->getValores(0,"data_ultimaalt"));
					$this->numrConstrucao = $vResult->getValores(0,"numr_construcao");
					$this->numrIddetentora = $vResult->getValores(0,"numr_id_detentora");
					$this->numrLigacao = $vResult->getValores(0,"numr_ligacao");
					$this->numrUndConsumidora = $vResult->getValores(0,"numr_undconsumidora");
					$this->numrAlturaTorre = $vResult->getValores(0,"numr_alturatorre");
					$this->numrTecnologia = $vResult->getValores(0,"numr_tecnologia");
					$this->numrRegiao = $vResult->getValores(0,"numr_regiao");
					
				}


			} catch(Exception $e) {

				Erros::addErro("Fonte: SIGO.Sites.setarDados()".$e->getMessage()."�");
				Oad::desconectar();
				return false;

			}
			Oad::desconectar();
		}

		return true;
	}



	/******************************************************************
	Data     : 24/03/2008
	Autor    : Thales A. Salvador
	Descri��o: armazena os dados do site no banco de dados
	******************************************************************/
	function cadastrar(){
		if(Erros::isError()) {

			return false;

		} else {

			Oad::conectar();

			$this->pValidaGravacao();

			if (Erros::isError()){
				Oad::desconectar();
				return false;
			} else {

				try	{

					Oad::begin();

					$sSql = "INSERT INTO ob_sites (";
					$sSql .= "  nome_site, numg_fase, sigl_uf, numg_municipio, ";
					$sSql .= " desc_endereco, desc_latitude,desc_longitude, numr_detentora, numr_tipo, numr_tipotorre, ";
					$sSql .= " numr_tipobts, desc_periculosidade, desc_pontoref, numg_operadorcad, data_cadastro, ";
					$sSql .= " numg_operadoralt, data_ultimaalt, numr_construcao,numr_id_detentora, numr_ligacao,numr_undconsumidora,numr_alturatorre,numr_tecnologia,numr_regiao";
					$sSql .= ") VALUES (";
					$sSql .= FormataStr($this->nomeSite).", ";
					$sSql .= FormataNumeroGravacao($this->numgFase).", ".FormataStr($this->siglUf).", ";
					$sSql .= FormataStr($this->numgMunicipio).", ".FormataStr($this->descEndereco).", ";
					$sSql .= FormataStr($this->descLatitude).", ".FormataStr($this->descLongitude).", ".FormataNumeroGravacao($this->numrDetentora).", ";
					$sSql .= FormataNumeroGravacao($this->numrTipo).", ".FormataNumeroGravacao($this->numrTipotorre).", ";
					$sSql .= FormataNumeroGravacao($this->numrTipobts).", ".FormataStr($this->descPericulosidade).", ";
					$sSql .= FormataStr($this->descPontoRef).", ".FormataStr($this->numgOperadorcad).", ";
					$sSql .= "CURRENT_TIMESTAMP, ".FormataStr($this->numgOperadoralt).", ";
					$sSql .= FormataDataGravacao($this->dataUltimaalt).", ".FormataNumeroGravacao($this->numrConstrucao).", ".FormataStr($this->numrIddetentora).",";
					$sSql .= FormataNumeroGravacao($this->numrLigacao).", ".FormataNumeroGravacao($this->numrUndConsumidora).", ".FormataValorGravacao($this->numrAlturaTorre).", ".FormataNumeroGravacao($this->numrTecnologia).", ".FormataNumeroGravacao($this->numrRegiao);
					$sSql .= ")";


					Oad::executar($sSql);

					$oResult = Oad::consultar("select max(numg_site) from ob_sites");
					$this->setNumgSite($oResult->getValores(0,0));

					if (!is_dir("imagens/upload/".$this->getNumgSite())){
						if (!mkdir("imagens/upload/".$this->getNumgSite())){
							header("Location:cadsites.php?info=4");
							exit;
						}
					}
					
					if (!is_dir("imagens/upload/".$this->getNumgSite()."/documentos/")){
						if (!mkdir("imagens/upload/".$this->getNumgSite()."/documentos/")){
							header("Location:cadsites.php?info=4");
							exit;
						}
					}

					Oad::commit();

				} catch(Exception $e) {

					Erros::addErro("Fonte: SIGO.Sites.cadastrar(); Descri��o: ".$e->getMessage()."�");
					Oad::rollback();
					Oad::desconectar();
					return false;

				}
			}
			Oad::desconectar();
			return true;
		}
	}

	/******************************************************************
	Data     : 24/03/2008
	Autor    : Thales A. Salvador
	Descri��o: atualiza os dados de uma empresa no banco de
	dados.
	******************************************************************/
	function editar(){
		if(Erros::isError()) {

			return false;

		} else {

			Oad::conectar();

			$this->pValidaGravacao();

			if (Erros::isError()){
				Oad::desconectar();
				return false;
			}
			else{

				try	{


					$sSql = "UPDATE ob_sites SET ";
					$sSql .= " nome_site = ".FormataStr($this->nomeSite).",";
					$sSql .= " numg_fase = ".FormataNumeroGravacao($this->numgFase).",";
					$sSql .= " sigl_uf = ".FormataStr($this->siglUf).",";
					$sSql .= " numg_municipio = ".FormataStr($this->numgMunicipio).",";
					$sSql .= " desc_endereco = ".FormataStr($this->descEndereco).",";
					$sSql .= " desc_latitude = ".FormataStr($this->descLatitude).",";
					$sSql .= " desc_longitude = ".FormataStr($this->descLongitude).",";
					$sSql .= " numr_detentora = ".FormataStr($this->numrDetentora).",";
					$sSql .= " numr_tipo = ".FormataNumeroGravacao($this->numrTipo).",";
					$sSql .= " numr_tipotorre = ".FormataNumeroGravacao($this->numrTipotorre).",";
					$sSql .= " numr_tipobts = ".FormataNumeroGravacao($this->numrTipobts).",";
					$sSql .= " desc_periculosidade = ".FormataStr($this->descPericulosidade).",";
					$sSql .= " desc_pontoref = ".FormataStr($this->descPontoRef).",";
					$sSql .= " numg_operadoralt = ".FormataStr($this->numgOperadoralt).",";
					$sSql .= " data_ultimaalt = CURRENT_TIMESTAMP,";
					$sSql .= " numr_construcao = ".FormataNumeroGravacao($this->numrConstrucao).",";
					$sSql .= " numr_id_detentora = ".FormataStr($this->numrIddetentora).",";
					$sSql .= " numr_ligacao = ".FormataNumeroGravacao($this->numrLigacao).",";
					$sSql .= " numr_undconsumidora = ".FormataNumeroGravacao($this->numrUndConsumidora).",";
					$sSql .= " numr_alturatorre = ".FormataValorGravacao($this->numrAlturaTorre).",";
					$sSql .= " numr_regiao = ".FormataValorGravacao($this->numrRegiao).",";
					$sSql .= " numr_tecnologia = ".FormataNumeroGravacao($this->numrTecnologia);
					$sSql .= " WHERE numg_site = ".$this->numgSite;

					Oad::executar($sSql);

				} catch(Exception $e) {

					Erros::addErro("Fonte: SIGO.Sites.editar(); Descri��o: ".$e->getMessage()."�");
					Oad::desconectar();
					return false;

				}
			}
			Oad::desconectar();
			return true;
		}

	}


	/******************************************************************
	Data     : 24/03/2008
	Autor    : Thales A. Salvador
	Descri��o: exclui uma empresa do banco de dados.
	******************************************************************/

	function excluir ($numgSite){

		if(Erros::isError()) {

			return false;

		} else {

			Oad::conectar();

			$this->pValidaExclusao($numgSite);

			if (Erros::isError()){
				Oad::desconectar();
				return false;
			}
			else{

				try	{


					$sSql  = "DELETE FROM ob_sites";
					$sSql .= " WHERE";
					$sSql .= " numg_site = ".$numgSite;

					Oad::executar($sSql);


				} catch(Exception $e) {

					Erros::addErro("Fonte: SIGO.Sites.excluir(); Descri��o: ".$e->getMessage()."�");
					Oad::desconectar();
					return false;

				}
			}
			Oad::desconectar();
			return true;
		}

	}

	
	/******************************************************************
	Data     : 24/03/2008
	Autor    : Thales A. Salvador
	Descri��o: retorna um Resultset contendo os dados encontrados na
	busca.
	******************************************************************/
	function consultarPorNome ($nomeSite) {

		if(Erros::isError()) {

			return false;

		} else {

			$sSql = "SELECT ";
			$sSql .= "numg_site,nome_site,numg_fase,sigl_uf,numg_municipio,";
			$sSql .= "desc_endereco,desc_latitude,desc_longitude,nome_detentora,numr_tipo,";
			$sSql .= "numr_tipotorre,numr_tipobts,desc_periculosidade,desc_pontoref,numg_operadorcad,";
			$sSql .= "data_cadstro,numg_operadoralt,data_ultimaalt,numr_construcao,numr_id_detentora,numr_ligacao, numr_undconsumidora, numr_alturatorre, numr_tecnologia,numr_regiao";
			$sSql .= " FROM ob_sites";
			$sSql .= " WHERE";
			$sSql .= " lower(nome_site) LIKE lower('%".addslashes($nomeSite)."%')";
			$sSql .= " ORDER BY nome_site";

			try {

				Oad::conectar();
				$result = Oad::consultar($sSql);
				Oad::desconectar();

			} catch(Exception $e) {

				Erros::addErro("Fonte: SIGO.Sites.consultarPorNome()".$e->getMessage()."�");
				Oad::desconectar();
				return false;

			}
			return $result;
		}
	}


	/******************************************************************
	Data     : 24/03/2008
	Autor    : Thales A. Salvador
	Descri��o: busca os sites cadastrados
	******************************************************************/
	function consultarTodas () {

		if(Erros::isError()) {

			return false;

		} else {

			$sSql = "SELECT ";
			$sSql .= "numg_site,nome_site,numg_fase,sigl_uf,numg_municipio,";
			$sSql .= "desc_endereco,desc_latitude,desc_longitude,numr_detentora,numr_tipo,";
			$sSql .= "numr_tipotorre,numr_tipobts,desc_periculosidade,desc_pontoref,numg_operadorcad,";
			$sSql .= "data_cadastro,numg_operadoralt,data_ultimaalt,numr_construcao,numr_id_detentora, numr_ligacao, numr_undconsumidora, numr_alturatorre, numr_tecnologia,numr_regiao";
			$sSql .= " FROM ob_sites";
			$sSql .= " ORDER BY nome_site";

			try {

				Oad::conectar();
				$result = Oad::consultar($sSql);
				Oad::desconectar();

			} catch(Exception $e) {

				Erros::addErro("Fonte: SIGO.Sites.consultarTodos()".$e->getMessage()."�");
				Oad::desconectar();
				return false;

			}
			return $result;
		}
	}

	/******************************************************************
	Data     : 24/03/2008
	Autor    : Thales A. Salvador
	Descri��o: busca os sites cadastrados
	******************************************************************/
	function consultarPorUF ($siglUf) {

		if(Erros::isError()) {

			return false;

		} else {

			$sSql = "SELECT ";
			$sSql .= "numg_site,nome_site,numg_fase,sigl_uf,numg_municipio,";
			$sSql .= "desc_endereco,desc_latitude,desc_longitude,numr_detentora,numr_tipo,";
			$sSql .= "numr_tipotorre,numr_tipobts,desc_periculosidade,desc_pontoref,numg_operadorcad,";
			$sSql .= "data_cadastro,numg_operadoralt,data_ultimaalt,numr_construcao,numr_id_detentora, numr_ligacao, numr_undconsumidora, numr_alturatorre, numr_tecnologia,numr_regiao";
			$sSql .= " FROM ob_sites";
			$sSql .= " WHERE";
			$sSql .= " lower(sigl_uf) = lower('".addslashes($siglUf)."')";
			$sSql .= " ORDER BY nome_site";

			try {

				Oad::conectar();
				$result = Oad::consultar($sSql);
				Oad::desconectar();

			} catch(Exception $e) {

				Erros::addErro("Fonte: SIGO.Sites.consultarPorUF()".$e->getMessage()."�");
				Oad::desconectar();
				return false;

			}
			return $result;
		}
	}


	/******************************************************************
	Data     : 24/03/2008
	Autor    : Thales A. Salvador
	Descri��o: valida os dados de um site antes de cadastr�-lo ou
	edit�-lo.
	Data Altera��o: 17/04/2008
	Autor    : Danilo Fernandes
	Descri��o valida a exclus�o do site de acordo com a pend�ncia e o diario 
	******************************************************************/
	private function pValidaGravacao(){

		//
		if (trim($this->nomeSite) != ""){

			//SE FOR UMA INCLUS�O
			if ($this->numgSite == 0){

				//VERIFICA SE J� EXISTE ALGUM REGISTRO CADASTRADO COM O NOME INFORMADO
				if (Oad::consultar("select numg_site from ob_sites where lower(nome_site) = lower('" . trim($this->nomeSite) . "')")->getCount() > 0){
					Erros::addErro("J� existe um Site cadastrado com o nome " . $this->nomeSite . ".�");
				}
				
				
			}else{

				$oResAux = Oad::consultar("select numg_site from ob_sites where lower(nome_site) = lower('" . trim($this->nomeSite) . "')");

				if ($oResAux->getCount() > 0){

					//SE O N� IDENTifICADOR FOR DifERENTE, SIGNifICA QUE J� EXISTE UM REGISTRO
					//COM NOME INFORMADO PARA EDI��O
					if ($oResAux->getValores(0,0) != $this->numgSite){
						Erros::addErro("J� existe um Site cadastrado com o nome " . $this->nomeSite . ".�");
					}
				}
			}
		}

	}


	/******************************************************************
	Data     : 24/03/2008
	Autor    : Thales A. Salvador
	Descri��o: valida um site antes de exclu�-lo.
	******************************************************************/
	private function pValidaExclusao($nNumgSite){
		if (Oad::consultar("select numg_fase from ob_fases where numg_site =". $nNumgSite)->getCount() > 0){
			Erros::addErro("Existe uma fase cadastrada com este site. Para exclu�-lo, remova antes a fase.�");
		}
		if (Oad::consultar("select numg_foto from ob_fotos where numg_site =". $nNumgSite)->getCount() > 0){
			Erros::addErro("Existe uma foto cadastrada com este site. Para exclu�-lo, remova antes a foto.�");
		}
		if( Oad::consultar("select numg_pendencia,numg_site from ob_pendencias  where numg_site =".$nNumgSite)->getCount() > 0){
			Erros::addErro("Existe uma pend�ncia cadastrada para este site. Para exclu�-lo, remova antes a pend�ncia .�");
		}
		if(Oad::consultar("select numg_diario,numg_site from ob_diarios where numg_site =" .$nNumgSite)->getCount() > 0){
			Erros::addErro("Existe um di�rio cadastrado para este site. Para exclu�-lo, remova antes o di�rio .�");
		}		
		
	}
	public static function atualizaUltimaAlteracao($numSite)
	{
		$sql = "UPDATE ob_sites SET data_ultimaalt = NOW() WHERE numg_site = " . $numSite;
		Oad::conectar();
		if(Oad::executar($sql))
		{
			Oad::desconectar();
			return true;
		}
		else 
		{
			Oad::desconectar();
			return false;
		}
	}
}
?>