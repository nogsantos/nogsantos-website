<?php
/************************************************************************
Empresa: Interagi Tecnologia

Descri��o: Class Formularios

Releases (Data, respons�vel e descri��o [�ltimo release primeiro]):
25/03/2008 (Danilo Fernandes)
Inclu�do este cabe�alho descrevendo a funcionalidade da p�gina
*************************************************************************/
class Site
{
	protected $numgSite;
	private $nomeSite;
	private $numrFase;
	private $numrConstrucao;
	private $numgFase;
	private $siglUf;
	private $numgMunicipio;
	private $descEndereco;
	private $descLatitude;
	private $descLongitude;
	private $numrDetentora;
	private $numrTipo;
	private $numrTipotorre;
	private $numrTipobts;
	private $descPericulosidade;
	private $descPontoRef;
	private $numgOperadorcad;
	private $dataCadastro;
	private $numgOperadoralt;
	private $dataUltimaalt;

	function setNumgSite($valor) {
		if ($valor != "") {
			$this->numgSite = $valor;
		} else {
			Erros::addErro("Campo numgSite Inv�lido.�");
		}
	}

	function getNumgSite() { return $this->numgSite;}


	function setNomeSite($valor) {
		if ($valor != "") {
			$this->nomeSite = $valor;
		} else {
			Erros::addErro("Campo nomeSite Inv�lido.�");
		}
	}

	function getNomeSite() { return $this->nomeSite;}


	function setNumrFase($valor) {
		if (is_numeric($valor)) {
			$this->numrFase = $valor;
		} else {
			Erros::addErro("N�mero de Fase do Site Inv�lido.�");
		}
	}

	function getNumrFase() { return $this->numrSite;}
	
	function setNumgFase($valor) {
		if (is_numeric($valor)) {
			$this->numgFase = $valor;
		} else {
			Erros::addErro("N�mero de Fase do Site Inv�lido.�");
		}
	}

	function getNumgFase() { return $this->numgFase;}
	
	function setNumrConstrucao($valor) {
		if (is_numeric($valor)) {
			$this->numrConstrucao = $valor;
		} else {
			Erros::addErro("N�mero de Fase do Site Inv�lido.�");
		}
	}

	function getNumrConstrucao() { return $this->numrConstrucao;}

	function setSiglUf($valor) {
		if ($valor != "") {
			$this->siglUf = $valor;
		} else {
			Erros::addErro("Campo Estado Inv�lido.�");
		}
	}

	function getSiglUf() { return $this->siglUf;}


	function setNumgMunicipio($valor) {
		if ($valor != "") {
			$this->numgMunicipio = $valor;
		} else {
			Erros::addErro("Campo Municipio Inv�lido.�");
		}
	}

	function getNumgMunicipio() { return $this->numgMunicipio;}


	function setDescEndereco($valor) {
		if ($valor != "") {
			$this->descEndereco = $valor;
		} else {
			Erros::addErro("Campo Endereco Inv�lido.�");
		}
	}

	function getDescEndereco() { return $this->descEndereco;}


	function setDescLatitude($valor) {
		if ($valor != "") {
			$this->descLatitude = $valor;
		} else {
			Erros::addErro("Campo Latitude Inv�lido.�");
		}
	}

	function getDescLatitude() { return $this->descLatitude;}
	
	function setDescLongitude($valor) {
		if ($valor != "") {
			$this->descLongitude = $valor;
		} else {
			Erros::addErro("Campo Longitude Inv�lido.�");
		}
	}

	function getDescLongitude() { return $this->descLongitude;}


	function setNumrDetentora($valor) {
		if ($valor != "") {
			$this->numrDetentora = $valor;
		} else {
			Erros::addErro("Campo nomeDetentora Inv�lido.�");
		}
	}

	function getNumrDetentora() { return $this->numrDetentora;}


	function setNumrTipo($valor) {
		if (is_numeric($valor)) {
			$this->numrTipo = $valor;
		} else {
			Erros::addErro("N�mero de numrTipo Inv�lido.�");
		}
	}

	function getNumrTipo() { return $this->numrTipo;}


	function setNumrTipotorre($valor) {
		if (is_numeric($valor)) {
			$this->numrTipotorre = $valor;
		} else {
			Erros::addErro("N�mero de numrTipotorre Inv�lido.�");
		}
	}

	function getNumrTipotorre() { return $this->numrTipotorre;}


	function setNumrTipobts($valor) {
		if (is_numeric($valor)) {
			$this->numrTipobts = $valor;
		} else {
			Erros::addErro("N�mero de numrTipobts Inv�lido.�");
		}
	}

	function getNumrTipobts() { return $this->numrTipobts;}


	function setDescPericulosidade($valor) {
		if ($valor != "") {
			$this->descPericulosidade = $valor;
		} else {
			Erros::addErro("Campo descPericulosidade Inv�lido.�");
		}
	}

	function getDescPericulosidade() { return $this->descPericulosidade;}


	function setDescPontoRef($valor) {
		if ($valor != "") {
			$this->descPontoRef = $valor;
		} else {
			Erros::addErro("Campo descPontoRef Inv�lido.�");
		}
	}

	function getDescPontoRef() { return $this->descPontoRef;}


	function setNumgOperadorcad($valor) {
		if ($valor != "") {
			$this->numgOperadorcad = $valor;
		} else {
			Erros::addErro("Campo numgOperadorcad Inv�lido.�");
		}
	}

	function getNumgOperadorcad() { return $this->numgOperadorcad;}


	function setDataCadastro($valor) {
		if ($valor != "") {
			$this->dataCadastro = $valor;
		} else {
			Erros::addErro("Data de dataCadastro Inv�lida.�");
		}
	}

	function getDataCadastro() { return $this->dataCadastro;}


	function setNumgOperadoralt($valor) {
		if ($valor != "") {
			$this->numgOperadoralt = $valor;
		} else {
			Erros::addErro("Campo numgOperadoralt Inv�lido.�");
		}
	}

	function getNumgOperadoralt() { return $this->numgOperadoralt;}


	function setDataUltimaalt($valor) {
		if ($valor != "") {
			$this->dataUltimaalt = $valor;
		} else {
			Erros::addErro("Data de dataUltimaalt Inv�lida.�");
		}
	}

	function getDataUltimaalt() { return $this->dataUltimaalt;}


	/******************************************************************
	Data     : 25/03/2008
	Autor    : Danilo Fernandes
	Descri��o: seta os dados de um formul�rio pelo seu n� identificador
	ou c�digo.
	******************************************************************/
	public function setarDados($numgSite){

		if(Erros::isError()) {

			return false;

		} else {

			try	{

				$sSql = "SELECT ";
				$sSql .= " numg_site, nome_site, numr_fase, sigl_uf, numg_municipio, ";
				$sSql .= " desc_endereco, desc_latitude,desc_longitude, numr_detentora, numr_tipo, numr_tipotorre, ";
				$sSql .= " numr_tipobts, desc_periculosidade, desc_pontoref, numg_operadorcad, data_cadastro, ";
				$sSql .= " numg_operadoralt, data_ultimaalt,numr_construcao";
				$sSql .= " FROM ob_sites";
				$sSql .= " WHERE numg_site = ".$numgSite;
				

				Oad::conectar();
				$vAux = Oad::consultar($sSql);
				Oad::desconectar();
				
				if ($vAux->getCount() > 0){
					$this->numgSite = $numgSite;
					$this->nomeSite = $vAux->getValores(0,1);
					$this->numrFase = $vAux->getValores(0,2);
					$this->siglUf = $vAux->getValores(0,3);
					$this->numgMunicipio = $vAux->getValores(0,4);
					$this->descEndereco = $vAux->getValores(0,5);
					$this->descLatitude = $vAux->getValores(0,6);
					$this->descLongitude= $vAux->getValores(0,7);
					$this->numrDetentora = $vAux->getValores(0,8); 
					$this->numrTipo = $vAux->getValores(0,9); 
					$this->numrTipotorre = $vAux->getValores(0,10); 
					$this->numrTipobts = $vAux->getValores(0,11); 
					$this->descPericulosidade = $vAux->getValores(0,12); 
					$this->descPontoRef = $vAux->getValores(0,13); 
					$this->numgOperadorCad  = $vAux->getValores(0,14);
					$this->dataCadastro = FormataDataHora($vAux->getValores(0,15));
					$this->numgOperadoralt = $vAux->getValores(0,16);
					$this->dataCadastro = FormataDataHora($vAux->getValores(0,17));				
					$this->numrConstrucao = $vAux->getValores(0,18);
				}
				
			} catch(Exception $e) {

				Erros::addErro("Fonte: SIGO.Site.setarDados(); Descri��o: ".$e->getMessage()."�");
				Oad::desconectar();
				return false;

			}
		}
	}

	/******************************************************************
	Data     : 25/08/2008
	Autor    : Danilo Fernandes
	Descri��o: cadastra os dados de um formul�rio.
	******************************************************************/
	public function cadastrar(){

		if(Erros::isError()) {

			return false;

		} else {

			Oad::conectar();

			$this->pValidaGravacao();

			if (Erros::isError()){
				Oad::desconectar();
				return false;
			}else{

				try	{

					$sSql = "INSERT INTO ob_sites (";
					$sSql .= "  nome_site, numr_fase, sigl_uf, numg_municipio, ";
					$sSql .= " desc_endereco, desc_latitude,desc_longitude, numr_detentora, numr_tipo, numr_tipotorre, ";
					$sSql .= " numr_tipobts, desc_periculosidade, desc_pontoref, numg_operadorcad, data_cadastro, ";
					$sSql .= " numg_operadoralt, data_ultimaalt, numr_construcao";
					$sSql .= ") VALUES (";
					$sSql .= FormataStr($this->nomeSite).", ";
					$sSql .= FormataNumeroGravacao($this->numrFase).", ".FormataStr($this->siglUf).", ";
					$sSql .= FormataStr($this->numgMunicipio).", ".FormataStr($this->descEndereco).", ";
					$sSql .= FormataStr($this->descLatitude).", ".FormataStr($this->descLongitude).", ".$this->numrDetentora.", ";
					$sSql .= FormataNumeroGravacao($this->numrTipo).", ".FormataNumeroGravacao($this->numrTipotorre).", ";
					$sSql .= FormataNumeroGravacao($this->numrTipobts).", ".FormataStr($this->descPericulosidade).", ";
					$sSql .= FormataStr($this->descPontoRef).", ".FormataStr($this->numgOperadorcad).", ";
					$sSql .= FormataDataGravacao($this->dataCadastro).", ".FormataStr($this->numgOperadoralt).", ";
					$sSql .= FormataDataGravacao($this->dataUltimaalt).", ".FormataNumeroGravacao($this->numrConstrucao);
					$sSql .= ")";
					
					Oad::executar($sSql);

					$vAux = Oad::consultar("select max(numg_site) from ob_sites");

					$this->setNumgSite = $vAux->getValores(0,0);

				} catch(Exception $e) {

					Erros::addErro("Fonte: SIGO.Site.cadastrar(); Descri��o: ".$e->getMessage()."�");
					Oad::desconectar();
					return false;

				}
			}
			Oad::desconectar();
			return true;
		}

	}
	/******************************************************************
	Data     : 25/03/2008
	Autor    : Danilo Fernandes
	Descri��o: edita os dados de um formul�rio.
	******************************************************************/
	public function editar(){

		if(Erros::isError()) {

			return false;

		} else {

			Oad::conectar();

			$this->pValidaGravacao();

			if (Erros::isError()){
				Oad::desconectar();
				return false;
			}else{

				try	{

					$sSql = "UPDATE ob_sites SET ";
					$sSql .= " nome_site = ".FormataStr($this->nomeSite).",";
					$sSql .= " numr_fase = ".FormataNumeroGravacao($this->numrFase).",";
					$sSql .= " sigl_uf = ".FormataStr($this->siglUf).",";
					$sSql .= " numg_municipio = ".FormataStr($this->numgMunicipio).",";
					$sSql .= " desc_endereco = ".FormataStr($this->descEndereco).",";
					$sSql .= " desc_latitude = ".FormataStr($this->descLatitude).",";
					$sSql .= " desc_longitude = ".FormataStr($this->descLongitude).",";
					$sSql .= " numr_detentora = ".FormataStr($this->numrDetentora).",";
					$sSql .= " numr_tipo = ".FormataNumeroGravacao($this->numrTipo).",";
					$sSql .= " numr_tipotorre = ".FormataNumeroGravacao($this->numrTipotorre).",";
					$sSql .= " numr_tipobts = ".FormataNumeroGravacao($this->numrTipobts).",";
					$sSql .= " desc_periculosidade = ".FormataStr($this->descPericulosidade).",";
					$sSql .= " desc_pontoref = ".FormataStr($this->descPontoRef).",";
					$sSql .= " numg_operadoralt = ".FormataStr($this->numgOperadoralt).",";
					$sSql .= " data_ultimaalt = ".FormataDataGravacao($this->dataUltimaalt).",";
					$sSql .= " numr_construcao = ".FormataNumeroGravacao($this->numrConstrucao);
					$sSql .= " WHERE numg_site = ".$this->numgSite;

					Oad::executar($sSql);

				} catch(Exception $e) {

					Erros::addErro("Fonte: SIGO.Site.editar(); Descri��o: ".$e->getMessage()."�");
					Oad::desconectar();
					return false;

				}
			}

			Oad::desconectar();
			return true;
		}
	}


	/******************************************************************
	Data     : 25/03/2008
	Autor    : Danilo Fernandes
	Descri��o: exclui os dados de um formul�rio.
	******************************************************************/
	public function excluir($nNumgSite){

		if(Erros::isError()) {

			return false;

		} else {

			Oad::conectar();

			$this->pValidaExclusao($nNumgSite);

			if (Erros::isError()){
				Oad::desconectar();
				return false;
			}else{

				try {

					$sSql = "DELETE FROM ob_sites WHERE numg_site = " . $nNumgSite;

					Oad::executar($sSql);

				} catch(Exception $e) {

					Erros::addErro("Fonte: SIGO.Site.excluir(); Descri��o: ".$e->getMessage()."�");
					Oad::desconectar();
					return false;
				}
			}

			Oad::desconectar();
			return true;
		}

	}
	
	
	
	/******************************************************************
	Data     : 25/03/2008
	Autor    : Danilo Fernandes
	Descri��o: conulta todas os sites
	******************************************************************/
	public function consultarTodas(){

		if(Erros::isError()) {

			return false;

		} else {

			try	{

				$sSql = "SELECT ";
				$sSql .= " numg_site, nome_site, numr_fase, data_cadastro";
				$sSql .= " FROM ob_sites";
				

				Oad::conectar();
				$vAux = Oad::consultar($sSql);
				Oad::desconectar();
				
				return $vAux;
				
			} catch(Exception $e) {

				Erros::addErro("Fonte: SIGO.Site.consultarTodas(); Descri��o: ".$e->getMessage()."�");
				Oad::desconectar();
				return false;

			}
		}
	}
	private function pValidaGravacao(){


	}
	private function pValidaExclusao(){


	}

}
?>