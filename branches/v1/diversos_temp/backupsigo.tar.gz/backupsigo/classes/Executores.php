<?php
/******************************************************
Empresa: Interagi Tecnologia

Descricao: Classe respons�vel pelo controle de Empresas

Releases (Data, respons�vel e descri��o [�ltimo release primeiro]):
09-06-2008 (Danilo) [Cria��o da Classe]
*******************************************************/

class Executores {

	//Atributos da Classe
	private $numgSite;
	private $numgFase;
	private $vSubatividades;
	private $numgEmpresa;

	function setVSubatividades($valor) {
		if ($valor != "") {
			$this->vSubatividades = $valor;
		} else {
			Erros::addErro("Atividades Inv�lidas.�");
		}
	}

	function getVSubatividades() { return $this->vSubatividades;}

	function setNumgEmpresa($valor) {
		if ($valor != "") {
			$this->numgEmpresa = $valor;
		} else {
			Erros::addErro("Campo numgEmpresa Inv�lido.�");
		}
	}

	function getNumgEmpresa() { return $this->numgEmpresa;}


	function setNumgSite($valor) {
		if ($valor != "") {
			$this->numgSite = $valor;
		} else {
			Erros::addErro("Campo numgSite Inv�lido.�");
		}
	}

	function getNumgSite() { return $this->numgSite;}

	function setNumgFase($valor) {
		if ($valor != "") {
			$this->numgFase = $valor;
		} else {
			Erros::addErro("Campo numgFase Inv�lido.�");
		}
	}

	function getNumgFase() { return $this->numgFase;}


	function setNumgSubatividade($valor) {
		if ($valor != "") {
			$this->numgSubatividade = $valor;
		} else {
			Erros::addErro("Campo numgSubatividade Inv�lido.�");
		}
	}

	function getNumgSubatividade() { return $this->numgSubatividade;}


	/******************************************************************
	Data     : 28/03/2008
	Autor    : Danilo Fernandes
	Descri��o: preenche os atributos da classe com os valores obtidos
	na busca.
	******************************************************************/
	function consultarExecutores($nNumgSite, $nNumgFase){

		if(Erros::isError()) {


			return false;

		} else {
			$sSql1 = "SELECT numg_subatividade from ob_executores where numg_site =".$nNumgSite." and numg_fase = ".$nNumgFase;
			//echo $sSql1."<br><br>";
			//exit();
			Oad::conectar();
			$oResult1 = Oad::consultar($sSql1);

			/*if($oResult1->getCount() == 0){

				$sSql  = " SELECT DISTINCT
							s.numg_subatividade, s.nome_subatividade, a.numg_atividade, a.nome_atividade, s.data_bloqueio
							from ob_subatividades s 
							inner join ob_atividades a on s.numg_atividade = a.numg_atividade
							";
			}else{*/
				$sSql  = " 
				
						SELECT distinct s.numg_subatividade, s.nome_subatividade, a.numg_atividade, a.nome_atividade,
						(select e1.numg_empresa from ob_executores e1 where e1.numg_site = ".$nNumgSite." and e1.numg_fase = ".$nNumgFase." and e1.numg_subatividade=s.numg_subatividade)as numg_empresa,
						s.data_bloqueio
						from ob_subatividades s 
						inner join ob_atividades a on s.numg_atividade = a.numg_atividade
						order by a.numg_atividade, s.numg_subatividade
						"; 
				
				
			//}
			try {


				$oResult = Oad::consultar($sSql);




			} catch(Exception $e) {

				Erros::addErro("Fonte: SIGO.Executores.consultarExecutores()".$e->getMessage()."�");
				Oad::desconectar();
				return false;

			}
			Oad::desconectar();
		}

		return $oResult;
	}

	
	/******************************************************************
	Data     : 31/07/2008
	Autor    : Danilo Fernandes
	Descri��o: busca todas as empresas.
	******************************************************************/
	function consultarEmpresas(){

		if(Erros::isError()) {


			return false;

		} else {
			
		$sSql = " SELECT distinct ex.numg_empresa as numg_empresa,ep.nome_empresa as nome_empresa from ob_executores ex inner join ob_empresas ep on ex.numg_empresa = ep.numg_empresa " ;
			//echo $sSql1."<br><br>";
			//exit();
			Oad::conectar();
			
		
			try {
				$oResult = Oad::consultar($sSql);

			} catch(Exception $e) {

				Erros::addErro("Fonte: SIGO.Executores.consultarEmpresas()".$e->getMessage()."�");
				Oad::desconectar();
				return false;

			}
			Oad::desconectar();
		}

		return $oResult;
	}
	
	
	 /**
     * Data     : 31/07/2008
     * Autor    : Danilo Fernandes
     * Descri��o: busca as subatividades que est�o com status nok e 
     */
    function consultarDesempenhoExecutores($numgEmpresa = "", $dataNokIni = "", $dataNokFim = ""){

		if(Erros::isError()) {
			
			return false;
	
		} else {

			$sSql  = " SELECT DISTINCT";
			$sSql .= " emp.nome_empresa,d.data_diario,nome_subatividade,s.nome_site ,f.nome_fase,ad.desc_comentario";
			$sSql .= " FROM ob_executores ex";
			$sSql .= " INNER JOIN ob_ativdiarios ad on ex.numg_subatividade = ad.numg_subatividade";
			$sSql .= " INNER JOIN ob_subatividades sub on ad.numg_subatividade = sub.numg_subatividade";
			$sSql .= " INNER JOIN ob_diarios d on ad.numg_diario = d.numg_diario";
			$sSql .= " INNER JOIN ob_sites s on s.numg_site = d.numg_site";
			$sSql .= " INNER JOIN ob_fases f on f.numg_site = d.numg_site";
			$sSql .= " INNER JOIN ob_empresas emp on emp.numg_empresa = ex.numg_empresa";
			$sSql .= " WHERE ad.numr_status = 3 AND (1=1)";
			if ($numgEmpresa != "") { $sSql .= " AND ex.numg_empresa = ".$numgEmpresa; }
			if ($dataNokIni != "" && $dataNokFim != "") {	$sSql .= " and d.data_diario between " . FormataDataConsulta($dataNokIni . " 00:00:00"). " and " . FormataDataConsulta($dataNokFim . " 23:59:59");	}
			$sSql .= " ORDER BY d.data_diario";		
			//echo $sSql;
			//exit();
			try {
	
				Oad::conectar();
				$result = Oad::consultar($sSql);
				Oad::desconectar();
				
			} catch(Exception $e) {
	
				Erros::addErro("Fonte: SIGO.Executores.consultarDesempenhoExecutores()".$e->getMessage()."�");
				Oad::desconectar();				
				return false;
	
			}
			return $result;
		}
    }
	/******************************************************************
	Data     : 28/03/2008
	Autor    : Danilo Fernandes
	Descri��o: armazena os dados da empresa no banco de dados
	******************************************************************/
	function cadastrar(){
		if(Erros::isError()) {

			return false;

		} else {

			Oad::conectar();

			$this->pValidaGravacao();

			if (Erros::isError()){
				Oad::desconectar();
				return false;
			} else {

				try	{



					Oad::begin();

					Oad::conectar();

					for($i=0;$i<count($this->vSubatividades);$i++){
						if($this->vSubatividades[$i][0]!=""){
							$sSql = "INSERT INTO ob_executores (";
							$sSql .= " numg_site,numg_fase,numg_subatividade,numg_empresa";
							$sSql .= ") VALUES (";
							$sSql .= FormataNumeroGravacao($this->numgSite).",".FormataNumeroGravacao($this->numgFase).",".FormataNumeroGravacao($this->vSubatividades[$i][1]).",".FormataNumeroGravacao($this->vSubatividades[$i][0]);
							$sSql .= ")";
	
							Oad::executar($sSql);
						}
					}
					//exit();


					Oad::commit();

				} catch(Exception $e) {

					Erros::addErro("Fonte: SIGO.Executores.cadastrar(); Descri��o: ".$e->getMessage()."�");
					Oad::rollback();
					Oad::desconectar();
					return false;

				}
			}
			Oad::desconectar();
			return true;
		}
	}

	/******************************************************************
	Data     : 28/03/2008
	Autor    : Danilo Fernandes
	Descri��o: atualiza os dados de uma empresa no banco de
	dados.
	******************************************************************/
	function editar(){
		if(Erros::isError()) {

			return false;

		} else {

			Oad::conectar();

			$this->pValidaGravacao();

			if (Erros::isError()){
				Oad::desconectar();
				return false;
			}
			else{

				try {

					for($i=0;$i<count($this->vSubatividades);$i++){
						if($this->vSubatividades[$i][0]!=""){
							if (Oad::consultar("select numg_subatividade from ob_executores where numg_site =". $this->numgSite . " and numg_subatividade =". $this->vSubatividades[$i][1])->getCount() > 0){
								//editar
								$sSql = "UPDATE ob_executores SET ";
								$sSql .= "numg_subatividade = ".FormataNumeroGravacao($this->vSubatividades[$i][1]).",";
								$sSql .= "numg_empresa = ".FormataNumeroGravacao($this->vSubatividades[$i][0]).",";
								$sSql .= "numg_site = ".FormataNumeroGravacao($this->numgSite).",";
								$sSql .= "numg_fase = ".FormataNumeroGravacao($this->numgFase);
								$sSql .= " WHERE numg_site = ".$this->numgSite . " and numg_subatividade =". $this->vSubatividades[$i][1]." and numg_fase =".$this->numgFase;
	
							}else{
								//incluir
								$sSql = "INSERT INTO ob_executores (";
								$sSql .= "numg_site,numg_fase,numg_subatividade,numg_empresa";
								$sSql .= " ) VALUES ( ";
								$sSql .= FormataNumeroGravacao($this->numgSite).",".FormataNumeroGravacao($this->numgFase).",".FormataNumeroGravacao($this->vSubatividades[$i][1]).",";
								$sSql .= FormataNumeroGravacao($this->vSubatividades[$i][0]);
								$sSql .= ")";
							}
						
						//echo $sSql . "<br><br>";
						Oad::conectar();
						Oad::executar($sSql);
						}
						
					}
					//exit;
				} catch(Exception $e) {

					Erros::addErro("Fonte: SIGO.Executores.editar(); Descri��o: ".$e->getMessage()."�");
					Oad::desconectar();
					return false;

				}
			}
			Oad::desconectar();
			return true;
		}

	}

	/******************************************************************
	Data     : 28/03/2008
	Autor    : Danilo Fernandes
	Descri��o: exclui uma empresa no banco de dados.
	******************************************************************/
	function excluir ($numgEmpresa){

		if(Erros::isError()) {

			return false;

		} else {

			Oad::conectar();

			$this->pValidaExclusao($numgEmpresa);

			if (Erros::isError()){
				Oad::desconectar();
				return false;
			}
			else{



				$sSql  = "DELETE FROM ob_empresas";
				$sSql .= " WHERE";
				$sSql .= " numg_empresa = ".$numgEmpresa;

				try {

					Oad::conectar();
					Oad::executar($sSql);
					Oad::executar($sSql);


				} catch(Exception $e) {

					Erros::addErro("Fonte: SIGO.Sites.excluir(); Descri��o: ".$e->getMessage()."�");
					Oad::desconectar();
					return false;

				}
			}
			Oad::desconectar();
			return true;
		}

	}

	/******************************************************************
	Data     : 28/08/2008
	Autor    : Danilo Fernandes
	Descri��o: valida os dados de um municipio antes de cadastr�-lo ou
	edit�-lo.
	******************************************************************/
	function pValidaGravacao(){

		if (trim($this->numgEmpresa) == "" ){

			//SE FOR UMA INCLUS�O
			if ($this->numgEmpresa == 0){

				//VERIFICA SE J� EXISTE ALGUM REGISTRO CADASTRADO COM O NOME INFORMADO
				if (Oad::consultar("select numg_empresa from ob_empresas where nome_empresa ='". $this->nomeEmpresa."'")->getCount() > 0){
					Erros::addErro("J� existe uma Empresa cadastrado com o nome ".$this->nomeEmpresa.".�");
				}
			}
		}else{

			$oResAux = Oad::consultar("select numg_empresa,nome_empresa from ob_empresas where nome_empresa = '" . trim($this->nomeEmpresa) . "'");

			if ($oResAux->getCount() > 0){

				if ($oResAux->getValores(0,0) != $this->numgEmpresa){
					Erros::addErro("J� existe uma Empresa cadastrado com o nome " . $this->nomeEmpresa . ".�");
				}
			}

		}
	}


	/******************************************************************
	Data     : 28/03/2008
	Autor    : Danilo Fernandes
	Descri��o: valida um grupo de acesso antes de exclu�-lo.
	******************************************************************/
	private function pValidaExclusao($nNumgEmpresa){
		if (Oad::consultar("select numg_pendencia from ob_pendencias where numg_empresaresp =". $nNumgEmpresa." or numg_empresaexec=".$nNumgEmpresa)->getCount() > 0){
			Erros::addErro("Existe uma pend�ncia cadastrada para essa empresa. Para exclu�-lo, remova antes a fase.�");
		}

	}

}
?>