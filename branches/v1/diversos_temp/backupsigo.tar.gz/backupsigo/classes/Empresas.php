<?php
/******************************************************
Empresa: Interagi Tecnologia

Descricao: Classe respons�vel pelo controle de Empresas

Releases (Data, respons�vel e descri��o [�ltimo release primeiro]):
28-03-2008 (Danilo) [Cria��o da Classe]
*******************************************************/

class Empresas {

	//PROPRIEDADES DO OPERADOR
	private $numgEmpresa;
	private $nomeEmpresa;

	function setNumgEmpresa($valor) {
		if ($valor != "") {
			$this->numgEmpresa = $valor;
		} else {
			Erros::addErro("Campo numgEmpresa Inv�lido.�");
		}
	}

	function getNumgEmpresa() { return $this->numgEmpresa;}


	function setNomeEmpresa($valor) {
		if ($valor != "") {
			$this->nomeEmpresa = $valor;
		} else {
			Erros::addErro("Campo nome da empresa Inv�lido.�");
		}
	}

	function getNomeEmpresa() { return $this->nomeEmpresa;}

	/******************************************************************
	Data     : 28/03/2008
	Autor    : Danilo Fernandes
	Descri��o: preenche os atributos da classe com os valores obtidos
	na busca.
	******************************************************************/
	function setarDados($nNumgEmpresa){

		if(Erros::isError()) {

			return false;

		} else {

			$sSql  = " SELECT ";
			$sSql .= " numg_empresa, nome_empresa";
			$sSql .= " FROM ob_empresas";
			$sSql .= " WHERE numg_empresa = ".$nNumgEmpresa;

			try {

				Oad::conectar();
				$oResult = Oad::consultar($sSql);

				if ($oResult->getCount() > 0){
					$this->numgEmpresa = $oResult->getValores(0,"numg_empresa");
					$this->nomeEmpresa = $oResult->getValores(0,"nome_empresa");
				}


			} catch(Exception $e) {

				Erros::addErro("Fonte: SIGO.Empresas.setarDados()".$e->getMessage()."�");
				Oad::desconectar();
				return false;

			}
			Oad::desconectar();
		}

		return true;
	}



	/******************************************************************
	Data     : 28/03/2008
	Autor    : Danilo Fernandes
	Descri��o: armazena os dados da empresa no banco de dados
	******************************************************************/
	function cadastrar(){
		if(Erros::isError()) {

			return false;

		} else {

			Oad::conectar();

			$this->pValidaGravacao();

			if (Erros::isError()){
				Oad::desconectar();
				return false;
			} else {

				try	{

					Oad::begin();

					$sSql = "INSERT INTO ob_empresas (";
					$sSql .= " nome_empresa";
					$sSql .= ") VALUES (";
					$sSql .= FormataStr($this->nomeEmpresa);
					$sSql .= ")";



					Oad::conectar();
					Oad::executar($sSql);
					$this->numgEmpresa = Oad::consultar("select max(numg_empresa) from ob_empresas")->getValores(0,0);
					Oad::commit();

				} catch(Exception $e) {

					Erros::addErro("Fonte: SIGO.Empresas.cadastrar(); Descri��o: ".$e->getMessage()."�");
					Oad::rollback();
					Oad::desconectar();
					return false;

				}
			}
			Oad::desconectar();
			return true;
		}
	}

	/******************************************************************
	Data     : 28/03/2008
	Autor    : Danilo Fernandes
	Descri��o: atualiza os dados de uma empresa no banco de
	dados.
	******************************************************************/
	function editar(){
		if(Erros::isError()) {

			return false;

		} else {

			Oad::conectar();

			$this->pValidaGravacao();

			if (Erros::isError()){
				Oad::desconectar();
				return false;
			}
			else{

				$sSql = "UPDATE ob_empresas SET ";
				$sSql .= " nome_empresa = ".FormataStr($this->nomeEmpresa);
				$sSql .= " WHERE numg_empresa = ".$this->numgEmpresa;

				try {

					Oad::conectar();
					Oad::executar($sSql);

				} catch(Exception $e) {

					Erros::addErro("Fonte: SIGO.Sites.editar(); Descri��o: ".$e->getMessage()."�");
					Oad::desconectar();
					return false;

				}
			}
			Oad::desconectar();
			return true;
		}

	}

	/******************************************************************
	Data     : 28/03/2008
	Autor    : Danilo Fernandes
	Descri��o: exclui uma empresa no banco de dados.
	******************************************************************/
	function excluir ($numgEmpresa){

		if(Erros::isError()) {

			return false;

		} else {

			Oad::conectar();

			$this->pValidaExclusao($numgEmpresa);

			if (Erros::isError()){
				Oad::desconectar();
				return false;
			}
			else{



				$sSql  = "DELETE FROM ob_empresas";
				$sSql .= " WHERE";
				$sSql .= " numg_empresa = ".$numgEmpresa;

				try {

					Oad::conectar();
					Oad::executar($sSql);
					Oad::executar($sSql);


				} catch(Exception $e) {

					Erros::addErro("Fonte: SIGO.Sites.excluir(); Descri��o: ".$e->getMessage()."�");
					Oad::desconectar();
					return false;

				}
			}
			Oad::desconectar();
			return true;
		}

	}

	/******************************************************************
	Data     : 28/03/2008
	Autor    : Danilo Fernandes
	Descri��o: consulta todas as empresas
	******************************************************************/
	function consultarEmpresas(){

		if(Erros::isError()) {

			return false;

		} else {

			$sSql  = " SELECT ";
			$sSql .= " numg_empresa, nome_empresa";
			$sSql .= " FROM ob_empresas";

			try {

				Oad::conectar();
				$result = Oad::consultar($sSql);

				return $result;

			} catch(Exception $e) {

				Erros::addErro("Fonte: SIGO.Empresas.consultarEmpresas()".$e->getMessage()."�");
				Oad::desconectar();
				return false;

			}
			Oad::desconectar();
		}


	}

	/******************************************************************
	Data     : 28/08/2008
	Autor    : Danilo Fernandes
	Descri��o: valida os dados de um municipio antes de cadastr�-lo ou
	edit�-lo.
	******************************************************************/
	function pValidaGravacao(){

		if (trim($this->numgEmpresa) == "" ){

			//SE FOR UMA INCLUS�O
			if ($this->numgEmpresa == 0){

				//VERIFICA SE J� EXISTE ALGUM REGISTRO CADASTRADO COM O NOME INFORMADO
				if (Oad::consultar("select numg_empresa from ob_empresas where nome_empresa ='". $this->nomeEmpresa."'")->getCount() > 0){
					Erros::addErro("J� existe uma Empresa cadastrado com o nome ".$this->nomeEmpresa.".�");
				}
			}
		}else{

			$oResAux = Oad::consultar("select numg_empresa,nome_empresa from ob_empresas where nome_empresa = '" . trim($this->nomeEmpresa) . "'");

			if ($oResAux->getCount() > 0){

				if ($oResAux->getValores(0,0) != $this->numgEmpresa){
					Erros::addErro("J� existe uma Empresa cadastrado com o nome " . $this->nomeEmpresa . ".�");
				}
			}

		}
	}


	/******************************************************************
	Data     : 28/03/2008
	Autor    : Danilo Fernandes
	Descri��o: valida um grupo de acesso antes de exclu�-lo.
	******************************************************************/
	private function pValidaExclusao($nNumgEmpresa){
		if (Oad::consultar("select numg_pendencia from ob_pendencias where numg_empresaresp =". $nNumgEmpresa." or numg_empresaexec=".$nNumgEmpresa)->getCount() > 0){
			Erros::addErro("Existe uma pend�ncia cadastrada para essa empresa. Para exclu�-lo, remova antes a fase.�");
		}

	}

}
?>