<?php
/******************************************************
Empresa: Interagi Tecnologia

Descricao: Classe respons�vel pelo controle de Empresas

Releases (Data, respons�vel e descri��o [�ltimo release primeiro]):
28-03-2008 (Danilo) [Cria��o da Classe]
*******************************************************/

class Fases {


	protected $numgFase;
	private $nomeFase;
	private $numgSite;
	private $dataBloqueio;
	private $numgOperadorBloq;
	private $nomeOperadorBloq;

	function setNumgFase($valor) {
		if ($valor != "") {
			$this->numgFase = $valor;
		} else {
			Erros::addErro("Campo n�mero da fase Inv�lido.�");
		}
	}

	function getNumgFase() { return $this->numgFase;}

	function setNomeFase($valor) {
		if ($valor != "") {
			$this->nomeFase = $valor;
		} else {
			Erros::addErro("Campo Nome da Fase Inv�lido.�");
		}
	}

	function getNomeFase() { return $this->nomeFase;}


	function setDataBloqueio($valor) {
		if ($valor != "") {
			$this->dataBloqueio = $valor;
		} else {
			Erros::addErro("Data de Data de Bloqueio Inv�lida.�");
		}
	}

	function getDataBloqueio() { return $this->dataBloqueio;}


	function setNumgOperadorBloq($valor) {
		if ($valor != "") {
			$this->numgOperadorBloq = $valor;
		} else {
			Erros::addErro("Campo Operador Bloqueio Inv�lido.�");
		}
	}

	function getNumgOperadorBloq() { return $this->numgOperadorBloq;}
	
	function getNumgSite() { return $this->numgSite;}

	function setNumgSite($valor) {
		if ($valor != "") {
			$this->numgSite = $valor;
		} else {
			Erros::addErro("Campo Site Inv�lido.�");
		}
	}
	
	function setNomeOperadorBloq($valor) {
		if ($valor != "") {
			$this->nomeOperadorBloq = $valor;
		} 
	}

	function getNomeOperadorBloq() { return $this->nomeOperadorBloq;}

	/******************************************************************
	Data     : 28/03/2008
	Autor    : Danilo Fernandes
	Descri��o: preenche os atributos da classe com os valores obtidos
	na busca.
	******************************************************************/
	function setarDados($nNumgFase){

		if(Erros::isError()) {

			return false;

		} else {

			$sSql = " SELECT ";
			$sSql .= " numg_fase, nome_fase, numg_site,ob_fases.data_bloqueio, ob_fases.numg_operadorbloq, nome_operador";
			$sSql .= " FROM ob_fases";
			$sSql .= " LEFT JOIN se_operadores on ob_fases.numg_operadorbloq = se_operadores.numg_operador";
			$sSql .= " WHERE numg_fase =".$nNumgFase;
			//echo $sSql;
			//exit();
			try {

				Oad::conectar();
				$oResult = Oad::consultar($sSql);

				if ($oResult->getCount() > 0){
					$this->numgFase = $nNumgFase;
					$this->nomeFase = $oResult->getValores(0,"nome_fase");
					$this->numgSite = $oResult->getValores(0,"numg_site");
					$this->dataBloqueio = $oResult->getValores(0,"data_bloqueio");
					$this->numgSite = $oResult->getValores(0,"numg_site");
					$this->nomeOperadorBloq = $oResult->getValores(0,"nome_operador");
				}


			} catch(Exception $e) {

				Erros::addErro("Fonte: SIGO.Fases.setarDados()".$e->getMessage()."�");
				Oad::desconectar();
				return false;

			}
			Oad::desconectar();
		}

		return true;
	}

	/******************************************************************
	Data     : 28/03/2008
	Autor    : Danilo Fernandes
	Descri��o: armazena os dados da fase no banco de dados
	******************************************************************/
	function cadastrar(){
		if(Erros::isError()) {

			return false;

		} else {

			Oad::conectar();

			$this->pValidaGravacao();

			if (Erros::isError()){
				Oad::desconectar();
				return false;
			} else {

				try	{

					Oad::begin();

					$sSql = "INSERT INTO ob_fases (";
					$sSql .= " nome_fase,numg_site";
					$sSql .= ") VALUES (";
					$sSql .= FormataStr($this->nomeFase) . "," .FormataNumeroGravacao($this->numgSite);
					$sSql .= ")";


					Oad::executar($sSql);

					$oResult = Oad::consultar("select max(numg_fase) from ob_fases");
					$this->setNumgFase($oResult->getValores(0,0));

					Oad::commit();

				} catch(Exception $e) {

					Erros::addErro("Fonte: SIGO.Fases.cadastrar(); Descri��o: ".$e->getMessage()."�");
					Oad::rollback();
					Oad::desconectar();
					return false;

				}
			}
			Oad::desconectar();
			return true;
		}
	}

	/******************************************************************
	Data     : 28/03/2008
	Autor    : Danilo Fernandes
	Descri��o: atualiza os dados de uma fase no banco de
	dados.
	******************************************************************/
	function editar () {

		Oad::conectar();

		$this->pValidaGravacao();

		if (Erros::isError()) {

			return false;

		} else {

			$sSql = " UPDATE ob_fases SET ";
			$sSql .= " nome_fase = ".FormataStr($this->nomeFase).",";
			$sSql .= " data_bloqueio = ".FormataDataGravacao($this->dataBloqueio).",";
			$sSql .= " numg_operadorbloq = ".FormataStr($this->numgOperadorBloq).", numg_site=".FormataNumeroGravacao($this->numgSite);
			$sSql .= " WHERE numg_fase = ".$this->numgFase;

			try {

				Oad::conectar();
				Oad::executar($sSql);
				Oad::desconectar();

			} catch(Exception $e) {

				Erros::addErro("Fonte: SIGO.Fases.editar()".$e->getMessage()."�");
				Oad::desconectar();
				return false;

			}
		}
		return true;
	}

	/******************************************************************
	Data     : 28/03/2008
	Autor    : Danilo Fernandes
	Descri��o: exclui uma fase no banco de dados.
	******************************************************************/
	function excluir($numgFase) {

		if(Erros::isError()) {

			return false;

		} else {

			Oad::conectar();

			$this->pValidaExclusao($numgFase);

			if (Erros::isError()){
				Oad::desconectar();
				return false;
			}
			else{

				$sSql  = "DELETE FROM ob_fases";
				$sSql .= " WHERE";
				$sSql .= " numg_fase = ".$numgFase;

				try {

					Oad::conectar();
					Oad::executar($sSql);
					Oad::desconectar();

				} catch(Exception $e) {

					Erros::addErro("Fonte: SIGO.Fases.excluir()".$e->getMessage()."�");
					Oad::desconectar();
					return false;
				}
			}
			return true;
		}
	}
	/******************************************************************
	 * Data     : 09/04/2008
	 * Autor    : Danilo Fernandes 
	 * Descri��o: bloqueia uma fase , setando a data de bloqueio
	 *			e o respons�vel.
	 *******************************************************************/
	public function bloquear(){

		if(Erros::isError()) {
			
			return false;
	
		} else {
				
			try	{
				$sSql =  " UPDATE ob_fases SET";
				$sSql .= " data_bloqueio = " . FormataDataGravacao($this->getDataBloqueio()) . ",";
				$sSql .= " numg_operadorbloq = " . $this->getNumgOperadorBloq();
				$sSql .= " WHERE numg_fase=" . $this->getNumgFase();
				
				Oad::conectar();
				Oad::executar($sSql);
				Oad::desconectar();
				return true;
			
			} catch(Exception $e) {			
			
				Erros::addErro("Fonte: Sigo.Fase.bloquear(); Descri��o: ".$e->getMessage()."�");
				Oad::desconectar();
				return false;
			
			}
		}		
	}
	
	/******************************************************************
	  Data     : 09/04/2008
	  Autor    : Danilo Fernandes
	  Descri��o: desbloqueia uma fase.
	 ******************************************************************/
	public function desbloquear(){

		if(Erros::isError()) {
			
			return false;
	
		} else {
			
			try	{
			
				$sSql =  " UPDATE ob_fases SET";
				$sSql .= " data_bloqueio = null,";
				$sSql .= " numg_operadorbloq = null";
				$sSql .= " WHERE numg_fase=" . $this->numgFase;
					
				Oad::conectar();
				Oad::executar($sSql);
				Oad::desconectar();
				return true;
				
			} catch(Exception $e) {			
			
				Erros::addErro("Fonte: Sigo.Fase.desbloquear(); Descri��o: ".$e->getMessage()."�");
				Oad::desconectar();
				return false;
			
			}
		}
	}
	/******************************************************************
	Data     : 28/03/2008
	Autor    : Danilo Fernandes
	Descri��o: consulta todas as empresas
	******************************************************************/
	function consultarTodas(){

		if(Erros::isError()) {

			return false;

		} else {

			$sSql  = " SELECT ";
			$sSql .= " numg_fase, nome_fase,numg_site, data_bloqueio, numg_operadorbloq";
			$sSql .= " FROM ob_fases";
			
			try {

				Oad::conectar();
				$result = Oad::consultar($sSql);

				return $result;

			} catch(Exception $e) {

				Erros::addErro("Fonte: SIGO.Fases.consultarTodas()".$e->getMessage()."�");
				Oad::desconectar();
				return false;

			}
			Oad::desconectar();
		}


	}

	/******************************************************************
	Data     : 28/03/2008
	Autor    : Danilo Fernandes
	Descri��o: consulta todas as empresas
	******************************************************************/
	function consultarPorSite($numgSite){

		if(Erros::isError()) {

			return false;

		} else {

			$sSql  = " SELECT ";
			$sSql .= " numg_fase, nome_fase, numg_site, data_bloqueio, numg_operadorbloq";
			$sSql .= " FROM ob_fases";
			$sSql .= " WHERE numg_site=". $numgSite;
			
			try {

				Oad::conectar();
				$result = Oad::consultar($sSql);

				return $result;

			} catch(Exception $e) {

				Erros::addErro("Fonte: SIGO.Fases.consultarPorSite()".$e->getMessage()."�");
				Oad::desconectar();
				return false;

			}
			Oad::desconectar();
		}


	}
	
	
/******************************************************************
	Data     : 09/04/2008
	Autor    : Thales A. Salvador
	Descri��o: consulta todas as fases desbloqueadas de um site
	******************************************************************/
	function consultarDesblPorSite($numgSite){

		if(Erros::isError()) {

			return false;

		} else {

			$sSql  = " SELECT ";
			$sSql .= " numg_fase, nome_fase,numg_site, data_bloqueio, numg_operadorbloq";
			$sSql .= " FROM ob_fases";
			$sSql .= " WHERE numg_site=". $numgSite;
			$sSql .= " and data_bloqueio is null";
			
			try {

				Oad::conectar();
				$result = Oad::consultar($sSql);

				return $result;

			} catch(Exception $e) {

				Erros::addErro("Fonte: SIGO.Fases.consultarDesblPorSite()".$e->getMessage()."�");
				Oad::desconectar();
				return false;

			}
			Oad::desconectar();
		}


	}
	/******************************************************************
	Data     : 17/04/2008
	Autor    : Thales A. Salvador
	Descri��o: valida os dados de uma fase antes de cadastr�-lo ou
	edit�-lo.
	******************************************************************/
	private function pValidaGravacao(){
		   //'NOME_fase
	    if (trim($this->nomeFase) != ""){
			
			//SE FOR UMA INCLUS�O
			if ($this->numgFase == 0){
					
				//VERIFICA SE J� EXISTE ALGUM REGISTRO CADASTRADO COM O NOME INFORMADO
				if (Oad::consultar("select numg_fase from ob_fases where lower(nome_fase) = lower('" . trim($this->nomeFase) . "') and numg_site = " . $this->numgSite)->getCount() > 0){
					Erros::addErro("J� existe uma fase cadastrada com o nome " . $this->nomeFase . " para este site.�");
				}
					
			}else{
					
				$oResAux = Oad::consultar("select numg_fase from ob_fases where lower(nome_fase) = lower('" . trim($this->nomeFase) . "') and numg_site = " . $this->numgSite);
					
				if ($oResAux->getCount() > 0){
							
					//SE O N� IDENTifICADOR FOR DifERENTE, SIGNifICA QUE J� EXISTE UM REGISTRO 
					//COM NOME INFORMADO PARA EDI��O
					if ($oResAux->getValores(0,0) != $this->numgFase){
						Erros::addErro("J� existe uma Fase cadastrada com o nome " . $this->nomeFase . " para este site.�");
					}
				}									
			}			
	    }

	}


	/******************************************************************
	Data     : 17/04/2008
	Autor    : Thales A. Salvador
	Descri��o: valida uma fase antes de exclu�-la.
	******************************************************************/
	private function pValidaExclusao($numgFase){
		if (Oad::consultar("select numg_diario from ob_diarios where numg_fase =". $numgFase)->getCount() > 0){
			Erros::addErro("Existem diarios cadastrados para esta fase.�");
		}
		if (Oad::consultar("select numg_pendencia from ob_pendencias where numg_fase =". $numgFase)->getCount() > 0){
			Erros::addErro("Existem pendencias cadastradas para esta fase.�");
		}
		
	}

}
?>