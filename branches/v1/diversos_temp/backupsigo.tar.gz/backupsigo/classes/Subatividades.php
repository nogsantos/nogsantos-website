<?php
/******************************************************
 Empresa: Interagi Tecnologia

 Descricao: Classe respons�vel pelo controle de Atividades
  
 Releases (Data, respons�vel e descri��o [�ltimo release primeiro]):
	29-03-2008 (Thales A. Salvador) [Cria��o da Classe]
*******************************************************/

class Subatividades {

	//PROPRIEDADES DO OPERADOR
	private $numgSubatividade;
	private $numgAtividade;
    private $nomeSubatividade;
    private $numgOperadorbloqueio;
    private $nomeOperadorbloqueio;
    private $dataBloqueio;
	
	function setNumgSubatividade($valor) {
       if ($valor != "") {
          $this->numgSubatividade = $valor;
       } else {
          Erros::addErro("Campo numgSubatividade Inv�lido.�");
       }
    }

    function getNumgSubatividade() { return $this->numgSubatividade;}
    
    function setNumgAtividade($valor) {
       if ($valor != "") {
          $this->numgAtividade = $valor;
       } else {
          Erros::addErro("Campo numgAtividade Inv�lido.�");
       }
    }

    function getNumgAtividade() { return $this->numgAtividade;}


    function setNomeSubatividade($valor) {
       if ($valor != "") {
          $this->nomeSubatividade = $valor;
       } else {
          Erros::addErro("Campo nome da subatividade Inv�lido.�");
       }
    }

    function getNomeSubatividade() { return $this->nomeSubatividade;}
    
    function setNumgOperadorbloqueio($valor) {
          $this->numgOperadorbloqueio = $valor;
       
    }
    function getNumgOperadorbloqueio() { return $this->numgOperadorbloqueio;}
    
    function getNomeOperadorbloqueio() { return $this->nomeOperadorbloqueio;}
    
     function setDatabloqueio($valor) {
          $this->dataBloqueio = $valor;
       
    }
    function getDatabloqueio() { return $this->dataBloqueio;}
	
	/******************************************************************
	 Data     : 29/03/2008
	 Autor    : Thales A. Salvador
	 Descri��o: preenche os atributos da classe com os valores obtidos 
	 na busca.
	******************************************************************/
	function setarDados($nNumgSubatividade){
	
		if(Erros::isError()) {
			
			return false;
	
		} else {
		
			$sSql  = " SELECT ";
			$sSql .= " numg_subatividade,numg_atividade, nome_subatividade,numg_operadorbloqueio,s.data_bloqueio,nome_operador";
			$sSql .= " FROM ob_subatividades s left join se_operadores o on s.numg_operadorbloqueio=o.numg_operador";
			$sSql .= " WHERE numg_subatividade = ".$nNumgSubatividade;
			
			try {
	
				Oad::conectar();
				$oResult = Oad::consultar($sSql);
				
				if ($oResult->getCount() > 0){
					$this->numgSubatividade = $oResult->getValores(0,"numg_subatividade");
					$this->numgAtividade = $oResult->getValores(0,"numg_atividade");
					$this->nomeSubatividade = $oResult->getValores(0,"nome_subatividade");
					$this->numgOperadorbloqueio = $oResult->getValores(0,"numg_operadorbloqueio");
					$this->dataBloqueio = $oResult->getValores(0,"data_bloqueio");
					$this->nomeOperadorbloqueio = $oResult->getValores(0,"nome_operador");
				}
				
				
			} catch(Exception $e) {
	
				Erros::addErro("Fonte: SIGO.Subatividades.setarDados()".$e->getMessage()."�");
				Oad::desconectar();
				return false;
	
			}
			Oad::desconectar();
		}
	
		return true;
	}



	/******************************************************************
	 Data     : 29/03/2008
	 Autor    : Thales A. Salvador
	 Descri��o: armazena os dados da subatividade no banco de dados 
	******************************************************************/
    function cadastrar(){
		if(Erros::isError()) {
			
			return false;
	
		} else {
	
			Oad::conectar();
				
			$this->pValidaGravacao();
				
			if (Erros::isError()){
				Oad::desconectar();
				return false;
			} else {
	
				try	{
				
					Oad::begin();
									
					$sSql = "INSERT INTO ob_subatividades (";
					$sSql .= " nome_subatividade,numg_atividade";
					$sSql .= ") VALUES (";
					$sSql .= FormataStr($this->nomeSubatividade).",";
					$sSql .= FormataStr($this->numgAtividade);
					$sSql .= ")";
					
					Oad::executar($sSql);
					
					$oResult = Oad::consultar("select max(numg_subatividade) from ob_subatividades");
					$this->setNumgSubatividade($oResult->getValores(0,0));				
					
					Oad::commit();
				
				} catch(Exception $e) {			
				
					Erros::addErro("Fonte: SIGO.Subatividades.cadastrar(); Descri��o: ".$e->getMessage()."�");
					Oad::rollback();
					Oad::desconectar();
					return false;
				
				}
			}
			Oad::desconectar();
			return true;
		}		
    }
	
	
	/******************************************************************
	 Data     : 29/03/2008
	 Autor    : Thales A. Salvador
	 Descri��o: atualiza os dados de uma subatividade no banco de 
	 			dados.
	******************************************************************/
    function editar () {

		if(Erros::isError()) {
			
			return false;
	
		} else {
		
			Oad::conectar();
				
			$this->pValidaGravacao();
	
			if (Erros::isError()){
				Oad::desconectar();
				return false;
			}
			else{
			
				try	{

					$sSql = "UPDATE ob_subatividades SET ";
					$sSql .= " nome_subatividade=".FormataStr($this->nomeSubatividade);
					$sSql .= " ,numg_atividade=".FormataNumeroGravacao($this->numgAtividade);
					$sSql .= " WHERE numg_subatividade=".$this->numgSubatividade;		
			
					Oad::executar($sSql);
					
				} catch(Exception $e) {			
				
					Erros::addErro("Fonte: SIGO.Subatividades.editar(); Descri��o: ".$e->getMessage()."�");
					Oad::desconectar();
					return false;
				
				}
			}
			Oad::desconectar();
			return true;
		}	
    }

	/******************************************************************
	 Data     : 28/03/2008
	 Autor    : Thales A. Salvador
	 Descri��o: exclui uma subatividade no banco de dados.
	******************************************************************/
    function excluir($numgSubatividade) {
		
		if(Erros::isError()) {
			
			return false;
	
		} else {
	
			Oad::conectar();
				
			$this->pValidaExclusao($numgSubatividade);
	
			if (Erros::isError()){
				Oad::desconectar();
				return false;
			}
			else{
	
				try	{
					
					
					$sSql  = "DELETE FROM ob_subatividades";
					$sSql .= " WHERE";
					$sSql .= " numg_subatividade = ". $numgSubatividade;
					
					Oad::executar($sSql);
				
					
				} catch(Exception $e) {			
				
					Erros::addErro("Fonte: SIGO.Subatividades.excluir(); Descri��o: ".$e->getMessage()."�");
					Oad::desconectar();
					return false;
				
				}
			}
			Oad::desconectar();
			return true;
		}

		
    }
    /******************************************************************
	 Data     : 08/10/2008
	 Autor    : Thales A. Salvador
	 Descri��o: bloqueia uma atividade.
	******************************************************************/
    function bloquear () {

		if(Erros::isError()) {
			
			return false;
	
		} else {
		
			Oad::conectar();
				
			$this->pValidaBloqueio();
	
			if (Erros::isError()){
				Oad::desconectar();
				return false;
			}
			else{
			
				try	{

					$sSql = "UPDATE ob_subatividades SET ";
					$sSql .= " numg_operadorbloqueio = ".FormataNumeroGravacao($this->numgOperadorbloqueio).",";
					$sSql .= " data_bloqueio = ".FormataDataGravacao($this->dataBloqueio);
					$sSql .= " WHERE numg_subatividade = ".$this->numgSubatividade;		
					
					Oad::executar($sSql);
					
				} catch(Exception $e) {			
				
					Erros::addErro("Fonte: SIGO.Subatividades.bloquear(); Descri��o: ".$e->getMessage()."�");
					Oad::desconectar();
					return false;
				
				}
			}
			Oad::desconectar();
			return true;
		}	
    }

    
    /******************************************************************
	 Data     : 08/10/2008
	 Autor    : Thales A. Salvador
	 Descri��o: desbloqueia uma atividade.
	******************************************************************/
    function desbloquear () {

		if(Erros::isError()) {
			
			return false;
	
		} else {
		
			Oad::conectar();
				
			
			if (Erros::isError()){
				Oad::desconectar();
				return false;
			}
			else{
			
				try	{

					$sSql = "UPDATE ob_subatividades SET ";
					$sSql .= " numg_operadorbloqueio = null,";
					$sSql .= " data_bloqueio = null";
					$sSql .= " WHERE numg_subatividade = ".$this->numgSubatividade;		
			
					Oad::executar($sSql);
					
				} catch(Exception $e) {			
				
					Erros::addErro("Fonte: SIGO.Subatividades.desbloquear(); Descri��o: ".$e->getMessage()."�");
					Oad::desconectar();
					return false;
				
				}
			}
			Oad::desconectar();
			return true;
		}	
    }
    
	/******************************************************************
	Data     : 24/03/2008
	Autor    : Thales A. Salvador
	Descri��o: busca os sites cadastrados
	******************************************************************/
	function consultarTodas() {
	
		if(Erros::isError()) {

			return false;

		} else {

			$sSql = "SELECT ";
			$sSql .= "numg_subatividade,nome_subatividade,s.numg_atividade,nome_atividade";
			$sSql .= " FROM ob_subatividades s inner join ob_atividades a on a.numg_atividade=s.numg_atividade";
			

			try {

				Oad::conectar();
				$result = Oad::consultar($sSql);
				Oad::desconectar();

			} catch(Exception $e) {

				Erros::addErro("Fonte: SIGO.Subatividades.consultarTodas()".$e->getMessage()."�");
				Oad::desconectar();
				return false;

			}
			return $result;
		}
	}
	
     /******************************************************************
	 Data     : 17/04/2008
	 Autor    : Danilo Fernandes
	 Descri��o: retorna um Resultset contendo os dados encontrados na 
	 busca.
	******************************************************************/
    function consultarSubAtiv () {

		if(Erros::isError()) {
			
			return false;
	
		} else {

			$sSql = "SELECT ";
			$sSql .= " numg_subatividade,nome_subatividade,s.numg_atividade,nome_atividade, s.data_bloqueio";
			$sSql .= " FROM ob_subatividades s inner join ob_atividades a on a.numg_atividade=s.numg_atividade";
			$sSql .= " ORDER BY nome_atividade,nome_subatividade";

			try {
	
				Oad::conectar();
				$result = Oad::consultar($sSql);
				Oad::desconectar();
				
			} catch(Exception $e) {
	
				Erros::addErro("Fonte: SIGO.Subatividades.consultarSubAtiv()".$e->getMessage()."�");
				Oad::desconectar();				
				return false;
	
			}
			return $result;
		}
    }
	/******************************************************************
	 Data     : 29/03/2008
	 Autor    : Thales A. Salvador
	 Descri��o: consulta subatividades por atividade
	******************************************************************/
	function consultarPorAtividade($nNumgAtividade){
	
		if(Erros::isError()) {
			
			return false;
	
		} else {
		
			$sSql  = " SELECT ";
			$sSql .= " numg_subatividade, nome_subatividade, s.data_bloqueio, s.numg_operadorbloqueio, o.nome_operador";
			$sSql .= " FROM ob_subatividades s left join se_operadores o on s.numg_operadorbloqueio=o.numg_operador ";
			$sSql .= " WHERE numg_atividade = ".$nNumgAtividade;
			$sSql .= " ORDER BY numg_subatividade";
				
			try {
	
				Oad::conectar();
				$result = Oad::consultar($sSql);
				
				return $result;				
				
			} catch(Exception $e) {
	
				Erros::addErro("Fonte: SIGO.Subatividades.consultarPorAtividade()".$e->getMessage()."�");
				Oad::desconectar();
				return false;
	
			}
			Oad::desconectar();
		}
	
		
	}
	
	/******************************************************************
	 Data     : 29/03/2008
	 Autor    : Thales A. Salvador
	 Descri��o: valida os dados de uma atividade antes da grava��o ou
	 			edi��o.
	******************************************************************/
	private function pValidaGravacao(){



	    //'NOME_municipio
	    if (trim($this->nomeSubatividade) != ""){
			
			//SE FOR UMA INCLUS�O
			if ($this->numgSubatividade == 0){
					
				//VERIFICA SE J� EXISTE ALGUM REGISTRO CADASTRADO COM O NOME INFORMADO
				if (Oad::consultar("select numg_subatividade from ob_subatividades where lower(nome_subatividade) = lower('" . trim($this->nomeSubatividade) . "') and numg_atividade = " . $this->numgAtividade)->getCount() > 0){
					
					
					Erros::addErro("J� existe uma Subatividade cadastrada com o nome " . $this->nomeSubatividade . ".�");
				}
					
			}else{
					
				$oResAux = Oad::consultar("select numg_subatividade from ob_subatividades where lower(nome_subatividade) = lower('" . trim($this->nomeSubatividade) . "')  and numg_atividade = " . $this->numgAtividade);
					
				if ($oResAux->getCount() > 0){
							
					//SE O N� IDENTifICADOR FOR DifERENTE, SIGNifICA QUE J� EXISTE UM REGISTRO 
					//COM NOME INFORMADO PARA EDI��O
					if ($oResAux->getValores(0,0) != $this->numgSubatividade){
						Erros::addErro("J� existe uma Subatividade cadastrada com o nome " . $this->nomeSubatividade . ".�");
					}
				}									
			}			
	    }

	}
	
	 

	
	
	/******************************************************************
	 Data     : 29/03/2008
	 Autor    : Thales A. Salvador
	 Descri��o: valida uma subatividade antes de exclu�-la.
	******************************************************************/
	private function pValidaExclusao($nNumgSubatividade){
		if (Oad::consultar("select numg_subatividade from ob_ativdiarios where numg_subatividade = " . $nNumgSubatividade)->getCount() > 0){
		    Erros::addErro("Esta subatividade possui v�nculo com algum di�rio. N�o � poss�vel exclu�-la.�");
		}
		if (Oad::consultar("select numg_subatividade from ob_pendencias where numg_subatividade = " . $nNumgSubatividade)->getCount() > 0){
		    Erros::addErro("Esta subatividade possui v�nculo com alguma pend�ncia. N�o � poss�vel exclu�-la.�");
		}
		if (Oad::consultar("select numg_subatividade from ob_executores where numg_subatividade = " . $nNumgSubatividade)->getCount() > 0){
		    Erros::addErro("Esta subatividade possui v�nculo com alguma executora. N�o � poss�vel exclu�-la.�");
		}	    
	}	
	
	/******************************************************************
	 Data     : 13/10/2008
	 Autor    : Thales A. Salvador
	 Descri��o: valida os dados de uma subatividade antes da bloquear.
	******************************************************************/
	private function pValidaBloqueio(){

	    

	}	
	
}
?>