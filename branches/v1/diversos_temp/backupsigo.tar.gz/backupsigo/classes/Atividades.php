<?php
/******************************************************
 Empresa: Interagi Tecnologia

 Descricao: Classe respons�vel pelo controle de Atividades
  
 Releases (Data, respons�vel e descri��o [�ltimo release primeiro]):
	29-03-2008 (Thales A. Salvador) [Cria��o da Classe]
*******************************************************/

class Atividades {

	//PROPRIEDADES DO OPERADOR
	private $numgAtividade;
    private $nomeAtividade;
    private $numgUsuariobloqueio;
    private $nomeOperadorbloqueio;
    private $dataBloqueio;
	
	 function setNumgAtividade($valor) {
       if ($valor != "") {
          $this->numgAtividade = $valor;
       } else {
          Erros::addErro("Campo numgAtividade Inv�lido.�");
       }
    }

    function getNumgAtividade() { return $this->numgAtividade;}


    function setNomeAtividade($valor) {
       if ($valor != "") {
          $this->nomeAtividade = $valor;
       } else {
          Erros::addErro("Campo nome da atividade Inv�lido.�");
       }
    }

    function getNomeAtividade() { return $this->nomeAtividade;}
    
    function setNumgOperadorbloqueio($valor) {
          $this->$numgOperadorbloqueio = $valor;
       
    }
    function getNumgOperadorbloqueio() { return $this->$numgOperadorbloqueio;}
    
    function getNomeOperadorbloqueio() { return $this->$nomeOperadorbloqueio;}
    
     function setDatabloqueio($valor) {
          $this->$dataBloqueio = $valor;
       
    }
    function getDatabloqueio() { return $this->$dataBloqueio;}
	
	/******************************************************************
	 Data     : 29/03/2008
	 Autor    : Thales A. Salvador
	 Descri��o: preenche os atributos da classe com os valores obtidos 
	 na busca.
	******************************************************************/
	function setarDados($nNumgAtividade){
	
		if(Erros::isError()) {
			
			return false;
	
		} else {
		
			$sSql  = " SELECT ";
			$sSql .= " numg_atividade, nome_atividade,numg_operadorbloqueio,a.data_bloqueio,nome_operador";
			$sSql .= " FROM ob_atividades a left join se_operadores o on a.numg_operadorbloqueio=o.numg_operador";
			$sSql .= " WHERE numg_atividade = ".$nNumgAtividade;
			
			try {
	
				Oad::conectar();
				$oResult = Oad::consultar($sSql);
				
				if ($oResult->getCount() > 0){
					$this->numgAtividade = $oResult->getValores(0,"numg_atividade");
					$this->nomeAtividade = $oResult->getValores(0,"nome_atividade");
					$this->numgOperadorbloqueio = $oResult->getValores(0,"numg_operadorbloqueio");
					$this->dataBloqueio = $oResult->getValores(0,"data_bloqueio");
					$this->nomeOperadorbloqueio = $oResult->getValores(0,"nome_operador");
				}
				
				
			} catch(Exception $e) {
	
				Erros::addErro("Fonte: SIGO.Atividades.setarDados()".$e->getMessage()."�");
				Oad::desconectar();
				return false;
	
			}
			Oad::desconectar();
		}
	
		return true;
	}



	/******************************************************************
	 Data     : 29/03/2008
	 Autor    : Thales A. Salvador
	 Descri��o: armazena os dados da atividade no banco de dados 
	******************************************************************/
    function cadastrar(){
		if(Erros::isError()) {
			
			return false;
	
		} else {
	
			Oad::conectar();
				
			$this->pValidaGravacao();
				
			if (Erros::isError()){
				Oad::desconectar();
				return false;
			} else {
	
				try	{
				
					Oad::begin();
									
					$sSql = "INSERT INTO ob_atividades (";
					$sSql .= " nome_atividade";
					$sSql .= ") VALUES (";
					$sSql .= FormataStr($this->nomeAtividade);
					$sSql .= ")";
				
					Oad::executar($sSql);
					
					$oResult = Oad::consultar("select max(numg_atividade) from ob_atividades");
					$this->setNumgAtividade($oResult->getValores(0,0));				
					
					Oad::commit();
				
				} catch(Exception $e) {			
				
					Erros::addErro("Fonte: SIGO.Atividades.cadastrar(); Descri��o: ".$e->getMessage()."�");
					Oad::rollback();
					Oad::desconectar();
					return false;
				
				}
			}
			Oad::desconectar();
			return true;
		}		
    }
	
	/******************************************************************
	 Data     : 29/03/2008
	 Autor    : Thales A. Salvador
	 Descri��o: atualiza os dados de uma atividade no banco de 
	 			dados.
	******************************************************************/
    function editar () {

		if(Erros::isError()) {
			
			return false;
	
		} else {
		
			Oad::conectar();
				
			$this->pValidaGravacao();
	
			if (Erros::isError()){
				Oad::desconectar();
				return false;
			}
			else{
			
				try	{

					$sSql = "UPDATE ob_atividades SET ";
					$sSql .= " nome_atividade = ".FormataStr($this->nomeAtividade);
					$sSql .= " WHERE numg_atividade = ".$this->numgAtividade;		
			
					Oad::executar($sSql);
					
				} catch(Exception $e) {			
				
					Erros::addErro("Fonte: SIGO.Atividades.editar(); Descri��o: ".$e->getMessage()."�");
					Oad::desconectar();
					return false;
				
				}
			}
			Oad::desconectar();
			return true;
		}	
    }

    
    
       
	/******************************************************************
	 Data     : 28/03/2008
	 Autor    : Thales A. Salvador
	 Descri��o: exclui uma atividade no banco de dados.
	******************************************************************/
    function excluir($numgAtividade) {
		
		if(Erros::isError()) {
			
			return false;
	
		} else {
	
			Oad::conectar();
				
			$this->pValidaExclusao($numgAtividade);
	
			if (Erros::isError()){
				Oad::desconectar();
				return false;
			}
			else{
	
				try	{
					
					
					$sSql  = "DELETE FROM ob_atividades";
					$sSql .= " WHERE";
					$sSql .= " numg_atividade = ".$numgAtividade;
					
					Oad::executar($sSql);
				
					
				} catch(Exception $e) {			
				
					Erros::addErro("Fonte: SIGO.Atividades.excluir(); Descri��o: ".$e->getMessage()."�");
					Oad::desconectar();
					return false;
				
				}
			}
			Oad::desconectar();
			return true;
		}

		
    }
    
    /******************************************************************
	 Data     : 08/10/2008
	 Autor    : Thales A. Salvador
	 Descri��o: bloqueia uma atividade.
	******************************************************************/
    function bloquear () {

		if(Erros::isError()) {
			
			return false;
	
		} else {
		
			Oad::conectar();
				
			$this->pValidaBloqueio();
	
			if (Erros::isError()){
				Oad::desconectar();
				return false;
			}
			else{
			
				try	{

					$sSql = "UPDATE ob_atividades SET ";
					$sSql .= " numg_operadorbloqueio = ".FormataNumeroGravacao($this->numgOperadorbloqueio);
					$sSql .= " data_bloqueio = ".FormataDataGravacao($this->databloqueio);
					$sSql .= " WHERE numg_atividade = ".$this->numgAtividade;		
			
					Oad::executar($sSql);
					
				} catch(Exception $e) {			
				
					Erros::addErro("Fonte: SIGO.Atividades.bloquear(); Descri��o: ".$e->getMessage()."�");
					Oad::desconectar();
					return false;
				
				}
			}
			Oad::desconectar();
			return true;
		}	
    }

    
    /******************************************************************
	 Data     : 08/10/2008
	 Autor    : Thales A. Salvador
	 Descri��o: desbloqueia uma atividade.
	******************************************************************/
    function desbloquear () {

		if(Erros::isError()) {
			
			return false;
	
		} else {
		
			Oad::conectar();
				
			
			if (Erros::isError()){
				Oad::desconectar();
				return false;
			}
			else{
			
				try	{

					$sSql = "UPDATE ob_atividades SET ";
					$sSql .= " numg_operadorbloqueio = null";
					$sSql .= " data_bloqueio = null";
					$sSql .= " WHERE numg_atividade = ".$this->numgAtividade;		
			
					Oad::executar($sSql);
					
				} catch(Exception $e) {			
				
					Erros::addErro("Fonte: SIGO.Atividades.desbloquear(); Descri��o: ".$e->getMessage()."�");
					Oad::desconectar();
					return false;
				
				}
			}
			Oad::desconectar();
			return true;
		}	
    }
    
	
	/******************************************************************
	 Data     : 29/03/2008
	 Autor    : Thales A. Salvador
	 Descri��o: consulta todas as atividades
	******************************************************************/
	function consultarAtividades(){
	
		if(Erros::isError()) {
			
			return false;
	
		} else {
		
			$sSql  = " SELECT ";
			$sSql .= " numg_atividade, nome_atividade";
			$sSql .= " FROM ob_atividades";
				
			try {
	
				Oad::conectar();
				$result = Oad::consultar($sSql);
				
				return $result;				
				
			} catch(Exception $e) {
	
				Erros::addErro("Fonte: SIGO.Atividades.consultarAtividades()".$e->getMessage()."�");
				Oad::desconectar();
				return false;
	
			}
			Oad::desconectar();
		}
	
		
	}
	
	/******************************************************************
	 Data     : 29/03/2008
	 Autor    : Thales A. Salvador
	 Descri��o: valida os dados de uma atividade antes da grava��o ou
	 			edi��o.
	******************************************************************/
	private function pValidaGravacao(){

	    //'NOME_municipio
	    if (trim($this->nomeAtividade) != ""){
			
			//SE FOR UMA INCLUS�O
			if ($this->numgAtividade == 0){
					
				//VERIFICA SE J� EXISTE ALGUM REGISTRO CADASTRADO COM O NOME INFORMADO
				if (Oad::consultar("select numg_atividade from ob_atividades where lower(nome_atividade) = lower('" . trim($this->nomeAtividade) . "')")->getCount() > 0){
					Erros::addErro("J� existe uma Atividade cadastrada com o nome " . $this->nomeAtividade . ".�");
				}
					
			}else{
					
				$oResAux = Oad::consultar("select numg_atividade from ob_atividades where lower(nome_atividade) = lower('" . trim($this->nomeAtividade) . "')");
					
				if ($oResAux->getCount() > 0){
							
					//SE O N� IDENTifICADOR FOR DifERENTE, SIGNifICA QUE J� EXISTE UM REGISTRO 
					//COM NOME INFORMADO PARA EDI��O
					if ($oResAux->getValores(0,0) != $this->numgAtividade){
						Erros::addErro("J� existe uma Atividade cadastrada com o nome " . $this->nomeAtividade . ".�");
					}
				}									
			}			
	    }

	}
	
	
	/******************************************************************
	 Data     : 29/03/2008
	 Autor    : Thales A. Salvador
	 Descri��o: valida uma atividadeantes de exclu�-la.
	******************************************************************/
	private function pValidaExclusao($nNumgAtividade){
		
		if (Oad::consultar("select numg_atividade from ob_subatividades where numg_atividade = " . $nNumgAtividade)->getCount() > 0){
		    Erros::addErro("Esta atividade possui subatividades. N�o � poss�vel exclu�-la.�");
		}
			    
	}
	
	
	/******************************************************************
	 Data     : 13/10/2008
	 Autor    : Thales A. Salvador
	 Descri��o: valida os dados de uma atividade antes da bloquear.
	******************************************************************/
	private function pValidaBloqueio(){

	    

	}	
	
}
?>