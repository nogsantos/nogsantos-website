<?php
//error_reporting(E_ALL);
/**************************************************************************
 Empresa: Net4U Solu��es Internet e Intranet

 Descri��o: objeto com as rotinas de acesso ao banco de dados PostgreSQL.
	
 Releases (Data, respons�vel e descri��o [�ltimo release primeiro]):
	27/07/2005 (Rafael C�cero) 
		Inclu�do este cabe�alho descrevendo a funcionalidade da p�gina
	04/08/2005 (Silas Junior
		Mudan�a de nomes dos m�todos da classe, adicionado suporte a
		keystring � fun��o Consultar.
						
**************************************************************************/
require_once('Resultset.php');

class Oad
{

	private static $oConexao;
	private static $vResult = array();
	private $result;
	
	/******************************************************************
	 Data     : 27/07/2005
	 Autor    : 
	 Descri��o: abre uma conex�o com o banco de dados.
	******************************************************************/
	static function conectar()
	{
		$sHost = "187.45.250.28";
		$sUser = "sigo";
		$sSenha = "locaweb1020";
		$sBd = "sigo";
		
		/*$sHost = "192.168.7.3";
		$sUser = "postgres";
		$sSenha = "123456";
		$sBd = "sigo";*/

		if(!(self::$oConexao = @pg_connect("host=$sHost port=5432 dbname=$sBd user=$sUser password=$sSenha"))) {
			throw new Exception("Erro ao conectar no banco de dados do sistema.�");			
		}

		
	}
		

	/******************************************************************
	 Data     : 27/07/2005
	 Autor    : 
	 Descri��o: abre uma conex�o com o banco de dados.
	******************************************************************/
	static function desconectar()
	{
		if(!(@pg_close())) {
			throw new Exception("Erro ao fechar o banco de dados do sistema.�");
		}
	}
	

	/******************************************************************
	 Data     : 27/07/2005
	 Autor    : 
	 Descri��o: executa uma query SQL no banco de dados.
	******************************************************************/
	static function executar($sQuery)
	{
			if(!@pg_query(self::$oConexao,$sQuery)) {									
				throw new Exception('Query: '.$sQuery.' '.pg_last_error(self::$oConexao));
			}			
	}
	

	/******************************************************************
	 Data     : 27/07/2005
	 Autor    : 
	 Descri��o: busca os dados no banco e armazena em um vetor.
	 * (Adendo: Implementada com fetch array para permitir refer�ncia
	 * por nome de coluna. Por: Silas Jr.)
	******************************************************************/
	static function consultar($sQuery) {

		$result = new Resultset();
	
		if(!($vAux = @pg_query(self::$oConexao,$sQuery))) {									
			throw new Exception('Query: '.$sQuery.' '.pg_last_error(self::$oConexao));			
		}
			
		$nRows = pg_numrows($vAux);
		$nCols = pg_numfields($vAux);
			
		if($nRows > 0){
			for($i=0; $i<=($nRows-1); $i++){
				self::$vResult[$i] = $vAuxResult = pg_fetch_array($vAux);
			}
		}
		
		$result->setValores($nRows,$nCols,self::$vResult);

		return $result;
	
	}
	/*
	public function BDConsult($sQuery)
	{
		if(!($vAux = @pg_query($_SESSION["oConexao"],$sQuery))) {									
			throw new Exception(pg_last_error($_SESSION["oConexao"]));			
		}
			
		$nRows = pg_numrows($vAux);
		$nCols = pg_numfields($vAux);
			
		if($nRows > 0){
			for($i=0; $i<=($nRows-1); $i++){
				for ($j=0; $j<=($nCols-1); $j++){
					$vResult[$i][$j] = pg_result($vAux,$i,$j); 
				}
			}
		}
			
		return $vResult;
	   	
	}	*/	
	
	/******************************************************************
	 Data     : 06/08/2005
	 Autor    : 
	 Descri��o: come�a uma transa��o com o banco de dados.
	******************************************************************/
	static function begin()
	{
		self::executar("BEGIN");
	}
	
	/******************************************************************
	 Data     : 06/08/2005
	 Autor    : 
	 Descri��o: confirma uma transa��o com o banco de dados.
	******************************************************************/
	static function commit()
	{
		self::executar("COMMIT");
	}
	
	/******************************************************************
	 Data     : 06/08/2005
	 Autor    : 
	 Descri��o: desfazer uma transa��o com o banco de dados.
	******************************************************************/
	static function rollback()
	{
		self::executar("ROLLBACK");
	}
	
}
?>
