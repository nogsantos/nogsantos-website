<?php
/******************************************************
* Empresa: Net4U Solu��es Internet e Intranet
*
* Descricao: Erros
* Autor:	 Silas Jr 
* 
* Releases (Data, respons�vel e descri��o [�ltimo release primeiro]):
*******************************************************/

class Erros {

	private static $sErros = null;
	private static $vErros = null;

	static function setaErro() {
			$_SESSION['erros'] = self::$sErros;
	}
	
	static function geraErro() {
		self::$vErros = split("�",$_SESSION['erros']);
		for ($i=0 ;$i<count(self::$vErros);$i++) {
			if (self::$vErros[$i] <> "") {
				$errcount = $i+1; 
				echo "0$errcount - ".self::$vErros[$i]."<br>".chr(13);
			}
		}
		$_SESSION['erros'] = null;
	}
	
	static function addErro($sErro) {
		
		$_SESSION['erros'] .= $sErro;

	}

	static function limpaErro() {
	
		$_SESSION['erros'] = null;
	
	}

	static function isError() {
	
		if ($_SESSION['erros']) {
		    return true;
		}
	
	}

 
}?>