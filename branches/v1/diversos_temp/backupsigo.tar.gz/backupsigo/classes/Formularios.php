<?php
/************************************************************************
 Empresa: Net4U Solu��es Internet e Intranet

 Descri��o: Class Formularios
	
 Releases (Data, respons�vel e descri��o [�ltimo release primeiro]):
	 01/08/2005 (Rafael C�cero) 
		 Inclu�do este cabe�alho descrevendo a funcionalidade da p�gina
*************************************************************************/
class Formularios
{

	//PROPRIEDADES DOS FORMUL�RIOS
	private $numgFormulario;
	private $codgFormulario;
	private $nomeFormulario;
	private $nomeCompleto;
	private $descFormulario;
	private $numrAgrupamento;
	private $flagOculto;
	private $numrOrdem;
	private $dataCadastro;
	private $nomeOperadorCad;
	private $dataBloqueio;
	private $nomeOperadorBloq;

	private $vAux, $vAux2, $sSql, $sErr;
	
	function __construct()
	{
	
	}
	
	function __destruct()
	{
	
	}
	
	function setNumgFormulario($valor){ 
		if (is_numeric($valor)){
			$this->numgFormulario = $valor;
		}else{
			Erros::addErro("N� identificador do formul�rio inv�lido.�");
		}
	}
	
	function getNumgFormulario(){ return $this->numgFormulario;}
	
	function setCodgFormulario($valor){ 
		if (trim($valor) != ""){
			$this->codgFormulario = $valor;
		}else{
			Erros::addErro("C�digo do formul�rio inv�lido.�");
		}
	}
	
	function getCodgFormulario(){ return $this->codgFormulario;}
	
	function setNomeFormulario($valor){ 
		if (trim($valor) != ""){
			$this->nomeFormulario = $valor;
		}else{
			Erros::addErro("Nome do formul�rio inv�lido.�");
		}
	}
	
	function getNomeFormulario(){ return $this->nomeFormulario;}
	
	function setNomeCompleto($valor){ 
		if (trim($valor) != ""){
			$this->nomeCompleto = $valor;
		}else{
			Erros::addErro("Nome completo do formul�rio inv�lido.�");
		}
	}
	
	function getNomeCompleto(){ return $this->nomeCompleto;}
	
	function setDescFormulario($valor){ 
		if (trim($valor) != ""){
			$this->descFormulario = $valor;
		}else{
			Erros::addErro("Descri��o do formul�rio inv�lida.�");
		}
	}
	
	function getDescFormulario(){ return $this->descFormulario;}
	
	function setNumrAgrupamento($valor){ 
		if (is_numeric($valor)){
			$this->numrAgrupamento = $valor;
		}else{
			Erros::addErro("Agrupamento do formul�rio inv�lido.�");
		}
	}
	
	function getNumrAgrupamento(){ return $this->numrAgrupamento;}
	
	function setFlagOculto($valor){ $this->flagOculto = $valor;}
	function getFlagOculto(){ return $this->flagOculto;}

	function setNumrOrdem($valor){ 
		if (is_numeric($valor)){
			$this->numrOrdem = $valor;
		}else{
			Erros::addErro("Ordem de apresenta��o do formul�rio inv�lida.�");
		}
	}
	
	function getNumrOrdem(){ return $this->numrOrdem;}
	
	function setDataCadastro($valor){ $this->dataCadastro = $valor;}
	function getDataCadastro(){ return $this->dataCadastro;}
	
	function setNumgOperadorCad($valor){ $this->numgOperadorCad = $valor;}
	function getNumgOperadorCad(){ return $this->numgOperadorCad;}

	function setNomeOperadorCad($valor){ $this->nomeOperadorCad = $valor;}
	function getNomeOperadorCad(){ return $this->nomeOperadorCad;}
	
	function setDataBloqueio($valor){ $this->dataBloqueio = $valor;}
	function getDataBloqueio(){ return $this->dataBloqueio;}
	
	function setNomeOperadorBloq($valor){ $this->nomeOperadorBloq = $valor;}
	function getNomeOperadorBloq(){ return $this->nomeOperadorBloq;}
	
	
	/******************************************************************
	 Data     : 01/08/2005
	 Autor    : Rafael C�cero
	 Descri��o: seta os dados de um formul�rio pelo seu n� identificador
				ou c�digo.
	******************************************************************/
	public function setarDadosFormulario($vDados){

		if(Erros::isError()) {
			
			return false;
	
		} else {
		
			try	{
			
				$sSql =  " select form.numg_formulario, form.codg_formulario, form.nome_formulario, form.nome_completo, form.desc_formulario, form.numr_agrupamento, flag_oculto, numr_ordem, form.data_cadastro, ope1.nome_operador, form.data_bloqueio, ope2.nome_operador";
				$sSql .= " from se_formularios form";
				$sSql .= " inner join se_operadores ope1 on ope1.numg_operador = form.numg_operadorCad";
				$sSql .= " left join se_operadores ope2 on ope2.numg_operador = form.numg_operadorBloq";
				if ($vDados[0] != ""){
				$sSql .= " where numg_formulario = " . $vDados[0];
				}else{
				$sSql .= " where lower(codg_formulario) = lower('" . $vDados[1] . "')";
				}

				Oad::conectar();
				$vAux = Oad::consultar($sSql);
				Oad::desconectar();
				
				if ($vAux->getCount() > 0){
					$this->numgFormulario = $vAux->getValores(0,0);
					$this->codgFormulario = $vAux->getValores(0,1);
					$this->nomeFormulario = $vAux->getValores(0,2);
					$this->nomeCompleto = $vAux->getValores(0,3);
					$this->descFormulario = $vAux->getValores(0,4);
					$this->numrAgrupamento = $vAux->getValores(0,5);
					$this->flagOculto = $vAux->getValores(0,6);
					$this->numrOrdem= $vAux->getValores(0,7);
					$this->dataCadastro = FormataDataHora($vAux->getValores(0,8));
					$this->nomeOperadorCad  = $vAux->getValores(0,9);
					$this->dataBloqueio = FormataDataHora($vAux->getValores(0,10));
					$this->nomeOperadorBloq = $vAux->getValores(0,11);
				}
			
			} catch(Exception $e) {			
			
				Erros::addErro("Fonte: SIGO.Formularios.setarDadosFormulario(); Descri��o: ".$e->getMessage()."�");
				Oad::desconectar();
				return false;
			
			}
		}		
	}


	/******************************************************************
	 Data     : 01/08/2005
	 Autor    : Rafael C�cero
	 Descri��o: cadastra os dados de um formul�rio.
	******************************************************************/
	public function cadastrar(){
	
		if(Erros::isError()) {
			
			return false;
	
		} else {
		
			Oad::conectar();
				
			$this->pValidaGravacao();
	
			if (Erros::isError()){
				Oad::desconectar();
				return false;
			}else{
	
				try	{
				
					$sSql =  " INSERT INTO se_formularios (codg_formulario, nome_formulario, nome_completo, desc_formulario, numr_agrupamento, flag_oculto, numr_ordem, data_cadastro, numg_operadorCad) values (";
					$sSql .= FormataStr($this->getCodgFormulario()) . ",";
					$sSql .= FormataStr($this->getNomeFormulario()) . ",";
					$sSql .= FormataStr($this->getNomeCompleto()) . ",";
					$sSql .= FormataStr($this->getDescFormulario()) . ",";
					$sSql .= $this->getNumrAgrupamento() . ",";
					$sSql .= FormataBool($this->getFlagOculto()) . ",";
					$sSql .= $this->getNumrOrdem() . ",";
					$sSql .= "CURRENT_TIMESTAMP,";
					$sSql .= $this->getNumgOperadorCad() . ")";
					
					Oad::executar($sSql);
		
					$vAux = Oad::consultar("select max(numg_formulario) from se_formularios");
					
					$this->setNumgFormulario = $vAux->getValores(0,0);
								
				} catch(Exception $e) {			
				
					Erros::addErro("Fonte: SIGO.Formularios.cadastrar(); Descri��o: ".$e->getMessage()."�");
					Oad::desconectar();
					return false;
				
				}
			}
			Oad::desconectar();
			return true;
		}		
		
	} 
	

	/******************************************************************
	 Data     : 01/08/2005
	 Autor    : Rafael C�cero
	 Descri��o: edita os dados de um formul�rio.
	******************************************************************/
	public function editar(){
	
		if(Erros::isError()) {
			
			return false;
	
		} else {
		
			Oad::conectar();
				
			$this->pValidaGravacao();
	
			if (Erros::isError()){
				Oad::desconectar();
				return false;
			}else{
	
				try	{
				
					$sSql =  " UPDATE se_formularios SET";
					$sSql .= " codg_formulario=" . FormataStr($this->getCodgFormulario()) . ",";
					$sSql .= " nome_formulario=" . FormataStr($this->getNomeFormulario()) . ",";
					$sSql .= " nome_completo=" . FormataStr($this->getNomeCompleto()) . ",";
					$sSql .= " desc_formulario=" . FormataStr($this->getDescFormulario()) . ",";
					$sSql .= " numr_agrupamento=" . $this->getNumrAgrupamento() . ",";
					$sSql .= " flag_oculto=" . FormataBool($this->getFlagOculto()) . ",";
					$sSql .= " numr_ordem=" . $this->getNumrOrdem();
					$sSql .= " WHERE numg_formulario = " . $this->getNumgFormulario();
					
					Oad::executar($sSql);
				
				} catch(Exception $e) {			
				
					Erros::addErro("Fonte: SIGO.Formularios.editar(); Descri��o: ".$e->getMessage()."�");
					Oad::desconectar();
					return false;
				
				}
			}
				
			Oad::desconectar();
			return true;
		}		
	} 
	

	/******************************************************************
	 Data     : 01/08/2005
	 Autor    : Rafael C�cero
	 Descri��o: exclui os dados de um formul�rio.
	******************************************************************/
	public function excluir($nNumgFormulario){
	
		if(Erros::isError()) {
			
			return false;
	
		} else {
		
			Oad::conectar();
				
			$this->pValidaExclusao($nNumgFormulario);
	
			if (Erros::isError()){
				Oad::desconectar();
				return false;
			}else{
	
				try {
				
					$sSql = "DELETE FROM se_formularios WHERE numg_formulario = " . $nNumgFormulario;
					
					Oad::executar($sSql);

				} catch(Exception $e) {			
				
					Erros::addErro("Fonte: SIGO.Formularios.excluir(); Descri��o: ".$e->getMessage()."�");
					Oad::desconectar();
					return false;
				}
			}
				
			Oad::desconectar();
			return true;
		}		
		
	}
	

	/******************************************************************
	 Data     : 01/08/2005
	 Autor    : Rafael C�cero
	 Descri��o: bloqueia os dados de um formul�rio, setando a data de
				bloqueio e o operador respons�vel pelo bloqueio.
	*******************************************************************/
	public function bloquear($vDados){
	
		if(Erros::isError()) {
			
			return false;
	
		} else {
	
			try {			
			
				$sSql =  " UPDATE se_formularios SET";
				$sSql .= " data_bloqueio = CURRENT_TIMESTAMP,";
				$sSql .= " numg_operadorBloq =" . $vDados[1];
				$sSql .= " WHERE numg_formulario=" . $vDados[0];
				
				Oad::conectar();
				Oad::executar($sSql);
				Oad::desconectar();
				return true;
			
			} catch(Exception $e) {			
			
				Erros::addErro("Fonte: SIGO.Formularios.bloquear(); Descri��o: ".$e->getMessage()."�");
				Oad::desconectar();
				return false;
			
			}
		}
	}
	

	/******************************************************************
	 Data     : 01/08/2005
	 Autor    : Rafael C�cero
	 Descri��o: desbloqueia um formul�rio.
	*******************************************************************/
	public function desbloquear($nNumgFormulario){
	
		if(Erros::isError()) {
			
			return false;
	
		} else {
			
			try	{
			
				$sSql =  " UPDATE se_formularios SET";
				$sSql .= " data_bloqueio=null,";
				$sSql .= " numg_operadorBloq=null";
				$sSql .= " WHERE numg_formulario=" . $nNumgFormulario;
				
				Oad::conectar();
				Oad::executar($sSql);
				Oad::desconectar();
				return true;
			
			} catch(Exception $e) {			
			
				Erros::addErro("Fonte: SIGO.Formularios.desbloquear(); Descri��o: ".$e->getMessage()."�");
				Oad::desconectar();
				return false;
			
			}
		}
	}


	/******************************************************************
	 Data     : 01/08/2005
	 Autor    : Rafael C�cero
	 Descri��o: busca os formul�rios cadastrados.
	*******************************************************************/
	public function consultarFormularios(){
		
		if(Erros::isError()) {
			
			return false;
	
		} else {

			try {
	
				$sSql =  " select numg_formulario, codg_formulario, nome_formulario, nome_completo, flag_oculto, data_bloqueio, numr_agrupamento ";
				$sSql .= " from se_formularios order by numr_agrupamento, numr_ordem";

				Oad::conectar();
				$oResult = Oad::consultar($sSql);
				Oad::desconectar();
				
			} catch(Exception $e) {
			
				Erros::addErro("Fonte: SIGO.Formularios.consultarFormularios(); Descri��o: ".$e->getMessage()."�");
				Oad::desconectar();
				return false;
			
			}
			return $oResult;
		}
		
	}
	

	/******************************************************************
	 Data     : 01/08/2005
	 Autor    : Rafael C�cero
	 Descri��o: busca os formul�rios acess�veis a um operador.
	*******************************************************************/
	public function consultarFormsOperador($nNumgOperador){
	
		if(Erros::isError()) {
			
			return false;
	
		} else {

			try {
	
				$sSql =  " select numr_agrupamento, nome_formulario, codg_formulario ";
				$sSql .= " from se_formularios ";
				$sSql .= " where flag_oculto = 'f' and data_bloqueio is null and ";
				$sSql .= " numg_formulario in (";
				$sSql .= " select distinct(numg_formulario) ";
				$sSql .= " from se_funcoes func ";
				$sSql .= " inner join se_gruposFuncoes tgf on tgf.numg_funcao = func.numg_funcao ";
				$sSql .= " inner join se_grupos gru on gru.numg_grupo = tgf.numg_grupo ";
				$sSql .= " inner join se_operadoresGrupos tog on tog.numg_grupo = gru.numg_grupo ";
				$sSql .= " where tog.numg_operador = " . $nNumgOperador;
				$sSql .= " ) order by numr_agrupamento, numr_ordem";
				
				Oad::conectar();
				$oResult = Oad::consultar($sSql);
				Oad::desconectar();
				
			} catch(Exception $e) {
			
				Erros::addErro("Fonte: SIGO.Formularios.consultarFormsOperador(); Descri��o: ".$e->getMessage()."�");
				Oad::desconectar();
				return false;
			
			}
			return $oResult;
		}
				
	}


	/******************************************************************
	 Data     : 01/08/2005
	 Autor    : Rafael C�cero
	 Descri��o: busca os formul�rios acess�veis a um operador.
	*******************************************************************/
	public function consultarFormsAdministrador(){		
	
		if(Erros::isError()) {
			
			return false;
	
		} else {

			try {
	
				$sSql =  " select numr_agrupamento, nome_formulario, codg_formulario ";
				$sSql .= " from se_formularios ";
				$sSql .= " where not flag_oculto order by numr_agrupamento, numr_ordem";

				Oad::conectar();
				$oResult = Oad::consultar($sSql);
				Oad::desconectar();
				
			} catch(Exception $e) {
			
				Erros::addErro("Fonte: SIGO.Formularios.consultarFormsAdministrador(); Descri��o: ".$e->getMessage()."�");
				Oad::desconectar();
				return false;
			
			}
			return $oResult;
		}		
	}


	/******************************************************************
	 Data     : 01/08/2005
	 Autor    : Rafael C�cero
	 Descri��o: fun��o de valida��o de formul�rio para um operador.
				O formul�rio em quest�o poder� estar bloqueado ou 
				possuir nenhuma fun��o dispon�vel para os grupos ao
				quais o operador pertence.
	*******************************************************************/
	public function validarAcesso($sCodgFormulario,$nNumgOperador){
	
		if(Erros::isError()) {
			
			return false;
	
		} else {

			try
			{
				Oad::conectar();
				$vAux = Oad::consultar("select numg_formulario, nome_completo, data_bloqueio from se_formularios where codg_formulario = '" . $sCodgFormulario . "'");
				Oad::desconectar();		
			
				if ($vAux->getCount() == 0){
					Erros::addErro("Formul�rio n�o identificado!�");
					return false;				
				//ADMINISTRADOR GERAL
				}else if ($nNumgOperador == 1){
					return $vAux->getValores(0,"nome_completo"); //RETORNA O NOME DO FORMUL�RIO
				}else{
					
					if (!is_null($vAux->getValores(0,"data_bloqueio"))){
						Erros::addErro("Este formul�rio encontra-se bloqueado!�");
						return false;				
					}else{
							
						//QUERY PARA BUSCAR A QTD DE FUNCOES DO FORMUL�RIO 
						//DISPON�VEIS PARA O OPERADOR
						$sSql =  " select count(func.numg_funcao) as qtd_funcao";
						$sSql .= " from se_funcoes func";
						$sSql .= " left join se_gruposFuncoes tgf on tgf.numg_funcao = func.numg_funcao";
						$sSql .= " where ";
						$sSql .= " func.data_bloqueio is null and func.numg_formulario = " . $vAux->getValores(0,"numg_formulario");
						$sSql .= " and ((tgf.numg_grupo in (select numg_grupo from se_operadoresGrupos where numg_operador = " . $nNumgOperador . ")) or (func.flag_publica = 't'))";

						Oad::conectar();
						$vAux2 = Oad::consultar($sSql);
						Oad::desconectar();
												
						if ($vAux2->getCount() <= 0){
							Erros::addErro("Formul�rio n�o dispon�vel para este operador!�");
							if (Erros::isError()) MostraErros();
							return false;				
						}else{
							if ($vAux2->getValores(0,"qtd_funcao") == 0){
								Erros::addErro("Nenhuma fun��o do formul�rio dispon�vel para este operador!�");
								if (Erros::isError()) MostraErros();
								return false;				
							}else{
								return $vAux->getValores(0,"nome_formulario"); //RETORNA O NOME DO FORMUL�RIO
							}
						}
							
					}
				}
			} catch(Exception $e) {
	
				Erros::addErro("Fonte: SIGO.Formularios.validarAcesso(); Descri��o: ".$e->getMessage()."�");
				Oad::desconectar();
				return false;
	
			}
		}
	} 


	/******************************************************************
	 Data     : 01/08/2005
	 Autor    : Rafael C�cero
	 Descri��o: valida os dados de um formul�rio antes de cadastr�-lo ou
				edit�-lo.
	******************************************************************/
	private function pValidaGravacao(){

	    //'CODG_formulario
	    if (trim($this->codgFormulario) != ""){
			
			//SE FOR UMA INCLUS�O
			if ($this->numgFormulario == 0){
					
				//VERIFICA SE J� EXISTE ALGUM REGISTRO CADASTRADO COM O NOME INFORMADO
				if (Oad::consultar("select numg_formulario from se_formularios where lower(codg_formulario) = lower('" . trim($this->codgFormulario) . "')")->getCount() > 0){
					Erros::addErro("J� existe um Formul�rio cadastrado com o c�digo " . $this->codgFormulario . ".�");
				}
					
			}else{
					
				$oResAux = Oad::consultar("select numg_formulario from se_formularios where lower(codg_formulario) = lower('" . trim($this->codgFormulario) . "')");
					
				if ($oResAux->getCount() > 0){
							
					//SE O N� IDENTifICADOR FOR DifERENTE, SIGNifICA QUE J� EXISTE UM REGISTRO 
					//COM NOME INFORMADO PARA EDI��O
					if ($oResAux->getValores(0,0) != $this->numgFormulario){
						Erros::addErro("J� existe um Formul�rio cadastrado com o c�digo " . $this->codgFormulario . ".�");
					}
				}									
			}			
	    }
	    
	}


	/******************************************************************
	 Data     : 01/08/2005
	 Autor    : Rafael C�cero
	 Descri��o: valida os dados de um formul�rio antes de exclu�-lo.
	******************************************************************/
	private function pValidaExclusao($nNumgFormulario){
	
		if (Oad::consultar("select numg_funcao from se_funcoes where numg_formulario = " . $nNumgFormulario)->getCount() > 0){
			Erros::addErro("Este formul�rio est� vinculado a alguma fun��o. N�o � poss�vel exclu�-lo.�");
		}
	    
	}

}
?>