<?php

include_once "funcoes.php";

include ("grafico/jpgraph.php");
include ("grafico/jpgraph_bar.php");

include ("classes/MunicipiosTuristicos.php");

$oMunicipio = new MunicipiosTur();

$oResult = $oMunicipio->consultarAtratServApoioTurPorAnoUf(2006, "GO");
if(Erros::isError()) MostraErros();

for ($i=0;$i<$oResult->getCount();$i++){
	$vMunicipios[$i] = $oResult->getValores($i,0);
	$datay1[$i] = $oResult->getValores($i,1);
	$datay2[$i] = $oResult->getValores($i,2);
	$datay3[$i] = $oResult->getValores($i,3);
}

// Some data
/*
$datay1=array(40,5,18,3,39);
$datay2=array(5,0,2,2,58);
$datay3=array(183,20,50,10,97);
*/

// Create the basic graph
$graph = new Graph(770,455,'auto');	
$graph->SetScale("textlin");
$graph->img->SetMargin(40,200,30,170);

// Adjust the position of the legend box
$graph->legend->Pos(0.02,0.15);

// Adjust the color for theshadow of the legend
$graph->legend->SetShadow('darkgray@0.5');
$graph->legend->SetFillColor('lightblue@0.3');

// Get localised version of the month names
#$graph->xaxis->SetTickLabels($gDateLocale->GetShortMonth());

$graph->xaxis->SetTickLabels($vMunicipios);
$graph->xaxis->SetLabelAngle(90);

// Set a nice summer (in Stockholm) image
$graph->SetBackgroundImage('imagens/azul.gif',BGIMG_COPY);

// Set axis titles and fonts
$graph->xaxis->title->Set('2006');
$graph->xaxis->title->SetFont(FF_FONT1,FS_BOLD);
$graph->xaxis->title->SetColor('black');
$graph->xaxis->SetTitleMargin(130);

$graph->xaxis->SetFont(FF_FONT0,FS_BOLD);
$graph->xaxis->SetColor('black');

$graph->yaxis->SetFont(FF_FONT1,FS_BOLD);
$graph->yaxis->SetColor('black');

//$graph->ygrid->Show(false);
$graph->ygrid->SetColor('black@0.5');

// Setup graph title
$graph->title->Set('Relat�rio de Atrativos, Servi�os Apoio e Turisticos');

// Some extra margin (from the top)
$graph->title->SetMargin(3);
$graph->title->SetFont(FF_FONT1,FS_BOLD,12);
$graph->title->SetColor('black');

// Create the three var series we will combine
$bplot1 = new BarPlot($datay1);
$bplot2 = new BarPlot($datay2);
$bplot3 = new BarPlot($datay3);

// Setup the colors with 40% transparency (alpha channel)
$bplot1->SetFillColor('orange@0.4');
$bplot2->SetFillColor('brown@0.4');
$bplot3->SetFillColor('darkgreen@0.4');

// Setup legends
$bplot1->SetLegend('Atrativos Turisticos');
$bplot2->SetLegend('Servi�os Apoio');
$bplot3->SetLegend('Servi�os Turisticos');

// Setup each bar with a shadow of 50% transparency
$bplot1->SetShadow('black@0.5');
$bplot1->value->Show();
$bplot2->SetShadow('black@0.5');
$bplot2->value->Show();
$bplot3->SetShadow('black@0.5');
$bplot3->value->Show();

$gbarplot = new GroupBarPlot(array($bplot1,$bplot2,$bplot3));
$gbarplot->SetWidth(0.6);
$graph->Add($gbarplot);

$graph->Stroke();
?>