<?
include_once "funcoes.php";
include_once "classes/Site.php";

/**
 * Empresa: Interagi Tecnologia
 * Descri��o:
 * Releases (Data, respons�vel e descri��o [�ltimo release primeiro]):
 *	 26/03/2008 (Danilo Fernandes) 
 *		 
 */

if (empty($_SESSION["NUMG_OPERADOR"]) || $_SESSION["NUMG_OPERADOR"] == ""){
	header("Location: expirou.htm"); exit;
}

switch ($_POST["txtFuncao"]){

	case "cadastrar_site":

		$oSite = new Site();

		$oSite->setNomeSite($_POST["nomeSite"]);
		$oSite->setSiglUf($_POST["siglUf"]);
		$oSite->setNumrFase($_POST["numrFase"]);
		$oSite->setNumrConstrucao($_POST["numrConstrucao"]);
		$oSite->setNumgMunicipio($_POST["numgMunicipio"]);
		$oSite->setDescEndereco($_POST["descEndereco"]);
		$oSite->setDescLatitude($_POST["descLatitude"]);
		$oSite->setDescLongitude($_POST["descLongitude"]);
		$oSite->setNumrDetentora($_POST["numrDetentora"]);
		$oSite->setNumrTipo($_POST["numrTipo"]);
		$oSite->setNumrTipotorre($_POST["numrTipotorre"]);
		$oSite->setNumrTipobts($_POST["numrTipobts"]);
		$oSite->setDescPericulosidade($_POST["descPericulosidade"]);
		$oSite->setDescPontoRef($_POST["descPontoRef"]);
		$oSite->setNumgOperadorcad($_SESSION["NUMG_OPERADOR"]);
		$oSite->setDataCadastro(date("d/m/Y"));
		$oSite->setNumgOperadoralt($_SESSION["NUMG_OPERADOR"]);
		$oSite->setDataUltimaalt(date("d/m/Y"));

		$oSite->cadastrar();

		if (Erros::isError()){
			MostraErros();
		}else{
			header("Location: cadsite.php?info=1"); exit;
		}

		break;

	case "editar_site":

		$oSite = new Site();
		
		$oSite->setNumgSite($_POST["numgSite"]);
		$oSite->setNomeSite($_POST["nomeSite"]);
		$oSite->setSiglUf($_POST["siglUf"]);
		$oSite->setNumrFase($_POST["numrFase"]);
		$oSite->setNumrConstrucao($_POST["numrConstrucao"]);
		$oSite->setNumgMunicipio($_POST["numgMunicipio"]);
		$oSite->setDescEndereco($_POST["descEndereco"]);
		$oSite->setDescLatitude($_POST["descLatitude"]);
		$oSite->setDescLongitude($_POST["descLongitude"]);
		$oSite->setNumrDetentora($_POST["numrDetentora"]);
		$oSite->setNumrTipo($_POST["numrTipo"]);
		$oSite->setNumrTipotorre($_POST["numrTipotorre"]);
		$oSite->setNumrTipobts($_POST["numrTipobts"]);
		$oSite->setDescPericulosidade($_POST["descPericulosidade"]);
		$oSite->setDescPontoRef($_POST["descPontoRef"]);
		$oSite->setNumgOperadoralt($_SESSION["NUMG_OPERADOR"]);
		$oSite->setDataUltimaalt(date("d/m/Y"));

		$oSite->editar();

		if (Erros::isError()){
			MostraErros();
		}else{
			header("Location: cadsite.php?info=2&numg_site=" . $oSite->getNumgSite()); exit;
		}

		break;

	case "excluir_site":

		$oSite = new Site();

		$oSite->excluir($_POST["numgSite"]);

		if (Erros::isError()){
			MostraErros();
		}else{
			header("Location: cadsite.php?info=3"); exit;
		}

		break;
		
	default:
		header("Location: cadsite.php"); exit;
		break;
}


?>