<?php
include_once "funcoes.php";
include_once "classes/Sites.php";
include_once("classes/Fases.php");
include_once("classes/Operadores.php");
include_once("classes/Subatividades.php");
include_once("classes/Empresas.php");
/**
 * Empresa: Interagi Tecnologia
 * Descri��o:
 * Releases (Data, respons�vel e descri��o [�ltimo release primeiro]):
 *	 16/04/2008 (Rafael C�cero) 
 *		 Inclu�do este cabe�alho descrevendo a funcionalidade da p�gina
 */

$CODG_FORMULARIO = "reldiarios";
$NOME_FORMULARIO = validarAcesso($CODG_FORMULARIO,$_SESSION["NUMG_OPERADOR"]);

$oSite = new Sites();
$oFase = new Fases();
$oOperador = new Operadores();
$oSubatividade = new Subatividades();
$oEmpresa = new Empresas();

$vSites = new Resultset();
$vFases = new Resultset();
$vSubatividades = $oSubatividade->consultarTodas();
$vEmpresas = new Resultset();

$vSites = $oSite->consultarTodas();
$vEmpresas = $oEmpresa->consultarEmpresas();

$oOperador->setarDadosOperador($_SESSION["NUMG_OPERADOR"]);

?>

<html>
<head>

<title>SIGO - Relat�rio de Di�rios</title>

<link href="estilos.css" rel="stylesheet" type="text/css">

<script language="JavaScript" src="funcoes.js"></script>

<script type="text/javascript" src="javascripts/prototype.js"> </script>

<script type="text/javascript" src="javascripts/populacombo.js"></script>

<script language="JavaScript">
function iniForm(){
	MontaFuncoes('<?=$CODG_FORMULARIO?>','<?=$NOME_FORMULARIO?>','1')
	document.form.numgSite.focus()
}
</script>

</head>
<body onLoad="iniForm();validaPrenc()" rightmargin="0" marginwidth="0" marginheight="0" leftmargin="0" bottommargin="0" topmargin="0" bgcolor="#FFFFFF">

<table border=0 width=100% align=center cellspacing=0 cellpadding=0>
	<tr>
		<td><img src="imagens/space.gif" border=0 height=10></td>
	</tr>
	<tr>
		<td align=center>
			<table border=0 width=600 cellspacing=0 cellpadding=0>
				<tr>
					<td><img src="imagens/formEsqSup.gif" border=0 width=10 height=10></td>
					<td background="imagens/formMidSup.gif"></td>
					<td><img src="imagens/formDirSup.gif" border=0 width=10 height=10></td>
				</tr>
				<tr valign=top>
					<td width=10 background="imagens/formEsqMid.gif"></td>
					<td>
						<table border=0 width=100% cellspacing=0 cellpadding=2 align=center background="imagens/formMid.gif">
						<form method="post" action="preldiarios.php" name="form" id="form">
							<tr>
								<td height=30 valign=top class=normal11b>Crit�rios dispon�veis para gera��o do relat�rio:</td>
							</tr>
							<tr>
								<td align=center>
									<table border=0 width=90% cellspacing=0 cellpadding=2 align=center>
										<tr class=normal11b>
											<td><INPUT type='radio' name=rdoOpcao value="1" checked></td>
											<td colspan="2">1 - Relat�rio de Di�rios</td>
										</tr>
										<tr height=30>
											<td width=5%>&nbsp;</td>
											<td width=50% class=normal11>Pelo SITE</td>
											<TD width=45%>
												<select tabindex="1" id="numgSite" name="numgSite" class="borda" style="width:300px">
													<? montaCombo($vSites,"numg_site","nome_site",$_GET["numg_site"],true);?>
												</select>
											</TD>
										</tr>
										<tr height=30>
											<td width=5%>&nbsp;</td>
											<td width=50% class=normal11>Pela FASE</td>
											<TD width=45%>
												<select tabindex="2" id="numgFase" name="numgFase" class="borda" style="width:300px">
													<? montaCombo($vFases,"numg_fase","nome_fase","",true);?>
												</select>
												<script type="text/javascript"> new PopulaCombo('numgSite', 'ajax/fase.php?funcao=consultarPorSite&numg_site=','numgFase', {incluirOptVazia: true});</script>
											</TD>
										</tr>
										<tr height=30>
											<td width=5%>&nbsp;</td>
											<td width=50% class=normal11>Pela Regi�o</td>
											<TD width=45%>
												<select tabindex="2" id="numrRegiao" name="numrRegiao" class="borda" style="width:300px">
													<option value=""></option>
													<option value="1">NE1</option>
													<option value="2">NE2</option>
												</select>
											</TD>
										</tr>
										<tr height=30 >
											<td colspan="3">
											<div <? if ($oOperador->getDescTipo() != "Vivo"){?>style="display:block"<? }else{?>style="display:none" <?}?>>
												<table width="100%">
													<tr>
														<td width=5%>&nbsp;</td>
														<td width=50% class=normal11>Pela SITUA��O do Di�rio</td>
														<TD width=45%>
															<select tabindex="3" name="descSituacao" id="descSituacao" class="borda" style="width:300px">
																<option value=""></option>
																<option value="L">Liberados</option>
																<option value="N">N�o Liberados</option>
															</select>
														</TD>
													</tr>
												</table>
											</div>	
											</td>											
										</tr>
										<tr height=30>
											<td>&nbsp;</td>
											<td class=normal11>Pelo PER�ODO</td>
											<TD class=normal11>de&nbsp;&nbsp;
												<INPUT tabindex="3" type="text" name="dataDiarioInicial" size=15 maxlength=10 class=datavalor onBlur="onBlurFormataData(this)">&nbsp;&nbsp;&nbsp;a&nbsp;&nbsp;
												<INPUT tabindex="4" type="text" name="dataDiarioFinal" size=15 maxlength=10 class=datavalor onBlur="onBlurFormataData(this)">
											</TD>
										</tr>
											
										<tr>
											<td colspan="3">
											<div <? if ($oOperador->getDescTipo() != "Vivo"){echo "style='display:block;'";}else{echo"style='display:none;'";}?> >
												<fieldset style="border:1px solid #CCCCCC; padding:0px;">
												<legend  class="normal11">Pela SUBATIVIDADE </legend>
												<div style="padding:10px;">
												<table>
													<tr height=30>
														<td width=5%>&nbsp;</td>
														<td width=50% class=normal11>Subatividade</td>
														<TD width=45%>
															<select tabindex="2" id="cboSubatividade" name="cboSubatividade" onchange="validaPrenc()" class="borda" style="width:300px">
																<? montaCombo($vSubatividades,"numg_subatividade","nome_subatividade","",true);?>
															</select>
														</TD>
													</tr>
													<tr height=30>
														<td width="5%"><INPUT type='radio' name=optOpcaoSub value="2"></td>
														<td width=50% class=normal11>Executora </td>
														<TD width=45%>
															<select name="cboEmpresa" id="cboEmpresa"  onFocus="document.form.optOpcaoSub[0].checked = true;document.form.cboStatus.value = ''" class=borda style="width:300px">
																<? montaCombo($vEmpresas,"numg_empresa","nome_empresa","",true);?>
															</select>
														</TD>
													</tr>
													<tr height=30>
														<td width="5%"><INPUT type='radio' name=optOpcaoSub value="1" checked></td>
														<td width=50% class=normal11>Status</td>
														<TD width=45%>
															<select name="cboStatus" id="cboStatus" class=borda onFocus="document.form.optOpcaoSub[1].checked = true;document.form.cboEmpresa.value = ''" style="width:50px">
																<option value="">&nbsp;</option>
																<option value="1" <? if ($vSubatividades->getValores($i,"numr_status") == "1") {  echo "selected"; }?>>NA</option>
																<option value="2" <? if ($vSubatividades->getValores($i,"numr_status") == "2") {  echo "selected"; }?>>OK</option>
																<option value="3" <? if ($vSubatividades->getValores($i,"numr_status") == "3") {  echo "selected"; }?>>NOK</option>
																<option value="4" <? if ($vSubatividades->getValores($i,"numr_status") == "4") {  echo "selected"; }?>>EC</option>
																<option value="5" <? if ($vSubatividades->getValores($i,"numr_status") == "5") {  echo "selected"; }?>>NI</option>
															</select>
														</TD>
													</tr>
												</table>
												</div>	
												</fieldset>
												</div>
												</td>
											</tr>		
											
																					
										</div>
									</table>
								</td>
							</tr>
						</table>
					</td>
					<td width=10 background="imagens/formDirMid.gif"></td>
				</tr>
				<tr>
					<td><img src="imagens/formEsqInf.gif" border=0 width=10 height=10></td>
					<td background="imagens/formMidInf.gif"></td>
					<td><img src="imagens/formDirInf.gif" border=0 width=10 height=10></td>
				</tr>
			</table>
		</td>
	</tr>
</table>

<script language="JavaScript">
function gerar_diarios(){
	if (pValidaGeracao()){
		document.form.submit()
	}

}

function validaPrenc(){
	if(document.form.cboSubatividade.value == ""){
		document.form.cboEmpresa.value = ""
		document.form.cboStatus.value = ""
		document.form.optOpcaoSub[0].checked = false
		document.form.optOpcaoSub[1].checked = false
		document.form.optOpcaoSub[0].disabled = 1
		document.form.optOpcaoSub[1].disabled = 1
		document.form.cboEmpresa.disabled = 1
		document.form.cboStatus.disabled = 1
	}else{
		document.form.optOpcaoSub[0].disabled = 0
		document.form.optOpcaoSub[1].disabled = 0
		document.form.cboEmpresa.disabled = 0
		document.form.cboStatus.disabled = 0		
	}
	
}

function pValidaGeracao(){

	var sErr = ""

	if (Trim(form.numgSite.value) == "" && Trim(form.numgFase.value) == "" && Trim(form.dataDiarioInicial.value) == "" && Trim(form.dataDiarioFinal.value) == "" && Trim(form.descSituacao.value) == "" && Trim(form.cboStatus.value) == "" && Trim(form.cboSubatividade.value) == "" && Trim(form.cboEmpresa.value) == "" && Trim(form.numrRegiao.value) == "")
	sErr = "Preencha alguma das op��es dispon�veis para gera��o do relat�rio!\n"

	if (Trim(form.dataDiarioInicial.value) != "" || Trim(form.dataDiarioFinal.value) != ""){

		var dataDiaIni = form.dataDiarioInicial.value
		var dataDiaFim = form.dataDiarioFinal.value

		//A DATA FINAL N�O PODE SER INFERIOR � DATA INICIAL
		if ((dataDiaFim.substring(6) + dataDiaFim.substring(3,5) + dataDiaFim.substring(0,2)) < (dataDiaIni.substring(6) + dataDiaIni.substring(3,5) + dataDiaIni.substring(0,2)))
		sErr = sErr + "A data final n�o pode ser inferior � data inicial!\n"

	}

	if((document.form.cboSubatividade.value != "") && (document.form.cboEmpresa.value == "" && document.form.cboStatus.value == "")){
		sErr = sErr + " Escolha EMPRESA ou STATUS!\n"
	}

	if((document.form.cboEmpresa.value != "" && document.form.cboSubatividade.value == "") || (document.form.cboStatus.value != "" && document.form.cboSubatividade.value == "")){
		sErr = sErr + " Escolha uma SUBATIVIDADE!\n"
	}
	//VERIFICA SE FOI ENCONTRADO ALGUM ERRO NA VALIDA��O DO FORMUL�RIO
	if (sErr != ""){
		sErr = "Verifique os erros encontrados abaixo:\n\n" + sErr
		alert(sErr)
		//return false
	}else
	return true

}

</script>

</body>
</html>