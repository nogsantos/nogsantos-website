<?php
include_once ("funcoes.php");
include_once ("classes/Imagens.php");
include_once ("classes/ImagensPendencias.php");
include_once ("classes/ImagensDiarios.php");
include_once("classes/Sites.php");

/************************************************************************
Empresa: Interagi Tecnologia

Descri��o:

Releases (Data, respons�vel e descri��o [�ltimo release primeiro]):
30/03/2008 (Silas Junior)
Inclu�do este cabe�alho descrevendo a funcionalidade da p�gina
************************************************************************/

$CODG_FORMULARIO = "cadimg";
$NOME_FORMULARIO = validarAcesso($CODG_FORMULARIO,$_SESSION["NUMG_OPERADOR"]);

$oSite = new Sites();
$oImagem = new Imagens();
$oResImgVinc = new ResultSet();
$vSites = new Resultset();

$vSites = $oSite->consultarTodas();
// para receber dados do iframeimg e setar o site
/*if($_GET['cat'] != "" && $_GET['id'] != "" || $_GET['numg_foto'] != "" ){
$_GET['numg_site'] = $_GET['id'];

}*/
$flagFt=0;


if ($_GET['cat'] != "") {

	switch($_GET['cat']) {

		case 1: //Sites
		$oObj = new Imagens();
		$numgSite = $_GET['id'];
		$numg = $_GET['id'];
		if($numg != ""){
			$oResImgVinc = $oObj->consultarImagensVinculadas($numg);
		}
		break;

		case 2://Pend�ncias
		$oObj = new ImagensPendencias();
		$vNumg = split("-",$_GET["id"]);// indice 0 = numg_pendencia indice 1 = numg_site
		$numgSite = $vNumg[1];
		$numg = $_GET['id'];
		$flagFt = 1;

		break;

		case 3://Diarios
		$oObj = new ImagensDiarios();
		$vNumg = split("-",$_GET["id"]);//indice 0 = numg_diario  indice 1 = numg_subatividade incice 2 = numg_site
		$numgSite = $vNumg[2];
		$numg = $_GET['id'];
		break;
	}


	$oResImgVinc = $oObj->consultarImagensVinculadas($numg);
	if(Erros::isError())MostraErros();

	if($flagFt == 1){
		$oResImgNaoVinc = $oObj->consultarImagensNaoVinculadas($numg,$numgSite);
		if(Erros::isError())MostraErros();
	}else{
		$oResImgNaoVinc = $oObj->consultarImagensNaoVinculadas($numg);
		if(Erros::isError())MostraErros();
	}
} else {

	$oObj = new Imagens();
	$numgSite = $_GET['id'];
	$numg = $_GET['id'];

	if($numg != ""){
		$oResImgVinc = $oObj->consultarImagensVinculadas($numg);
	}

}

if ($_GET["numg_foto"] != ""){

	$oObj->setarDadosImagem($_GET["numg_foto"]);

}


?>
<html>
<head>
<title>Sigo - Cadastro de Imagens</title>
<link href="estilos.css" rel="stylesheet" type="text/css">
<script language="JavaScript" src="funcoes.js" type="text/javascript"></script>
<script language="javascript" type="text/javascript">

function mostraImgVinc(form){
	if (document.getElementById("cboVinc").selectedIndex > -1){
		document.images.imgvinc.src = "imagens/upload/<?=$numgSite?>/" + document.getElementById("cboVinc")[document.getElementById("cboVinc").selectedIndex].text
		form.txtNumgFoto.value = document.getElementById("cboVinc").value
		form.descFoto.value = document.getElementById("cboVinc")[document.getElementById("cboVinc").selectedIndex].label
		<? if($_GET['cat'] != "1" && $_GET['cat'] != ""){?>
		form.rdoimg[1].checked="checked"
		<? }else{?>
		form.rdoimg.checked="checked"
		<? }?>
		MontaFuncoes('<?=$CODG_FORMULARIO; ?>','<?=$NOME_FORMULARIO; ?>',form.txtNumgFoto.value)
		document.form.txtImagemVinc.value = "true"
		document.form.txtPath0.disabled='disabled'
		document.form.txtPath1.disabled='disabled'
		document.form.txtPath2.disabled='disabled'
		document.form.txtPath3.disabled='disabled'
		document.form.txtPath4.disabled='disabled'
	}
}

function mostraImgDisp(form){
	if (document.getElementById("cboDisp").selectedIndex > -1){
		document.images.imgdisp.src = "imagens/upload/<?=$numgSite?>/" + document.getElementById("cboDisp")[document.getElementById("cboDisp").selectedIndex].text
		form.txtNumgFoto.value = document.getElementById("cboDisp").value
		form.descFoto.value = document.getElementById("cboDisp")[document.getElementById("cboDisp").selectedIndex].label
		form.rdoimg[0].checked="checked"
		MontaFuncoes('<?=$CODG_FORMULARIO; ?>','<?=$NOME_FORMULARIO; ?>',form.txtNumgFoto.value)
		document.getElementById("cboVinc").selectedIndex = -1
		document.form.txtImagemVinc.value = "space"
		document.form.txtImagemDisp.value = "true"
		document.images.imgvinc.src = "imagens/space.gif"
		document.form.txtPath0.disabled='disabled'
		document.form.txtPath1.disabled='disabled'
		document.form.txtPath2.disabled='disabled'
		document.form.txtPath3.disabled='disabled'
		document.form.txtPath4.disabled='disabled'
	}
}

function nova_imagem(){
	window.location.href = '<?=$CODG_FORMULARIO?>.php?id=<?=$numg?>&cat=<?=$_GET["cat"]?>'
}

function cadastrar_imagem(){
	if (document.form.txtNumgFoto.value == ""){
		if (pValidaGravacao()){
			document.form.txtFuncao.value = "cadastrar_imagem"
			document.form.submit()

		}
	}else{
		alert("Fun��o de CADASTRO n�o dispon�vel para este formul�rio!")
	}

}
function editar_imagem(){
	if (document.form.txtNumgFoto.value != ""){
		if (pValidaGravacao()){
			document.form.txtFuncao.value = "editar_imagem"
			document.form.submit()

		}
	}else{
		alert("Fun��o de EDI��O n�o dispon�vel para este formul�rio!")
	}

}

function excluir_imagem(){
	if (document.form.txtNumgFoto.value != ""){
		if (confirm("Confirma a EXCLUS�O da Imagem?")){
			document.form.txtFuncao.value = "excluir_imagem"
			document.form.submit()
		}
	}else{
		alert("Fun��o de EXCLUS�O n�o dispon�vel para este formul�rio!")
	}
}

function vincular_imagem () {
	<? if($_GET['cat'] == "1" || $_GET['cat'] == ""){?>
	alert("V�nculo de Imagem dispon�vel apenas para pend�ncias e di�rios")
	<? }else{?>
	if (document.getElementById("cboDisp").value == "") {
		alert("Selecione uma Imagem na lista de Imagens n�o vinculadas.")
	}else{
		document.form.txtFuncao.value = "vincular_imagem"
		document.form.submit()

	}
	<? }?>

}

function desvincular_imagem () {
	<? if($_GET['cat'] == "1" || $_GET['cat'] == ""){?>
	alert("V�nculo de Imagem dispon�vel apenas para pend�ncias e di�rios")
	<? }else{?>
	if (document.getElementById("cboVinc").value == "") {
		alert("Selecione uma Imagem na lista de Imagens vinculadas.")
	}else{
		document.form.txtFuncao.value = "desvincular_imagem"
		document.form.submit()

	}
	<? }?>
}

function pValidaGravacao(){

	var sErr = ""

	if (document.form.txtNumgFoto.value == ""){
		if (document.form.txtPath0.value == '' && document.form.txtPath1.value == '' && document.form.txtPath2.value == '' && document.form.txtPath3.value == '' && document.form.txtPath4.value == '' ){
			sErr += "Imagem inv�lida!"
		} else {
			var vTiposPermitidos = Array("jpg","gif","png");
			<?for($i=0;$i<5;$i++){?>
			if( document.form.txtPath<?=$i?>.value != ""){
				var qtdLetras<?=$i?> = document.form.txtPath<?=$i?>.value.length;
			}
			if( document.form.txtPath<?=$i?>.value != ""){
				var extensao<?=$i?> =  document.form.txtPath<?=$i?>.value.substr(qtdLetras<?=$i?> -3).toLowerCase();
				if(vTiposPermitidos.toString().indexOf(extensao<?=$i?>) === -1){
					sErr += 'Imagem inv�lida!\nExtens�es permitidas "gif,jpg e png"';
				}
			}
			<? }?>
		}
	}

	//VERIFICA SE FOI ENCONTRADO ALGUM ERRO NA VALIDA��O DO FORMUL�RIO
	if (sErr != ""){
		sErr = "Verifique os erros encontrados abaixo:\n\n" + sErr
		alert(sErr)
		return false
	}else
	return true
}



function visualizar(tipo){
	if (tipo == "vinc"){
		if (document.form.txtImagemVinc.value == "space"){
			alert("Para visualizar selecione uma da(s) imagem(ns) vinculada(s)!")
		} else {
			window.open("visualizador.php?numg=" + document.form.txtNumgFoto.value,"visualizador","status=no,menubar=no,toolbar=no")
		}
	}
}

function setarSite(){
	if(document.form.numgSite.value != ""){
		window.location.href='<?=$CODG_FORMULARIO?>.php?id='+document.form.numgSite.value;
	}
}

function iniForm(){
	MontaFuncoes('<?=$CODG_FORMULARIO; ?>','<?=$NOME_FORMULARIO; ?>','<?=$oObj->getNumgFoto()?>')
	<? if($numgSite != ""){?>
	mostraImgVinc(document.form)
	<?}?>
	<? if($_GET['cat'] != "1" && $_GET['cat'] != ""){?>
	mostraImgDisp(document.form)
	<? }?>
}
</script>
</head>
<body onLoad="iniForm();window.focus()" rightmargin="0" marginwidth="0" marginheight="0" leftmargin="0" bottommargin="0" topmargin="0" bgcolor="#FFFFFF">
<table border=0 width=400 align=center cellspacing=0 cellpadding=0>
	<tr>
		<td><img src="imagens/space.gif" border=0 height=10></td>
	</tr>
	<tr>
		<td align=center>
			<table border=0 width=400 cellspacing=0 cellpadding=0>
				<tr>
					<td><img src="imagens/formEsqSup.gif" border=0 width=10 height=10></td>
					<td background="imagens/formMidSup.gif"></td>
					<td><img src="imagens/formDirSup.gif" border=0 width=10 height=10></td>
				</tr>
				<tr valign=top>
					<td width=10 background="imagens/formEsqMid.gif"></td>
					<td>
						<table border=0 width=100% cellspacing=0 cellpadding=2 align=center background="imagens/formMid.gif">
							<form method="post" action="pcadimg.php" name="form" id="form" autocomplete="off" enctype="multipart/form-data">
								<input type=hidden name=txtNumgFoto value="<?=$oObj->getNumgFoto()?>">
								<input type=hidden name=txtFuncao value="">
								<input type=hidden name=txtNumgId value="<?=$_GET['id']?>">
								<input type=hidden name=txtCat value="<?=$_GET['cat']?>">
								<input type=hidden name=txtImagemVinc value="space">
							
								
								<!-- IN�CIO CAMPOS DO FORMUL�RIO  -->
								<?php if ($_GET["info"] != ""){?>
								<tr>
									<td colspan=4 align=center height=20 valign=middle class=normal11><img src="imagens/icones/info.gif" border=0 align=absbottom>&nbsp;&nbsp;
										<?php		
										switch ($_GET["info"]){
											case 3:
												echo "Cadastro realizado com sucesso";
												break;
											case 4:
												echo "Edi��o realizada com sucesso";
												break;
											case 5:
												echo "Exclus�o realizada com sucesso";
												break;

									}  ?>
									</td>
								</tr>
								<?php } ?>
								<? if($oObj->getNumgSite() != ""){?>
									<tr>
										<td colspan="4" align="center" height="20" valign="middle" class="normal11" bgcolor="#FEFECC" style="border:1px solid #FE0000">
											Imagens suportadas: jpg, gif, png.
										</td>
									</tr>
								<?}?>
								
								<? if($_GET["cat"]!=""){//Cadsite?>
									<input type="hidden" name="numgSite"id="numgSite" value="<?=$numgSite?>" >
								
								<? }else{?>
									
								<tr>
									<td align=right class=normal11b>Site:</td>
									<td colspan="3">
										<select name="numgSite" class="borda" id="numgSite" tabindex="9" style="width:443px"  onChange="setarSite()" >
											<? 
											if($oObj->getNumgSite() != ""){
												montaCombo($vSites,"numg_site","nome_site",$oObj->getNumgSite(),true);
											}else{
												montaCombo($vSites,"numg_site","nome_site",$numgSite,true);
											}
											?>						
										</select>
									</td>
								</tr>
								<? }?>
						<?// if($_GET["cat"] == ""){?>
														
								<tr>
									
									<td width=20% align=right class=normal11b>Arquivo:</td>
									<td colspan=2>
										<table border=0 width=100% cellspacing=0 cellpadding=0>
											<tr>
												<TD width=79% class="normal11b">													
													<INPUT name="txtPath0" type="file" class="borda" id="txtDescArquivo0" size="39" <? if ($oObj->getNumgFoto()){?> disabled="disabled"<? }?> >
												</TD>
											</tr>
											<tr>
												<TD width=79% class="normal11b">													
													<INPUT name="txtPath1" type="file" class="borda" id="txtDescArquivo1" size="39" <? if ($oObj->getNumgFoto()){?> disabled="disabled"<? }?> >
												</TD>
											</tr>
											<tr>
												<TD width=79% class="normal11b">													
													<INPUT name="txtPath2" type="file" class="borda" id="txtDescArquivo2" size="39" <? if ($oObj->getNumgFoto()){?> disabled="disabled"<? }?> >
												</TD>
											</tr>
											<tr>
												<TD width=79% class="normal11b">													
													<INPUT name="txtPath3" type="file" class="borda" id="txtDescArquivo3" size="39" <? if ($oObj->getNumgFoto()){?> disabled="disabled"<? }?> >
												</TD>
											</tr>
											<tr>
												<TD width=79% class="normal11b">													
													<INPUT name="txtPath4" type="file" class="borda" id="txtDescArquivo14" size="39" <? if ($oObj->getNumgFoto()){?> disabled="disabled"<? }?> >
												</TD>
											</tr>
										</table>
									</td>
								</tr>
								<tr valign=top>
									<td align=right class=normal11b>Descri��o:</td>
									<TD colspan=3><table width="100%" border="0" cellpadding="0">
											<tr>
												<td valign="top"><textarea name="descFoto" rows=2 cols=50 class=borda onKeyUp="LimitaCampo(this,255)"><?=$oObj->getDescFoto()?></textarea></td>
												<td align="center" valign="top"></td>
											</tr>
										</table>
									</TD>
								</tr>
								<tr valign=top>									
									
								<?// if($oObj->getNumgPendencia != ""){ ?>
									<TD colspan="4" align="left">
																	
										<table width="100%" border="0" cellpadding="0">
											<tr>
												<? if($_GET['cat'] != "1" && $_GET['cat'] != ""){?>
												<td width="50%" class="normal11b">Imagens N�o Vinculadas</td>
												<? }?>
												<td width="50%" class="normal11b">Imagens Vinculadas</td>
											</tr>
										</table>
									</TD>
									
								</tr>
								<tr valign=top>									
									<TD colspan=4>
										<table width="100%" border="0" cellpadding="0">
											<tr>
												<? if($_GET['cat'] != "1" && $_GET['cat'] != ""){?>
												<!-- *************************************************************************-->
												<td width="10%" align="center" valign="top"></td>
												<td width="40%" class="normal11b" align="left">
												
												<select id="cboDisp" name="cboDisp[]" multiple="multiple" style="width:150px;height:60px;" class="normal11" onChange="mostraImgDisp(document.form)">
														<? if ($oResImgNaoVinc->getCount() > 0){
																for ($i=0;$i<$oResImgNaoVinc->getCount();$i++){?>
																<option value="<?=$oResImgNaoVinc->getValores($i,"numg_foto")?>" label="<?=$oResImgNaoVinc->getValores($i,"desc_foto")?>" <? if ($oObj->getNumgFoto() == $oResImgNaoVinc->getValores($i,"numg_foto")) {?> selected="selected" <? }?>><?=$oResImgNaoVinc->getValores($i,"nome_arquivo")?></option>																
																<?	}														
															}?>
												</select>
												<!--**************************************************************************-->
												</td>
												<? }?>
												<td width="10%" align="center" valign="top">&nbsp;</td>
												<td width="40%" class="normal11b" align="left">
													<select id="cboVinc" name="cboVinc[]" size="15" multiple="multiple" style="width:150px;height:60px;" class="normal11" onChange="mostraImgVinc(document.form)">
														<? if ($oResImgVinc->getCount() > 0){
															for ($i=0;$i<$oResImgVinc->getCount();$i++){?>
																<option value="<?=$oResImgVinc->getValores($i,"numg_foto")?>" label="<?=$oResImgVinc->getValores($i,"desc_foto")?>" <? if ($oObj->getNumgFoto() == $oResImgVinc->getValores($i,"numg_foto") || $_GET['numg_foto'] == $oResImgVinc->getValores($i,"numg_foto") ) { echo "selected=selected"; }?>>
																	<?=$oResImgVinc->getValores($i,"nome_arquivo")?>
																</option>																
														<?	}															
														 }?>														
													</select>
												</td>
												
											</tr>						
								
											
									</table>
									</TD>
								</tr>
								<tr valign=top height="150">									
									<TD colspan=4>
										<table width="100%" border="0" cellpadding="0">
											<tr>
												<? if($_GET['cat'] != "1" && $_GET['cat'] != ""){?>
												<td width="10%"></td>
												<td width="40%"><a href="javascript:visualizar('disp');"><img src="imagens/space.gif" width="150" height="150" alt="" name="imgdisp" class="bordaFrameTotal" border="0" /></a></td>
												<? }?>
												<td width="10%" align="center"></td>
												<td width="40%"><a href="javascript:visualizar('vinc');"><img src="imagens/space.gif" width="150" height="150" alt="" name="imgvinc" class="bordaFrameTotal" border="0" /></a></td>
											</tr>
											<tr>
												<? if($_GET['cat'] != "1" && $_GET['cat'] != ""){?>
												<td width="10%"></td>
												<td width="40%" align="left">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; &nbsp;
												  <input type="radio" name="rdoimg"></td>
												<? }?>
												<td width="10%" align="center"></td>
												<td width="40%" align="left">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; &nbsp;<input type="radio" name="rdoimg"></td>
											
											</tr>
										</table>
									</TD>
								</tr>
						</form>
						<?//}?>
						</table>												
					</td>
					<td width=10 background="imagens/formDirMid.gif"></td>
				</tr>
				<tr>
					<td><img src="imagens/formEsqInf.gif" border=0 width=10 height=10></td>
					<td background="imagens/formMidInf.gif"></td>
					<td><img src="imagens/formDirInf.gif" border=0 width=10 height=10></td>
				</tr>
			</table></td>
	</tr>
</table>
</body>

<head>
<META HTTP-EQUIV="Pragma" CONTENT="no-cache">
<META HTTP-EQUIV="Expires" CONTENT="-1">
</head>

</html>
