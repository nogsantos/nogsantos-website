<?php
include_once ("funcoes.php");
include_once ("classes/Imagens.php");
include_once("classes/Sites.php");

/************************************************************************
 Empresa: Interagi Tecnologia

 Descri��o:
	
 Releases (Data, respons�vel e descri��o [�ltimo release primeiro]):
	 05/12/2005 (Silas Junior) 
		 Inclu�do este cabe�alho descrevendo a funcionalidade da p�gina
************************************************************************/	

	$CODG_FORMULARIO = "cadimagens";
	$NOME_FORMULARIO = validarAcesso($CODG_FORMULARIO,$_SESSION["NUMG_OPERADOR"]);
	
	$oImagem = new Imagens();
	$oSite = new Sites();
	$vSites = new Resultset();
	
	$vSites = $oSite->consultarTodas();
	
	if ($_GET["numg_imagem"] != ""){
		$oImagem->setarDadosImagem($_GET["numg_imagem"]);
	}
	
	if ($_GET['cat'] != "") { 
		
		switch($_GET['cat']) {
		
			case 1: 
				$oObj = new Imagens();
				$numg = $_GET['id'];
			break;
			
		}
	} else {

		include_once("classes/Imagens.php");
		$oObj = new Imagens();
		$numg = $_GET['id'];
	
	}	

	//$oResImgVinc = $oObj->consultarImagensVinculadas($numg);
	if(Erros::isError())MostraErros();
	
//	$oResImgNaoVinc = $oObj->consultarImagensNaoVinculadas($numg);
	if(Erros::isError())MostraErros();
	
	
	
?>
<html>
<head>
<title>Sigo - Cadastro de Imagens</title>
<link href="estilos.css" rel="stylesheet" type="text/css">
<script language="JavaScript" src="funcoes.js" type="text/javascript"></script>
<script language="javascript" type="text/javascript">
function iniForm(){
	MontaFuncoes('<?=$CODG_FORMULARIO; ?>','<?=$NOME_FORMULARIO; ?>','<?=$oImagem->getNumgImagem()?>')	
	mostraImgVinc(document.form)
	mostraImgDisp(document.form)	
}
</script>
</head>
<body onLoad="iniForm();window.focus()" rightmargin="0" marginwidth="0" marginheight="0" leftmargin="0" bottommargin="0" topmargin="0" bgcolor="#FFFFFF">
<table border=0 width=400 align=center cellspacing=0 cellpadding=0>
	<tr>
		<td><img src="imagens/space.gif" border=0 height=10></td>
	</tr>
	<tr>
		<td align=center>
			<table border=0 width=400 cellspacing=0 cellpadding=0>
				<tr>
					<td><img src="imagens/formEsqSup.gif" border=0 width=10 height=10></td>
					<td background="imagens/formMidSup.gif"></td>
					<td><img src="imagens/formDirSup.gif" border=0 width=10 height=10></td>
				</tr>
				<tr valign=top>
					<td width=10 background="imagens/formEsqMid.gif"></td>
					<td>
						<table border=0 width=100% cellspacing=0 cellpadding=2 align=center background="imagens/formMid.gif">
							<form method="post" action="pcadimg.php" name="form" autocomplete="off" enctype="multipart/form-data">
								<input type=hidden name=txtNumgImagem value="<?=$oImagem->getNumgImagem()?>">
								<input type=hidden name=txtFuncao value="">
								<input type=hidden name=txtNumgId value="<?=$_GET['id']?>">
								<input type=hidden name=txtCat value="<?=$_GET['cat']?>">
								<input type=hidden name=txtImagemDisp value="space">
								<input type=hidden name=txtImagemVinc value="space">
								
								<!-- IN�CIO CAMPOS DO FORMUL�RIO  -->
								<?php if ($_GET["info"] != ""){?>
								<tr>
									<td colspan=4 align=center height=20 valign=middle class=normal11><img src="imagens/icones/info.gif" border=0 align=absbottom>&nbsp;&nbsp;
										<?php		
									switch ($_GET["info"]){
										case 1:
											echo "Vincula��o realizada com sucesso";
											break;
										case 2:
											echo "Desvincula��o realizada com sucesso";
											break;
										case 3:
											echo "Cadastro realizado com sucesso";
											break;
										case 4:
											echo "Edi��o realizada com sucesso";
											break;
										case 5:
											echo "Exclus�o realizada com sucesso";
											break;																						
										
									}  ?>
									</td>
								</tr>
								<?php } ?>
								<tr>
									<td colspan="4" align="center" height="20" valign="middle" class="normal11" bgcolor="#FEFECC" style="border:1px solid #FE0000">
										Imagens suportadas: jpg, gif, png.
									</td>
								</tr>
								<tr>
									<td width=20% align=right class=normal11b>Arquivo  :</td>
									<td colspan=3><table border=0 width=100% cellspacing=0 cellpadding=0>
											<tr>
												<TD width=79% class="normal11b">													
													<INPUT name="txtPath" type="file" class="borda" id="txtDescArquivo" size="39" <? if ($oImagem->getNumgImagem()){?> disabled="disabled"<? }?> >
												</TD>
											</tr>
										</table></td>
								</tr>
								<tr>
									<td align=right class=normal11b>Site:</td>
									<td colspan="3">
										<select name="numgFase" class="borda" id="numgFase" tabindex="9" style="width:443px" onkeydown="setarFocus(this,'form',event)" >
											<? montaCombo($vSites,"numg_site","nome_site",$oObj->getNumgSite(),true); ?>						
										</select>
									</td>
								</tr>
								<tr valign=top>
									<td align=right class=normal11b>Descri��o:</td>
									<TD colspan=3><table width="100%" border="0" cellpadding="0">
											<tr>
												<td valign="top"><textarea name="txtDescImagem" rows=2 cols=50 class=borda onKeyUp="LimitaCampo(this,255)"><?=$oImagem->getDescImagem()?></textarea></td>
												<td align="center" valign="top"></td>
											</tr>
										</table>
									</TD>
								</tr>
								<tr valign=top>									
									<TD colspan=4>
										<table width="100%" border="0" cellpadding="0">
											<tr>
												<td width="40%" class="normal11b">N�o vinculadas</td>
												<td width="20%"></td>
												<td width="40%" class="normal11b">Vinculadas</td>
											</tr>
										</table>
									</TD>
								</tr>
								<tr valign=top>									
									<TD colspan=4>
										<table width="100%" border="0" cellpadding="0">
											<tr>
												<td width="40%" class="normal11b">
													<select id="cboDisp" name="cboDisp[]" multiple="multiple" style="width:150px;height:60px;" class="normal11" onChange="mostraImgDisp(document.form)">
														<? //if ($oResImgNaoVinc->getCount() > 0){
															//for ($i=0;$i<$oResImgNaoVinc->getCount();$i++){?>
																<option value="<?//$oResImgNaoVinc->getValores($i,"numg_imagem")?>" label="<?//$oResImgNaoVinc->getValores($i,"desc_imagem")?>" <? //if ($oImagem->getNumgImagem() == $oResImgNaoVinc->getValores($i,"numg_imagem")) {?> selected="selected" <? //}?>><?//$oResImgNaoVinc->getValores($i,"nome_imagem")?></option>																
														<?//	}} ?>
													</select>
												</td>
												<td width="20%" align="center" valign="top"></td>
												<td width="40%" class="normal11b">
													<select id="cboVinc" name="cboVinc[]" multiple="multiple" style="width:150px;height:60px;" class="normal11" onChange="mostraImgVinc(document.form)">
														<? //if ($oResImgVinc->getCount() > 0){
															//for ($i=0;$i<$oResImgVinc->getCount();$i++){?>
																<option value="<?//$oResImgVinc->getValores($i,"numg_imagem")?>" label="<?//$oResImgVinc->getValores($i,"desc_imagem")?>" <? //if ($oImagem->getNumgImagem() == $oResImgVinc->getValores($i,"numg_imagem")) { echo "selected"; }?>><?//$oResImgVinc->getValores($i,"nome_imagem")?></option>																
														<?	//}															
														// }?>														
													</select>												</td>
											</tr>
										</table>
									</TD>
								</tr>
								<tr valign=top height="150">									
									<TD colspan=4>
										<table width="100%" border="0" cellpadding="0">
											<tr>
												<td width="40%"><a href="javascript:visualizar('disp');"><img src="imagens/space.gif" width="150" height="150" alt="" name="imgdisp" class="bordaFrameTotal" border="0" /></a></td>
												<td width="20%" align="center"></td>
												<td width="40%"><a href="javascript:visualizar('vinc');"><img src="imagens/space.gif" width="150" height="150" alt="" name="imgvinc" class="bordaFrameTotal" border="0" /></a></td>
											</tr>
										</table>
									</TD>
								</tr>
								<tr valign=top>									
									<TD colspan=4>
										<table width="100%" border="0" cellpadding="0">
											<tr>
												<td width="40%" align="center"><input type="radio" name="rdoimg"></td>
												<td width="20%" align="center"></td>
												<td width="40%" align="center"><input type="radio" name="rdoimg"></td>
											</tr>
										</table>
									</TD>
								</tr>
								<!-- FIM CAMPOS DO FORMUL�RIO  -->							
							</form>
						</table>												
					</td>
					<td width=10 background="imagens/formDirMid.gif"></td>
				</tr>
				<tr>
					<td><img src="imagens/formEsqInf.gif" border=0 width=10 height=10></td>
					<td background="imagens/formMidInf.gif"></td>
					<td><img src="imagens/formDirInf.gif" border=0 width=10 height=10></td>
				</tr>
			</table></td>
	</tr>
</table>
<script language="JavaScript" type="text/javascript">
function mostraImgDisp(form){		
	if (document.getElementById("cboDisp").selectedIndex > -1){
		document.images.imgdisp.src = "imagens/upload/<?=$_POST["numg_site"]?>/" + document.getElementById("cboDisp")[document.getElementById("cboDisp").selectedIndex].text		
		form.txtNumgImagem.value = document.getElementById("cboDisp").value				
		form.txtDescImagem.value = document.getElementById("cboDisp")[document.getElementById("cboDisp").selectedIndex].label		
		form.rdoimg[0].checked="checked"
		MontaFuncoes('<?=$CODG_FORMULARIO; ?>','<?=$NOME_FORMULARIO; ?>',form.txtNumgImagem.value)
		document.getElementById("cboVinc").selectedIndex = -1
		document.form.txtImagemVinc.value = "space"
		document.form.txtImagemDisp.value = "true"
		document.images.imgvinc.src = "imagens/space.gif"
		document.form.txtPath.disabled='disabled'
	}
}
function mostraImgVinc(form){		
	if (document.getElementById("cboVinc").selectedIndex > -1){	
		document.images.imgvinc.src = "imagens/upload/<?=$_POST["numg_site"]?>/" + document.getElementById("cboVinc")[document.getElementById("cboVinc").selectedIndex].text
		form.txtNumgImagem.value = document.getElementById("cboVinc").value		
		form.txtDescImagem.value = document.getElementById("cboVinc")[document.getElementById("cboVinc").selectedIndex].label
		form.rdoimg[1].checked="checked"
		MontaFuncoes('<?=$CODG_FORMULARIO; ?>','<?=$NOME_FORMULARIO; ?>',form.txtNumgImagem.value)
		document.getElementById("cboDisp").selectedIndex = -1
		document.form.txtImagemDisp.value = "space"
		document.form.txtImagemVinc.value = "true"
		document.images.imgdisp.src = "imagens/space.gif"
		document.form.txtPath.disabled='disabled'
	}
}
function vincular_imagem () {
	if (document.getElementById("cboDisp").value == "") {
		alert("Selecione uma Imagem na lista de Imagens n�o vinculadas.")
	}else{
		
			document.form.txtFuncao.value = "vincular_imagem"
			document.form.submit()
		
	}

}

function desvincular_imagem () {
	if (document.getElementById("cboVinc").value == "") {
		alert("Selecione uma Imagem na lista de Imagens vinculadas.")
	}else{
			document.form.txtFuncao.value = "desvincular_imagem"
			document.form.submit()
		
	}	
}

function novo_imagem(){
	window.location.href = '<?=$CODG_FORMULARIO?>.php'
}

function cadastrar_imagem(){
	if (document.form.txtNumgImagem.value == ""){
		if (pValidaGravacao()){
				document.form.txtFuncao.value = "cadastrar_imagem"
				document.form.submit()
			
		}
	}else{
		alert("Fun��o de CADASTRO n�o dispon�vel para este formul�rio!")
	}
	
}
function editar_imagem(){
	if (document.form.txtNumgImagem.value != ""){
		if (pValidaGravacao()){
				document.form.txtFuncao.value = "editar_imagem"
				document.form.submit()
			
		}
	}else{ 
		alert("Fun��o de EDI��O n�o dispon�vel para este formul�rio!")
	}

}

function excluir_imagem(){
	if (document.form.txtNumgImagem.value != ""){
		if (confirm("Confirma a EXCLUS�O da Imagem?")){
			document.form.txtFuncao.value = "excluir_imagem"
			document.form.submit()
		}
	}else{ 
		alert("Fun��o de EXCLUS�O n�o dispon�vel para este formul�rio!")
	}
}

function pValidaGravacao(){
	
	var sErr = ""	
	
	if (document.form.txtNumgImagem.value == ""){
		if (document.form.txtPath.value == ''){
			sErr += "Imagem inv�lida!"		
		} else {
			var qtdLetras = document.form.txtPath.value.length;		
			var extensao =  document.form.txtPath.value.substr(qtdLetras -3).toLowerCase();
			var vTiposPermitidos = Array("jpg","gif","png");
			if(vTiposPermitidos.toString().indexOf(extensao) === -1){
				sErr += 'Imagem inv�lida!\nExtens�es permitidas "gif,jpg e png"';
			}
		}
	}
	
	//VERIFICA SE FOI ENCONTRADO ALGUM ERRO NA VALIDA��O DO FORMUL�RIO
	if (sErr != ""){
		sErr = "Verifique os erros encontrados abaixo:\n\n" + sErr
		alert(sErr)	
		return false
	}else
		return true
}

function visualizar(tipo){
	if (tipo == "disp"){
		if (document.form.txtImagemDisp.value == "space"){
			alert("Para visualizar selecione uma da(s) imagem(ns) n�o vinculada(s)!") 
		} else {
			window.open("visualizador.php?numg=" + document.form.txtNumgImagem.value,"visualizador","status=no,menubar=no,toolbar=no")
		}
	}
	
	if (tipo == "vinc"){
		if (document.form.txtImagemVinc.value == "space"){
			alert("Para visualizar selecione uma da(s) imagem(ns) vinculada(s)!") 
		} else {
			window.open("visualizador.php?numg=" + document.form.txtNumgImagem.value,"visualizador","status=no,menubar=no,toolbar=no")
		}
	}
}
</script>
</body>

<head>
<META HTTP-EQUIV="Pragma" CONTENT="no-cache">
<META HTTP-EQUIV="Expires" CONTENT="-1">
</head>

</html>
