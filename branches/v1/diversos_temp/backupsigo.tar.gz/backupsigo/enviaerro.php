<?
/************************************************************************
 Empresa: Interagi Tecnologia

 Descri��o: processa o envio das mensagens de erro para a conta de suporte
	
 Releases (Data, respons�vel e descri��o [�ltimo release primeiro]):
	 16/01/2007 (Rafael C�cero) 
		 Inclu�do este cabe�alho descrevendo a funcionalidade da p�gina
						
************************************************************************/

	include "mime/htmlMimeMail.php";

	$email = "suporte@interagi.com.br";
		
	$mail = new htmlMimeMail();
	$mail->setFrom("lluciano@elotelecom.com.br");
	$mail->setSubject("Sigo - Erro");

	$sMensagem  = "Erro(s) encontrado(s) no sistema Sigo:<br><br>";	
	$sMensagem .= trim($_POST["txtErro"]) . "<br><br>";	
	$sMensagem .= "Operador: " . $_POST["txtOperador"] . " [" . $_POST["txtId"] . "]<br>";
	$sMensagem .= "Data Envio: " . date("d/m/Y H:i");
	
	$mail->setHtml($sMensagem);	
	$result = $mail->send(array($email));
	
?>
<html>
<head>
<title>Sigo - Erros</title>
</head>
<body onLoad="setTimeout('window.close()',5000)" rightmargin="0" marginwidth="0" marginheight="0" leftmargin="0" bottommargin="0" topmargin="0">
<table width="100%" height=100% border="0" cellpadding="0" cellspacing="0" align="left">
	<tr>
		<td height=100% align=center style="font-family:Arial, Helvetica, sans-serif; font-size:11px; color:#000000"><b>Aguarde, enviando erro para o Suporte...</b></td>
	</tr>
</table>
</body>
</html>