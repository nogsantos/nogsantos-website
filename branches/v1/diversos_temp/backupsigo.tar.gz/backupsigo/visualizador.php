<?php
include_once ("funcoes.php");
include_once ("classes/Imagens.php");

$oImagem = new Imagens();

if ($_GET['numg']) {
	
	$oImagem->setarDadosImagem($_GET["numg"]);			
	if (Erros::isError()) MostraErros();

	$path = "imagens/upload/".$oImagem->getNumgSite()."/";
	
	if (($oImagem->getNomeArquivo()!="") && ( file_exists($path.$oImagem->getNomeArquivo()))) {
		$oImagem->setNumrSize(getimagesize($path.$oImagem->getNomeArquivo()));
		$oImagem->setNumrLargura($oImagem->getNumrSize(0));
		$oImagem->setNumrAltura($oImagem->getNumrSize(1));
		
		$maxwidth = 500;
		$maxheight = 500;
		
		$srcW = $oImagem->getNumrSize(0);
		$srcH = $oImagem->getNumrSize(1);
		$wdiff = $srcW - $maxwidth;
		$hdiff = $srcH - $maxheight;
		
		if ($wdiff > $hdiff) {
		 $newW = $maxwidth;
		  $aspect = ($newW/$srcW);
		  $newH = (int)($srcH * $aspect);
		} else {
		  $newH = $maxheight;
		  $aspect = ($newH/$srcH);
		  $newW = (int)($srcW * $aspect);
		}
		$newH = $newH + 25;
		$newW = $newW + 25;
?>
<head>
<link href="estilos.css" rel="stylesheet" type="text/css">
<script language="JavaScript">
function openWindow(arquivo,w,h) { //v2.0
 // window.open('thumbnail.php?&arquivo=' + arquivo + '&width=500&height=500','popup2','directories=no,width=' + w + ',height=' + h + ',hotkeys=no,location=no,menubar=no,resizable=no,scrollbars=no,status=no,toolbar=no,copyhistory=no,screenX=0,screenY=0,left=0,top=0');

}
</script>
</head>
<body leftmargin="0" topmargin="0">
<table height="100%" width="100%">
	<tr>
		<td align="center" valign="middle">
			<img src="thumbnail.php?numg_site=<?=$oImagem->getNumgSite()?>&arquivo=<?=$oImagem->getNomeArquivo()?>&width=<?=$newW?>&height=<?=$newH?>" alt="" border="0" /><br />
			<span class="normal11b"><?=$oImagem->getDescFoto()?></span>
		</td>
	</tr>
</table>
</body>
<? 	} else {?>
<body leftmargin="0" topmargin="0">
<table height="100%" width="100%">
	<tr>
		<td align="center" valign="middle">Imagem n�o dispon�vel, favor entre em contato com o administrador do sistema.</td>
	</tr>
</table>
</body>
<?	}
}?>