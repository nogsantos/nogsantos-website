<?php
include_once "funcoes.php";
/************************************************************************
 Empresa: Interagi Tecnologia

 Descri��o:
	
 Releases (Data, respons�vel e descri��o [�ltimo release primeiro]):
	 03/08/2005 (Rafael C�cero) 
		 Inclu�do este cabe�alho descrevendo a funcionalidade da p�gina
						
************************************************************************/
	
	$CODG_FORMULARIO = "cadformularios";
	$NOME_FORMULARIO = validarAcesso($CODG_FORMULARIO,$_SESSION["NUMG_OPERADOR"]);

	$bPesquisa = true;
	
	$oFormularios = new Formularios;
		
	if ($_GET["numg_formulario"] != "" || $_GET["codg_formulario"] != "") {
		
		$oFormularios->setarDadosFormulario(array($_GET["numg_formulario"],$_GET["codg_formulario"]));
		
		if ($oFormularios->getNumgFormulario() == "") $bPesquisa = false;
	}	

	//BUSCA OS FORMUL�RIOS CADASTRADOS
	$vFormularios = $oFormularios->consultarFormularios();
	
?>

<html>
<head>

<title>Sigo - Cadastro de Formul�rios</title>

<link href="estilos.css" rel="stylesheet" type="text/css">

<SCRIPT language=JavaScript src="funcoes.js"></SCRIPT>

<SCRIPT language=JavaScript>
function iniForm(){
	MontaFuncoes('<?=$CODG_FORMULARIO?>','<?=$NOME_FORMULARIO?>','<?=$oFormularios->getNumgFormulario()?>')
	document.form.txtCodgFormulario.focus()
}

function pesquisarFormulario(){
	if (Trim(document.form.txtCodgFormulario.value) != ""){
		window.location.href = "cadformularios.php?codg_formulario=" + document.form.txtCodgFormulario.value
	}else{
		alert("Informe um nome de formul�rio v�lido para realizar a pesquisa.")
		document.form.txtCodgFormulario.focus()
	}
}
</script>

</head>
<body onLoad="iniForm()" rightmargin="0" marginwidth="0" marginheight="0" leftmargin="0" bottommargin="0" topmargin="0" bgcolor="#FFFFFF">

<table border=0 width=100% align=center cellspacing=0 cellpadding=0>
	<tr>
		<td><img src="imagens/space.gif" border=0 height=10></td>
	</tr>
	<tr>
		<td align=center>
			<table border=0 width=600 cellspacing=0 cellpadding=0>
				<tr>
					<td><img src="imagens/formEsqSup.gif" border=0 width=10 height=10></td>
					<td background="imagens/formMidSup.gif"></td>
					<td><img src="imagens/formDirSup.gif" border=0 width=10 height=10></td>
				</tr>
				<tr valign=top>
					<td width=10 background="imagens/formEsqMid.gif"></td>
					<td>
						<table border=0 width=100% cellspacing=0 cellpadding=2 align=center background="imagens/formMid.gif">
						<form method="post" action="pcadformularios.php" name="form">
							<input type=hidden name=txtFuncao value="">
							<input type=hidden name=txtNumgFormulario value="<?=$oFormularios->getNumgFormulario()?>">
							
							<!-- IN�CIO CAMPOS DO FORMUL�RIO  -->
							<?php if ($_GET["info"] != "") {?>
							<tr>
								<td colspan=4 align=center height=20 valign=middle class=normal11>
								<img src="imagens/icones/info.gif" border=0 align=absbottom>&nbsp;&nbsp;
								<?php 		
									switch ($_GET["info"]){
										case 1:
											echo "Cadastro de formul�rio realizado com sucesso";
											break;
										case 2:
											echo "Edi��o de dados realizada com sucesso";
											break;
										case 3:
											echo "Exclus�o de formul�rio realizada com sucesso";
											break;
										case 4:
											echo "Bloqueio de formul�rio realizada com sucesso";
											break;
										case 5:
											echo "Desbloqueio de formul�rio realizada com sucesso";
											break;
										default:
											echo "&nbsp;";
											break;
									} ?>
								</td>
							</tr>
							<?php }else if (!$bPesquisa) {?>
							<tr>
								<td colspan=4 align=center height=20 valign=middle class=normal11>
									<img src="imagens/icones/excla.gif" border=0 align=absbottom>&nbsp;&nbsp;Nenhum registro encontrado para a pesquisa						
								</td>
							</tr>
							<?php }?>				
							<tr>
								<td align=right class=normal11b>C�digo:</td>
								<TD colspan=3>
									<table border=0 width=100% cellspacing=0 cellpadding=0>
										<tr>
											<TD width=50%>
												<table border=0 cellpadding=0 cellspacing=0>
													<tr>
														<td><INPUT type="text" name="txtCodgFormulario" value='<?=$oFormularios->getCodgFormulario()?>' size=25 maxlength=30 class=borda></TD>
														<td>&nbsp;<input type=image src='imagens/icones/pesquisar.gif' border=0 onClick="pesquisarFormulario();return false" align=center id=image1 name=image1></td>
													</tr>
												</table>
											</td>	
											<TD width=50%>
												<?php if ($oFormularios->getDataCadastro() != "" && !is_null($oFormularios->getDataCadastro())) {?>
												<table border=0 width=202 cellspacing=0 cellpadding=0>
													<tr>
														<td align=right class=normal11>cadastrado em: <b><?=$oFormularios->getDataCadastro()?></b> [<?=$oFormularios->getNomeOperadorCad()?>]</td>
													</tr>
												</table>
												<?php }?>
											</TD>
										</tr>
									</table>
								</td>
							</tr>
							<tr>
								<td align=right class=normal11b>Nome formul�rio:</td>
								<TD colspan=3><INPUT type="text" name="txtNomeFormulario" value='<?=$oFormularios->getNomeFormulario()?>' size=70 maxlength=30 class=borda onkeypress=SetFocus(document.form.txtNomeCompleto)></TD>
							</tr>
							<tr>
								<td align=right class=normal11b>Nome completo:</td>
								<TD colspan=3><INPUT type="text" name="txtNomeCompleto" value='<?=$oFormularios->getNomeCompleto()?>' size=70 maxlength=50 class=borda onkeypress=SetFocus(document.form.txtDescFormulario)></TD>
							</tr>
							<tr valign=top>
								<td align=right class=normal11b>Descri��o:</td>
								<TD colspan=3><textarea name="txtDescFormulario" rows=3 cols=69 class=borda onKeyUp="LimitaCampo(this,255)"><?=$oFormularios->getDescFormulario()?></textarea></TD>
							</tr>
							<tr>
								<td width=20% align=right class=normal11b>Agrupamento:</td>
								<TD colspan=3>
									<table border=0 width=100% cellspacing=0 cellpadding=0>
										<tr>
											<TD width=50%>
												<select name=cboAgrupamentos class=borda>
													<option value="">
													<option value=1 <?php if ($oFormularios->getNumrAgrupamento() == 1) echo "selected"?>>1 - Gerenciamento de Obras
													<option value=2 <?php if ($oFormularios->getNumrAgrupamento() == 2) echo "selected"?>>2 - Atrativos Tur�sticos
													<option value=3 <?php if ($oFormularios->getNumrAgrupamento() == 3) echo "selected"?>>3 - Serv. Equip. Tur�sticos
													<option value=4 <?php if ($oFormularios->getNumrAgrupamento() == 4) echo "selected"?>>4 - Serv. Equip. de Apoio
													<option value=5 <?php if ($oFormularios->getNumrAgrupamento() == 5) echo "selected"?>>5 - Permiss�o de Acesso
													<option value=6 <?php if ($oFormularios->getNumrAgrupamento() == 6) echo "selected"?>>6 - Relat�rios
													<option value=7 <?php if ($oFormularios->getNumrAgrupamento() == 7) echo "selected"?>>7 - Gr�ficos
												</select>
											</td>	
											<TD width=50%>
												<table border=0 width=207 cellspacing=0 cellpadding=0>
													<tr>
														<td align=right class=normal11>Formul�rio Oculto <input type=checkbox name=chkFlagOculto value="f" <?php if ($oFormularios->getFlagOculto() != "f" && $oFormularios->getFlagOculto() != "") echo "checked"?>></td>
													</tr>
												</table>
											</TD>
										</tr>
									</table>
								</TD>
							</tr>
							<tr>
								<td class=normal11b align=right>Ordem:</td>
								<td colspan=3><INPUT type="text" name="txtNumrOrdem" value='<?=$oFormularios->getNumrOrdem()?>' size=10 maxlength=2 class=borda onKeyPress="SetFocus(document.form.txtNumrOrdem)"></td>
							</tr>
							<?php if ($oFormularios->getDataBloqueio() != "" && !is_null($oFormularios->getDataBloqueio())) {?>
							<tr>
								<td></td>
								<td colspan=3 class=normal11><img src="imagens/icones/excla.gif" border=0 align=absbottom>&nbsp;Formul�rio bloqueado em: <b><?=$oFormularios->getDataBloqueio()?></b> [<?=$oFormularios->getNomeOperadorBloq()?>]</td>
							</tr>
							<?php }?>
							
							<!-- FIM CAMPOS DO FORMUL�RIO  -->
							
						</form>
						</table>
					</td>
					<td width=10 background="imagens/formDirMid.gif"></td>
				</tr>
				<tr>
					<td><img src="imagens/formEsqInf.gif" border=0 width=10 height=10></td>
					<td background="imagens/formMidInf.gif"></td>
					<td><img src="imagens/formDirInf.gif" border=0 width=10 height=10></td>
				</tr>
			</table>
		</td>
	</tr>
	
	<?php if (!empty($vFormularios)) {?>
	<tr>
		<td>
			<table border=0 width=95% cellspacing=0 cellpadding=0 align=center>
				<tr>
					<td colspan=5 class=normal11 height=25 valign=bottom>Rela��o de Formul�rios cadastrados:</td>
				</tr>
				<tr height=20 class=normal11b align=center>
					<td background="imagens/fundoBarraRelatorio.gif" width=20%>C�digo</td>
					<td background="imagens/fundoBarraRelatorio.gif" width=25%>Formul�rio</td>
					<td background="imagens/fundoBarraRelatorio.gif" width=35%>Nome completo</td>
					<td background="imagens/fundoBarraRelatorio.gif" width=10%>Oculto?</td>
					<td background="imagens/fundoBarraRelatorio.gif" width=10%>Data Bloq.</td>
				</tr>
				<?php for ($i=0; $i<$vFormularios->getCount(); $i++){?>
				<tr height=20 <?php if ($i % 2 == 1) {?>bgcolor="#E8E8E8"<?php }?> class=relatorio>
					<td><a href="cadformularios.php?numg_formulario=<?=$vFormularios->getValores($i,"numg_formulario")?>" class=relatorio><?=$vFormularios->getValores($i,"numr_agrupamento") . " - " . $vFormularios->getValores($i,"codg_formulario")?></a></td>
					<td><?=$vFormularios->getValores($i,"nome_formulario")?></td>
					<td><?=$vFormularios->getValores($i,"nome_completo")?></td>
					<td align=center><?php if ($vFormularios->getValores($i,"flag_oculto") != "f") echo "<span class=destaque>sim</span>"; else echo "n�o";?></td>
					<td align=center><?=FormataDataHora($vFormularios->getValores($i,"data_bloqueio"));?></td>
				</tr>
				<?php }?>
				<tr height=20 <?php if ($i % 2 == 1) {?>bgcolor="#E8E8E8"<?php }?>>
					<td colspan=3 class=destaque>* Clique no c�digo do formul�rio para edit�-lo</td>
					<td colspan=2 class=normal11b align=right>TOTAL: <?=$vFormularios->getCount()?></td>
				</tr>
			</table>
		</td>
	</tr>
	<?php }?>
	<tr>
		<td><img src="imagens/space.gif" border=0 height=10></td>
	</tr>
</table>

<script language="JavaScript">
function novo_formulario(){
	window.location.href = '<?=$CODG_FORMULARIO?>.php'
}

function cadastrar_formulario(){
	if (document.form.txtNumgFormulario.value == ""){
		if (pValidaGravacao()){
				document.form.txtFuncao.value = "cadastrar_formulario"
				document.form.submit()
			
		}
	}else{
		alert("Fun��o de CADASTRO n�o dispon�vel para este formul�rio!")
	}
	
}

function editar_formulario(){
	if (document.form.txtNumgFormulario.value != ""){
		if (pValidaGravacao()){
				document.form.txtFuncao.value = "editar_formulario"
				document.form.submit()
			
		}
	}else{ 
		alert("Fun��o de EDI��O n�o dispon�vel para este formul�rio!")
	}

}

function excluir_formulario(){
	if (document.form.txtNumgFormulario.value != ""){
		if (confirm("Confirma a EXCLUS�O do Formul�rio?")){
			document.form.txtFuncao.value = "excluir_formulario"
			document.form.submit()
		}
	}else{ 
		alert("Fun��o de EXCLUS�O n�o dispon�vel para este formul�rio!")
	}
}

function bloquear_formulario(){
	<?php if ($oFormularios->getDataBloqueio() == "") {?>
	if (document.form.txtNumgFormulario.value != ""){
			document.form.txtFuncao.value = "bloquear_formulario"
			document.form.submit()
		
	}else{ 
		alert("Fun��o de BLOQUEIO n�o dispon�vel para este formul�rio!")
	}
	<?php }else{?>
	alert("Fun��o de BLOQUEIO n�o dispon�vel! O formul�rio j� encontra-se bloqueado.")
	<?php }?>
}

function desbloquear_formulario(){
	<?php if ($oFormularios->getDataBloqueio() != "") {?>
	if (document.form.txtNumgFormulario.value != ""){
			document.form.txtFuncao.value = "desbloquear_formulario"
			document.form.submit()
		
	}else{ 
		alert("Fun��o de DESBLOQUEIO n�o dispon�vel para este formul�rio!")
	}
	<?php }else{?>
	alert("Fun��o de DESBLOQUEIO n�o dispon�vel! O formul�rio j� encontra-se desbloqueado.")
	<?php }?>
}

function pValidaGravacao(){
	
	var sErr = ""
	
	//...
	
	//VERIFICA SE FOI ENCONTRADO ALGUM ERRO NA VALIDA��O DO FORMUL�RIO
	if (sErr != ""){
		sErr = "Verifique os erros encontrados abaixo:\n\n" + sErr
		alert(sErr)	
		return false
	}else
		return true
}

</script>

<?php $oFormularios->free;?>

</body>

<head>
<META HTTP-EQUIV="Pragma" CONTENT="no-cache">
<META HTTP-EQUIV="Expires" CONTENT="-1">
</head>

</html>