<?php
include_once ("funcoes.php");
include_once ("classes/Funcoes.php");
/**
 * Empresa: Interagi Tecnologia
 * Descri��o:
 * Releases (Data, respons�vel e descri��o [�ltimo release primeiro]):
 *	 10/03/2008 (Rafael C�cero) 
 *		 Inclu�do este cabe�alho descrevendo a funcionalidade da p�gina
 */

	
	if ($_GET["flag_novoRegistro"] != "") { 
		$bFlagNovoRegistro = false; 
	} else { 
		$bFlagNovoRegistro = true; 
	}
	
	$sCodgFormulario = $_GET["codg_formulario"];
	$sNomeFormulario = $_GET["nome_formulario"];

	$oFuncao = new Funcoes();
		
	//ADMINISTRADOR GERAL DO SISTEMA
	if ($_SESSION["NUMG_OPERADOR"] == 1) {
		$vFuncao = $oFuncao->consultarFuncoesFormAdministrador($sCodgFormulario);
	} else {
		$vFuncao = $oFuncao->consultarFuncoesFormOperador(array($sCodgFormulario,$_SESSION["NUMG_OPERADOR"]));
	}
	//if (Erros::isError()) MostraErros();
	
	if ($sNomeFormulario == "") { $sNomeFormulario = "SIGO"; }
?>

<HTML>
<HEAD>

<title>SIGO - Barra de Fun&ccedil;&otilde;es</title>

<link href="estilos.css" rel="stylesheet" type="text/css">

<script language="JavaScript" src="funcoes.js"></script>

<script language="JavaScript">
//FUN��O PARA VERIFICAR SE A P�GINA DO FRAME "CONTEUDO" � ERROS.ASP
function IsPaginaErros(){
	var aux = top.frames[3].document.location.href
	
	if (aux.indexOf("erros.php") > 0)
		return true
	else
		return false

}

function setaTitulo(){
		top.document.title = "SIGO"
}

</script>

</HEAD>
<BODY onLoad="setaTitulo()" topmargin="0" leftmargin="0" rightmargin="0" bottommargin="0">

<table border=0 height=30 width=100% cellpadding=0 cellspacing=0>
	<tr height=30 class=titulo11 bgcolor="#E8E8E8">
		<td width=100%>
			<table border=0 width=100% cellpadding=0 cellspacing=0>
				<tr style="padding:2px">
					<td class="titulo11" nowrap>&nbsp;<?=$sNomeFormulario?> </td>
					<td width="100%">&nbsp;</td>
					<? 
					$aux=0;
					if (!empty($vFuncao)){
						if ($vFuncao->getCount() > 0) {					
							for ($i=0;$i<$vFuncao->getCount();$i++) {
								if (($vFuncao->getValores($i,"flag_novoregistro") == "t" && $bFlagNovoRegistro == true) || !($vFuncao->getValores($i,"flag_novoregistro") == "t" || $bFlagNovoRegistro == true)) {?>													
									<td><input type=image src="imagens/botoes/<?php echo $vFuncao->getValores($i,"nome_icone");?>" border=0 align=absbottom onClick="if (!IsPaginaErros()) top.frames[3].<?php echo $vFuncao->getValores($i,"codg_funcao");?>(); else alert('Fun��o n�o dispon�vel! Clique no bot�o Voltar.');" title="<?php echo $vFuncao->getValores($i,"desc_funcao");?>"></td>
									<td class="normal11" nowrap><a href="javascript: if (!IsPaginaErros()) top.frames[3].<?php echo $vFuncao->getValores($i,"codg_funcao");?>(); else alert('Fun��o n�o dispon�vel! Clique no bot�o Voltar.');" class="relatorio" title="<?php echo $vFuncao->getValores($i,"desc_funcao");?>"><?php echo $vFuncao->getValores($i,"nome_funcao");?></a></td>
									<td><img src="imagens/div_titulo.gif" border=0></td>
					<?  		$aux++;
								}
							} 
						} 
						
					} ?>
					<td valign=bottom><a href="javascript:window.location.reload();top.frames[3].location.reload()" class=link-net4u>&nbsp;<img src="imagens/icones/atualizar.gif" border=0 alt="Atualizar Formul�rio"></a>&nbsp;</td>
				</tr>
			</table>
		</td>
	</tr>
</table>

</BODY>
</HTML>
