<?php 
include_once "funcoes.php";
include_once "classes/Grupos.php";
/************************************************************************
 Empresa: Interagi Tecnologia

 Descri��o: 
	
 Releases (Data, respons�vel e descri��o [�ltimo release primeiro]):
	 04/08/2005 (Rafael C�cero) 
		 Inclu�do este cabe�alho descrevendo a funcionalidade da p�gina
************************************************************************/

	if (empty($_SESSION["NUMG_OPERADOR"]) || $_SESSION["NUMG_OPERADOR"] == ""){
		header("Location: expirou.htm"); exit;
	}


	switch ($_POST["txtFuncao"]){
	
		case "cadastrar_grupo":

			$oGrupo = new Grupos;
			
			$oGrupo->setNumgGrupo(0);
			$oGrupo->setNomeGrupo($_POST["txtNomeGrupo"]);
			$oGrupo->setDescGrupo($_POST["txtDescGrupo"]);
			$oGrupo->setNumgOperadorCad($_SESSION["NUMG_OPERADOR"]);
			
			$oGrupo->cadastrar();
			
			if (Erros::isError()){
				MostraErros();
			}else{ 
				header("Location: cadgrupos.php?info=1&numg_grupo=" . $_POST["numg_grupo"]); exit;
			}				
			
		break;
								
		case "editar_grupo":
			
			$oGrupo = new Grupos;
			
			$oGrupo->setNumgGrupo($_POST["txtNumgGrupo"]);
			$oGrupo->setNomeGrupo($_POST["txtNomeGrupo"]);
			$oGrupo->setDescGrupo($_POST["txtDescGrupo"]);
			
			$oGrupo->editar();
			
			if (Erros::isError()){
				MostraErros();
			}else{ 
				header("Location: cadgrupos.php?info=2&numg_grupo=" . $_POST["numg_grupo"]); exit;
			}				
			
		break;

		case "excluir_grupo":

			$oGrupo = new Grupos;
			
			$oGrupo->excluir($_POST["txtNumgGrupo"]);
			
			if (Erros::isError()){
				MostraErros();
			}else{ 
				header("Location: cadgrupos.php?info=3"); exit;
			}				
			
		break;

		case "bloquear_grupo":

			$oGrupo = new Grupos;
			
			$oGrupo->bloquear(array($_POST["txtNumgGrupo"],$_SESSION["NUMG_OPERADOR"]));
			
			if (Erros::isError()){
				MostraErros();
			}else{ 
				header("Location: cadgrupos.php?info=4&numg_grupo=" . $_POST["numg_grupo"]); exit;
			}				
			
		break;
					
		case "desbloquear_grupo":

			$oGrupo = new Grupos;
			
			$oGrupo->desbloquear($_POST["txtNumgGrupo"]);
			
			if (Erros::isError()){
				MostraErros();
			}else{ 
				header("Location: cadgrupos.php?info=5&numg_grupo=" . $_POST["numg_grupo"]); exit;
			}				
			
		break;

		default:
			header("Location: cadgrupos.php"); exit;
		break;									
	}

?>