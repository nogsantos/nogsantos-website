<?php
include_once ("funcoes.php");
/************************************************************************
 Empresa: Net4U Solu��es Internet e Intranet

 Descri��o:
	
 Releases (Data, respons�vel e descri��o [�ltimo release primeiro]):
	 01/08/2005 (Rafael C�cero) 
		 Inclu�do este cabe�alho descrevendo a funcionalidade da p�gina
						
************************************************************************/
	
	if (empty($_SESSION["NUMG_OPERADOR"]) || $_SESSION["NUMG_OPERADOR"] == ""){ header("Location: expirou.htm"); exit; }
	
?>
<html>
<head>
<title>SIGO - Sistema de Gerenciamento de Obras</title>

<script language=JavaScript>
function VerificaWindow(){
	if (top.name != "gerenciador_sigo"){
		//window.location.href = "index.htm"
	}
}

</script>

<link href="estilos.css" rel="stylesheet" type="text/css">

</head>

<frameset onLoad="VerificaWindow();window.focus()" framespacing="0" border="0" rows="60,100%,20" frameborder="0" marginwidth="0" marginheight="0">

	<!-- BARRA DE ATALHOS -->
	<frame name="barra_atalhos" style="background-color:#3E3E3E" target="conteudo" src="barra_atalhos/barra_atalhos.php" scrolling="no" noresize marginwidth="0" marginheight="0">
	<frameset framespacing="5" border="0" cols="150,100%" frameborder="0">
		<!-- MENU DE NAVEGA��O -->
		<frame class=bordaFrameTotal name="menu" target="conteudo" src="menu.php" scrolling="no" noresize marginwidth="0" marginheight="0">
		<frameset framespacing="0" border="0" rows="30,100%" frameborder="0">
			<!-- BARRA DE FUN��ES -->
			<frame class=bordaFrameEsqDirSup name="barra_funcoes" target="conteudo" src="barra_funcoes.php" scrolling="no" noresize>
			<!-- CONTE�DO GERAL -->
			<frame class=bordaFrameTotal name="conteudo" target="conteudo" src="conteudo.php" scrolling="yes">
		</frameset>
	</frameset>
	<!-- BARRA DE STATUS -->
	<frame name="status" target="conteudo" src="barra_status.php" scrolling="no" noresize marginwidth="0" marginheight="0">
  
	<noframes>
		<body topmargin="0" leftmargin="0">
			<p>Este navegador n�o suporta quadros.</p>
		</body>
	</noframes>

</frameset>

</html>
