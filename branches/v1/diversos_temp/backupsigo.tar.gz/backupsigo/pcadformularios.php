<?php 
include_once "funcoes.php";
/************************************************************************
 Empresa: Interagi Tecnologia

 Descri��o: 
	
 Releases (Data, respons�vel e descri��o [�ltimo release primeiro]):
	 04/08/2005 (Rafael C�cero) 
		 Inclu�do este cabe�alho descrevendo a funcionalidade da p�gina
************************************************************************/

	if (empty($_SESSION["NUMG_OPERADOR"]) || $_SESSION["NUMG_OPERADOR"] == ""){
		header("Location: expirou.htm"); exit;
	}


	switch ($_POST["txtFuncao"]){
	
		case "cadastrar_formulario":
			
			$oFormulario = new Formularios;
			
			$oFormulario->setNumgFormulario(0);
			$oFormulario->setCodgFormulario($_POST["txtCodgFormulario"]);
			$oFormulario->setNomeFormulario($_POST["txtNomeFormulario"]);
			$oFormulario->setNomeCompleto($_POST["txtNomeCompleto"]);
			$oFormulario->setDescFormulario($_POST["txtDescFormulario"]);
			$oFormulario->setNumrAgrupamento($_POST["cboAgrupamentos"]);
			if ($_POST["chkFlagOculto"]){ 
				$oFormulario->setFlagOculto("t");
			}else{
				$oFormulario->setFlagOculto("f");
			}
			$oFormulario->setNumrOrdem($_POST["txtNumrOrdem"]);
			$oFormulario->setNumgOperadorCad($_SESSION["NUMG_OPERADOR"]);
			
			$oFormulario->cadastrar();
			
			if (Erros::isError()) { 
				MostraErros();
			}else{				
				header("Location: cadformularios.php?info=1"); exit;
			}
			
		break;
			
		case "editar_formulario":

			$oFormulario = new Formularios;
			
			$oFormulario->setNumgFormulario($_POST["txtNumgFormulario"]);
			$oFormulario->setCodgFormulario($_POST["txtCodgFormulario"]);
			$oFormulario->setNomeFormulario($_POST["txtNomeFormulario"]);
			$oFormulario->setNomeCompleto($_POST["txtNomeCompleto"]);
			$oFormulario->setDescFormulario($_POST["txtDescFormulario"]);
			$oFormulario->setNumrAgrupamento($_POST["cboAgrupamentos"]);
			if ($_POST["chkFlagOculto"]){ 
				$oFormulario->setFlagOculto("t");
			}else{
				$oFormulario->setFlagOculto("f");
			}
			$oFormulario->setNumrOrdem($_POST["txtNumrOrdem"]);
			
			$oFormulario->editar();

			if (Erros::isError()) { 
				MostraErros();
			}else{				
				header("Location: cadformularios.php?info=2"); exit;
			}
			
		break;
			
		case "excluir_formulario":

			$oFormulario = new Formularios;
			
			$oFormulario->excluir($_POST["txtNumgFormulario"]);

			if (Erros::isError()) { 
				MostraErros();
			}else{				
				header("Location: cadformularios.php?info=3"); exit;
			}
			
		break;
			
		case "bloquear_formulario":

			$oFormulario = new Formularios;
			
			$oFormulario->bloquear(array($_POST["txtNumgFormulario"],$_SESSION["NUMG_OPERADOR"]));
			
			if (Erros::isError()) { 
				MostraErros();
			}else{				
				header("Location: cadformularios.php?info=4"); exit;
			}

		break;
			
		case "desbloquear_formulario":		

			$oFormulario = new Formularios;
			
			$oFormulario->desbloquear($_POST["txtNumgFormulario"]);
			
			if (Erros::isError()) { 
				MostraErros();
			}else{				
				header("Location: cadformularios.php?info=5"); exit;
			}

		break;
			
		default:
			header("Location: cadformularios.php");	exit;
		break;
	}

?>