<?
include_once "funcoes.php";
include_once "classes/Sites.php";

/**
 * Empresa: Interagi Tecnologia
 * Descri��o:
 * Releases (Data, respons�vel e descri��o [�ltimo release primeiro]):
 *	 26/03/2008 (Danilo Fernandes) 
 *		 
 */

if (empty($_SESSION["NUMG_OPERADOR"]) || $_SESSION["NUMG_OPERADOR"] == ""){
	header("Location: expirou.htm"); exit;
}

switch ($_POST["txtFuncao"]){

	case "cadastrar_site":
		
		
		$oSite = new Sites();

		$oSite->setNomeSite($_POST["nomeSite"]);
		$oSite->setSiglUf($_POST["siglUf"]);
		$oSite->setNumrConstrucao($_POST["numrConstrucao"]);
		$oSite->setNumgMunicipio($_POST["numgMunicipio"]);
		$oSite->setDescEndereco($_POST["descEndereco"]);
		$oSite->setDescLatitude($_POST["descLatitude"]);
		$oSite->setDescLongitude($_POST["descLongitude"]);
		$oSite->setNumrDetentora($_POST["numrDetentora"]);
		$oSite->setNumrIdDetentora($_POST["numrIddetentora"]);
		$oSite->setNumrTipo($_POST["numrTipo"]);
		$oSite->setNumrTipotorre($_POST["numrTipotorre"]);
		$oSite->setNumrTipobts($_POST["numrTipobts"]);
		$oSite->setDescPericulosidade($_POST["descPericulosidade"]);
		$oSite->setDescPontoRef($_POST["descPontoRef"]);
		$oSite->setNumgOperadorcad($_SESSION["NUMG_OPERADOR"]);
		$oSite->setDataCadastro(date("d/m/Y"));
		$oSite->setNumgOperadoralt($_SESSION["NUMG_OPERADOR"]);
		$oSite->setDataUltimaalt(date("d/m/Y"));
		$oSite->setNumrLigacao($_POST["numrLigacao"]);
		$oSite->setNumrUndConsumidora($_POST["numrUndConsumidora"]);
		$oSite->setNumrAlturaTorre($_POST["numrAlturaTorre"]);
		$oSite->setNumrTecnologia($_POST["numrTecnologia"]);
		$oSite->setNumrRegiao($_POST["numrRegiao"]);

		

		$oSite->cadastrar();

		if (Erros::isError()){
			MostraErros();
		}else{
			header("Location: cadsites.php?info=1&numg_site=".$oSite->getNumgSite()); exit;
		}

		break;

	case "editar_site":

		$oSite = new Sites();

		$oSite->setNumgSite($_POST["numgSite"]);
		$oSite->setNomeSite($_POST["nomeSite"]);
		$oSite->setSiglUf($_POST["siglUf"]);
		$oSite->setNumrConstrucao($_POST["numrConstrucao"]);
		$oSite->setNumgMunicipio($_POST["numgMunicipio"]);
		$oSite->setDescEndereco($_POST["descEndereco"]);
		$oSite->setDescLatitude($_POST["descLatitude"]);
		$oSite->setDescLongitude($_POST["descLongitude"]);
		$oSite->setNumrDetentora($_POST["numrDetentora"]);
		$oSite->setNumrIdDetentora($_POST["numrIddetentora"]);
		$oSite->setNumrTipo($_POST["numrTipo"]);
		$oSite->setNumrTipotorre($_POST["numrTipotorre"]);
		$oSite->setNumrTipobts($_POST["numrTipobts"]);
		$oSite->setDescPericulosidade($_POST["descPericulosidade"]);
		$oSite->setDescPontoRef($_POST["descPontoRef"]);
		$oSite->setNumgOperadoralt($_SESSION["NUMG_OPERADOR"]);
		$oSite->setDataUltimaalt(date("d/m/Y"));
		$oSite->setNumrLigacao($_POST["numrLigacao"]);
		$oSite->setNumrUndConsumidora($_POST["numrUndConsumidora"]);
		$oSite->setNumrAlturaTorre($_POST["numrAlturaTorre"]);
		$oSite->setNumrTecnologia($_POST["numrTecnologia"]);
		$oSite->setNumrRegiao($_POST["numrRegiao"]);

		$oSite->editar();

		if (Erros::isError()){
			MostraErros();
		}else{
			header("Location: cadsites.php?info=2&numg_site=" . $oSite->getNumgSite()); exit;
		}

		break;

	case "excluir_site":

		$oSite = new Sites();

		$oSite->excluir($_POST["numgSite"]);

		if (Erros::isError()){
			MostraErros();
		}else{
			header("Location: cadsites.php?info=3"); exit;
		}

		break;
		
	case "cadastrar_documento":
			$NomeArquivo = strtolower(str_replace(" ","_",retiraAcentuacao($_FILES['txtPath']['name'])));
			
			if (move_uploaded_file($_FILES['txtPath']['tmp_name'], $_POST["txtCaminhoRelativo"].$NomeArquivo)) 
			{
				chmod($_POST["txtCaminhoRelativo"].$NomeArquivo,0777);
				
				//Atualiza Altera��o
				if (!empty($_POST['numgSite'])) 
				{
					Sites::atualizaUltimaAlteracao($_POST['numgSite']);
				}
				
				header("Location: cadsites.php?info=1&aba=doc&numg_site=".$_POST['numgSite']);	
				exit;
			} 
			else 
			{
				header("Location: cadsites.php?info=3&aba=doc&numg_site=".$_POST['numgSite']);
				exit;
			}
			break;	
		
	case "excluir_documento":
		$vArquivos = $_POST["chkNomeArquivo"];
			$Erro=0;
			
			for ($i=0;$i<count($vArquivos);$i++){
				if (!unlink($vArquivos[$i])) {
					$Erro+=1;
					if (!empty($_POST['numgSite'])) 
					{
						Sites::atualizaUltimaAlteracao($_POST['numgSite']);
					}
				} 				
			}
	break;
	default:
		header("Location: cadsites.php?info=3&aba=doc&numg_site=".$_POST['numgSite']); exit;
		break;
}
?>