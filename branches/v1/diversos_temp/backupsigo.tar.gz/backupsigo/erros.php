<?php
include_once ('funcoes.php');

/*******************************************************************************
 Empresa: Net4U Solu��es Internet e Intranet
 Cria��o: Rafael C�cero

 Descri��o:
	 Esta p�gina � respons�vel por apresentar as mensagens dos erros ocorridos
	 durante as opera��es do gerenciador. 
	
 Releases (Data, respons�vel e descri��o [�ltimo release primeiro]):
	 27/07/2005 (Rafael C�cero) 
		 Inclu�do este cabe�alho descrevendo a funcionalidade da p�gina
						
*******************************************************************************/

?>

<html>
<head>

<title>Sigo - Erros</title>

<link href="estilos.css" rel="stylesheet" type="text/css">

<SCRIPT language=JavaScript src="funcoes.js"></SCRIPT>

</head>
<body rightmargin="0" marginwidth="0" marginheight="0" leftmargin="0" bottommargin="0" topmargin="0" bgcolor="#FFFFFF">

<table border=0 width=100% align=center cellspacing=0 cellpadding=0>
<form method="post" action="enviaerro.php" name="form" target="envia_erro" onsubmit="return false">
	<input type=hidden name=txtErro value="">
	<input type=hidden name=txtOperador value="<?=$_SESSION["NOME_OPERADOR"]?>">
	<input type=hidden name=txtId value="<?=$_SESSION["NUMG_OPERADOR"]?>">
	<tr>
		<td><img src="imagens/space.gif" border=0 height=10></td>
	</tr>
	<tr>
		<td align=center>
			<table border=0 width=600 cellspacing=0 cellpadding=0>
				<tr>
					<td><img src="imagens/formEsqSup.gif" border=0 width=10 height=10></td>
					<td background="imagens/formMidSup.gif"></td>
					<td><img src="imagens/formDirSup.gif" border=0 width=10 height=10></td>
				</tr>
				<tr valign=top>
					<td width=10 background="imagens/formEsqMid.gif"></td>
					<td align=center>
						<table border=0 width=100% cellspacing=0 cellpadding=0 background="imagens/formMid.gif">
							<tr>
								<td height=10></td>
							</tr>
							<tr align=center>
								<td colspan=3>
									<table border=0 cellspacing=0 cellpadding=0 align=center width="100%">
										<tr>
											<td width=50% align=right><img src="imagens/icones/atencao.gif" border=0></td>
											<td width=50% class=normal11b>ATEN��O</td>
										</tr>
									</table>
								</td>
							<tr>
							<tr height=30 valign=top>
								<td class=normal11 align=center>Confira o(s) erro(s) encontrado(s) na execu��o da opera��o e clique no bot�o Voltar para corrig�-los:</td>
							</tr>
							<tr valign=top>
								<td class=normal11><span id="erro"><?=Erros::geraErro();?></span></td>
							</tr>
							<tr>
								<td height=10></td>
							</tr>

							<!-- IN�CIO BOT�ES DO FORMUL�RIO  -->
							<tr height=25 valign=bottom>
								<td colspan=4 align=right>
								<input type=button value="Enviar Erro" onClick="enviaErro()" class=botao id=submit1 name=submit1>&nbsp;
								<input type=button value=" Voltar " onClick="javascript:history.back()" class=botao id=submit1 name=submit1>
								</td>
							</tr>
							<!-- FIM BOT�ES DO FORMUL�RIO  -->

						</table>
					</td>
					<td width=10 background="imagens/formDirMid.gif"></td>
				</tr>
				<tr>
					<td><img src="imagens/formEsqInf.gif" border=0 width=10 height=10></td>
					<td background="imagens/formMidInf.gif"></td>
					<td><img src="imagens/formDirInf.gif" border=0 width=10 height=10></td>
				</tr>
				
			</table>
		</td>
	</tr>
	<tr>
		<td><img src="imagens/space.gif" border=0 height=10></td>
	</tr>
</form>
</table>
<script language=JavaScript>
	
function enviaErro(){
	document.form.txtErro.value = document.getElementById("erro").innerHTML;
	window.open("", "envia_erro", "directories=no,height=100,width=250,hotkeys=no,location=no,menubar=no,resizable=no,scrollbars=yes,status=no,toolbar=no,copyhistory=no,top=20,left=20")
	document.form.submit()
}
					
</script>
</body>
</html>