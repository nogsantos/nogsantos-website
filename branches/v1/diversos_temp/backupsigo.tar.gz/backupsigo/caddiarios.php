<? 
	include_once "funcoes.php"; 
	include_once("classes/Sites.php");
	include_once("classes/Diarios.php");
	include_once("classes/Fases.php");
	include_once("classes/Subatividades.php");
	include_once("classes/Operadores.php");
	
	$CODG_FORMULARIO = "caddiarios";
	$NOME_FORMULARIO = validarAcesso($CODG_FORMULARIO,$_SESSION["NUMG_OPERADOR"]);
	
	$numgSite = $_GET["numg_site"];
	$numgDiario = $_GET["numg_diario"];
	$numgSubatividade = $_GET["numg_subatividade"];
	
	$oSite = new Sites();
	$oDiario = new Diarios();
	$oFase = new Fases();
	$oSubatividades = new Subatividades();
	$oOperador = new Operadores();
	
	$bFoto = false;
	
	if(!empty($numgDiario)){
		$oDiario->setarDados($numgDiario);
		$vSubatividades = $oDiario->consultarSubativSimples($numgDiario);
		
		if($oDiario->existemSubativCadastradas($numgDiario)){
			$bFoto = true;
		}
	}	
	$vSites = $oSite->consultarTodas();
	
	if(!empty($numgSite)){
		$vFases = $oFase->consultarDesblPorSite($numgSite);
	}elseif($oDiario->getNumgDiario() != ""){
		$vFases = $oFase->consultarDesblPorSite($oDiario->getNumgSite());
	}
	
	if(!empty($numgSubatividade)){
		$oSubatividades->setarDados($numgSubatividade);
	}
	
	
	
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<title>::: SIGO :::</title>
<link href="estilos.css" rel="stylesheet" type="text/css">
<script language="JavaScript" src="funcoes.js"></script>
<script language="JavaScript">

function buscar_diario(){

	if (document.form.cboSite.value != "" && document.form.cboFase.value != "" && document.form.dataDiario.value != ""){
		document.form.txtFuncao.value = "buscar_diario"
		document.form.submit()
	}else{
		alert("Preencha o site, a fase e a data do di�rio a ser localizado!")
	}
}
function novo_diario(){
	window.location.href = '<?=$CODG_FORMULARIO?>.php'
}
function cadastrar_diario(){
	if (document.form.numgDiario.value == ""){
		if (pValidaGravacao()){
				document.form.txtFuncao.value = "cadastrar_diario"
				document.form.submit()
		}
	}else{
		alert("Fun��o de CADASTRO n�o dispon�vel para este formul�rio!")
	}
}

function editar_diario(){
	if (document.form.numgDiario.value != ""){
		if (pValidaGravacao()){
				document.form.txtFuncao.value = "editar_diario"
				document.form.submit()
		
		}
	}else{
		alert("Fun��o de EDI��O n�o dispon�vel para este formul�rio!")
	}
}

function liberar_diario(){
	if (document.form.numgDiario.value != ""){
			if (confirm("Confirma a Libera��o dos dados do Di�rio?")){
				document.form.txtFuncao.value = "liberar_diario"
				document.form.submit()
			}
		
	}else{
		alert("Fun��o de LIBERA��O n�o dispon�vel para este formul�rio!")
	}
}


function excluir_diario(){
	if (document.form.numgDiario.value != ""){
		if (confirm("Confirma a EXCLUS�O do Di�rio?")){
			document.form.txtFuncao.value = "excluir_diario"
			document.form.submit()
		}
	}else{
		alert("Fun��o de EXCLUS�O n�o dispon�vel para este formul�rio!")
	}
}

function imprimir_diario(){
		var w = 750;
		var h = 650;
		window.open('impdiarios.php?bloqueadas=<?=$_GET["bloqueadas"]?>&numg_diario=<?=$numgDiario?>', '', 'width='+w+',height='+h+',fullscreen=no,scrollbars=yes,resizable=yes,status=no,toolbar=no,menubar=no,location=no');
}

function imprimir_status(){
		var w = 750;
		var h = 650;
		window.open('impstatussite.php?bloqueadas=<?=$_GET["bloqueadas"]?>&numg_diario=<?=$numgDiario?>', '', 'width='+w+',height='+h+',fullscreen=no,scrollbars=yes,resizable=yes,status=no,toolbar=no,menubar=no,location=no');
}

function pValidaGravacao(){

	var sErr = ""
	
	if(!IsDate(document.form.dataDiario.value)){
		sErr = sErr + "Data inv�lida"
	}

	//VERIFICA SE FOI ENCONTRADO ALGUM ERRO NA VALIDA��O DO FORMUL�RIO
	if (sErr != ""){
		sErr = "Verifique os erros encontrados abaixo:\n\n" + sErr
		alert(sErr)
		return false
	}else
	return true
}
function iniForm(){
	MontaFuncoes('<?=$CODG_FORMULARIO?>','<?=$NOME_FORMULARIO?>','<?=$oDiario->getNumgDiario()?>')
	<? if($oDiario->getNumgDiario() != "" ){?>
		<? if($_GET["aba"]==2){?>
			AlteraTab(2,2)
		<? }else{?>
			AlteraTab(1,1)	
		<? }?>
	<? }?>
}
function confirmaGravacao(destino){
	if (confirm("Todas as informa��es n�o salvas ser�o perdidas.\n Deseja continuar?")){
		window.location.href=destino;
	}
}

</script>

<style type="text/css">

#dhtmltooltip{
position: absolute;
width: 200px;
border: 1px solid black;
padding: 5px;
background-color: lightyellow;
visibility: hidden;
z-index: 100;
/*Remove below line to remove shadow. Below line should always appear last within this CSS*/
filter: progid:DXImageTransform.Microsoft.Shadow(color=gray,direction=135);
}

</style>
</head>

<body onLoad="iniForm()" rightmargin="0" marginwidth="0" marginheight="0" leftmargin="0" bottommargin="0" topmargin="0" bgcolor="#FFFFFF">

<div id="dhtmltooltip"></div>

<script language=JavaScript>

/***********************************************
* Cool DHTML tooltip script- � Dynamic Drive DHTML code library (www.dynamicdrive.com)
* This notice MUST stay intact for legal use
* Visit Dynamic Drive at http://www.dynamicdrive.com/ for full source code
***********************************************/

var offsetxpoint=-60 //Customize x offset of tooltip
var offsetypoint=20 //Customize y offset of tooltip
var ie=document.all
var ns6=document.getElementById && !document.all
var enabletip=false
if (ie||ns6)
var tipobj=document.all? document.all["dhtmltooltip"] : document.getElementById? document.getElementById("dhtmltooltip") : ""

function ietruebody(){
	return (document.compatMode && document.compatMode!="BackCompat")? document.documentElement : document.body
}

function ddrivetip(thetext, thecolor, thewidth){
	if (ns6||ie){
		if (typeof thewidth!="undefined") tipobj.style.width=thewidth+"px"
		if (typeof thecolor!="undefined" && thecolor!="") tipobj.style.backgroundColor=thecolor
		tipobj.innerHTML=thetext
		enabletip=true
		return false
	}
}

function positiontip(e){
	if (enabletip){

		var curX=(ns6)?e.pageX : event.x+ietruebody().scrollLeft;
		var curY=(ns6)?e.pageY : event.y+ietruebody().scrollTop;
		//Find out how close the mouse is to the corner of the window
		var rightedge=ie&&!window.opera? ietruebody().clientWidth-event.clientX-offsetxpoint : window.innerWidth-e.clientX-offsetxpoint-20
		var bottomedge=ie&&!window.opera? ietruebody().clientHeight-event.clientY-offsetypoint : window.innerHeight-e.clientY-offsetypoint-20

		var leftedge=(offsetxpoint<0)? offsetxpoint*(-1) : -1000

		//if the horizontal distance isn't enough to accomodate the width of the context menu
		if (rightedge<tipobj.offsetWidth)
			//move the horizontal position of the menu to the left by it's width
			tipobj.style.left=ie? ietruebody().scrollLeft+event.clientX-tipobj.offsetWidth+"px" : window.pageXOffset+e.clientX-tipobj.offsetWidth+"px"
		else if (curX<leftedge)
			tipobj.style.left="5px"
		else
			//position the horizontal position of the menu where the mouse is positioned
			tipobj.style.left=curX+offsetxpoint+"px"

		//same concept with the vertical position
		if (bottomedge<tipobj.offsetHeight)
			tipobj.style.top=ie? ietruebody().scrollTop+event.clientY-tipobj.offsetHeight-offsetypoint+"px" : window.pageYOffset+e.clientY-tipobj.offsetHeight-offsetypoint+"px"
		else
			tipobj.style.top=curY+offsetypoint+"px"
			
		tipobj.style.visibility="visible"
	}
}

function hideddrivetip(){
	if (ns6||ie){
		enabletip=false
		tipobj.style.visibility="hidden"
		tipobj.style.left="-1000px"
		tipobj.style.backgroundColor=''
		tipobj.style.width=''
	}
}

function visualizar_naoliberados()
{
	document.getElementsByTagName('input').item(0).name = 'rdoOpcao';
	document.getElementsByTagName('input').item(0).value = '1';
	document.getElementsByTagName('input').item(1).name = 'descSituacao';
	document.getElementsByTagName('input').item(1).value = 'N';
	document.forms[0].action = 'preldiarios.php';
	document.forms[0].submit();
}
document.onmousemove=positiontip

</script>
<table border=0 width=100% align=center cellspacing=0 cellpadding=0>
	<tr>
		<td><img src="imagens/space.gif" border=0 height=10></td>
	</tr>
	<tr>
		<td align=center>
			<table border=0 width=600 cellspacing=0 cellpadding=0>
				<tr>
					<td><img src="imagens/formEsqSup.gif" border=0 width=10 height=10></td>
					<td background="imagens/formMidSup.gif"></td>
					<td><img src="imagens/formDirSup.gif" border=0 width=10 height=10></td>
				</tr>
				<tr valign=top>
					<td width=10 background="imagens/formEsqMid.gif"></td>
					<td>
						<table border=0 width=100% cellspacing=0 cellpadding=0 align=center background="imagens/formMid.gif">
						<form method="post" action="pcaddiarios.php" name="form">
							<input type=hidden name=txtFuncao value="">
							<input type=hidden name=numgDiario value="<?=$oDiario->getNumgDiario()?>">
							
							<!-- IN�CIO CAMPOS DO FORMUL�RIO  -->
							<?php if ($_GET["info"] != ""){?>
							<tr>
								<td colspan=2 align=center height=20 valign=middle class=normal11>
								<img src="imagens/icones/info.gif" border=0 align=absbottom>&nbsp;&nbsp;
								<?php 		
									switch ($_GET["info"]){
										case 1:
											echo "Cadastro realizado com sucesso";
											break;
										case 2:
											echo "Edi��o realizada com sucesso";
											break;
										case 3:
											echo "Exclus�o realizada com sucesso";
											break;
										case 4:
											echo "Libera��o realizada com sucesso";
											break;
										
									} ?>
								</td>
							</tr>
							<?php }?>				
							<tr>
								<td colspan=3>
									<table border=0 width=580 cellspacing=0 cellpadding=2>
										<tr>
											<td width=20% align=right class=normal11b>Site:</td>
											<TD width=80% align="left">
												<select name=cboSite id=cboSite class=borda style="width:435px" onChange="window.location.href='caddiarios.php?numg_site=' + document.form.cboSite.value">
												<? if($oDiario->getNumgDiario() == ""){
													montaCombo($vSites,"numg_site","nome_site",$numgSite,true);
												 }else{ 
													montaCombo($vSites,"numg_site","nome_site",$oDiario->getNumgSite(),true);
												  }?>	
												</select>
												
											</TD>
										</tr>
										<tr>
											<td width=20% align=right class=normal11b>Fase:</td>
											<TD width=80% align="left">
												<select name=cboFase id=cboFase class=borda style="width:435px">
												<? if($oDiario->getNumgDiario() == ""){
													montaCombo($vFases,"numg_fase","nome_fase",$numgFase,true);
												 }else{ 
													montaCombo($vFases,"numg_fase","nome_fase",$oDiario->getNumgFase(),true);
												  }?>	
												</select>
												
											</TD>
										</tr>
										<tr>
											<td width=20% align=right class=normal11b>Data:</td>
										  	<TD width=80% align="left">
												<table cellpadding="0" cellspacing="0" border="0" width="100%">
													<tr>
														<td width="50%">
															<input name="dataDiario" type="text" class="borda" id="dataDiario" value="<?=FormataData($oDiario->getDataDiario())?>" size="10" maxlength="10" onKeyUp="FormataData('dataDiario',event)">
															<input type=image src='imagens/icones/pesquisar.gif' border=0 onClick="buscar_diario();return false" align=center id=imagePesquisar name=imagePesquisar>											
														</td>
														<td align="right" class="normal11" width="50%">
														<?
																if ($_GET["numg_diario"] != "" ){
																	$oOperador->setarDadosOperador($oDiario->getNumgOperadorcad());
																?>
																		cadastrado em: <b><?=FormataDataHora($oDiario->getDataCadastro())?></b>&nbsp;[<?=$oOperador->getNomeOperador()?>]
																		
															<?	}
															?>
														</td>
													</tr>
												</table>
											</TD>
										</tr>
									</table>
								</td>
							</tr>
							<tr>
								<td height=10></td>
							</tr>
							
							<? if($oDiario->getNumgDiario() != "" ){?>
							<tr>
								<td colspan=3>
									<script language="JavaScript">										
									<? if($_GET["aba"]=="2"){?>
										montaTabs(Array("Di�rio","Imagens","",""),2)
									<? }else{ ?>	
										montaTabs(Array("Di�rio","","",""),1)
									<? }?>
									</script>
								</td>
							</tr>
							<tr>
								<td colspan=3>
									<div id="tab1">
												<table border="0" width="580" cellspacing="0" cellpadding="2" class="bordaEsqDirInf"> 
													<tr>
														<td class="normal11" align="left">
															<table border="0" width="100%">
																<tr>
																	<td class="normal11b" align="right">NA:</td>
																	<td class="normal11" align="left">N�o se aplica</td>
																	<td class="normal11b" align="right">OK:</td>
																	<td class="normal11" align="left">OK</td>
																	<td class="normal11b" align="right">NI:</td>
																	<td class="normal11" align="left" width="50%">N�o Iniciado</td>
																</tr>
																<tr>
																	<td class="normal11b" align="right">NOK:</td>
																	<td class="normal11" align="left">N�o OK</td>
																	<td class="normal11b" align="right">EC:</td>
																	<td class="normal11" align="left">Em Constru��o</td>
																</tr>
																<tr>
																	<td colspan=6 class="normal11" align="left"> <!--&nbsp;&nbsp;&nbsp;&nbsp;*Itens em <span class="destaque"><b>vermelho</b></span> possuem um <b>NOK</b> anterior n�o resolvido.--></td>
																</tr>
																<tr>
																	<td colspan=6 class="normal11" align="right">
																		<? if($_GET["bloqueadas"] == "true"){?>
																		<a class="relatorio" href="caddiarios.php?numg_diario=<?=$oDiario->getNumgDiario()?>">&raquo; Ocultar bloqueadas</a>	
																	<?	}else{?>
																		<a class="relatorio" href="caddiarios.php?numg_diario=<?=$oDiario->getNumgDiario()?>&bloqueadas=true">&raquo; Apresentar bloqueadas</a> 
																	<?	}?>
																	</td>
																</tr>
															</table>
															
															<? $tituloAtividade = ""; 
															for ($i=0; $i<$vSubatividades->getCount(); $i++){?>
															<!-- IN�CIO DE UM CAMPO DE SUBATIVIDADE -->	
															<table border="0" width="575" cellspacing="0" cellpadding="2"> 	
																<? if($tituloAtividade != $vSubatividades->getValores($i,"nome_atividade")){?>
																<tr>
																	<td colspan="3"><img src="imagens/space.gif" height="5" /></td>
																</tr>
																<tr> 
																	<td width="30%" bgcolor="#F3F3F3" align="center" class="normal11"><strong><?=$vSubatividades->getValores($i,"nome_atividade")?></strong></td> 
																	<td width="10%" bgcolor="#F3F3F3" align="center" class="normal11"><strong>Status</strong></td> 
																	<td width="60%" bgcolor="#F3F3F3" align="center" class="normal11"><strong>Descri��o</strong></td> 
																</tr>	
																<? 
																	$tituloAtividade = $vSubatividades->getValores($i,"nome_atividade");
																	} ?>
																<? if(($vSubatividades->getValores($i,"data_bloqueio")=="")or($vSubatividades->getValores($i,"data_bloqueio")!="" and $_GET["bloqueadas"]=="true")){?>
																<tr> 
																	<td width="30%" align="right" class="<? if ($vSubatividades->getValores($i,"count_ok") == "0" && $vSubatividades->getValores($i,"data_nok") != "" ){echo "destaque";}else{echo "normal11";}?>"><?=$vSubatividades->getValores($i,"nome_subatividade");?> <?if($vSubatividades->getValores($i,"numr_status")!="" and $vSubatividades->getValores($i,"data_bloqueio")!=""){ echo " (Bloqueada)";}?></td> 
																	<td width="10%" align="left" class="normal11">
																		<select name="cboStatus<?=$vSubatividades->getValores($i,"numg_subatividade")?>" id="cboStatus<?=$vSubatividades->getValores($i,"numg_subatividade")?>" class=borda <?if($vSubatividades->getValores($i,"numr_status")!="" and $vSubatividades->getValores($i,"data_bloqueio")!=""){ echo "disabled=disabled";}?>>
																			<option value="1" <? if ($vSubatividades->getValores($i,"numr_status") == "1" || $vSubatividades->getValores($i,"numr_status") == "" ) {  echo "selected"; }?>>NA</option>
																			<option value="2" <? if ($vSubatividades->getValores($i,"numr_status") == "2") {  echo "selected"; }?>>OK</option>
																			<option value="3" <? if ($vSubatividades->getValores($i,"numr_status") == "3") {  echo "selected"; }?>>NOK</option>
																			<option value="4" <? if ($vSubatividades->getValores($i,"numr_status") == "4") {  echo "selected"; }?>>EC</option>
																			<option value="5" <? if ($vSubatividades->getValores($i,"numr_status") == "5") {  echo "selected"; }?>>NI</option>
																		</select> 
																	</td> 
																	<td width="60%" align="left" class="normal11">
																		<input type="text" name="descComentario<?=$vSubatividades->getValores($i,"numg_subatividade")?>" id="descComentario<?=$vSubatividades->getValores($i,"numg_subatividade")?>" class="borda" style="width:305px;" value="<?=htmlspecialchars($vSubatividades->getValores($i,"desc_comentario"))?>" <? if($vSubatividades->getValores($i,"desc_comentario") != ""){?>onMouseover="ddrivetip('<span class=normal11><?=htmlspecialchars($vSubatividades->getValores($i,"desc_comentario"))?></span>','white',250)" onMouseout="hideddrivetip()"<? }?> maxlength="255" <?if($vSubatividades->getValores($i,"numr_status")!="" and $vSubatividades->getValores($i,"data_bloqueio")!=""){ echo "disabled=disabled";}?>>
																		<? if($bFoto){?>
																			<? if(intval($vSubatividades->getValores($i,"numr_fotos"))==0){?>
																				<a href="#"><img src="imagens/icone_imagens.jpg" alt="Incluir fotos" width="16" height="16" border="0" onclick="confirmaGravacao('caddiarios.php?numg_diario=<?=$numgDiario?>&numg_subatividade=<?=$vSubatividades->getValores($i,"numg_subatividade")?>&aba=2')"/></a>
																			<? }else{?>
																				<a href="#"><img src="imagens/icone_imgs.jpg" alt="<?=$vSubatividades->getValores($i,"numr_fotos")?> foto(s) cadastrada(s)" width="16" height="16" border="0" onclick="confirmaGravacao('caddiarios.php?numg_diario=<?=$numgDiario?>&numg_subatividade=<?=$vSubatividades->getValores($i,"numg_subatividade")?>&aba=2')"/></a>
																			<? }?>
																		<? }?>
																	</td> 
																</tr>
																<?}?>
															</table>
															<!-- FIM DE UM CAMPO DE SUBATIVIDADE -->
															<? 
																	if($i == ($vSubatividades->getCount()-1)){
																		$sNumgsSubatividades .= $vSubatividades->getValores($i,"numg_subatividade");
																	}else{
																		$sNumgsSubatividades .= $vSubatividades->getValores($i,"numg_subatividade") . ",";
																	}
																} ?>
													  </td>
													</tr>
														
												</table>		 
												
										</div>
								<input type="hidden" name="numgsSubatividades" id="numgsSubatividades" value="<?=$sNumgsSubatividades?>" />
									<? if($_GET['aba'] == "2" ){ 	?>
									   <div id="tab2">
									   		<iframe name="iframe" src="iframecadimg.php?cat=3&id=<?=$oDiario->getNumgDiario()?>-<?=$numgSubatividade?>-<?=$oDiario->getNumgSite()?>&nome_subatividade=<?=$oSubatividades->getNomeSubatividade()?>" frameborder="0" width="100%" height="300" scrolling="no" class="bordaEsqDirInf"></iframe>
									   </div>
									 <? }?>
								</td>
							</tr>
							<!-- FIM CAMPOS DO FORMUL�RIO  -->
							<? }?>
						</form>
							<tr>
								<td colspan="6" class="normal11" align="right">
									<?
										if ($_GET["numg_diario"] != "" ){ 
											$oOperador->setarDadosOperador($oDiario->getNumgOperadoralt());
											if($oDiario->getDataUltimaalt() != ""){
										?>
												�ltima altera��o: <b><?=FormataDataHora($oDiario->getDataUltimaalt())?></b>&nbsp;[<?=$oOperador->getNomeOperador()?>]
												
									<?		}
										}
									?>
								</td>
							</tr>
							<tr>
								<td colspan="6" class="normal11" align="right">
									<?
										if ($_GET["numg_diario"] != "" ){ 
											$oOperador->setarDadosOperador($oDiario->getNumgOperadorlib());
											if($oDiario->getDataLiberacao() != ""){
										?>
												libera��o: <b><?=FormataDataHora($oDiario->getDataLiberacao())?></b>&nbsp;[<?=$oOperador->getNomeOperador()?>]
												
									<?		}
										}
									?>
								</td>
							</tr>
						</table>
					</td>
					<td width=10 background="imagens/formDirMid.gif"></td>
				</tr>
				<tr>
					<td><img src="imagens/formEsqInf.gif" border=0 width=10 height=10></td>
					<td background="imagens/formMidInf.gif"></td>
					<td><img src="imagens/formDirInf.gif" border=0 width=10 height=10></td>
				</tr>
			</table>
		</td>
	</tr>
	
	<tr>
		<td><img src="imagens/space.gif" border=0 height=10></td>
	</tr>
</table>
</body>
</html>
