<?
include_once "funcoes.php";
include_once("classes/Empresas.php");


/************************************************************************
'Empresa: Interagi Tecnologia

'Descri��o:

'Releases (Data, respons�vel e descri��o [�ltimo release primeiro]):
'25/03/2008 (Danilo Fernandes)
'Criada

'************************************************************************/

$CODG_FORMULARIO = "cadempresas";
$NOME_FORMULARIO = validarAcesso($CODG_FORMULARIO,$_SESSION["NUMG_OPERADOR"]);


$oEmpresa = new Empresas();
$vEmpresas = new Resultset();
$vEmpresas = $oEmpresa->consultarEmpresas();
if ($_GET["numg_empresa"] != "") {
		
		$oEmpresa->setarDados($_GET["numg_empresa"]);
		if (Erros::isError()) MostraErros();
		
	
		if (Erros::isError()) MostraErros();
		
	} 
$bPesquisa = true;
	
if (Erros::isError()){
	MostraErros();
}


?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<title>::: SIGO :::</title>
<link href="estilos.css" rel="stylesheet" type="text/css">
<script type="text/javascript" src="javascripts/prototype.js"> </script>
<script language="JavaScript" src="funcoes.js"></script>
<script type="text/javascript" src="javascripts/populacombo.js"></script>
<script language="JavaScript">
function nova_empresa(){
	window.location.href = '<?=$CODG_FORMULARIO?>.php'
}
function cadastrar_empresa(){
	if (document.form.numgEmpresa.value == ""){
		if (pValidaGravacao()){
				document.form.txtFuncao.value = "cadastrar_empresa"
				document.form.submit()
			
		}
	}else{
		alert("Fun��o de CADASTRO n�o dispon�vel para este formul�rio!")
	}
}

function editar_empresa(){
	if (document.form.numgEmpresa.value != ""){
		if (pValidaGravacao()){
				document.form.txtFuncao.value = "editar_empresa"
				document.form.submit()
			
		}
	}else{
		alert("Fun��o de EDI��O n�o dispon�vel para este formul�rio!")
	}
}

function excluir_empresa(){
	if (document.form.numgEmpresa.value != ""){
		if (confirm("Confirma a EXCLUS�O da Empresa?")){
			document.form.txtFuncao.value = "excluir_empresa"
			document.form.submit()
		}
	}else{
		alert("Fun��o de EXCLUS�O n�o dispon�vel para este formul�rio!")
	}
}

function pValidaGravacao(){

	var sErr = ""

	//VERIFICA SE FOI ENCONTRADO ALGUM ERRO NA VALIDA��O DO FORMUL�RIO
	if (sErr != ""){
		sErr = "Verifique os erros encontrados abaixo:\n\n" + sErr
		alert(sErr)
		return false
	}else
	return true
}

function iniForm(){
	MontaFuncoes('<?=$CODG_FORMULARIO?>','<?=$NOME_FORMULARIO?>','<?=$oEmpresa->getNumgEmpresa()?>')
	AlteraTab(1,1)
	
}

</script>
</head>

<body onLoad="iniForm()" rightmargin="0" marginwidth="0" marginheight="0" leftmargin="0" bottommargin="0" topmargin="0" bgcolor="#FFFFFF">
<table border="0" width="100%" align="center" cellspacing="0" cellpadding="0">
	<tr>
		<td><img src="imagens/space.gif" border="0" height="10"></td>
	</tr>
	<tr>
		<td align="center">
			<table border="0" width="600" cellspacing="0" cellpadding="0">
				<tr>
					<td><img src="imagens/formEsqSup.gif" border="0" width="10" height="10"></td>
					<td background="imagens/formMidSup.gif"></td>
					<td><img src="imagens/formDirSup.gif" border="0" width="10" height="10"></td>
				</tr>
				<tr valign="top">
					<td width="10" background="imagens/formEsqMid.gif"></td>
					<td>
						<table border="0" width="580" cellspacing="0" cellpadding="0" align="center" background="imagens/formMid.gif">
							
								<form method="post" action="pcadempresas.php" name="form" id="form"> 
									<input name="numgEmpresa" type="hidden" value="<?=$oEmpresa->getNumgEmpresa()?>"> 
									<input name="txtFuncao" type="hidden" value=""> 
									<? if ($_GET["info"] != "") { ?>
									<tr>
										<td colspan="4" align="center" background="#F5F7F7"  height="20" valign="middle" class="normal11">
											<img src="imagens/icones/info.gif" border="0" align="absbottom">&nbsp;&nbsp;
										<? 		
										switch ($_GET["info"]){
											case 1:
												echo "Cadastro realizado com sucesso";
												break;
											case 2:
												echo "Edi��o de dados realizada com sucesso";
												break;
											case 3:
												echo "Exclus�o realizada com sucesso";
												break;									
										} 
										?>		
										</td>
									</tr>
										<? }else if (!$bPesquisa) { ?>
										<tr>
											<td colspan="4" align="center" height="20" valign="middle" class="normal11">
												<img src="imagens/icones/excla.gif" border="0" align="absbottom">&nbsp;&nbsp;Nenhum registro encontrado para a pesquisa						
											</td>
										</tr>
								<? } ?>
								<tr> 
									<td>
									
										<script language="JavaScript">										
											montaTabs(Array("Dados Gerais","","",""),1)
										</script>	
										
									</td> 
									</tr> 
									<tr> 
										<td align="left">
											<div id="tab1">
												<table border="0" width="580" cellspacing="0" cellpadding="2" class="bordaEsqDirInf"> 
														<tr>
															<td><img src="imagens/space.gif" border="0" height="5"></td>
														</tr>
														<tr> 
															<td align="right" class="normal11">
																<strong>Nome:</strong>
															</td> 
															<td colspan="5" >
																<span class="normal11" > 
																	<input name="nomeEmpresa" tabindex="1" type="text" class="borda" id="nomeEmpresa" value="<?=$oEmpresa->getNomeEmpresa();?>" size="72" maxlength="50" onkeydown="setarFocus(this,'form',event)"> 
																</span>
															</td> 
														</tr>
														<tr>
															<td>
																<img src="imagens/space.gif" border=0 height=10>
															</td>
														</tr>
												</table>		 
											</div> 					
										</td>
									</tr>
								</table>
							</form>
					</td>
					<td width="10" background="imagens/formDirMid.gif"></td>
				</tr>
				<tr>
					<td><img src="imagens/formEsqInf.gif" border="0" width="10" height="10"></td>
					<td background="imagens/formMidInf.gif"></td>
					<td><img src="imagens/formDirInf.gif" border="0" width="10" height="10"></td>
				</tr>
			</table>
			
		</td>
	</tr>
	<?php 
	if (isset($vEmpresas)){
	if ($vEmpresas->getCount() > 0){?>
	<tr>
		<td >
			<table border=0 width="600" cellspacing=0 cellpadding=0 align=center>
				<tr>
					<td colspan=2 class=normal11 height=25 valign=bottom>Rela��o dos sites cadastradas:</td>
				</tr>
				<tr height=20 class=normal11b align=center>
					<td background="imagens/fundoBarraRelatorio.gif" colspan="2">Nome</td>
				</tr>
				<?php for ($i=0; $i<$vEmpresas->getCount(); $i++){?>
				<tr height=20 <?php if ($i % 2 == 1){?>bgcolor="#E8E8E8"<?php }?> class=relatorio>
					<td colspan="2"><a href="cadempresas.php?numg_empresa=<?=$vEmpresas->getValores($i,"numg_empresa");?>" class="relatorio"><?=$vEmpresas->getValores($i,"nome_empresa");?></a></td>

				</tr>
				<?php }?>
				<tr height=20 <?php if ($i % 2 == 1){?>bgcolor="#E8E8E8"<?php }?>>
					<td class=destaque>* Clique no nome da site para edit�-lo</td>
					<td class=normal11b align=right>TOTAL: <?=$vEmpresas->getCount(); ?></td>
				</tr>
			</table>
			
		</td>
	</tr>
	<?php } }?>
	<tr>
		<td><img src="imagens/space.gif" border=0 height=10></td>
	</tr>
	
</table>

<? $oEmpresa->free; ?>

</body>

<head>
<META HTTP-EQUIV="Pragma" CONTENT="no-cache">
<META HTTP-EQUIV="Expires" CONTENT="-1">
</head>
</html>
