<?php 
include_once "funcoes.php";
include_once "classes/Funcoes.php";
include_once "classes/Grupos.php";
/************************************************************************
 Empresa: Interagi Tecnologia

 Descri��o: 
	
 Releases (Data, respons�vel e descri��o [�ltimo release primeiro]):
	 04/08/2005 (Rafael C�cero) 
		 Inclu�do este cabe�alho descrevendo a funcionalidade da p�gina
************************************************************************/

	if (empty($_SESSION["NUMG_OPERADOR"]) || $_SESSION["NUMG_OPERADOR"] == ""){
		header("Location: expirou.htm"); exit;
	}
	
	switch ($_POST["txtFuncao"]){
	
		case "cadastrar_funcao":
			
			$oFuncao = new Funcoes;
			
			$oFuncao->setNumgFuncao(0);
			$oFuncao->setNumgFormulario($_POST["cboFormularios"]);
			$oFuncao->setCodgFuncao($_POST["txtCodgFuncao"]);
			$oFuncao->setNomeFuncao($_POST["txtNomeFuncao"]);
			$oFuncao->setDescFuncao($_POST["txtDescFuncao"]);
			$oFuncao->setNomeIcone($_POST["cboIcones"]);
			$oFuncao->setNumrOrdem($_POST["txtNumrOrdem"]);
			$oFuncao->setFlagNovoRegistro($_POST["chkFlagNovoRegistro"]);
			$oFuncao->setFlagPublica($_POST["chkFlagPublica"]);
			$oFuncao->setNumgOperadorCad($_SESSION["NUMG_OPERADOR"]);
			
			$oFuncao->cadastrar();
			
			if (Erros::isError()){
				MostraErros();
			}else{ 
				header("Location: cadfuncoes.php?info=1&numg_funcao=" . $oFuncao->getNumgFuncao()); exit;
			}				

		break;
						
		case "editar_funcao":
			
			$oFuncao = new Funcoes;
			
			$oFuncao->setNumgFuncao($_POST["txtNumgFuncao"]);
			$oFuncao->setNumgFormulario($_POST["cboFormularios"]);
			$oFuncao->setCodgFuncao($_POST["txtCodgFuncao"]);
			$oFuncao->setNomeFuncao($_POST["txtNomeFuncao"]);
			$oFuncao->setDescFuncao($_POST["txtDescFuncao"]);
			$oFuncao->setNomeIcone($_POST["cboIcones"]);
			$oFuncao->setNumrOrdem($_POST["txtNumrOrdem"]);
			$oFuncao->setFlagNovoRegistro($_POST["chkFlagNovoRegistro"]);
			$oFuncao->setFlagPublica($_POST["chkFlagPublica"]);
			
			$oFuncao->editar();
			
			if (Erros::isError()){
				MostraErros();
			}else{ 
				header("Location: cadfuncoes.php?info=2&numg_formulario=" . $_POST["cboFormularios"]); exit;
			}				
			
		break;
						
		case "excluir_funcao":
		
			$oFuncao = new Funcoes;
			
			$oFuncao->excluir($_POST["txtNumgFuncao"]);
			
			if (Erros::isError()){
				MostraErros();
			}else{ 
				header("Location: cadfuncoes.php?info=3&numg_formulario=" . $_POST["cboFormularios"]); exit;
			}					
			
		break;

		case "bloquear_funcao":

			$oFuncao = new Funcoes;
			
			$oFuncao->bloquear(array($_POST["txtNumgFuncao"],$_SESSION["NUMG_OPERADOR"]));
			
			if (Erros::isError()){
				MostraErros();
			}else{ 
				header("Location: cadfuncoes.php?info=4&numg_formulario=" . $_POST["cboFormularios"]); exit;
			}					
			
		break;
					
		case "desbloquear_funcao":	

			$oFuncao = new Funcoes;
			
			$oFuncao->desbloquear($_POST["txtNumgFuncao"]);
			
			if (Erros::isError()){
				MostraErros();
			}else{ 
				header("Location: cadfuncoes.php?info=5&numg_formulario=" . $_POST["cboFormularios"]); exit;
			}					
			
		break;

		case "cadastrar_grupofunc":
		
			$vGruposDisponiveis = $_POST["cboGruposDisponiveis"];

			$oGrupos = new Grupos;
			for ($i=0; $i<count($vGruposDisponiveis); $i++){
				$oGrupos->cadastrarGrupoFuncao(array($vGruposDisponiveis[$i],$_POST["txtNumgFuncao"]));
			}
			
			if (Erros::isError()){
				MostraErros();
			}else{ 
				header("Location: cadfuncoes.php?info=6&numg_funcao=" . $_POST["txtNumgFuncao"]); exit;
			}
			
		case "excluir_grupofunc":
			
			$vGruposFuncao = $_POST["cboGruposFuncao"];

			$oGrupos = new Grupos;
			for ($i=0; $i<count($vGruposFuncao); $i++){
				$oGrupos->excluirGrupoFuncao(array($vGruposFuncao[$i],$_POST["txtNumgFuncao"]));
			}

			if (Erros::isError()){
				MostraErros();
			}else{ 
				header("Location: cadfuncoes.php?info=7&numg_funcao=" . $_POST["txtNumgFuncao"]); exit;
			}

		default:
			header("Location: cadfuncoes.php"); exit;
		break;									
	}

?>