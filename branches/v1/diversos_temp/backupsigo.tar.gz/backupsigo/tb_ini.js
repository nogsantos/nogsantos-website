var mmwwm="imagens/botoes/";
var mmmmmm="caixacores.htm";
var www="infotabelas.htm"; 
var url_imagem = "infoimagens.php";
var wwwmwm="O tamanho do campo '%s1' ultrapassa o limite de %s2 caracteres, com %s3, incluindo formata��o."; 

var wwm=new Array(G_numFields);

for(var wwwww=0;wwwww<G_numFields;wwwww++){ 
	wwm[wwwww]=new Array();
}
   
var wmmmwmm=0;  
var mmwwmwww=1;  
var m=2; 
var mwmwmmm=3; 
var wmwmmmmm=4;  

function mmmmmww(){}
function mwwwmw(){}
function mmmmmwm(){} 

// ESTRUTURA OS BOT�ES NA BARRA DE FERRAMENTAS 
function MontaBotoes(wwww,mmmm,wm,wmwwmmmw,ww){
	var mmmwmww="cmd"+wwww+ww.toString();
	if(wmwwmmmw==mwmwmmm){
		document.write("<td width=\"6\" height=\"22\">");
		document.write("<div style=\"height: 22px; width: 6px;\"></div>");
	}else{
		document.write("<td width=\"24\" height=\"23\">");
		document.write("<div id=\""+mmmwmww+"\" title=\""+mmmm+"\" cmdStr=\""+wwww+"\" cmdType=\""+wmwwmmmw+"\""); 
		document.write(" class=\"buttonUp\" onmousedown=\"return mmmmmww("+ww.toString()+");\" "); 
		document.write("onmousemove=\"return false;\" ondragstart=\"return mmmmmwm()\" onselectstart=\"return mmmmmwm()\" onselect=\"return mmmmmwm()\" onclick=\"return mmmmmwm()\" onkeydown=\"return mmmmmwm()\">");
		document.write("<img src=\""+mmwwm+wm+"\" width=\"23\" height=\"22\">");
		document.write("</div>");
	}
	document.write("</td>");
	if(wwww!=""){
		wwm[ww][wwm[ww].length]=document.all[mmmwmww];
	}
} 

function mwwmmwmw(ww){  
	if(G_showToolbar[ww]==false||G_fieldVisible[ww]==false||G_enableRichTextMode[ww]==false)return;
	var wmmm=6;
	var mwmmmw=24;
	var mww=135;
	var wwwmmm=618;
	var wmww=wwwmmm; 
	var w=12;   
	var wmmmwmw=0;
	var wwmwmmm=1;
	var mwwmw=2;
	var wwmww=3;
	var wmw=4;
	var mwmww=5;
	var mm=7;
	var mwmwmm=8;
	var wwmwm=9;
	var wwwmwwm=6;
	var wmwwwmmm=10;
	var wwmm=11; 
	var wwmmmm=false;
	var mmmmmmww=new Array(w);
	
	mmmmmmww[wmmmwmw]=mwmmmw*3;
	mmmmmmww[wmwwwmmm]=mwmmmw*1;
	mmmmmmww[wwmwmmm]=mwmmmw*1;
	mmmmmmww[mwwmw]=mwmmmw*6;
	mmmmmmww[wwmww]=80;
	mmmmmmww[wmw]=35;
	mmmmmmww[mwmww]=mwmmmw*3;
	mmmmmmww[mm]=mwmmmw*3;
	mmmmmmww[mwmwmm]=mwmmmw*2;
	mmmmmmww[wwmwm]=mwmmmw*2;
	mmmmmmww[wwwmwwm]=mwmmmw*2;
	mmmmmmww[wwmm]=mwmmmw*1;
	document.write("<div id=\"TB"+ww.toString()+"\">"); 
	document.write("<div id=\"TBA"+ww.toString()+"\" class=\"toolbar\">");
	document.write("<table cellspacing=\"0\" cellpadding=\"0\" border=\"0\" width=\"620\" height=\"24\"><tr width=\"620\" height=\"24\">");   
	
	function wwwmmmww(mmwwww){
		wmww=wmww-wmmm-mmmmmmww[mmwwww];
		if(wmww<0){
			wmww=wwwmmm;
			mwmmmmww(); 
			document.write("</tr></table></div>"); 
			document.write("<div id=\"TBB"+ww.toString()+"\" class=\"toolbar\">");
			document.write("<table cellspacing=\"0\" cellpadding=\"0\" border=\"0\" width=\"620\" height=\"24\"><tr width=\"620\" height=\"24\">");
		}
		
		wmww=wmww-wmmm;
		MontaBotoes("","","",mwmwmmm,ww);  //Espa�o entre os bot�es
	}  
	
	function mwmmmmww(){
		document.write("<td>&nbsp;</td>"); 
		if(wwmmmm==false && G_enableShowHTMLControl[ww]==true){
			wwmmmm=true;
			var wmwwmwmw="";
			if(G_currEditMode[ww]==MODE_DHTML){
				wmwwmwmw=" checked";
			}
			document.write("<td width=\"155\" height=\"24\"><table cellspacing=\"0\" cellpadding=\"0\" border=\"0\">");
			document.write("<tr><td><input type=\"checkbox\""+wmwwmwmw+" id=\"chkShowHTML"+ww.toString()+"\" ");  
			document.write("onclick=\"mmmmw("+ww.toString()+")\"></td>");
			document.write("<td><div id=\"lblShowHTML"+ww.toString()+"\" class=\"textShowHTMLEnabled\">Modo HTML</div>");
			document.write("</td></tr></table></td>");
		}
	} 
	
	if(G_enableShowHTMLControl[ww]==true){wmww=wmww-mww;}  
	
	//LOOP PARA MONTAR A BARRA DE FERRAMENTAS
	for(var wwwww=0;wwwww<w;wwwww++){
		switch(wwwww){
			case wmmmwmw: 
				if(G_enableClipboardControls[ww]==true){
					wwwmmmww(wwwww);
					MontaBotoes("Cut","Recortar","tb_cut.gif",mmwwmwww,ww);
					MontaBotoes("Copy","Copiar","tb_copy.gif",mmwwmwww,ww);
					MontaBotoes("Paste","Colar","tb_paste.gif",mmwwmwww,ww);
				}
				break;
			case wwmwmmm: 
				if(G_enableTableControl[ww]==true){
					wwwmmmww(wwwww);
					MontaBotoes("InsertTable","Inserir tabela","tb_instable.gif",wmwmmmmm,ww);
				}
				break;
			case mwwmw: 
				if(G_enableAdvancedTableControls[ww]==true){
					wwwmmmww(wwwww);
					MontaBotoes("InsertRow","Inserir linha","tb_insrow.gif",wmwmmmmm,ww);
					MontaBotoes("DeleteRow","Excluir linha","tb_delrow.gif",wmwmmmmm,ww);
					MontaBotoes("InsertCol","Inserir coluna","tb_inscol.gif",wmwmmmmm,ww);
					MontaBotoes("DeleteCol","Excluir coluna","tb_delcol.gif",wmwmmmmm,ww);
					MontaBotoes("InsertCell","Inserir c�lula","tb_inscell.gif",wmwmmmmm,ww);
					MontaBotoes("DeleteCell","Excluir c�lula","tb_delcell.gif",wmwmmmmm,ww);
				}
				break;
			case wwmww: 
				if(G_enableFontFaceControls[ww]==true){
					wwwmmmww(wwwww);
					document.write("<td width=\"80\" height=\"24\">");
					document.write("<select id=\"cmbFontName"+ww.toString()+"\" ");  
					document.write("style=\"width:113;font-size:xx-small;font-family:helvetica;\" onchange=\"mwwwwmm("+ww.toString()+")\">");
					document.write("<option value=\"arial, helvetica, sans-serif\">Arial");
					document.write("<option value=\"verdana, arial, helvetica, sans-serif \">Verdana");
					document.write("<option value=\"trebuchet ms, arial, helvetica, sans-serif \">Trebuchet MS");
					document.write("<option value=\"comic sans ms, arial, helvetica, sans-serif\">Comic Sans MS");
					document.write("<option value=\"tahoma, arial, helvetica, sans-serif\">Tahoma");
					document.write("<option value=\"arial black, arial, helvetica, sans-serif\">Arial Black");
					document.write("<option value=\"courier new, courier, mono\">Courier New");
					document.write("<option value=\"times new roman, times, serif\">Times New Roman");
					document.write("<option value=\"georgia, times new roman, times, serif\">Georgia");
					document.write("<option value=\"garamond, times new roman, times, serif\">Garamond");
					document.write("<option value=\"webdings, wingdings, zapf dingbats, dingbats\">Webdings");
					document.write("</select>&nbsp;");
					document.write("</td>");
				}
				break;
			case wmw: 
				if(G_enableFontSizeControls[ww]==true){
					wwwmmmww(wwwww);
					document.write("<td width=\"35\" height=\"24\">");
					document.write("<select id=\"cmbFontSize"+ww.toString()+"\" ");  
					document.write("style=\"width:33;font-size:xx-small;font-family:helvetica;\" onchange=\"mwm("+ww.toString()+")\">");
					document.write("<option value=\"1\">1");
					document.write("<option value=\"2\">2");
					document.write("<option value=\"3\">3");
					document.write("<option value=\"4\">4");
					document.write("<option value=\"5\">5");
					document.write("<option value=\"6\">6");
					document.write("<option value=\"7\">7");
					document.write("</select>&nbsp;");
					document.write("</td>");
				}
				break;
			case mwmww: 
				if(G_enableFontFormatControls[ww]==true){
					wwwmmmww(wwwww);  
					MontaBotoes("Bold","Negrito","tb_negrito.gif",wmmmwmm,ww);
					MontaBotoes("Italic","It�lico","tb_italic.gif",wmmmwmm,ww);
					MontaBotoes("Underline","Sublinhado","tb_sublinhado.gif",wmmmwmm,ww);
				}
				break;
			case wwwmwwm: 
				if(G_enableFontColorControls[ww]==true){
					wwwmmmww(wwwww);
					MontaBotoes("ForeColor","Cor do texto","tb_fgcolor.gif",wmmmwmm,ww);
					MontaBotoes("BackColor","Cor de fundo","tb_bgcolor.gif",wmmmwmm,ww);
				}
				break;
			case mm: 
				if(G_enableJustifyControls[ww]==true){
					wwwmmmww(wwwww);
					MontaBotoes("JustifyLeft","Alinhar � esquerda","tb_left.gif",wmmmwmm,ww);
					MontaBotoes("JustifyCenter","Centralizar","tb_center.gif",wmmmwmm,ww);
					MontaBotoes("JustifyRight","Alinhar � direita","tb_right.gif",wmmmwmm,ww);
				}
				break;
			case mwmwmm: 
				if(G_enableListControls[ww]==true){
					wwwmmmww(wwwww);
					MontaBotoes("InsertOrderedlist","Numera��o","tb_numlist.gif",wmmmwmm,ww);
					MontaBotoes("InsertUnorderedlist","Marcadores","tb_bullist.gif",wmmmwmm,ww);				
				}
				break;
			case wwmwm: 
				if(G_enableIndentControls[ww]==true){
					wwwmmmww(wwwww);
					MontaBotoes("Outdent","Diminuir recuo","tb_deindent.gif",wmmmwmm,ww);
					MontaBotoes("Indent","Aumentar recuo","tb_inindent.gif",wmmmwmm,ww);
				}
				break;
			case wmwwwmmm: 
				if(G_enableLinkControl[ww]==true){
					wwwmmmww(wwwww);
					MontaBotoes("CreateLink","Inserir hyperlink","tb_link2.gif",mmwwmwww,ww);
				}
				break;
			case wwmm: 
				if(G_enableLinkControl[ww]==true){
					wwwmmmww(wwwww);
					MontaBotoes("InsertImage","Inserir imagem","tb_image.gif",mmwwmwww,ww);
				}
				break;
				
		}
	}
		
	mwmmmmww(); 
	document.write("</tr></table></div></div>");
}
generateToolbar=mwwmmwmw;