<?php
include_once "funcoes.php";
include_once "classes/Grupos.php";
include_once "classes/Operadores.php";
/************************************************************************
Empresa: Interagi Tecnologia

Descri��o:

Releases (Data, respons�vel e descri��o [�ltimo release primeiro]):
31/01/2005 (Rafael C�cero)
Inclu�do este cabe�alho descrevendo a funcionalidade da p�gina

************************************************************************/

$CODG_FORMULARIO = "cadoperadores";
$NOME_FORMULARIO = validarAcesso($CODG_FORMULARIO,$_SESSION["NUMG_OPERADOR"]);


$bPesquisa = true;

$oOperadores = new Operadores;

if ($_GET["numg_operador"] != "" || $_GET['nome_operador'] != "") {


	$oOperadores->setarDadosOperador(array($_GET["numg_operador"],$_GET['nome_operador']));

	if (Erros::isError()) MostraErros();

	if ($oOperadores->getNumgOperador() != "") {

		$oGrupos = new Grupos;

		//BUSCA OS GRUPOS DISPON�VEIS PARA O OPERADOR
		$vGruposDisponiveis = $oGrupos->consultarGruposNaoOperador($oOperadores->getNumgOperador());
		if (Erros::isError()) MostraErros();

		//BUSCA OS GRUPOS AOS QUAIS O OPERADOR PERTENCE
		$vGruposOperador = $oGrupos->consultarGruposOperador($oOperadores->getNumgOperador());
		if (Erros::isError()) MostraErros();

		$oGrupos->free;
	}else{
		$bPesquisa = false;
	}

}
 ?>

<html>
<head>

<title>Sigo - Cadastro de Operadores</title>

<link href="estilos.css" rel="stylesheet" type="text/css">
<script type="text/javascript" src="javascripts/prototype.js"> </script>
<script language="JavaScript" src="funcoes.js"></script>
<script type="text/javascript" src="javascripts/populacombo.js"></script>

<SCRIPT language="JavaScript">
function iniForm(){
	MontaFuncoes('<?=$CODG_FORMULARIO?>','<?=$NOME_FORMULARIO?>','<?=$oOperadores->getNumgOperador()?>')
	AlteraTab(1,2)
	document.form.txtNomeOperador.focus()
}

function pesquisarOperador(){
	if (document.form.txtNomeOperador.value != ""){
		window.location.href = "cadoperadores.php?nome_operador=" + document.form.txtNomeOperador.value
	}else{
		alert("Informe um nome de operador v�lido para realizar a pesquisa.")
		document.form.txtNomeOperador.focus()
	}
}


</script>

</head>
<body onLoad="iniForm()" rightmargin="0" marginwidth="0" marginheight="0" leftmargin="0" bottommargin="0" topmargin="0" bgcolor="#FFFFFF">

<table border=0 width=100% align=center cellspacing=0 cellpadding=0>
	<tr>
		<td><img src="imagens/space.gif" border=0 height=10></td>
	</tr>
	<tr>
		<td align=center>
			<table border=0 width=600 cellspacing=0 cellpadding=0>
				<tr>
					<td><img src="imagens/formEsqSup.gif" border=0 width=10 height=10></td>
					<td background="imagens/formMidSup.gif"></td>
					<td><img src="imagens/formDirSup.gif" border=0 width=10 height=10></td>
				</tr>
				<tr valign=top>
					<td width=10 background="imagens/formEsqMid.gif"></td>
					<td>
						<table border=0 width=580 cellspacing=0 cellpadding=0 align=center background="imagens/formMid.gif">
						<form method="post" action="pcadoperadores.php" name="form" id="form">
							<input type=hidden name=txtFuncao id="txtFuncao" value="">
							<input type=hidden name=txtNumgOperador id="txtNumgOperador" value="<?=$oOperadores->getNumgOperador()?>">
							
							<!-- IN�CIO CAMPOS DO FORMUL�RIO  -->
							<?php if ($_GET["info"] != "") { ?>
							<tr>
								<td colspan=4 align=center height=20 valign=middle class=normal11>
								<img src="imagens/icones/info.gif" border=0 align=absbottom>&nbsp;&nbsp;
								<?php 		
								switch ($_GET["info"]){
									case 1:
										echo "Cadastro de operador realizado com sucesso";
										break;
									case 2:
										echo "Edi��o de dados realizada com sucesso";
										break;
									case 3:
										echo "Exclus�o de operador realizada com sucesso";
										break;
									case 4:
										echo "Bloqueio de operador realizado com sucesso";
										break;
									case 5:
										echo "Desbloqueio de operador realizado com sucesso";
										break;
									case 6:
										echo "Inclus�o de grupo para operador realizado com sucesso";
										break;
									case 7:
										echo "Exclus�o de grupo do operador realizado com sucesso";
										break;
									case 8:
										echo "Senha enviada com sucesso";
										break;
								}
								 ?>		
								</td>
							</tr>
							<?php }else if (!$bPesquisa) { ?>
							<tr>
								<td colspan=4 align=center height=20 valign=middle class=normal11>
									<img src="imagens/icones/excla.gif" border=0 align=absbottom>&nbsp;&nbsp;Nenhum registro encontrado para a pesquisa						
								</td>
							</tr>
							<?php } ?>
							<tr>
								<td colspan=4>
									<table border=0 width=580 cellspacing=0 cellpadding=2>
										<tr>
											<td width=20% align=right class=normal11b>Operador:</td>
											<TD width=30%>
												<table border=0 cellpadding=0 cellspacing=0>
													<tr>
														<td><INPUT type="text" name="txtNomeOperador" id="txtNomeOperador" value='<?=$oOperadores->getNomeOperador()?>' size=20 maxlength=20 class=borda></TD>
														<td>&nbsp;<input type=image src='imagens/icones/pesquisar.gif' border=0 onClick="pesquisarOperador();return false" align=center id=image2 name=image2></td>
													</tr>
												</table>
											</td>	
											<TD width=50%>
												<?php if ($oOperadores->getDataCadastro() != "" && !is_null($oOperadores->getDataCadastro())) { ?>
												<table border=0 width=285 cellspacing=0 cellpadding=0>
													<tr>
														<td align=right class=normal11>cadastrado em: <b><?=$oOperadores->getDataCadastro()?></b> [<?=$oOperadores->getNomeOperadorCad()?>]</td>
													</tr>
												</table>
												<?php } ?>
											</TD>
										</tr>
										
									</table>
								</td>
							</tr>
							<tr>
								<td height=10></td>
							</tr>
							<tr>
								<td colspan=4>
									<script language="JavaScript">										
									montaTabs(Array("Dados Pessoais","Grupos de Acesso","",""),2)
									</script>
								</td>
							</tr>
							<tr>
								<td colspan=4>
									<div id="tab1">
									<table border=0 width=580 cellspacing=0 cellpadding=2 align=center class=bordaEsqDirInf>
										<tr>
											<td height=10></td>
										</tr>
										<tr>
											<td align=right class=normal11b>Nome Completo:</td>
											<TD colspan=3><INPUT type="text" name="txtNomeCompleto" id="txtNomeCompleto" value='<?=$oOperadores->getNomeCompleto()?>' size=68 maxlength=50 class=borda onkeypress=SetFocus(document.form.txtDescSenha)></TD>
										</tr>
										<tr>
											<td align=right class=normal11b>Senha:</td>
											<TD><INPUT type="password" name="txtDescSenha" id="txtDescSenha" value='<?=$oOperadores->getDescSenha()?>' size=20 maxlength=8 class=borda onkeypress=SetFocus(document.form.txtConfirmaSenha)></TD>
											<td align=right class=normal11b>Confirma��o:</td>
											<TD><INPUT type="password" name="txtConfirmaSenha" id="txtConfirmaSenha" value='<?=$oOperadores->getDescSenha()?>' size=16 maxlength=8 class=borda onkeypress=SetFocus(document.form.txtNumrCpf)></TD>
										</tr>
										<tr>
											<td align="right" class=normal11b>Tipo:</td>
											<td>
												<select name="cboDescTipo" id="cboDescTipo" class=borda style="width:135px" >
													<option value="Gerente Geral" <? if($oOperadores->getDescTipo() == "Gerente Geral"){ echo"selected=selected";} ?>>Gerente Geral</option>
													<option value="Coordenador Geral" <? if($oOperadores->getDescTipo() == "Coordenador Geral"){ echo"selected=selected";} ?>>Coordenador Geral</option>
													<option value="Supervisor" <? if($oOperadores->getDescTipo() == "Supervisor"){ echo"selected=selected";} ?>>Supervisor</option>
													<option value="Vivo" <? if($oOperadores->getDescTipo() == "Vivo"){ echo"selected=selected";} ?>>Vivo e Prestadoras</option>
												</select>
											</td>
										</tr>
										<tr>
											<td align=right class=normal11b>E-mail:</td>
											<TD colspan="3" ><INPUT type="text" name="txtDescEmail" id="txtDescEmail" value='<?=$oOperadores->getDescEmail()?>' size=68 maxlength=50 class=borda onkeypress=SetFocus(document.form.txtDescEmail)>&nbsp;<a href="mailto:<?=$oOperadores->getDescEmail()?>"><img src="imagens/icones/carta.gif" border=0 alt="Clique para enviar e-mail"></a></TD>
											
										</tr>
										<tr>
											<td align=right class=normal11b>&nbsp;&nbsp;</td>
											<TD colspan="3" class="normal11">
											 <label>
										    <input type="checkbox" name="chkFlagEmailDiario" value="1"<? if($oOperadores->getFlagEmailDiario()=="'t'"){ echo " checked";}?>>
										    Receber e-mail de libera��o de di�rio</label> &nbsp;&nbsp;&nbsp;
											<label>
											  <input type="checkbox" name="chkFlagEmailPendencia" value="1"<? if($oOperadores->getFlagEmailPendencia()=="'t'"){ echo " checked";}?>>
										    Receber e-mail de libera��o de pend�ncia</label>
										   </TD>
											
										</tr>
										<?php if ($oOperadores->getDataBloqueio() != "" && !is_null($oOperadores->getDataBloqueio())) { ?>
										<tr>
											<td></td>
											<td colspan=3 class=normal11><img src="imagens/icones/excla.gif" border=0 align=absbottom>&nbsp;Operador bloqueado em: <b><?=$oOperadores->getDataBloqueio()?></b> [<?=$oOperadores->getNomeOperadorBloq()?>]</td>
										</tr>
										<?php } ?>
										<tr>
											<td height=10></td>
										</tr>
									</table>
									</div>

									<div id="tab2">
									<table border=0 width=580 cellspacing=0 cellpadding=2 align=center class=bordaEsqDirInf>
										<tr>
											<td height=10></td>
										</tr>
										<tr class=normal11b height=15>
											<td width=5%></td>
											<td width=45%>Grupos dispon�veis</td>
											<td width=45% align=right>Grupos do operador</td>
											<td width=5%></td>
										</tr>
										<tr>
											<td></td>
											<td>
												<select multiple name="cboGruposDisponiveis[]" id="cboGruposDisponiveis[]" class=borda size=10 style="width:230">
													<? montaCombo($vGruposDisponiveis,"numg_grupo","nome_grupo");?>
												</select>
											</td>
											<td align=right>
												<select name="cboGruposOperador[]" id="cboGruposOperador[]" multiple class=borda size=10 style="width:230">
													<? montaCombo($vGruposOperador,"numg_grupo","nome_grupo");?>
												</select>
											</td>
											<td></td>
										</tr>
										<tr>
											<td height=10></td>
										</tr>
									</table>
									</div>
								</td>
							</tr>	
							<?php if ($oOperadores->getDataUltimaAlt() != "" && !is_null($oOperadores->getDataUltimaAlt())) { ?>
							<tr>
								<td colspan=4>
									<table border=0 width=580 cellspacing=0 cellpadding=0>
										<tr>
											<td width=50%></td>
											<td width=50% height=20 align=right class=normal11>�ltima altera��o: <b><?=$oOperadores->getDataUltimaAlt() ?></b> [<?=$oOperadores->getNomeOperadorAlt()?>]</td>
										</tr>
									</table>
								</td>
							</tr>
							<?php } ?>
							<!-- FIM CAMPOS DO FORMUL�RIO  -->
						
						</form>
						</table>
					</td>
					<td width=10 background="imagens/formDirMid.gif"></td>
				</tr>
				<tr>
					<td><img src="imagens/formEsqInf.gif" border=0 width=10 height=10></td>
					<td background="imagens/formMidInf.gif"></td>
					<td><img src="imagens/formDirInf.gif" border=0 width=10 height=10></td>
				</tr>
			</table>
		</td>
	</tr>
	<tr>
		<td><img src="imagens/space.gif" border=0 height=10></td>
	</tr>
</table>

<script language="JavaScript">
function novo_operador(){
	window.location.href = '<?=$CODG_FORMULARIO ?>.php'
}

function cadastrar_operador(){
	if (document.form.txtNumgOperador.value == ""){
		if (pValidaGravacao()){
				document.form.txtFuncao.value = "cadastrar_operador"
				document.form.submit()
			
		}
	}else{
		alert("Fun��o de CADASTRO n�o dispon�vel para este formul�rio!")
	}

}

function editar_operador(){
	if (document.form.txtNumgOperador.value != ""){
		if (pValidaGravacao()){
				document.form.txtFuncao.value = "editar_operador"
				document.form.submit()
			
		}
	}else{
		alert("Fun��o de EDI��O n�o dispon�vel para este formul�rio!")
	}

}

function excluir_operador(){
	if (document.form.txtNumgOperador.value != ""){
		if (confirm("Confirma a EXCLUS�O do Operador?")){
			document.form.txtFuncao.value = "excluir_operador"
			document.form.submit()
		}
	}else{
		alert("Fun��o de EXCLUS�O n�o dispon�vel para este formul�rio!")
	}
}

function bloquear_operador(){
	<?php if ($oOperadores->getDataBloqueio() == "") { ?>
	if (document.form.txtNumgOperador.value != ""){
			document.form.txtFuncao.value = "bloquear_operador"
			document.form.submit()
		
	}else{
		alert("Fun��o de BLOQUEIO n�o dispon�vel para este formul�rio!")
	}
	<?php }else{ ?>
	alert("Fun��o de BLOQUEIO n�o dispon�vel! O operador j� encontra-se bloqueado.")
	<?php } ?>
}

function desbloquear_operador(){
	<?php if ($oOperadores->getDataBloqueio() != "") { ?>
	if (document.form.txtNumgOperador.value != ""){
			document.form.txtFuncao.value = "desbloquear_operador"
			document.form.submit()
		
	}else{
		alert("Fun��o de DESBLOQUEIO n�o dispon�vel para este formul�rio!")
	}
	<?php }else{ ?>
	alert("Fun��o de DESBLOQUEIO n�o dispon�vel! O operador j� encontra-se desbloqueado.")
	<?php } ?>
}

function enviar_senha(){
	if (document.form.txtNumgOperador.value != ""){
			document.form.txtFuncao.value = "enviar_senha"
			document.form.submit()
		
	}else{
		alert("Fun��o de ENVIO de SENHA n�o dispon�vel para este formul�rio!")
	}
}


function cadastrar_grupoope(){

	if ($F("txtNumgOperador") != ""){
		if ($F("cboGruposDisponiveis[]") == ""){
			alert("Selecione um Grupo na lista de Grupos dispon�veis.");
			AlteraTab(2,2);
			$("cboGruposDisponiveis[]").focus();
		}else{
				$("txtFuncao").value = "cadastrar_grupoope";
				$("form").submit();
			
		}
	}else{
		alert("Fun��o de CADASTRO DE GRUPO n�o dispon�vel para este formul�rio!");
	}
}
function excluir_grupoope(){
	if ($F("txtNumgOperador") != ""){
		if ($F("cboGruposOperador[]") == ""){
			alert("Selecione um Grupo na lista de Grupos de acesso a fun��o.");
			AlteraTab(2,2);
			$("cboGruposOperador[]").focus();
		}else{
				$("txtFuncao").value = "excluir_grupoope";
				$("form").submit();

		}
	}else{
		alert("Fun��o de CADASTRO DE GRUPO n�o dispon�vel para este formul�rio!");
	}

}

function pValidaGravacao(){

	var sErr = ""

	//SENHA	DE ACESSO
	var senha = Trim(form.txtDescSenha.value)
	var confirmasenha = Trim(form.txtConfirmaSenha.value)

	if (senha != confirmasenha){
		sErr = "Confirma��o de Senha inv�lida!\n"
	}
	else if (senha != "" && senha.length < 4){
		sErr = "Informe uma senha com pelo menos 4 caracteres!\n"
	}
	//E-MAIL DE CONTATO
	if (Trim(document.form.txtDescEmail.value) != "" && !IsEmail(document.form.txtDescEmail.value)){
		sErr = sErr + "E-mail inv�lido.\n"
	}

	//VERIFICA SE FOI ENCONTRADO ALGUM ERRO NA VALIDA��O DO FORMUL�RIO
	if (sErr != ""){
		sErr = "Verifique os erros encontrados abaixo:\n\n" + sErr
		alert(sErr)
		return false
	}else{
		return true
	}
}

</script>

<?php $oOperadores->free; ?>

</body>

<head>
<META HTTP-EQUIV="Pragma" CONTENT="no-cache">
<META HTTP-EQUIV="Expires" CONTENT="-1">
</head>
</html>