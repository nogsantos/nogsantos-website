<?php
include_once("funcoes.php");
include_once "classes/Sites.php";
include_once("classes/Fases.php");
include_once("classes/Operadores.php");
include_once("classes/Executores.php");

/**
 * Empresa: Interagi Tecnologia
 * Descri��o:
 * Releases (Data, respons�vel e descri��o [�ltimo release primeiro]):
 *	 16/04/2008 (Rafael C�cero) 
 *		 Inclu�do este cabe�alho descrevendo a funcionalidade da p�gina
 */

	$CODG_FORMULARIO = "prelexec";
	//$NOME_FORMULARIO = validarAcesso($CODG_FORMULARIO,$_SESSION["NUMG_OPERADOR"]);
	
	$sTitulo = "Relat�rio de Desempenho das Empresas Executoras";
	
	//$oOperador = new Operadores();
	//$oOperador->setarDadosOperador($_SESSION["NUMG_OPERADOR"]);
		
	
	switch ($_POST["rdoOpcao"]){

		case 1:
			
			$oExecutores = new Executores();
			$vDados = $oExecutores->consultarDesempenhoExecutores($_POST["numgEmpresa"],$_POST["dataCadastroInicial"], $_POST["dataCadastroFinal"]);
			if (Erros::isError()) MostraErros();

			if ($vDados->getCount() > 0){
				$vLabels = array("Empresa Executora","Per�odo","Subatividade","Site","Fase","Descri��o Di�rio");
				$vFormat = array("20C0","10C1","25C0","10C0","10C0","25C0");
				$vPosicao = array(0,1,2,3,4,5);
			}
			
			break;
						
		default:
			header("relexec.php"); exit;
	}
	
?>

<html>
<head>

<title>SIGO - Relat�rio de Desempenho de Executores</title>

<link href="estilos.css" rel="stylesheet" type="text/css">

<SCRIPT language=JavaScript src="funcoes.js"></SCRIPT>	

<script language="JavaScript">
function iniForm(){
	MontaFuncoes('<?=$CODG_FORMULARIO?>','<?=$NOME_FORMULARIO?>','1')
}
</script>

</head>
<body onLoad="iniForm()" rightmargin="0" marginwidth="0" marginheight="0" leftmargin="0" bottommargin="0" topmargin="0">

<TABLE border=0 width="650" align=center cellspacing=0 cellpadding=0>
	<tr>
		<td colspan=2 class=normal11b height=40 align=center><?=$sTitulo?></td>
	</tr>
	<? if ($vDados->getCount() > 0){ ?>
	<tr>
		<td colspan=2>
			<table border=0 width=100% cellspacing=0 cellpadding=0 align=center>
				<tr height=20 class=normal11b align=center>
					<? for ($i=0; $i<count($vLabels); $i++){?>
					<td width="<?=Left($vFormat[$i],2)?>%" align="<?=RetornaAlign(substr($vFormat[$i],2,1))?>" background="imagens/fundoBarraRelatorio.gif"><?=$vLabels[$i]?></td>
					<? }?>
				</tr>
				<? for ($i=0; $i<$vDados->getCount(); $i++){?>
				<tr height=20 <? if ($i % 2 == 1){?>bgcolor="#EEEEEE"<? }?> class=relatorio>
					<? for ($j=0; $j<count($vLabels); $j++){?>
						
						<? if ($j==0){?>
						<td width="<?=Left($vFormat[$j],2)?>%" align="<?=RetornaAlign(substr($vFormat[$j],2,1))?>"><?=RetornaDadoFormatado($vDados->getValores($i,$vPosicao[$j]),Right($vFormat[$j],1))?></td>
						<? }else{ ?>
						<td width="<?=Left($vFormat[$j],2)?>%" align="<?=RetornaAlign(substr($vFormat[$j],2,1))?>"><?=RetornaDadoFormatado($vDados->getValores($i,$vPosicao[$j]),Right($vFormat[$j],1))?></td>
						<? }?>
						
					<? }?>
				</tr>
				<? }?>
			</table>
		</td>
	</tr>
	<tr <? if ($i % 2 == 1){?>bgcolor="#EEEEEE"<? }?> height=20>
		<td width=80% class=destaque>*Clique no nome da empresa para visualizar seus dados</td>
		<td width=20% class=normal11b align=right>TOTAL: <?=$vDados->getCount()?></td>
	</tr>
	
	<? }else{?>
	<tr>
		<td colspan=2 class=destaque align=center>Nenhum registro encontrado</td>
	</tr>
	<? }?>
	
</TABLE>

<script language="JavaScript">
function imprimir_pendencias(){
	if (confirm("Confirma a IMPRESS�O do relat�rio?")){
		window.print()
	}	
}

</script>

</body>
</html>