<? 
	include_once "funcoes.php"; 
	include_once("classes/Diarios.php");
	include_once("classes/Operadores.php");
	
	$CODG_FORMULARIO = "preldesempsuperv";
	$NOME_FORMULARIO = validarAcesso($CODG_FORMULARIO,$_SESSION["NUMG_OPERADOR"]);
	
	$oDiario = new Diarios();
	$oOperador = new Operadores();
	
	$vSupervisores = $oOperador->consultarSupervisoresDesbl();
	if (Erros::isError()) MostraErros();
	
	$ano = $_POST["ano"];
	$mes = $_POST["mes"];
	
	switch($mes){
		case 1:
			$dataInicio = "01/01/".$ano;
			$dataFim = "31/01/".$ano;
			$sMes = "Janeiro";
		break;
		case 2:
			$dataInicio = "01/02/".$ano;
			$dataFim = "29/02/".$ano;
			$sMes = "Fevereiro";
		break;
		case 3:
			$dataInicio = "01/03/".$ano;
			$dataFim = "31/03/".$ano;
			$sMes = "Mar�o";
		break;
		case 4:
			$dataInicio = "01/04/".$ano;
			$dataFim = "30/04/".$ano;
			$sMes = "Abril";
		break;
		case 5:
			$dataInicio = "01/05/".$ano;
			$dataFim = "31/05/".$ano;
			$sMes = "Maio";
		break;
		case 6:
			$dataInicio = "01/06/".$ano;
			$dataFim = "30/06/".$ano;
			$sMes = "Junho";
		break;
		case 7:
			$dataInicio = "01/07/".$ano;
			$dataFim = "31/07/".$ano;
			$sMes = "Julho";
		break;
		case 8:
			$dataInicio = "01/08/".$ano;
			$dataFim = "31/08/".$ano;
			$sMes = "Agosto";
		break;
		case 9:
			$dataInicio = "01/09/".$ano;
			$dataFim = "30/09/".$ano;
			$sMes = "Setembro";
		break;
		case 10:
			$dataInicio = "01/10/".$ano;
			$dataFim = "31/10/".$ano;
			$sMes = "Outubro";
		break;
		case 11:
			$dataInicio = "01/11/".$ano;
			$dataFim = "30/11/".$ano;
			$sMes = "Novembro";
		break;
		case 12:
			$dataInicio = "01/12/".$ano;
			$dataFim = "31/12/".$ano;
			$sMes = "Dezembro";
		break;
	}
	
	
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<title>::: SIGO - Desempenho Supervisores :::</title>
<link href="estilos.css" rel="stylesheet" type="text/css">
<script language="JavaScript" src="funcoes.js"></script>
<script language="JavaScript">
function iniForm(){
	MontaFuncoes('<?=$CODG_FORMULARIO?>','<?=$NOME_FORMULARIO?>','1')
}
</script>

</head>

<body onLoad="iniForm()" rightmargin="0" marginwidth="0" marginheight="0" leftmargin="0" bottommargin="0" topmargin="0" bgcolor="#FFFFFF">
<table border=0 align=center cellspacing=0 cellpadding=0>
	<tr>
		<td><img src="imagens/space.gif" border=0 height=10></td>
	</tr>
	<tr>
		<td align=center>
			<table border=0 width=100% cellspacing=0 cellpadding=0>
				<tr>
					<td><img src="imagens/formEsqSup.gif" border=0 width=10 height=10></td>
					<td background="imagens/formMidSup.gif"></td>
					<td><img src="imagens/formDirSup.gif" border=0 width=10 height=10></td>
				</tr>
				<tr valign=top>
					<td width=10 background="imagens/formEsqMid.gif"></td>
					<td>
						<table border=0 width=100% cellspacing=0 cellpadding=0 align=center background="imagens/formMid.gif">
																
							<tr>
								<td colspan=3>
									<table border=0 width=580 cellspacing=0 cellpadding=2>
										<tr>
											<td colspan="2" class="normal11b" align="center">Quantidade de Di�rios por Supervisor</TD>
										</tr>
										<tr>
											<td width=20% align=right class=normal11b>M&ecirc;s:</td>
											<TD width=80% align="left" class=normal11>
												<?=$sMes."/ ".$ano?></TD>
										</tr>
										
									</table>
								</td>
							</tr>
							<tr>
								<td height=10></td>
							</tr>
							
							<tr>
								<td colspan=3>
									<div id="tab1">
												<table border="0" cellspacing="0" cellpadding="2"> 
													<tr>
														<td class="normal11" align="left">
														 	<table border="1" bordercolor="#999999" cellspacing="0" cellpadding="2"> 	
																
																<tr> 
																	<td bgcolor="#F3F3F3" align="center" class="normal11" width="110"><strong>Nome/Dia</strong></td> 
																	<td bgcolor="#F3F3F3" align="center" class="normal11"><strong>01</strong></td> 
																	<td bgcolor="#F3F3F3" align="center" class="normal11"><strong>02</strong></td> 
																	<td bgcolor="#F3F3F3" align="center" class="normal11"><strong>03</strong></td> 
																	<td bgcolor="#F3F3F3" align="center" class="normal11"><strong>04</strong></td> 
																	<td bgcolor="#F3F3F3" align="center" class="normal11"><strong>05</strong></td> 
																	<td bgcolor="#F3F3F3" align="center" class="normal11"><strong>06</strong></td> 
																	<td bgcolor="#F3F3F3" align="center" class="normal11"><strong>07</strong></td> 
																	<td bgcolor="#F3F3F3" align="center" class="normal11"><strong>08</strong></td> 
																	<td bgcolor="#F3F3F3" align="center" class="normal11"><strong>09</strong></td> 
																	<td bgcolor="#F3F3F3" align="center" class="normal11"><strong>10</strong></td> 
																	<td bgcolor="#F3F3F3" align="center" class="normal11"><strong>11</strong></td> 
																	<td bgcolor="#F3F3F3" align="center" class="normal11"><strong>12</strong></td> 
																	<td bgcolor="#F3F3F3" align="center" class="normal11"><strong>13</strong></td> 
																	<td bgcolor="#F3F3F3" align="center" class="normal11"><strong>14</strong></td> 
																	<td bgcolor="#F3F3F3" align="center" class="normal11"><strong>15</strong></td> 
																	<td bgcolor="#F3F3F3" align="center" class="normal11"><strong>16</strong></td> 
																	<td bgcolor="#F3F3F3" align="center" class="normal11"><strong>17</strong></td> 
																	<td bgcolor="#F3F3F3" align="center" class="normal11"><strong>18</strong></td> 
																	<td bgcolor="#F3F3F3" align="center" class="normal11"><strong>19</strong></td> 
																	<td bgcolor="#F3F3F3" align="center" class="normal11"><strong>20</strong></td> 
																	<td bgcolor="#F3F3F3" align="center" class="normal11"><strong>21</strong></td> 
																	<td bgcolor="#F3F3F3" align="center" class="normal11"><strong>22</strong></td> 
																	<td bgcolor="#F3F3F3" align="center" class="normal11"><strong>23</strong></td> 
																	<td bgcolor="#F3F3F3" align="center" class="normal11"><strong>24</strong></td> 
																	<td bgcolor="#F3F3F3" align="center" class="normal11"><strong>25</strong></td> 
																	<td bgcolor="#F3F3F3" align="center" class="normal11"><strong>26</strong></td> 
																	<td bgcolor="#F3F3F3" align="center" class="normal11"><strong>27</strong></td> 
																	<td bgcolor="#F3F3F3" align="center" class="normal11"><strong>28</strong></td> 
																	<td bgcolor="#F3F3F3" align="center" class="normal11"><strong>29</strong></td> 
																	<td bgcolor="#F3F3F3" align="center" class="normal11"><strong>30</strong></td>
																	<td bgcolor="#F3F3F3" align="center" class="normal11"><strong>31</strong></td> 
																	<td bgcolor="#F3F3F3" align="center" class="normal11"><strong>Total</strong></td> 
																</tr>	
																<?
																for($i=0;$i<$vSupervisores->getCount();$i++){
																$nTotal=0;
																$vCountDiarios = $oDiario->consultarNumDiariosPorDia($vSupervisores->getValores($i,"numg_operador"),$dataInicio, $dataFim);
																if (Erros::isError()) MostraErros();
																$vDiasDiarios[1]=0;
																$vDiasDiarios[2]=0;
																$vDiasDiarios[3]=0;
																$vDiasDiarios[4]=0;
																$vDiasDiarios[5]=0;
																$vDiasDiarios[6]=0;
																$vDiasDiarios[7]=0;
																$vDiasDiarios[8]=0;
																$vDiasDiarios[9]=0;
																$vDiasDiarios[10]=0;
																$vDiasDiarios[11]=0;
																$vDiasDiarios[12]=0;
																$vDiasDiarios[13]=0;
																$vDiasDiarios[14]=0;
																$vDiasDiarios[15]=0;
																$vDiasDiarios[16]=0;
																$vDiasDiarios[17]=0;
																$vDiasDiarios[18]=0;
																$vDiasDiarios[19]=0;
																$vDiasDiarios[20]=0;
																$vDiasDiarios[21]=0;
																$vDiasDiarios[22]=0;
																$vDiasDiarios[23]=0;
																$vDiasDiarios[24]=0;
																$vDiasDiarios[25]=0;
																$vDiasDiarios[26]=0;
																$vDiasDiarios[27]=0;
																$vDiasDiarios[28]=0;
																$vDiasDiarios[29]=0;
																$vDiasDiarios[30]=0;
																$vDiasDiarios[31]=0;
																
																for($j=0;$j<$vCountDiarios->getCount();$j++){
																	$vDiasDiarios[intval(substr($vCountDiarios->getValores($j,"data_diario"),8,2))]=$vCountDiarios->getValores($j,"count_diarios");
																}
																 
															?>
																<tr> 
																	<td bgcolor="#F3F3F3" align="center" class="normal11" width="110"><?=$vSupervisores->getValores($i,"nome_completo")?></td> 
																<?	for($x=1;$x<=31;$x++){?>
																		<td bgcolor="#F3F3F3" align="center" class="normal11"><?=$vDiasDiarios[$x]?></td> 
																<?	$nTotal += $vDiasDiarios[$x];
																	}?>
																<td class="normal11" align="center"><?=$nTotal?></td>
																</tr>
															
															<? }?>
																
															</table>
															
													  </td>
													</tr>
														
												</table>		 
												
										</div>
									
								</td>
							</tr>
							<!-- FIM CAMPOS DO FORMUL�RIO  -->
							
						</table>
					</td>
					<td width=10 background="imagens/formDirMid.gif"></td>
				</tr>
				<tr>
					<td><img src="imagens/formEsqInf.gif" border=0 width=10 height=10></td>
					<td background="imagens/formMidInf.gif"></td>
					<td><img src="imagens/formDirInf.gif" border=0 width=10 height=10></td>
				</tr>
			</table>
		</td>
	</tr>
	
	<tr>
		<td><img src="imagens/space.gif" border=0 height=10></td>
	</tr>
</table>
</body>
</html>
