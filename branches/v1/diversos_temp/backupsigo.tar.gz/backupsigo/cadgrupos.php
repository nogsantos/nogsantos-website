<?php
include_once "funcoes.php";
include_once "classes/Grupos.php";
/************************************************************************
 Empresa: Interagi Tecnologia

 Descri��o:
	
 Releases (Data, respons�vel e descri��o [�ltimo release primeiro]):
	 08/08/2005 (Rafael C�cero) 
		 Inclu�do este cabe�alho descrevendo a funcionalidade da p�gina
************************************************************************/
	
	$CODG_FORMULARIO = "cadgrupos";
	$NOME_FORMULARIO = validarAcesso($CODG_FORMULARIO,$_SESSION["NUMG_OPERADOR"]);


	$oGrupos = new Grupos;
	
	if ($_GET["numg_grupo"] != ""){
		
		$oGrupos->setarDadosGrupo($_GET["numg_grupo"]);
		if (Erros::isError()) MostraErros();
	}	

	//BUSCA OS GRUPOS DE ACESSO CADASTRADOS
	$vGrupos = $oGrupos->consultarGrupos();
	if (Erros::isError()) MostraErros();
	
?>

<html>
<head>

<title>Sigo - Cadastro de Grupos de Acesso</title>

<link href="estilos.css" rel="stylesheet" type="text/css">

<SCRIPT language=JavaScript src="funcoes.js"></SCRIPT>

<SCRIPT language=JavaScript>
function iniForm(){
	MontaFuncoes('<?=$CODG_FORMULARIO?>','<?=$NOME_FORMULARIO?>','<?=$oGrupos->getNumgGrupo()?>')
	document.form.txtNomeGrupo.focus()
}
</script>

</head>
<body onLoad="iniForm()" rightmargin="0" marginwidth="0" marginheight="0" leftmargin="0" bottommargin="0" topmargin="0" bgcolor="#FFFFFF">

<table border=0 width=100% align=center cellspacing=0 cellpadding=0>
	<tr>
		<td><img src="imagens/space.gif" border=0 height=10></td>
	</tr>
	<tr>
		<td align=center>
			<table border=0 width=600 cellspacing=0 cellpadding=0>
				<tr>
					<td><img src="imagens/formEsqSup.gif" border=0 width=10 height=10></td>
					<td background="imagens/formMidSup.gif"></td>
					<td><img src="imagens/formDirSup.gif" border=0 width=10 height=10></td>
				</tr>
				<tr valign=top>
					<td width=10 background="imagens/formEsqMid.gif"></td>
					<td>
						<table border=0 width=100% cellspacing=0 cellpadding=2 align=center background="imagens/formMid.gif">
						<form method="post" action="pcadgrupos.php" name="form">
							<input type=hidden name=txtFuncao value="">
							<input type=hidden name=txtNumgGrupo value="<?=$oGrupos->getNumgGrupo()?>">
							
							<!-- IN�CIO CAMPOS DO FORMUL�RIO  -->
							<?php if ($_GET["info"] != ""){?>
							<tr>
								<td colspan=4 align=center height=20 valign=middle class=normal11>
								<img src="imagens/icones/info.gif" border=0 align=absbottom>&nbsp;&nbsp;
								<?php		
									switch ($_GET["info"]){
										case 1:
											echo "Cadastro de grupo de acesso realizado com sucesso";
											break;
										case 2:
											echo "Edi��o de dados realizada com sucesso";
											break;
										case 3:
											echo "Exclus�o de grupo de acesso realizada com sucesso";
											break;
										case 4:
											echo "Bloqueio de grupo de acesso realizada com sucesso";
											break;
										case 5:
											echo "Desbloqueio de grupo de acesso realizada com sucesso";
											break;
									}  ?>
								</td>
							</tr>
							<?php } ?>				
							<tr>
								<td width=20% align=right class=normal11b>Nome grupo:</td>
								<td colspan=3>
									<table border=0 width=100% cellspacing=0 cellpadding=0>
										<tr>
											<TD width=50%><INPUT type="text" name="txtNomeGrupo" value='<?=$oGrupos->getNomeGrupo()?>' size=25 maxlength=50 class=borda onKeyPress="SetFocus(document.form.txtDescGrupo)"></TD>
											<TD width=50%>
												<?php if ($oGrupos->getDataCadastro() != "" && !is_null($oGrupos->getDataCadastro())){?>
												<table border=0 width=202 cellspacing=0 cellpadding=0>
													<tr>
														<td align=right class=normal11>cadastrado em: <b><?=$oGrupos->getDataCadastro() ?></b> [<?=$oGrupos->getNomeOperadorCad()?>]</td>
													</tr>
												</table>
												<?php } ?>
											</TD>
										</tr>
									</table>
								</td>
							</tr>
							<tr valign=top>
								<td align=right class=normal11b>Descri��o:</td>
								<TD colspan=3><textarea name="txtDescGrupo" rows=3 cols=69 class=borda onKeyUp="LimitaCampo(this,255)"><?=$oGrupos->getDescGrupo()?></textarea></TD>
							</tr>
							<?php if ($oGrupos->getDataBloqueio() != "" && !is_null($oGrupos->getDataBloqueio())){ ?>
							<tr>
								<td></td>
								<td colspan=3 class=normal11><img src="imagens/icones/excla.gif" border=0 align=absbottom>&nbsp;Grupo bloqueado em: <b><?=$oGrupos->getDataBloqueio()?></b> [<?=$oGrupos->getNomeOperadorBloq()?>]</td>
							</tr>
							<?php } ?>
							<!-- FIM CAMPOS DO FORMUL�RIO  -->
							
						</form>
						</table>
					</td>
					<td width=10 background="imagens/formDirMid.gif"></td>
				</tr>
				<tr>
					<td><img src="imagens/formEsqInf.gif" border=0 width=10 height=10></td>
					<td background="imagens/formMidInf.gif"></td>
					<td><img src="imagens/formDirInf.gif" border=0 width=10 height=10></td>
				</tr>
			</table>
		</td>
	</tr>
	
	<?php 
	if (isset($vGrupos)){
	if ($vGrupos->getCount() > 0){ ?>
	<tr>
		<td>
			<table border=0 width=95% cellspacing=0 cellpadding=0 align=center>
				<tr>
					<td colspan=5 class=normal11 height=25 valign=bottom>Rela��o de Grupos de Acesso cadastrados:</td>
				</tr>
				<tr height=20 class=normal11b align=center>
					<td background="imagens/fundoBarraRelatorio.gif" width=30%>Grupo</td>
					<td background="imagens/fundoBarraRelatorio.gif" width=50%>Descri��o</td>
					<td background="imagens/fundoBarraRelatorio.gif" width=20%>Data Bloqueio</td>
				</tr>
				<?php for ($i=0; $i<$vGrupos->getCount(); $i++) {?>
				<tr height=20 <?php if ($i % 2 == 1){ ?>bgcolor="#E8E8E8"<?php } ?> class=relatorio>
					<td><a href="cadgrupos.php?numg_grupo=<?=$vGrupos->getValores($i,"numg_grupo") ?>" class=relatorio><?=$vGrupos->getValores($i,"nome_grupo") ?></a></td>
					<td><?=$vGrupos->getValores($i,"desc_grupo") ?></td>
					<td align=center><?=FormataDataHora($vGrupos->getValores($i,"data_bloqueio")) ?></td>
				</tr>
				<?php } ?>
				<tr height=20 <?php if ($i % 2 == 1){ ?>bgcolor="#E8E8E8"<?php } ?>>
					<td colspan=2 class=destaque>* Clique no nome do grupo para edit�-lo</td>
					<td class=normal11b align=right>TOTAL: <?=$vGrupos->getCount() ?></td>
				</tr>
			</table>
		</td>
	</tr>
	<?php } }?>
	<tr>
		<td><img src="imagens/space.gif" border=0 height=10></td>
	</tr>
</table>

<script language="JavaScript">
function novo_grupo(){
	window.location.href = '<?=$CODG_FORMULARIO?>.php'
}

function cadastrar_grupo(){
	if (document.form.txtNumgGrupo.value == ""){
		if (pValidaGravacao()){
				document.form.txtFuncao.value = "cadastrar_grupo"
				document.form.submit()
			
		}
	}else{
		alert("Fun��o de CADASTRO n�o dispon�vel para este formul�rio!")
	}
	
}

function editar_grupo(){
	if (document.form.txtNumgGrupo.value != ""){
		if (pValidaGravacao()){
				document.form.txtFuncao.value = "editar_grupo"
				document.form.submit()
			
		}
	}else{ 
		alert("Fun��o de EDI��O n�o dispon�vel para este formul�rio!")
	}

}

function excluir_grupo(){
	if (document.form.txtNumgGrupo.value != ""){
		if (confirm("Confirma a EXCLUS�O dos dados do Grupo?")){
			document.form.txtFuncao.value = "excluir_grupo"
			document.form.submit()
		}
	}else{ 
		alert("Fun��o de EXCLUS�O n�o dispon�vel para este formul�rio!")
	}
}

function bloquear_grupo(){
	<?php if ($oGrupos->getDataBloqueio() == ""){ ?>
	if (document.form.txtNumgGrupo.value != ""){
			document.form.txtFuncao.value = "bloquear_grupo"
			document.form.submit()
		
	}else{ 
		alert("Fun��o de BLOQUEIO n�o dispon�vel para este formul�rio!")
	}
	<?php }else{ ?>
	alert("Fun��o de BLOQUEIO n�o dispon�vel! O grupo de acesso j� encontra-se bloqueado.")
	<?php } ?>
}

function desbloquear_grupo(){
	<?php if ($oGrupos->getDataBloqueio() != ""){ ?>
	if (document.form.txtNumgGrupo.value != ""){
			document.form.txtFuncao.value = "desbloquear_grupo"
			document.form.submit()
		
	}else{ 
		alert("Fun��o de DESBLOQUEIO n�o dispon�vel para este formul�rio!")
	}
	<?php }else{ ?>
	alert("Fun��o de DESBLOQUEIO n�o dispon�vel! O grupo de acesso j� encontra-se desbloqueado.")
	<?php } ?>
}

function pValidaGravacao(){
	
	var sErr = ""
	
	//...
	
	//VERIFICA SE FOI ENCONTRADO ALGUM ERRO NA VALIDA��O DO FORMUL�RIO
	if (sErr != ""){
		sErr = "Verifique os erros encontrados abaixo:\n\n" + sErr
		alert(sErr)	
		return false
	}else
		return true
}

</script>

<?php //$oGrupos->free; ?>

</body>

<head>
<META HTTP-EQUIV="Pragma" CONTENT="no-cache">
<META HTTP-EQUIV="Expires" CONTENT="-1">
</head>

</html>