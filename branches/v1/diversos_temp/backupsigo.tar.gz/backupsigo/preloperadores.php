<?php
include_once "funcoes.php";
include_once "classes/Operadores.php";

/************************************************************************
 Empresa: Interagi Tecnologia

 Descri��o: 
	
 Releases (Data, respons�vel e descri��o [�ltimo release primeiro]):
	 22/08/2005 (Rafael C�cero) 
		 Inclu�do este cabe�alho descrevendo a funcionalidade da p�gina
						
************************************************************************/

	$CODG_FORMULARIO = "preloperadores";
	$NOME_FORMULARIO = validarAcesso($CODG_FORMULARIO,$_SESSION["NUMG_OPERADOR"]);
	
	$sTitulo = "RELAT�RIO DE OPERADORES";
	
	switch ($_POST["rdoOpcao"]){

		case 1:
			
			$oOperadores = new Operadores;
			
			$vDados = $oOperadores->consultarOperadores(array(0,$_POST["txtNomeOperador"],$_POST["txtDataNascimentoInicial"],$_POST["txtDataNascimentoFinal"],$_POST["txtDataCadastroInicial"],$_POST["txtDataCadastroFinal"]));
			if (Erros::isError()) MostraErros();

			if ($vDados->getCount() > 0){
				$vLabels = array("Nome","Data Cadastro");
				$vFormat = array("80E0","20C3");
				$vPosicao = array(1,2);
			}
			
			break;
			
		case 2:

			$oOperadores = new Operadores;
			
			$vDados = $oOperadores->consultarBloqueados($_SESSION["NUMG_MUNICIPIO"]);
			if (Erros::isError()) MostraErros();
			
			if ($vDados->getCount() > 0){
				$vLabels = array("Nome","Data Cadastro");
				$vFormat = array("80E0","20C3");
				$vPosicao = array(1,2);
			}
			
			break;
			
		case 3:
			
			$oOperadores = new Operadores;
			
			$vDados = $oOperadores->consultarNaoBloqueados($_SESSION["NUMG_MUNICIPIO"]);
			if (Erros::isError()) MostraErros();
			
			if ($vDados->getCount() > 0){
				$vLabels = array("Nome","Data Cadastro");
				$vFormat = array("80E0","20C3");
				$vPosicao = array(1,2);
			}

			break;
			
		case 4:
			
			$oOperadores = new Operadores;
			
			$vDados = $oOperadores->consultarOperadores(array($_SESSION["NUMG_MUNICIPIO"]));
			if (Erros::isError()) MostraErros();
			
			if ($vDados->getCount() > 0){
				$vLabels = array("Nome","Data Cadastro");
				$vFormat = array("80E0","20C3");
				$vPosicao = array(1,2);
			}
			
			break;
			
		default:
			header("reloperadores.php"); exit;
	}
	
?>

<html>
<head>

<title>Sigo - Relat�rio de Operadores</title>

<link href="estilos.css" rel="stylesheet" type="text/css">

<SCRIPT language=JavaScript src="funcoes.js"></SCRIPT>	

<script language="JavaScript">
function iniForm(){
	MontaFuncoes('<?=$CODG_FORMULARIO?>','<?=$NOME_FORMULARIO?>','1')
}
</script>

</head>
<body onLoad="iniForm()" rightmargin="0" marginwidth="0" marginheight="0" leftmargin="0" bottommargin="0" topmargin="0">

<TABLE border=0 width=98% align=center cellspacing=0 cellpadding=0>

	<tr>
		<td colspan=2 class=normal11b height=40 align=center><?=$sTitulo?></td>
	</tr>
	<? if ($vDados->getCount() > 0){ ?>
	<tr>
		<td colspan=2>
			<table border=0 width=100% cellspacing=0 cellpadding=0 align=center>
				<tr height=20 class=normal11b align=center>
					<? for ($i=0; $i<count($vLabels); $i++){?>
					<td width="<?=Left($vFormat[$i],2)?>%" align="<?=RetornaAlign(substr($vFormat[$i],2,1))?>" background="imagens/fundoBarraRelatorio.gif"><?=$vLabels[$i]?></td>
					<? }?>
				</tr>
				<? for ($i=0; $i<$vDados->getCount(); $i++){?>
				<tr height=20 <? if ($i % 2 == 1){?>bgcolor="#EEEEEE"<? }?> class=relatorio>
					<? for ($j=0; $j<count($vLabels); $j++){?>
						
						<? if ($j==0){?>
						<td width="<?=Left($vFormat[$j],2)?>%" align="<?=RetornaAlign(substr($vFormat[$j],2,1))?>"><a href="cadoperadores.php?numg_operador=<?=$vDados->getValores($i,"numg_operador")?>" class=relatorio><?=RetornaDadoFormatado($vDados->getValores($i,$vPosicao[$j]),Right($vFormat[$j],1))?></a></td>
						<? }else{ ?>
						<td width="<?=Left($vFormat[$j],2)?>%" align="<?=RetornaAlign(substr($vFormat[$j],2,1))?>"><?=RetornaDadoFormatado($vDados->getValores($i,$vPosicao[$j]),Right($vFormat[$j],1))?></td>
						<? }?>
						
					<? }?>
				</tr>
				<? }?>
			</table>
		</td>
	</tr>
	<tr <? if ($i % 2 == 1){?>bgcolor="#EEEEEE"<? }?> height=20>
		<td width=80% class=destaque>*Clique no operador para visualizar seus dados</td>
		<td width=20% class=normal11b align=right>TOTAL: <?=$vDados->getCount()?></td>
	</tr>

	<? }else{?>
	<tr>
		<td colspan=2 class=destaque align=center>Nenhum registro encontrado</td>
	</tr>
	<? }?>
	
</TABLE>

<script language="JavaScript">
function imprimir_operadores(){
	if (confirm("Confirma a IMPRESS�O do relat�rio?")){
		window.print()
	}	
}

</script>

</body>
</html>