<?php 
session_start();
header("Cache-control: private");
include_once "classes/Oad.php";
include_once "classes/Formularios.php";
include_once "classes/Erros.php";
/************************************************************************
 Empresa: Net4U Solu��es Internet e Intranet

 Descri��o:
	
 Releases (Data, respons�vel e descri��o [�ltimo release primeiro]):
	 01/08/2005 (Rafael C�cero) 
		 Inclu�do este cabe�alho descrevendo a funcionalidade da p�gina
************************************************************************/

function MostraErros(){

	if (!headers_sent()) {
		header ('Location: erros.php');
		exit;
	}
}

/*********************************
 FORMATA A STRING PARA GRAVA��O 
*********************************/
function FormataStr($str){

	if ($str == "") {
	    $str = "null";
	}else{
		$str = str_replace("'", "''", $str);
	    $str = trim($str);
	    $str = "'" . $str . "'";
	}
	    
    return $str;
}


/*********************************
 FORMATA UM VALOR BOOLEANO
*********************************/
function FormataBool($valor){

	if (trim($valor) == ""){
		return "NULL";
	}else if ($valor == NULL) {
	    return "NULL";
	}else if ((trim($valor) == 't') OR (trim($valor) == 'true') OR (trim($valor) == 'y') OR (trim($valor) == 'yes') OR (trim($valor) == '1')){
		return "'t'";
	}else if ((trim($valor) == 'f') OR (trim($valor) == 'false') OR (trim($valor) == 'n') OR (trim($valor) == 'no') OR (trim($valor) == '0')){
		return "'f'";
	}

}
/*********************************
 retorna o tamanho do arquivo em bytes, Kb, MB ou GB
*********************************/

function retornaTamanhoArquivo($tamanho){
		$tamanhoDefault = $tamanho;		
		$vNomenclatura = array("bytes","KB","MB","GB");		
		$cont = 0;
		$tamanho = floor($tamanho/1024);		
		while($tamanho > 0){			
			$cont+=1;
			$tamanho = floor($tamanho/1024);
		}		
		$resultado = $tamanhoDefault/pow(1024,$cont);
		return (number_format($resultado,2,",",".") . " " . $vNomenclatura[$cont]);				
	}
/*============================================='
' RETIRA Acentua��o '
'=============================================*/	
	function retiraAcentuacao( $texto ){
		return preg_replace("/&([a-z])[a-z]+;/i","$1",htmlentities($texto));
	}	
/*============================================='
' RETIRA OS CARACTERES ESPECIAIS DE UMA STRING '
'=============================================*/
function RetiraCaracEsp($texto){

	$texto = str_replace("�","a",$texto);
	$texto = str_replace("�","a",$texto);
	$texto = str_replace("�","a",$texto);
	$texto = str_replace("�","a",$texto);
	$texto = str_replace("�","a",$texto);
	$texto = str_replace("�","A",$texto);
	$texto = str_replace("�","A",$texto);
	$texto = str_replace("�","A",$texto);
	$texto = str_replace("�","A",$texto);
	$texto = str_replace("�","A",$texto);
	$texto = str_replace("�","e",$texto);
	$texto = str_replace("�","e",$texto);
	$texto = str_replace("�","e",$texto);
	$texto = str_replace("�","e",$texto);
	$texto = str_replace("�","E",$texto);
	$texto = str_replace("�","E",$texto);
	$texto = str_replace("�","E",$texto);
	$texto = str_replace("�","E",$texto);
	$texto = str_replace("�","i",$texto);
	$texto = str_replace("�","i",$texto);
	$texto = str_replace("�","i",$texto);
	$texto = str_replace("�","i",$texto);
	$texto = str_replace("�","I",$texto);
	$texto = str_replace("�","I",$texto);
	$texto = str_replace("�","I",$texto);
	$texto = str_replace("�","I",$texto);
	$texto = str_replace("�","o",$texto);
	$texto = str_replace("�","o",$texto);
	$texto = str_replace("�","o",$texto);
	$texto = str_replace("�","o",$texto);
	$texto = str_replace("�","o",$texto);
	$texto = str_replace("�","O",$texto);
	$texto = str_replace("�","O",$texto);
	$texto = str_replace("�","O",$texto);
	$texto = str_replace("�","O",$texto);
	$texto = str_replace("�","O",$texto);
	$texto = str_replace("�","u",$texto);
	$texto = str_replace("�","u",$texto);
	$texto = str_replace("�","u",$texto);
	$texto = str_replace("�","u",$texto);
	$texto = str_replace("�","U",$texto);
	$texto = str_replace("�","U",$texto);
	$texto = str_replace("�","U",$texto);
	$texto = str_replace("�","U",$texto);
	$texto = str_replace("�","c",$texto);
	$texto = str_replace("�","C",$texto);
	$texto = str_replace("�","n",$texto);
	$texto = str_replace("�","N",$texto);
	$texto = str_replace("~"," ",$texto);
	$texto = str_replace("`"," ",$texto);
	$texto = str_replace("�"," ",$texto);
	$texto = str_replace("^"," ",$texto);
	$texto = str_replace("�"," ",$texto);
	$texto = str_replace(" ","_",$texto);
	
	return $texto;
	
}

/*
'=============================='
' FORMATA A DATA PARA GRAVA��O '
'=============================='
Function FormataDataConsulta(ByVal data)

    FormataDataConsulta = "'" & year(data) & "/" & right("0" & month(data),2) & "/" & right("0" & day(data),2) & " " & right("0" & hour(data),2) & ":" & right("0" & minute(data),2) & ":" & right("0" & second(data),2) & "'"
    
}


'=============================='
' FORMATA A DATA PARA GRAVA��O '
'=============================='
Function FormataDataGravacao(ByVal data)

    FormataDataGravacao = "'" & year(data) & "/" & right("0" & month(data),2) & "/" & right("0" & day(data),2) & " " & right("0" & hour(data),2) & ":" & right("0" & minute(data),2) & ":" & right("0" & second(data),2) & "'"
    
}


'=============================='
' FORMATA A HORA PARA GRAVA��O '
'=============================='
Function FormataHoraGravacao(ByVal hora)

	dim vAux
	
	vAux = split(hora,":")
	
	if ubound(vAux) = 1 then FormataHoraGravacao = "'" & right("0" & Trim(vAux(0)),2) & ":" & right("0" & Trim(vAux(1)),2) & "'"
    
}

*/

/**************************************
 FORMATA A DATA NO PADR�O DD/MM/AAAA 
**************************************/
function FormataData($vData){
	if ($vData == "") return false;

	$vData = ereg_replace("-","/",$vData);
	$pos = strpos($vData,"/");
	
	if ($pos === 4) {		
  		$vXchange = explode("/",$vData);
		$vXchangeAux = explode(" ",$vXchange[2]);
		$vData = $vXchangeAux[0]."/".$vXchange[1]."/".$vXchange[0]." ".$vXchangeAux[1];
  	}
	
	if (strstr($vData,'/')) {		
		$vTime = null;
		$vData=explode("/",$vData);		
			
		if(strlen($vData[1])==1){
			$vData[1]="0".$vData[1];
		}
		if(strlen($vData[0])==1){
			$vData[0]="0".$vData[0];
		}
		
		if(strlen($vData[2]>4)) {
			$vTimeAux=explode(" ",$vData[2]);
			$vTime=explode(":",$vTimeAux[1]);
			$vData[2] = $vTimeAux[0];
			return $vData[0]."/".$vData[1]."/".$vData[2];	
		} else {
			return $vData[0]."/".$vData[1]."/".$vData[2];
		}
	} else {
		return $vData;
	}
}


/*
'============================================='
' FORMATA A HORA DE UMA DATA NO FORMATO HH:MM '
'============================================='
Function FormataHora(ByVal data)

	if data <> "" and not IsNull(data) then
		FormataHora = right("0" & hour(data),2) & ":" & right("0" & minute(data),2)
	else
		FormataHora = ""
	end if
    
}


'====================================================='
' FORMATA A DATA E A HORA NO FORMATO DD/MM/AAAA HH:MM '
'====================================================='
Function FormataDataHora(ByVal data)

	if data <> "" and not IsNull(data) then
		FormataDataHora = right("0" & day(data),2) & "/" & right("0" & month(data),2) & "/" & year(data) & " " & right("0" & hour(data),2) & ":" & right("0" & minute(data),2)
	else
		FormataDataHora = ""
	end if
    
}

*/

/******************************************************
 FORMATA O VALOR NO FORMATO XXX,XX					  
******************************************************/
function FormataValor($valor){

	if ($valor != "" && !is_null($valor)){
		return number_format($valor,2,',','.');
	}else{
		return "";
	}
}

/*

'============================================'
' FUN��O PARA RETORNAR O VALOR DE UMA STRING '
'============================================'
function Val(str)

	if IsNumeric(str) and Trim(str) <> "" and not IsNull(str) then
		Val = Int(str)
	else
		Val = 0
	end if
	
}


'=========================================='
' FUN��O PARA FORMATAR O VALOR P/ GRAVA��O '
'=========================================='
function FormataValorGravacao(valor)
	
	valor = FormatNumber(valor,2)
	valor = Replace(valor,".","")
	valor = Replace(valor,",",".")
		
	FormataValorGravacao = valor
	
}


'============================================='
' FUN��O PARA FORMATAR O CPF (XXX.XXX.XXX-XX) '
'============================================='
function FormataCPF(cpf)

	if Len(cpf) = 11 then
		FormataCPF = mid(cpf,1,3) & "." & mid(cpf,4,3) & "." & mid(cpf,8,3) & "-" & mid(cpf,10,2)
	else
		FormataCPF = cpf
	end if
	
}


'=================================================='
' FUN��O PARA FORMATAR O CNPJ (XX.XXX.XXX/XXXX-XX) '
'=================================================='
function FormataCNPJ(cnpj)

	if Len(cnpj) = 14 then
		FormataCNPJ = mid(cnpj,1,2) & "." & mid(cnpj,3,3) & "." & mid(cnpj,6,3) & "/" & mid(cnpj,9,4) & "-" & mid(cnpj,13,2)
	else
		FormataCNPJ = cnpj
	end if
	
}



/*********************************************
 FUN��O PARA RETORNAR O NOME DO AGRUPAMENTO 
 DOS FORMUL�RIOS DO SISTEMA				 
*********************************************/
function RetornaAgrupamento($id)
{	
	switch($id){
	case 1:
		return "Gerenciamento de Obras";
		break;
	case 2:
		return "Atrativos Tur�sticos";
		break;
	case 3:
		return "Serv. Equip. Tur�sticos";
		break;
	case 4:
		return "Serv. Equip. de Apoio";
		break;
	case 5:
		return "Permiss�o de Acesso";
		break;
	case 6:
		return "Relat�rios";
		break;
	case 7:
		return "Gr�ficos";
		break;
	default:
		return "N�o definido";
		break;
	}
	
}


/*********************************************
 RETORNA O TIPO DE ALINHAMENTO QUE DEVE SER 
 UTILIZADO EM ALGUMA COLUNA DE RELAT�RIO				 
*********************************************/
function RetornaAlign($cod)
{	
	switch($cod){
	case "E":
		return "left";
		break;
	case "D":
		return "right";
		break;
	case "C":
		return "center";
		break;
	default:
		return "left";
		break;
	}
	
}


/*********************************************
 FUN��O PARA RETORNAR UM DETERMINADO DADO NO 
 TIPO DE FORMATO IDENTIFICADO					   
*********************************************/
function RetornaDadoFormatado($dado, $tipo)
{	
	switch(substr($tipo,0,1)){
	case 1:
		return FormataData($dado);		
		break;
	case 2:
		return FormataHora($dado);
		break;
	case 3:						
		return FormataDataHora($dado);
		break;
	case 4:
		return FormataValor($dado);
		break;
	default:		
		return $dado;
		break;
	}
	
}

/*
public function RetornaDiaSemana(data)

	select case weekday(data)
	case 1
		RetornaDiaSemana = "Domingo"
	case 2
		RetornaDiaSemana = "Segunda-feira"
	case 3
		RetornaDiaSemana = "Ter�a-feira"
	case 4
		RetornaDiaSemana = "Quarta-feira"
	case 5
		RetornaDiaSemana = "Quinta-feira"
	case 6
		RetornaDiaSemana = "Sexta-feira"
	case 7
		RetornaDiaSemana = "S�bado"
	end select
	
}

*/


/***********************************************
 VALIDA UMA DATA GREGORIANA (DD/MM/YYYY)
 bool checkdate ( int m�s, int dia, int ano )
***********************************************/
function IsDate($data)
{ 
	if (trim($data) != ""){
		$aux = explode("/",$data); 
		return checkdate($aux[1],$aux[0],$aux[2]); 
	}else{
		return false;
	}
}

/***********************************************
 VALIDA O ACESSO DE UM OPERADOR A UM FORMUL�RIO 
***********************************************/
function validarAcesso($sCodgFormulario,$nNumgOperador)
{
	//VERIFICA SE A SESS�O EXPIROU
	if (empty($nNumgOperador) || $nNumgOperador == ""){
		header("Location: expirou.htm");
		exit;
	}else{
	
		$oFormularios = new Formularios;
	
		return $oFormularios->validarAcesso($sCodgFormulario,$nNumgOperador);
		
		$oFormularios->free;
	}
		
}


/***********************************************
 VALIDA O CPF INFORMADO (SEM DIVISORES) 
***********************************************/
function IsCpf($cpf) 
{
    $tam_cpf = strlen($cpf); 
	$cpf_limpo = "";

    for ($i=0; $i<$tam_cpf; $i++) { 
      $carac = substr($cpf, $i, 1); 
      // verifica se o codigo asc refere-se a 0-9 
      if (ord($carac)>=48 && ord($carac)<=57) 
        $cpf_limpo .= $carac; 
    } 
    if (strlen($cpf_limpo)!=11) 
      return false; 

    // achar o primeiro digito verificador 
    $soma = 0; 
    for ($i=0; $i<9; $i++) 
      $soma += (int)substr($cpf_limpo, $i, 1) * (10-$i); 

    if ($soma == 0) 
      return false; 

    $primeiro_digito = 11 - $soma % 11; 

    if ($primeiro_digito > 9) 
      $primeiro_digito = 0; 

    if (substr($cpf_limpo, 9, 1) != $primeiro_digito) 
      return false; 

    // acha o segundo digito verificador 
    $soma = 0; 
    for ($i=0; $i<10; $i++) 
      $soma += (int)substr($cpf_limpo, $i, 1) * (11-$i); 

    $segundo_digito = 11 - $soma % 11; 

    if ($segundo_digito > 9) 
      $segundo_digito = 0; 

    if (substr($cpf_limpo, 10, 1) != $segundo_digito) 
      return false; 

    return true; 

} 


/***********************************************
 VALIDA O CNPJ INFORMADO (SEM DIVISORES) 
***********************************************/
function IsCnpj($cnpj)
{
    $pontos = array(',','-','.','','/');
    
    $cnpj = str_replace($pontos,'',$cnpj);
    $cnpj = trim($cnpj);
    
	if(empty($cnpj) || strlen($cnpj) != 14) return FALSE;
    else {
        if(check_fake($cnpj,14)) return FALSE;
        else {
            $rev_cnpj = strrev(substr($cnpj, 0, 12));
            for ($i = 0; $i <= 11; $i++) {
                $i == 0 ? $multiplier = 2 : $multiplier;
                $i == 8 ? $multiplier = 2 : $multiplier;
                $multiply = ($rev_cnpj[$i] * $multiplier);
                $sum = $sum + $multiply;
                $multiplier++;

            }
            $rest = $sum % 11;
            if ($rest == 0 || $rest == 1)  $dv1 = 0;
            else $dv1 = 11 - $rest;
            
            $sub_cnpj = substr($cnpj, 0, 12);
            $rev_cnpj = strrev($sub_cnpj.$dv1);
            unset($sum);
            for ($i = 0; $i <= 12; $i++) {
                $i == 0 ? $multiplier = 2 : $multiplier;
                $i == 8 ? $multiplier = 2 : $multiplier;
                $multiply = ($rev_cnpj[$i] * $multiplier);
                $sum = $sum + $multiply;
                $multiplier++;

            }
            $rest = $sum % 11;
            if ($rest == 0 || $rest == 1)  $dv2 = 0;
            else $dv2 = 11 - $rest;

            if ($dv1 == $cnpj[12] && $dv2 == $cnpj[13]) return TRUE; //$cnpj;
            else return FALSE;
        }
    }
}

/**************************************************
 UTILIZADA PELAS FUN��ES DE VALIDA��O DE CPF E CNPJ
***************************************************/
function check_fake($string, $length)
{
    for($i = 0; $i <= 9; $i++) {
        $fake = str_pad('', $length, $i);
        if($string === $fake) return(1);
    }
}


#####################################################################################################
## Fun��o para transformar datas no formato dd/mm/yyyy para yyyy/mm/dd para se trabalhar com o BD: ##
#####################################################################################################
function data2bd($data) {
	$vData=explode("/",$data);
	if(strlen($vData[1])==1){
		$vData[1]="0".$vData[1];
	}
	if(strlen($vData[0])==1){
		$vData[0]="0".$vData[0];
	}
	$data = $vData[2]."/".$vData[1]."/".$vData[0];
	return $data;
}
function bd2data($data) {
	$vData=explode("/",$data);
	if(strlen($vData[1])==1){
		$vData[1]="0".$vData[1];
	}
	if(strlen($vData[2])==1){
		$vData[2]="0".$vData[2];
	}
	$data = $vData[2]."/".$vData[1]."/".$vData[0];
	
	//$data = substr($data,8,2)."/".substr($data,5,2)."/".substr($data,0,4);
	return $data;
}
function bd2hora($hora){
	$hora=substr($hora,0,5);
	return $hora;
}


//Fun��o para gerar listas de estados brasileiros:
## Fun��o para gerar listas de estados brasileiros: ##
function geraListaEstados($initSel) {
	$estados = array("AC","AP","AM","BA","CE","DF","ES","GO","MA","MT","MS","MG","PA","PB","PR","PE","PI","RJ","RN","RS","RO","RR","SC","SP","SE","TO");
	for ($linha=0;$linha<=count($estados)-1;$linha++) {
		$selected = ($initSel == $estados[$linha]) ? " selected" : "";
		echo "<option value=\"".$estados[$linha]."\"".$selected.">".$estados[$linha]."</option>";
	}
}


##..Fim geraListaEstados() ##
//####################################################################################
/************************************************************************************
Fun�ao de c�lculo de horas. 
Pega duas datas e duas horas e calcula o quanto tempo em horas tem de uma a outra. 
Sintaxe: float date_diff(str $data1, str $hora1, srt $data2, str $hora2,str $unidade); 
Exemplo: date_diff("1981-03-20","06:00:00",date("Y-m-d"),date("H:i:s"),"hor"); 
Retorna a diferen�a entre duas horas, na unidade dada 
Fun��o original: http://phpbrasil.com/scripts/source.php/id/1421
**************************************************************************************/ 
function date_diff($timestamp1,$timestamp2,$unidade){ 
	$timestamp1 = substr($timestamp1,0,-3);
	$timestamp2 = substr($timestamp2,0,-3);
	
	$tstamp1 = explode(" ",$timestamp1);
	$tstamp2 = explode(" ",$timestamp2);
	
	$data1 = $tstamp1[0];
	$hora1 = $tstamp1[1];
	$data2 = $tstamp2[0];
	$hora2 = $tstamp2[1];

    $i = split(":",$hora1); 
    $j = split("-",$data1); 
    $k = split(":",$hora2); 
    $l = split("-",$data2); 

	$tempo1 = mktime($i[0],$i[1],$i[2],$j[1],$j[2],$j[0]); 
	$tempo2 = mktime($k[0],$k[1],$k[2],$l[1],$l[2],$l[0]); 
	
	$calculo = ($tempo2 - $tempo1); 
	$tempo["segundos"] = $calculo;
	$tempo["minutos"] = ($calculo/60);
	$tempo["horas"] = (($calculo/60)/60); 
	$tempo["dias"] = ($tempo["horas"])/24; 
	$tempo["semanas"] = ($tempo["dias"])/7;

	$tempo["meses"] = ($tempo["dias"])/30; 
	$tempo["anos"] = ($tempo["dias"])/365;
	
	switch ($unidade) {
	   case "seg":
		   return $tempo["segundos"];
		   break;
	   case "min":
		   return $tempo["minutos"];
		   break;
	   case "hor":
		   return $tempo["horas"];
		   break;
		case "dia":
		   return $tempo["dias"];
		   break;
		case "sem":
		   return $tempo["semanas"];
		   break;
		case "mes":
		   return $tempo["meses"];
		   break;
		case "ano":
		   return $tempo["anos"];
		   break;
	}

} 

// SUBSTITUI "." POR "" E "," POR "." (C�LCULOS)
function virgula2ponto($valor) {
	return str_replace(",",".",str_replace(".","",$valor));
}
//..SUBSTITUI "." POR "" E "," POR "."

//REDIMENSIONA UMA IMAGEM ESTIPULANDO UMA LARGURA M�XIMA:
function redi($maxW,$src) {
	$size = getimagesize($src);
	$w = $size[0]; //largura
	$h = $size[1]; //altura
	if ($w > $maxW) {
		$w = $maxW;
		$h = ($size[1]*$maxW)/$size[0]; //f�rmula pra calcular proporcionalmente a nova altura
	}
	return array($w,$h);
}


//SIMULA A FUNCAO LEFT DO ASP
function Left($palavra,$comprimento){

	return substr($palavra,0,$comprimento);

}


//SIMULA A FUNCAO RIGHT DO ASP
function Right($palavra,$comprimento){

	$comprimento=($comprimento*(-1));
	return substr($palavra,$comprimento);
	
}


//'=============================='
//' SIMULA A FUNCAO NOW() DO ASP '
//'=============================='
function now() {
	return date("Y-m-d")." ".date("H:i:s");
}


//'=============================='
//' FORMATA A DATA PARA GRAVA��O '
//'=============================='
function FormataDataGravacao($vData) {

	if (trim($vData) == ""){
		 return "null";
	}else {
	
		$vData = ereg_replace("/","-",$vData);
		$vData = trim($vData); 
		$pos = strpos($vData,"-");
		
		if ($pos === 2) {
	  		$vXchange = explode("-",$vData); //10-10-2005 12:12:12
			$vXchangeAux = explode(" ",$vXchange[2]); //
			$vData = $vXchangeAux[0]."-".$vXchange[1]."-".$vXchange[0]." ".$vXchangeAux[1];
	  	}
		
		$vTime = null;
		$vData=explode("-",$vData);
		if(strlen($vData[1])==1){
			$vData[1]="0".$vData[1];
		}
		if(strlen($vData[0])==1){
			$vData[0]="0".$vData[0];
		}
		if(strlen($vData[2])>4) {
			$vTimeAux=explode(" ",$vData[2]);
			$vTime=explode(":",$vTimeAux[1]);
			$vData[2] = $vTimeAux[0];	
			if ($vTime[2] != "") {
				return "'".$vData[0]."-".$vData[1]."-".$vData[2]." ".$vTime[0].":".$vTime[1].":".$vTime[2]."'";
			} else {
				$vTime[2] = "00";
				return "'".$vData[0]."-".$vData[1]."-".$vData[2]." ".$vTime[0].":".$vTime[1].":".$vTime[2]."'";
			}
		} else {
			return "'".$vData[0]."-".$vData[1]."-".$vData[2]."'";
		}
	}
}

//'================'
//' RETORNA A DATA '
//'================'
/*function FormataData($vData){
if ($vData == "") return false;
return date("d/m/Y",strtotime($vData));
/*

$vData = ereg_replace("-","/",$vData);
$pos = strpos($vData,"/");
	if ($pos === 2) {
  		$vXchange = explode("/",$vData);
		$vXchangeAux = explode(" ",$vXchange[2]);
		$vData = $vXchangeAux[0]."/".$vXchange[1]."/".$vXchange[0]." ".$vXchangeAux[1];
  	}
	
	if (strstr($vData,'/')) {
		$vTime = null;
		$vData=explode("/",$vData);
		if(strlen($vData[1])==1){
			$vData[1]="0".$vData[1];
		}
		if(strlen($vData[0])==1){
			$vData[0]="0".$vData[0];
		}
		if(strlen($vData[2]>4)) {
			$vTimeAux=explode(" ",$vData[2]);
			$vTime=explode(":",$vTimeAux[1]);
			$vData[2] = $vTimeAux[0];
			return $vData[2]."/".$vData[1]."/".$vData[0];	
		} else {
			return $vData[2]."/".$vData[1]."/".$vData[0];
		}
	} else {
		return $vData;
	}
*/
//}
//'================'
//' RETORNA A DATA '
//'================'
function FormataDataConsulta($vData) {

//return variant_date_to_timestamp($vData);

if ($vData == "") return false;
$vData = ereg_replace("/","-",$vData);
$vData = trim($vData); 
$pos = strpos($vData,"-");
	if ($pos === 2) {
  		$vXchange = explode("-",$vData);
		$vXchangeAux = explode(" ",$vXchange[2]);
		$vData = $vXchangeAux[0]."-".$vXchange[1]."-".$vXchange[0]." ".$vXchangeAux[1];
  	}
	if (strstr($vData,'-')) {
		$vTime = null;
		$vData=explode("-",$vData);
		if(strlen($vData[1])==1){
			$vData[1]="0".$vData[1];
		}
		if(strlen($vData[0])==1){
			$vData[0]="0".$vData[0];
		}
	if(strlen($vData[2])>4) {
		$vTimeAux=explode(" ",$vData[2]);
		$vTime=explode(":",$vTimeAux[1]);
		$vData[2] = $vTimeAux[0];	
		if ($vTime[2] != "") {
			return "'".$vData[0]."-".$vData[1]."-".$vData[2]." ".$vTime[0].":".$vTime[1].":".$vTime[2]."'";
		} else {
			$vTime[2] = "00";
			return "'".$vData[0]."-".$vData[1]."-".$vData[2]." ".$vTime[0].":".$vTime[1].":".$vTime[2]."'";
		}
	} else {
		return "'".$vData[0]."-".$vData[1]."-".$vData[2]."'";
	}
	}
}

//'================================='
//' RETORNA A HORA DE UMA DATA/HORA '
//'================================='
function FormataHora($vData){
if ($vData == "") return false;
$vData = ereg_replace("-","/",$vData);
$pos = strpos($vData,"/");
	if ($pos === 2) {
  		$vXchange = explode("/",$vData);
		$vXchangeAux = explode(" ",$vXchange[2]);
		$vData = $vXchangeAux[0]."/".$vXchange[1]."/".$vXchange[0]." ".$vXchangeAux[1];
  	}
	$vTime = null;
	$vData=explode("/",$vData);
	if(strlen($vData[1])==1){
		$vData[1]="0".$vData[1];
	}
	if(strlen($vData[0])==1){
		$vData[0]="0".$vData[0];
	}
	if(strlen($vData[2])>4) {
		$vTimeAux=explode(" ",$vData[2]);
		$vTime=explode(":",$vTimeAux[1]);
		$vData[2] = $vTimeAux[0];
		return $vTime[0].":".$vTime[1];		
	} 
}
//'========================='
//' RETONRA A DATA E A HORA '
//'========================='

function FormataDataHora($vData){
	if ($vData == "") return false;
	$vData = ereg_replace("-","/",$vData);
	$pos = strpos($vData,"/");
	if ($pos === 2) {
  		$vXchange = explode("/",$vData);
		$vXchangeAux = explode(" ",$vXchange[2]);
		$vData = $vXchangeAux[0]."/".$vXchange[1]."/".$vXchange[0]." ".$vXchangeAux[1];
  	}	
	$vTime = null;
	$vData=explode("/",$vData);
	if(strlen($vData[1])==1){
		$vData[1]="0".$vData[1];
	}
	if(strlen($vData[0])==1){
		$vData[0]="0".$vData[0];
	}
	if(strlen($vData[2])>4) {
		$vTimeAux=explode(" ",$vData[2]);
		$vTime=explode(":",$vTimeAux[1]);
		$vData[2] = $vTimeAux[0];
		return $vData[2]."/".$vData[1]."/".$vData[0]." ".$vTime[0].":".$vTime[1];	
	} else {
		return $vData[2]."/".$vData[1]."/".$vData[0];
	}
}


//'=========================================='
//' FUN��O PARA FORMATAR O VALOR P/ GRAVA��O 
//' formato XXX,XX							 '
//'=========================================='
function FormataValorGravacao($valor) {

	if (trim($valor) == "") {
	    return "null";
	}else{
		return str_replace(",",".",str_replace(".","",$valor));
	}	
}

//'=========================================='
//' FUN��O PARA FORMATAR O VALOR P/ GRAVA��O 
//' somente verifica se ta nulo				 '
//'=========================================='
function FormataNumeroGravacao($valor) {

	if (trim($valor) == "") {
	    return "null";
	}else{
		return str_replace(",","",str_replace(".","",$valor));
	}	
}

//'============================================'
//' FUN��O PARA RETORNAR O VALOR DE UMA STRING '
//'============================================'
function Val($str) {

	//if(is_numeric($str) and (trim($str) <> "")) {
		settype($aux,"int");
		$aux = $str;
		settype($str,"int");
		$str = $aux;
		return $str;
	//} else {
	//	return 0;
	//}
	
}

//'================================================'
//' FUN��O UTILIZADA PARA CRIPTOGRAFAR INFORMA��ES '
//'================================================'
function Criptografa($strSenha) {
    
    for ($intContador = 0; $intContador < strlen($strSenha); $intContador++) {
        $strAux .=chr(ord(substr($strSenha,$intContador, 1)) + $intContador);
    } 
   //echo $strSenha." ".$strAux;
   //exit();    
    return $strAux;
    
}

//'==================================================='
//' FUN��O UTILIZADA PARA DESCRIPTOGRAFAR INFORMA��ES '
//'==================================================='
function Descriptografa($strSenha) {

       
   for($intContador = 0; $intContador < strlen($strSenha); $intContador++) {
      $strAux .= chr(ord(substr($strSenha,$intContador, 1)) - $intContador);
   }
   return $strAux;
    
}

//'===================================='
//' FUN��O PARA RETORNAR O NOME DO M�S '
//'===================================='
function RetornaMes($nMes) {

	switch($nMes){
	case 1:
		return "Janeiro";
	break;
	
	case 2:
		return "Fevereiro";
	break;
	
	case 3:
		return "Mar�o";
	break;
	
	case 4:
		return "Abril";
	break;
	
	case 5:
		return "Maio";
	break;
	
	case 6:
		return "Junho";
	break;
	
	case 7:
		return "Julho";
	break;
	
	case 8:
		return "Agosto";
	break;
	
	case 9:
		return "Setembro";
	break;
	
	case 10:
		return "Outubro";
	break;
	
	case 11:
		return "Novembro";
	break;
	
	case 12:
		return "Dezembro";
	break;
	
	}    
}

//'===================================='
//' FUN��O PARA RETORNAR A COORDENADA  '
//'===================================='
function RetornaCoordenada($sCoord) {

	switch($sCoord){
	case "N":
		return "Norte";
	break;
	
	case "S":
		return "Sul";
	break;
	
	case "L":
		return "Leste";
	break;

	case "O":
		return "Oeste";
	break;

	}
}

/**************************************************
 VERIFICA SE UM VALOR EST� CONTIDO EM UM VETOR
***************************************************/
function InArray($valor, $vetor){
	if (is_array($vetor)){
		if (in_array($valor,$vetor)){
			return true;
		}else{
			return false;
		}
	}else{
		return false;
	}
}


/**************************************************
 TRANSFORMA UMA STRING EM UM VETOR DE DADOS
***************************************************/
function FormataArray($delimitador, $string){
	if (trim($string) != ""){
		return explode($delimitador,$string);
	}else{
		return "";
	}
}

/**************************************************
 Escreve a Qualidade do Tipo de Transporte de um
 atrativo
***************************************************/
function retornaQualidTipoTransp($nQualid) {
	switch ($nQualid) {
		case 1: echo "Bom";break;
		case 2: echo "Regular";break;
		case 3: echo "Prec�rio";break;
		default: echo "";
	}
}
	
/**************************************************
 Escreve a Adapta��o do Tipo de Transporte de um
 atrativo
***************************************************/	
function retornaAdaptTipoTransp($nAdapt) {
	switch ($nAdapt) {
		case 1: echo "Adaptado";break;
		case 2: echo "N�o-Adaptado";break;
		case 3: echo "Parcialmente Adaptado";break;
		default: echo "";
	}
}
	
/**************************************************
 Escreve o de Transporte de um atrativo
***************************************************/
function retornaTipoTransp($nTipo) {
	switch ($nTipo) {
		case 1: echo "�nibus";break;
		case 2: echo "Caminh�o";break;
		case 3: echo "Embarca��o";break;
		case 4: echo "Aeronave";break;
		case 5: echo "Carro";break;
		case 6: echo "Moto";break;
		case 7: echo "Bicicleta";break;
		case 8: echo "A cavalo";break;
		case 9: echo "A p�";break;
		case 10: echo "Triciclo";break;
		default: echo "";
	}
}

/**************************************************
 Escreve a Frequencia do Tipo de Transporte de um
 atrativo
***************************************************/
function retornaFreqTipoTransp($nFrequencia) {
	switch ($nFrequencia) {
		case 1: echo "Di�ria";break;
		case 2: echo "Semanal";break;
		default: echo "";
	}
}

function retornaNomeCategoria($codgCategoria) {
	switch ($codgCategoria) {
		case 'A1':
			return "Atrativos Naturais";
		break;
		case 'A2':
			return "Atrativos Culturais";
		break;
		case 'A3':
			return "Atividades Econ�micas";
		break;
		case 'A4':
			return "Realiza��es T�cnicas, Cient�ficas e Art�sticas";
		break;
		case 'A5':
			return "Eventos Programados";
		break;
		case 'B1':
			return "Servi�os e Equipamentos de Hospedagem";
		break;
		case 'B2':
			return "Servi�os e Equipamentos de Alimenta��o";
		break;
		case 'B3':
			return "Servi�os e Equipamentos de Agenciamento";
		break;
		case 'B4':
			return "Servi�os e Equipamentos de Transportes";
		break;
		case 'B5':
			return "Servi�os e Equipamentos para Eventos";
		break;
		case 'B6':
			return "Servi�os e Equipamentos de Lazer e Entretenimento";
		break;
		case 'B7':
			return "Outros Servi�os e Equipamentos Tur�sticos";
		break;
		case 'C1':
			return "Informa��es B�sicas do Munic�pio";
		break;
		case 'C2':
			return "Meios de Acesso ao Munic�pio";
		break;
		case 'C3':
			return "Sistema de Comunica��es";
		break;
		case 'C4':
			return "Sistema de Seguran�a";
		break;
		case 'C5':
			return "Sistema M�dico-Hospitalar";
		break;
		case 'C6':
			return "Sistema Educacional";
		break;
		case 'C7':
			return "Outros Servi�os e Equipamentos";
		break;
		case 'A':
			return "Atividades Tur�sticas";
		break;
		case 'P':
			return "Pacotes Tur�sticos";		
	}
}
	
function retornaFormCategoria($codgCategoria) {

	switch ($codgCategoria) {
		case 'A1':
			return "cadatratnaturais";
		break;
		case 'A2':
			return "cadatratculturais";
		break;
		case 'A3':
			return "cadativecon";
		break;
		case 'A4':
			return "cadrealiztca";
		break;
		case 'A5':
			return "cadeventosprog";
		break;
		case 'B1':
			return "cadservequipturhosp";
		break;
		case 'B2':
			return "cadservequipturaliment";
		break;
		case 'B3':
			return "cadservequipturagenc";
		break;
		case 'B4':
			return "cadservequipturtransp";
		break;
		case 'B5':
			return "cadservequiptureventos";
		break;
		case 'B6':
			return "cadservequipturlazerentret";
		break;
		case 'B7':
			return "cadservequipturoutros";
		break;
		case 'C1':
			return "cadmunicipiosturisticos";
		break;
		case 'C2':
			return "cadmeiosacesso";
		break;
		case 'C3':
			return "cadservequipapoiocom";
		break;
		case 'C4':
			return "cadservequipapoioseg";
		break;
		case 'C5':
			return "cadservequipapoiomedhosp";
		break;
		case 'C6':
			return "cadservequipapoioedu";
		break;
		case 'C7':
			return "cadservequipapoiooutros";
		break;
		case 'A':
			return "cadativtur";
		break;
		case 'P':
			return "cadpacotestur";
		break;
	}	
}

function retornaFieldCategoria($codgCategoria) {

	switch ($codgCategoria) {
		case 'A1':
		case 'A2':
		case 'A3':
		case 'A4':
		case 'A5':
			return "numg_atrativo";
		break;

		case 'B1':
		case 'B2':
		case 'B3':
		case 'B4':
		case 'B5':
		case 'B6':
		case 'B7':
			return "numg_servequiptur";
		break;

		case 'C1':
			return "numg_municipio";
		break;
		case 'C2':
		case 'C3':
		case 'C4':
		case 'C5':
		case 'C6':
		case 'C7':
			return "numg_servequipapoio";
		break;
		case 'A':
			return "numg_ativtur";
		break;
		case 'P':
			return "numg_pacotetur";
		break;
	}
}
	/**
 * Descri��o: monta combo 
 * Autor: Jean Moreira
 * Data: 12/11/2007
 */
function montaCombo($oResultset,$indiceValue,$indiceLabel,$indiceSelecionado = null,$incluirOptVazia = false){
	if (!is_null($oResultset)){
		if($incluirOptVazia){
			echo '<option value=""></option>'.chr(13);
		}
		if($indiceSelecionado != null){
			for ($i=0;$i<$oResultset->getCount();$i++) { ?>
			<?='<option value="'.$oResultset->getValores($i,$indiceValue).'"'?><? if ($oResultset->getValores($i,$indiceValue) == $indiceSelecionado) {  echo ' selected="selected"'; }?><?=">"?><?=$oResultset->getValores($i,$indiceLabel)."</option>".chr(13)?>
			<? } 
		}else{
			for ($i=0;$i<$oResultset->getCount();$i++) { ?>
			<?='<option value="'.$oResultset->getValores($i,$indiceValue).'">'?><?=$oResultset->getValores($i,$indiceLabel)."</option>".chr(13)?>
		<? }
		}
	}
	
}

/**
 * Descri��o: monta combo com check
 * Autor: Jean Moreira
 * Data: 12/11/2007
 */
function montaComboCheck($oResultset,$idName,$indiceValue,$indiceLabel,$selecionados){

	if(!empty($oResultset)){
	
		if(empty($selecionados)){		
			for ($i=0;$i<$oResultset->getCount();$i++) {
				echo '<input type="checkbox" id="'.$idName.$i.'" name="'.$idName.$i.'" value="'.$oResultset->getValores($i,$indiceValue).'"';
				
				echo ' /><label for="'.$idName.$i.'">'.$oResultset->getValores($i,$indiceLabel).'</label><br />';				
			}
		} else {
			for ($i=0;$i<$oResultset->getCount();$i++) {
				echo '<input type="checkbox" id="'.$idName.$i.'" name="'.$idName.$i.'" value="'.$oResultset->getValores($i,$indiceValue).'"';
				
				if(is_array($selecionados)){
					if(in_array($oResultset->getValores($i,$indiceValue),$selecionados))
						echo 'checked="checked"';
				} else {
					if($oResultset->getValores($i,$indiceValue) == $selecionados)
						echo 'checked="checked"';
				}
				
				echo ' /><label for="'.$idName.$i.'">'.$oResultset->getValores($i,$indiceLabel).'</label><br />';				
			}
		}
		
	}
}
	

?>