<?php
include_once "funcoes.php";
/**
 * Empresa: Interagi Tecnologia
 * Descri��o:
 * Releases (Data, respons�vel e descri��o [�ltimo release primeiro]):
 *	 16/04/2008 (Rafael C�cero) 
 *		 Inclu�do este cabe�alho descrevendo a funcionalidade da p�gina
 */

$CODG_FORMULARIO = "reldesempsuperv";
$NOME_FORMULARIO = validarAcesso($CODG_FORMULARIO,$_SESSION["NUMG_OPERADOR"]);

?>

<html>
<head>

<title>SIGO - Relat�rio de Desempenho do Supervisor</title>

<link href="estilos.css" rel="stylesheet" type="text/css">

<script language="JavaScript" src="funcoes.js"></script>

<script type="text/javascript" src="javascripts/prototype.js"> </script>
<script type="text/javascript" src="javascripts/funcoes.js"> </script>
<script type="text/javascript" src="javascripts/populacombo.js"></script>

<script language="JavaScript">
function iniForm(){
	MontaFuncoes('<?=$CODG_FORMULARIO?>','<?=$NOME_FORMULARIO?>','1')
}
</script>

</head>
<body onLoad="iniForm()" rightmargin="0" marginwidth="0" marginheight="0" leftmargin="0" bottommargin="0" topmargin="0" bgcolor="#FFFFFF">

<table border=0 width=100% align=center cellspacing=0 cellpadding=0>
	<tr>
		<td><img src="imagens/space.gif" border=0 height=10></td>
	</tr>
	<tr>
		<td align=center>
			<table border=0 width=600 cellspacing=0 cellpadding=0>
				<tr>
					<td><img src="imagens/formEsqSup.gif" border=0 width=10 height=10></td>
					<td background="imagens/formMidSup.gif"></td>
					<td><img src="imagens/formDirSup.gif" border=0 width=10 height=10></td>
				</tr>
				<tr valign=top>
					<td width=10 background="imagens/formEsqMid.gif"></td>
					<td>
						<table border=0 width=100% cellspacing=0 cellpadding=2 align=center background="imagens/formMid.gif">
						<form method="post" action="preldesempsuperv.php" name="form" id="form">
							<tr>
								<td height=30 valign=top class=normal11b>Crit�rios dispon�veis para gera��o do relat�rio:</td>
							</tr>
							<tr>
								<td align=center>
									<table border=0 width=90% cellspacing=0 cellpadding=2 align=center>
										<tr class=normal11b>
											<td><INPUT type='radio' name=rdoOpcao value="1" checked></td>
											<td colspan="2">1 - Relat�rio de Desempenho de Supervisores</td>
										</tr>
										<tr height=30>
											<td width=5%>&nbsp;</td>
											<td width=50% class=normal11>Pelo M�s/Ano</td>
											<TD width=45%>
												<select tabindex="1" id="mes" name="mes" class="borda">
													<option value="1">Janeiro</option>
													<option value="2">Fevereiro</option>
													<option value="3">Mar�o</option>
													<option value="4">Abril</option>
													<option value="5">Maio</option>
													<option value="6">Junho</option>
													<option value="7">Julho</option>
													<option value="8">Agosto</option>
													<option value="9">Setembro</option>
													<option value="10">Outubro</option>
													<option value="11">Novembro</option>
													<option value="12">Dezembro</option>
												</select>/
												<input type=text name="ano" class=borda size=4 maxlength=4 onKeyPress="return IsNumber()">
											</TD>
										</tr>
										
									</table>
								</td>
							</tr>
						</table>
					</td>
					<td width=10 background="imagens/formDirMid.gif"></td>
				</tr>
				<tr>
					<td><img src="imagens/formEsqInf.gif" border=0 width=10 height=10></td>
					<td background="imagens/formMidInf.gif"></td>
					<td><img src="imagens/formDirInf.gif" border=0 width=10 height=10></td>
				</tr>
			</table>
		</td>
	</tr>
</table>

<script language="JavaScript">
function gerar_reldesempsuperv(){
	if (pValidaGeracao()){

		document.form.submit()

	}
}

function pValidaGeracao(){

	var sErr = ""

	if (Trim(form.ano.value) == "")
	sErr = "Preencha o campo ano para gera��o do relat�rio!\n"

	//VERIFICA SE FOI ENCONTRADO ALGUM ERRO NA VALIDA��O DO FORMUL�RIO
	if (sErr != ""){
		sErr = "Verifique os erros encontrados abaixo:\n\n" + sErr
		alert(sErr)
		return false
	}else
	return true
}

</script>

</body>
</html>