<?
include_once "funcoes.php";
include_once "classes/Empresas.php";

/**
 * Empresa: Interagi Tecnologia
 * Descri��o:
 * Releases (Data, respons�vel e descri��o [�ltimo release primeiro]):
 *	 28/03/2008 (Danilo Fernandes) 
 *		 
 */

if (empty($_SESSION["NUMG_OPERADOR"]) || $_SESSION["NUMG_OPERADOR"] == ""){
	header("Location: expirou.htm"); exit;
}

switch ($_POST["txtFuncao"]){

	case "cadastrar_empresa":

		$oEmpresa = new Empresas();
		
		$oEmpresa->setNomeEmpresa($_POST["nomeEmpresa"]);
	
		$oEmpresa->cadastrar();

		if (Erros::isError()){
			MostraErros();
		}else{
			header("Location: cadempresas.php?info=1"); exit;
		}

		break;

	case "editar_empresa":

		$oEmpresa = new Empresas();
		
		$oEmpresa->setNumgEmpresa($_POST["numgEmpresa"]);
		$oEmpresa->setNomeEmpresa($_POST["nomeEmpresa"]);
		$oEmpresa->editar();

		if (Erros::isError()){
			MostraErros();
		}else{
			header("Location: cadempresas.php?info=2&numg_empresa=" . $oEmpresa->getNumgEmpresa()); exit;
		}

		break;

	case "excluir_empresa":

		$oEmpresa = new Empresas();

		$oEmpresa->excluir($_POST["numgEmpresa"]);

		if (Erros::isError()){
			MostraErros();
		}else{
			header("Location: cadempresas.php?info=3"); exit;
		}

		break;

	default:
		header("Location: cadsite.php"); exit;
		break;
}


?>