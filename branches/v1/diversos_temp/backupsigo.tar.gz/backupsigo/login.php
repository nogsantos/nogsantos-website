<?php
include_once ("funcoes.php");
include_once ("classes/Operadores.php");
/*********************************************************************************
 Empresa: Net4U Solu��es Internet e Intranet
 Cria��o: Rafael C�cero
 
 Descri��o: P�gina respons�vel pela identifica��o dos usu�rios do sistema.

 Releases (Data, respons�vel e descri��o [�ltimo release primeiro]):
	 05/08/2005 (Rafael C�cero) 
		 Inclu�do este cabe�alho descrevendo a funcionalidade desta p�gina
		
*********************************************************************************/

	if ($_GET["opt"] == 1) 
	{
		
		if ($_SESSION["NUMG_OPERADOR"] != "" && !empty($_SESSION["NUMG_OPERADOR"]))
		{
			$oOperadores = new Operadores;
		
			//ATUALIZA A DATA DO �LTIMO ACESSO AO SISTEMA
			$oOperadores->editarUltimoAcesso($_SESSION["NUMG_OPERADOR"]);
			if (Erros::isError()) MostraErros();

		}	
	}
	
	//INICIALIZA AS SESSIONS
	$_SESSION["NUMG_OPERADOR"] = "";
	$_SESSION["NOME_OPERADOR"] = "";
	$_SESSION["NOME_COMPLETO"] = "";
	$_SESSION["DATA_ULTIMOACESSO"] = "";
	
	
		if ($_POST["txtNomeOperador"] != "" && $_POST["txtDescSenha"] != "")
	{
		$bOpen = true;

		$oOperadores = new Operadores;
		$oResult = new Resultset();
		
		$oResult = $oOperadores->consultarPorNomeOperador($_POST["txtNomeOperador"]);
		
		if (Erros::isError()) MostraErros();
	
		if ($oResult->getCount() == 0){
			header("Location: login.php?erro=1");
		}else{
			
			//VERIFICA SE A SENHA EST� CORRETA
			//if (trim(Descriptografa($vDados[0][3])) != trim($_GET["txtDescSenha"])){
			if (trim(Descriptografa($oResult->getValores(0,"desc_senha"))) != trim($_POST["txtDescSenha"])){
				header("Location: login.php?erro=3"); exit;
			//VERIFICA SE O OPERADOR EST� BLOQUEADO
			}elseif (!is_null($oResult->getValores(0,"data_bloqueio"))){
				header("Location: login.php?erro=2"); exit;
			}else{
				$_SESSION["NUMG_OPERADOR"] = $oResult->getValores(0,"numg_operador");
				$_SESSION["NOME_OPERADOR"] = strtolower($_POST["txtNomeOperador"]);
				$_SESSION["NOME_COMPLETO"] = $oResult->getValores(0,"nome_completo");
				$_SESSION["DATA_ULTIMOACESSO"] = $oResult->getValores(0,"data_ultimoacesso");
				
												
				$bOpen = true;
			}
		}
	}
	
	
?>

<html>
<head>
<title>Sigo - Acesso Restrito</title>
<meta http-equiv="Content-Type" content="text/html;">
<LINK href="estilos.css" rel=stylesheet type=text/css>
<SCRIPT language=JavaScript src="funcoes.js"></SCRIPT>
<script language=JavaScript>
 
function Open(){
	<?php 
	if ($bOpen && $_GET["opt"] == ""){
	?>
		//window.open("gerenciador.php", "gerenciador_sigo", "directories=no,height=546,width=792,hotkeys=no,location=no,menubar=no,resizable=yes,scrollbars=no,status=no,toolbar=no,copyhistory=no,left=0,top=0")	
		//if (window.name == "login_sigo")	window.close()
		window.location.href = "gerenciador.php";
	<?php
	}
	?>
}
</script>
<style type="text/css">

td img {display: block;}td img {display: block;}
</style>
</head>

<body onLoad="Open();window.focus();document.form.txtNomeOperador.focus()" bgcolor="#f3f3f3" topmargin=0 leftmargin=0 rightmargin=0 bottommargin=0>

<table border="0" cellpadding="0" cellspacing="0" width="100%" height="100%" bgcolor="#f3f3f3" align=center valign=middle>
	<tr>
		<td valign=middle align=center>
					
			<table>	
				<tr>
					<td><table border="0" cellpadding="0" cellspacing="0" width="600">
                      <!-- fwtable fwsrc="Untitled" fwbase="interface.jpg" fwstyle="Dreamweaver" fwdocid = "1110553482" fwnested="0" -->
                      <tr>
                        <td><img src="imagens/spacer.gif" width="13" height="1" border="0" alt="" /></td>
                        <td><img src="imagens/spacer.gif" width="11" height="1" border="0" alt="" /></td>
                        <td><img src="imagens/spacer.gif" width="360" height="1" border="0" alt="" /></td>
                        <td><img src="imagens/spacer.gif" width="14" height="1" border="0" alt="" /></td>
                        <td><img src="imagens/spacer.gif" width="178" height="1" border="0" alt="" /></td>
                        <td><img src="imagens/spacer.gif" width="9" height="1" border="0" alt="" /></td>
                        <td><img src="imagens/spacer.gif" width="15" height="1" border="0" alt="" /></td>
                        <td><img src="imagens/spacer.gif" width="1" height="1" border="0" alt="" /></td>
                      </tr>
                      <tr>
                        <td colspan="7"><img name="interface_r1_c1" src="imagens/interface_r1_c1.jpg" width="600" height="10" border="0" id="interface_r1_c1" alt="" /></td>
                        <td><img src="imagens/spacer.gif" width="1" height="10" border="0" alt="" /></td>
                      </tr>
                      <tr>
                        <td rowspan="6"><img name="interface_r2_c1" src="imagens/interface_r2_c1.jpg" width="13" height="302" border="0" id="interface_r2_c1" alt="" /></td>
                        <td rowspan="3" colspan="2"><img name="interface_r2_c2" src="imagens/interface_r2_c2.jpg" width="371" height="220" border="0" id="interface_r2_c2" alt="" /></td>
                        <td colspan="4"><img name="interface_r2_c4" src="imagens/interface_r2_c4.jpg" width="216" height="27" border="0" id="interface_r2_c4" alt="" /></td>
                        <td><img src="imagens/spacer.gif" width="1" height="27" border="0" alt="" /></td>
                      </tr>
                      <tr>
                        <td rowspan="3"><img name="interface_r3_c4" src="imagens/interface_r3_c4.jpg" width="14" height="194" border="0" id="interface_r3_c4" alt="" /></td>
                        <td colspan="2">
									<TABLE border=0 width=183 cellspacing=0 cellpadding=0 >
												<FORM method="post" action="login.php" name="form" autocomplete=off>
													<input type=hidden name=txtTipoFuncao value="">
														<tr>
															<td valign=top bgcolor="#F3F3F3">
																<TABLE width="170" border=0 align=center cellpadding=0 cellspacing=0 bgcolor="#F3F3F3">
																	<tr>
																		<td class=destaque align=center height="20" colspan=3>
																		<?php	
																		//MENSAGENS DE ERRO
																		if ($_GET["erro"] != "")
																		{
									
																			switch ($_GET["erro"]){
																				case 1:
																					echo "Operador n�o encontrado!";
																					break;
																				case 2:
																					echo "Este operador encontra-se bloqueado!";
																					break;
																				case 3:
																					echo "Senha incorreta! Tente novamente.";
																					break;
																				case 4:
																					echo "N�o foi poss�vel criar o diret�rio de imagens!";
																					break;
																			}
									
																		//MENSAGENS DE ERRO
																		}elseif ($_GET["opt"] != ""){
									
																			switch ($_GET["opt"]){
																				case 1:
																					echo "Operador efetuou logoff!";
																					break;
																				case 2:
																					echo "Tempo de conex�o expirado!";
																					break;
																			}
																		
																		}
																		?>
																		</td>
																	</tr>	
																	<tr>
																		<td width="7"></td>
																		<td width="160" height="15" class=normal11b>Operador:</td>
																		<td width="11"></td>
																	</tr>
																	<tr>
																		<td></td>
																		<td><INPUT type="text" name="txtNomeOperador" size=20 maxlength=20 class=borda tabindex=1></td>
																		<td></td>
																	</tr>
																	<tr>
																		<td></td>
																		<td class=normal11b height="15">Senha:</td>
																		<td></td>
																	</tr>
																	<tr>
																		<td></td>
																		<td><INPUT type="password" name="txtDescSenha" size=20 maxlength=8 class=borda tabindex=2></td>
																		<td></td>
																	</tr>
																	<tr>
																		<td height=10></td>
																	</tr>
																	<tr>
																		<td colspan=3 align=right>
																			<TABLE border=0 width="100%" align=center cellspacing=0 cellpadding=0>
																				<tr>
																					<td bgcolor="#F3F3F3" class="normal11">
																				  &nbsp;
																				  <input type=submit value=" Entrar " border=0 onClick="return ValidaForm(document.form)" class=botao tabindex="3">																				  &nbsp;&nbsp;																				  </td>
																			    </tr>
																			</table>
																		</td>
																	</tr>
																	<tr>
																		<td height="25" colspan="3" class="normal11">&nbsp;</td>
																	</tr>
															  </table>
															</td>
														</tr>
										  </FORM>
									
						  </table>
						
						</td>
                        <td rowspan="5"><img name="interface_r3_c7" src="imagens/interface_r3_c7.jpg" width="15" height="275" border="0" id="interface_r3_c7" alt="" /></td>
                        <td><img src="imagens/spacer.gif" width="1" height="161" border="0" alt="" /></td>
                      </tr>
                      <tr>
                        <td rowspan="2" colspan="2"><img name="interface_r4_c5" src="imagens/interface_r4_c5.jpg" width="187" height="33" border="0" id="interface_r4_c5" alt="" /></td>
                        <td><img src="imagens/spacer.gif" width="1" height="32" border="0" alt="" /></td>
                      </tr>
                      <tr>
                        <td colspan="2"><img name="interface_r5_c2" src="imagens/interface_r5_c2.jpg" width="371" height="1" border="0" id="interface_r5_c2" alt="" /></td>
                        <td><img src="imagens/spacer.gif" width="1" height="1" border="0" alt="" /></td>
                      </tr>
                      <tr>
                        <td rowspan="2"><img name="interface_r6_c2" src="imagens/interface_r6_c2.jpg" width="11" height="81" border="0" id="interface_r6_c2" alt="" /></td>
                        <td colspan="3"><img src="imagens/interface_r6_c3.jpg" alt="" name="interface_r6_c3" width="552" height="61" border="0" usemap="#interface_r6_c3Map" id="interface_r6_c3" /></td>
                        <td rowspan="2"><img name="interface_r6_c6" src="imagens/interface_r6_c6.jpg" width="9" height="81" border="0" id="interface_r6_c6" alt="" /></td>
                        <td><img src="imagens/spacer.gif" width="1" height="61" border="0" alt="" /></td>
                      </tr>
                      <tr>
                        <td colspan="3"><img name="interface_r7_c3" src="imagens/interface_r7_c3.jpg" width="552" height="20" border="0" id="interface_r7_c3" alt="" /></td>
                        <td><img src="imagens/spacer.gif" width="1" height="20" border="0" alt="" /></td>
                      </tr>
                    </table></td>
				</tr>	
			</table>
		
		</td>
	</tr>
	
</table>

<script language="JavaScript">
<!--

//FUN��O PARA VALIDAR O NOME DE OPERADOR E A SENHA
function ValidaForm(form){
	
	if (Trim(form.txtNomeOperador.value) == ""){
		alert("Nome do operador inv�lido!")
		form.txtNomeOperador.focus()
		return false
	}

	if (Trim(form.txtDescSenha.value) == ""){
		alert("Senha inv�lida!")
		form.txtDescSenha.focus()
		return false
	}
}

//-->
</script>


<map name="interface_r6_c3Map"><area shape="rect" coords="9,5,216,61" href="http://www.interagi.com.br" target="_blank" alt="">
</map></body>
</html>