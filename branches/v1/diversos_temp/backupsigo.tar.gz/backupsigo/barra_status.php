<?php 
include_once ("funcoes.php");
/************************************************************************
'Empresa: Net4U Solu��es Internet e Intranet

'Descri��o: Barra de fun��es da Sigo
	
'Releases (Data, respons�vel e descri��o [�ltimo release primeiro]):
	'29/07/2005 (Jean Moreira) 
		'Inclu�do este cabe�alho descrevendo a funcionalidade da p�gina
						
'***********************************************************************/
?>

<HTML>
<HEAD>

<!--<meta http-equiv="Refresh" content="100 ; URL=barra_status.asp">-->

<title>Sigo - Sistema de Gerenciamento de Obras</title>

<link href="estilos.css" rel="stylesheet" type="text/css">

</HEAD>
<BODY topmargin="0" leftmargin="0" rightmargin="0" bottommargin="0">

<table border=0 height=20 width=100% cellpadding=0 cellspacing=0>
	<tr>
		<td valign=bottom>
			<table border=0 cellpadding=0 cellspacing=0 height=20 width=100% background=imagens/fundoBarraStatus.gif bgcolor=#f3f3f3>
				<tr height=20 class=titulo11>
					<td>&nbsp;
					<?php 
					if (date("G") < 12 and date("G") > 6) {
						echo "Bom-dia, ";
					} else if ( date("G") >= 12 and date("G") < 19) {
						echo "Boa-tarde, ";
					} else {
						echo "Boa-noite, ";
					}
					echo $_SESSION["NOME_COMPLETO"] . " !";
					?>
					</td>
					<td align=center width=80>	
						<table border=0 cellpadding=0 cellspacing=0 width=100%>
							<tr>
								<td><img src="imagens/icones/operador.gif" border=0 align=absbottom alt="Operador do sistema"></td>
								<td class=titulo11>&nbsp;<?=$_SESSION["NOME_OPERADOR"]?></td>
							</tr>
						</table>
					</td>
					<td><img src="imagens/div_status.gif" border=0></td>
					<td align=center width=120><?=FormataDataHora($_SESSION["DATA_ULTIMOACESSO"]) ?></td>
					<td><img src="imagens/div_status.gif" border=0></td>
					<td align=center width=140><?=date("d/m/Y H:m") . "h" ?></td>
				</tr>
			</table>
		</td>
	</tr>
</table>

</BODY>
</HTML>
