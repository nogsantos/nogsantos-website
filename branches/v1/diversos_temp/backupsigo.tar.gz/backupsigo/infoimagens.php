<?php
include_once "funcoes.php";
include_once "classes/Imagens.php";
	
	session_start();
	header("Cache-control: private");

	$oImagens = new Imagens;
	
	$vImagens = $oImagens->consultarPorMunicipio($_SESSION["NUMG_MUNICIPIO"]);
	if (Erros::isError()) MostraErros();
	
?>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.0 Transitional//EN">
<HTML>
<HEAD>
<TITLE>.:: Informa��es sobre a Imagem ::.</TITLE>
<META content="MSHTML 6.00.2800.1400" name=GENERATOR>
<META http-equiv=Content-Type content="text/html; charset=windows-1252">
<link href="estilos.css" rel="stylesheet" type="text/css">
<SCRIPT language=JavaScript src="funcoes.js"></SCRIPT>
<SCRIPT language=JavaScript>
  <!--
  window.onload = windowOnLoad;

  function windowOnLoad() {
    document.frmImagem.alt.value = window.dialogArguments["alt"];
    document.frmImagem.hspace.value = window.dialogArguments["hspace"];
    document.frmImagem.src.value = window.dialogArguments["src"];
    document.frmImagem.align.value = window.dialogArguments["align"];
    document.frmImagem.vspace.value = window.dialogArguments["vspace"];
    document.frmImagem.border.value = window.dialogArguments["border"];
  }

	function ValidaForm() {

		if (Trim(document.frmImagem.src.value) == ""){
			alert("Selecione uma imagem na lista.")
			document.frmImagem.src.focus()
		}else if (!IsNumeric(document.frmImagem.hspace.value)){
			alert("Inform um valor entre 0 e 99 para o Espa�amento Horizontal.")
			document.frmImagem.hspace.value = ""
			document.frmImagem.hspace.focus()
		}else if (!IsNumeric(document.frmImagem.vspace.value)){
			alert("Inform um valor entre 0 e 99 para o Espa�amento Vertical.")
			document.frmImagem.vspace.value = ""
			document.frmImagem.vspace.focus()
		}else if (!IsNumeric(document.frmImagem.border.value)){
			alert("Inform um valor v�lido para a Borda.")
			document.frmImagem.border.value = ""
			document.frmImagem.border.focus()
		}else{
	
			var imagemVals = new Array();

			imagemVals["alt"] = document.frmImagem.alt.value;
			imagemVals["hspace"] = document.frmImagem.hspace.value;
			imagemVals["src"] = "imagens/upload/<?=$_SESSION["NUMG_MUNICIPIO"]?>/" + document.frmImagem.src.value;
			imagemVals["align"] = document.frmImagem.align.value;
			imagemVals["vspace"] = document.frmImagem.vspace.value;
			imagemVals["border"] = document.frmImagem.border.value;

			window.returnValue = imagemVals;
			window.close();
		}
	}

function AlteraImagem(img) {
	oImage = eval("document.frmImagem.imagem");
	if (img != "")
		oImage.src = "imagens/upload/<?=$_SESSION["NUMG_MUNICIPIO"]?>/" + img;
	else
		oImage.src = "imagens/space.gif"
	
}
//-->
</script>
</HEAD>
<BODY bgColor=white topmargin=10 leftmargin=10>
<FORM name=frmImagem>
<table width="100%" border="0" align="center" cellpadding="0" cellspacing="0">
    <tr>
        <td><img src="imagens/formEsqSup.gif" border=0 width=10 height=10></td>
        <td background="imagens/formMidSup.gif"></td>
        <td><img src="imagens/formDirSup.gif" border=0 width=10 height=10></td>
    </tr>
    <tr>
        <td width=10 background="imagens/formEsqMid.gif"> </td>
        <td><TABLE cellSpacing=0 cellpadding=0 width="100%" border=0 background="imagens/formMid.gif">
        <tr>
            <td ><TABLE cellSpacing=0 cellpadding=2 width="97%" border=0 bgcolor=#f3f3f3 align=right class="normal11">
                    <TBODY>
                        <tr>
                            <td height=10></td>
                        </tr>
                        <tr>
                            <td width=22% class=normal align=right>Imagem:</td>
                            <td width=42% class="normal11"><select name=src style=width:165 class=borda onChange="AlteraImagem(document.frmImagem.src.value)">
                                    <?php
												if (!empty($vImagens)) {
													if ($vImagens->getCount() > 0){
														for ($i=0; $i < $vImagens->getCount(); $i++){ ?>
                                    <option value="<?=$vImagens->getValores($i,"nome_imagem");?>">
                                    <?=$vImagens->getValores($i,"nome_imagem");?>
                                    <? }
													}
												}?>
                                </select>
                            </td>
                            <td width=36% rowspan=6 align=center><TABLE cellSpacing=0 cellpadding=0 width="120" height="120" border=0 bgcolor=#f3f3f3 align=center>
                                    <tr>
                                        <td class=borda height=120 width=120 align=center><img src="imagens/space.gif" width="120" height="120" border=0 name=imagem align=center></td>
                                    </tr>
                                </table></td>
                        </tr>
                        <TR>
                            <TD class=normal11 align=right>Texto alternativo:</TD>
                            <TD><INPUT size=25 maxlength=50 name=alt class=borda></TD>
                        </TR>
                        <TR>
                            <TD class=normal align=right>Alinhamento:</TD>
                            <TD class="normal11"><select name=align class=normal>
                                    <option value="left">Esquerdo</option>
                                    <option value="right">Direito</option>
                                    <option value="textTop">In�cio do texto</option>
                                    <option value="absMiddle">Centro absoluto</option>
                                    <option value="baseline">Linha de base</option>
                                    <option value="absBottom">Inferior absoluto</option>
                                    <option value="bottom">Inferior</option>
                                    <option value="middle">Centro</option>
                                    <option value="top">Superior</option>
                                </select>
                            </TD>
                        </TR>
                        <TR>
                            <TD class=normal align=right>Esp. Horizontal:</TD>
                            <TD><INPUT size=5 maxlength=2 name=hspace class=borda></TD>
                        </TR>
                        <TR>
                            <TD class=normal align=right>Esp. Vertical:</TD>
                            <TD><INPUT size=5 maxlength=2 name=vspace class=borda></TD>
                        </TR>
                        <TR>
                            <TD class=normal align=right>Borda:</TD>
                            <TD><INPUT size=5 maxlength=2 name=border class=borda></TD>
                        </TR>
                        
                    </TBODY>
                </TABLE></td>
        </tr>
        <tr>
            <td><TABLE cellSpacing=0 cellpadding=2 width="97%" border=0 align=right>
                    <tr height=40>
                        <td align=right class=normal><input type=button value="Ok" class="botao" onClick="ValidaForm();return false">
                            &nbsp;
                            <input type=button value="Cancelar" class="botao" onClick="window.close()">
                            &nbsp;&nbsp;&nbsp; </td>
                    </tr>
                </table></td>
        </tr>
    </table>
	</td>
        <td width=10 background="imagens/formDirMid.gif"></td>
    </tr>
    <tr>
        <td><img src="imagens/formEsqInf.gif" border=0 width=10 height=10></td>
        <td background="imagens/formMidInf.gif"></td>
        <td><img src="imagens/formDirInf.gif" border=0 width=10 height=10></td>
    </tr>
</table>


    
</FORM>
</BODY>
</HTML>
