<?php
/************************************************************************
 Empresa: Net4U Solu��es Internet e Intranet

 Descri��o:
	
 Releases (Data, respons�vel e descri��o [�ltimo release primeiro]):
	 25/01/2005 (Rafael C�cero) 
		 Inclu�do este cabe�alho descrevendo a funcionalidade da p�gina
						
************************************************************************/

	if (empty($_SESSION["numg_operador"]) || $_SESSION["numg_operador"] == ""){
		//header("Location: expirou.htm"); exit;
	}

?>
<HTML>
<HEAD>

<title>SIGO - Barra de Atalhos</title>

<link href="estilos.css" rel="stylesheet" type="text/css">

<!--<base target="conteudo">-->
</HEAD>
<BODY topmargin="0" leftmargin="0" bottommargin=0 rightmargin=0>

<table border=0 height=62 width=100% cellpadding=0 cellspacing=0 background-color="#3E3E3E">
	<tr>
		<td bgcolor="#3E3E3E">
			<img src="imagens/logo_sistema.jpg" alt="" width="500" height="60" />		</td>
	</tr>
</table>

</BODY>
</HTML>
