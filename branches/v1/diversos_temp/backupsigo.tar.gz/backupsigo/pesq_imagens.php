<?php
include_once "funcoes.php";
include_once "classes/Imagens.php";
/************************************************************************
 Empresa: Interagi Tecnologia

 Descri��o:
	
 Releases (Data, respons�vel e descri��o [�ltimo release primeiro]):
	 08/08/2005 (Rafael C�cero) 
		 Inclu�do este cabe�alho descrevendo a funcionalidade da p�gina
************************************************************************/
	session_start();
	header("Cache-control: private");

	$oImagens = new Imagens;
	
	$vImagens = $oImagens->consultarPorMunicipio($_SESSION["NUMG_MUNICIPIO"]);
	if (Erros::isError()) MostraErros();
	
?>

<html>
<head>

<title>.:: Net Manager ::.</title>

<link href="estilos.css" rel="stylesheet" type="text/css">

<SCRIPT language=JavaScript src="funcoes.js"></SCRIPT>

</head>
<body onLoad="window.focus()" rightmargin="0" marginwidth="0" marginheight="0" leftmargin="0" bottommargin="0" topmargin="0">

<table border=0 width=380 align=center cellspacing=0 cellpadding=0>
	<tr>
		<td><img src="imagens/space.gif" border=0 height=10></td>
	</tr>
	<tr>
		<td align=center>
			<table border=0 width=380 cellspacing=0 cellpadding=0>
				<tr>
					<td><img src="imagens/formEsqSup.gif" border=0 width=10 height=10></td>
					<td background="imagens/formMidSup.gif"></td>
					<td><img src="imagens/formDirSup.gif" border=0 width=10 height=10></td>
				</tr>
				<tr valign=top>
					<td width=10 background="imagens/formEsqMid.gif"></td>
					<td>
						<table border=0 width=100% cellspacing=0 cellpadding=0 align=center background="imagens/formMid.gif">
						<FORM method="post" action="pcadpublicacoes.php" name="form">
					
							<tr>
								<td width=60% valign=top>
									<table border=0 width=100% cellpadding=0 cellspacing=0>
										<tr class="normal11" height=15>
											<td>Imagem:</td>
										</tr>
										<tr>
											<td>
												<select name=cboImagens class="borda" style="width:180" onChange="AlteraImagem(document.form.cboImagens.value)">
												<option value="">
												<?php
												if (!empty($vImagens)) {
													if ($vImagens->getCount() > 0){
														for ($i=0; $i < $vImagens->getCount(); $i++){ ?>
														<option value="<?=$vImagens->getValores($i,"nome_imagem");?>"><?=$vImagens->getValores($i,"nome_imagem");?>
														<? }
													}
												}?>
												</select>
											</td>
										</tr>	
									</table>
								</td>
								<td width=40% align=center>
									<TABLE cellSpacing=0 cellpadding=0 width="120" height="120" border=0 bgcolor=#f3f3f3 align=center>
										<tr>
											<td class=borda height=120 width=120 align=center><img src="imagens/space.gif" width="120" height="120" border=0 name=imagem align=center></td>
										</tr>
									</table>
								</td>						
							</tr>
							<tr valign="bottom">
								<td colspan="2" align=right height="30">
								<input type=button value="Ok" class="botao" onClick="SetaImagem(document.form)">&nbsp;
								<input type=button value="Cancelar" class="botao" onClick="window.close()">&nbsp;&nbsp;&nbsp;
								</td>
								<td width=10></td>
							</tr>
							<!-- FIM CAMPOS DO FORMUL�RIO  -->
							
						</form>
						</table>
					</td>
					<td width=10 background="imagens/formDirMid.gif"></td>
				</tr>
				<tr>
					<td><img src="imagens/formEsqInf.gif" border=0 width=10 height=10></td>
					<td background="imagens/formMidInf.gif"></td>
					<td><img src="imagens/formDirInf.gif" border=0 width=10 height=10></td>
				</tr>
			</table>
		</td>
	</tr>
    <!-- FIM CAMPOS DO FORMUL�RIO  -->
	<tr>
		<td><img src="imagens/space.gif" border=0 height=10></td>
	</tr>
	
</table>

<script language="JavaScript">
<!--

function SetaImagem(form)
{
	window.opener.document.form.txtNomeImagem.value = form.cboImagens.value
	window.close()
}

function AlteraImagem(img) {
	oImage = eval("document.form.imagem");
	if (img != "")
		oImage.src = "imagens/upload/<?=$_SESSION["NUMG_MUNICIPIO"]?>/" + img;
	else
		oImage.src = "imagens/space.gif"
}

//-->
</script>

</body>
</html>