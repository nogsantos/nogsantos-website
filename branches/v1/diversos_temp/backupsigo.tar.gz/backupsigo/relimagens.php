<?php
include_once "funcoes.php";

/************************************************************************
 Empresa: Interagi Tecnologia

 Descri��o:
	
 Releases (Data, respons�vel e descri��o [�ltimo release primeiro]):
	 01/12/2005 (Rafael C�cero) 
		 Inclu�do este cabe�alho descrevendo a funcionalidade da p�gina
						
************************************************************************/
	
	$CODG_FORMULARIO = "relimagens";
	$NOME_FORMULARIO = validarAcesso($CODG_FORMULARIO,$_SESSION["NUMG_OPERADOR"]);

?>

<html>
<head>

<title>Sigo - Relat�rio de Imagens</title>

<link href="estilos.css" rel="stylesheet" type="text/css">

<SCRIPT language=JavaScript src="funcoes.js"></SCRIPT>

<script language="JavaScript">
function iniForm(){
	MontaFuncoes('<?=$CODG_FORMULARIO?>','<?=$NOME_FORMULARIO?>','1')
	document.form.txtNomeImagem.focus()
}

</script>

</head>
<body onLoad="iniForm()" rightmargin="0" marginwidth="0" marginheight="0" leftmargin="0" bottommargin="0" topmargin="0" bgcolor="#FFFFFF">

<table border=0 width=100% align=center cellspacing=0 cellpadding=0>
	<tr>
		<td><img src="imagens/space.gif" border=0 height=10></td>
	</tr>
	<tr>
		<td align=center>
			<table border=0 width=600 cellspacing=0 cellpadding=0>
				<tr>
					<td><img src="imagens/formEsqSup.gif" border=0 width=10 height=10></td>
					<td background="imagens/formMidSup.gif"></td>
					<td><img src="imagens/formDirSup.gif" border=0 width=10 height=10></td>
				</tr>
				<tr valign=top>
					<td width=10 background="imagens/formEsqMid.gif"></td>
					<td>
						<table border=0 width=100% cellspacing=0 cellpadding=2 align=center background="imagens/formMid.gif">
						<form method="post" action="prelimagens.php" name="form">
							<tr>
								<td height=30 valign=top class=normal11b>Crit�rios dispon�veis para gera��o do relat�rio:</td>
							</tr>
							<? if ($_GET["info"] != "") {?>
								<tr>
									<td height=30 valign=top class="normal11" align="center">
										<img src="imagens/icones/info.gif" border=0 align=absbottom>&nbsp;&nbsp;
										<?php		
											switch ($_GET["info"]){
												case 1:
													echo "Nenhum registro encontrado para pesquisa!";
													break;												
											}  ?>
									</td>
								</tr>
							<? }?> 
							<tr>
								<td align=center>
									<table border=0 width=90% cellspacing=0 cellpadding=2 align=center>
										<tr class=normal11b>
											<td><INPUT type='radio' name=rdoOpcao value=1 checked></td>
											<td>1 - Pesquisa condicionada</td>
										</tr>
										<tr height=30>
											<td width=5%>&nbsp;</td>
											<td width=50% class=normal11>Pelo NOME da imagem </td>
											<TD width=45%><input name="txtNomeImagem" type=text class=borda id="txtNomeImagem" size=40 maxlength=80 onKeyPress="document.form.rdoOpcao[0].checked='checked';SetFocus(document.form.cboTipo)"></TD>
										</tr>
										<tr height=30>
											<td>&nbsp;</td>
											<td class=normal11>Pela imagem VINCULADA a</td>
											<TD class=normal11><select name="cboTipo" id="cboTipo" class="borda" style="width:250" onChange="document.form.rdoOpcao[0].checked='checked';">
												<option value="0">---------------- Selecione ----------------</option>
												<option value="1">Munic&iacute;pios Tur&iacute;sticos</option>
												<option value="2">Atividades Tur&iacute;sticas</option>
												<option value="3">Pacotes Tur&iacute;sticos</option>
												<option value="4">Atrativos Tur&iacute;sticos</option>
												<option value="5">Serv. Equip. Tur&iacute;sticos</option>
												<option value="6">Serv. Equip. Apoio</option>
												
												
											</select>
											</TD>
										</tr>
										<tr height=30>
											<td>&nbsp;</td>
											<td class=normal11>Pela DATA de CADASTRO da imagem </td>
											<TD class=normal11>de&nbsp;&nbsp;
												<INPUT type="text" name="txtDataCadastroInicial" size=15 maxlength=10 class=datavalor onKeyPress="document.form.rdoOpcao[0].checked='checked';SetFocus(document.form.txtDataCadastroFinal);return IsNumber()" onKeyUp="FormataData('txtDataCadastroInicial',event)">&nbsp;&nbsp;&nbsp;a&nbsp;&nbsp;
												<INPUT type="text" name="txtDataCadastroFinal" size=15 maxlength=10 class=datavalor onKeyPress="document.form.rdoOpcao[0].checked='checked';if (event.keyCode == 13) return gerar_imagens();return IsNumber()" onKeyUp="FormataData('txtDataCadastroFinal',event)"></TD>
										</tr>
										<tr>
											<td height=10></td>
										</tr>
										<tr height=30 class=normal11b>
											<td><INPUT type='radio' name=rdoOpcao value=2></td>
											<td colspan=2>2 - Todos as imagens cadastradas </td>
										</tr>
									</table>
								</td>
							</tr>
							</form>
						</table>
					</td>
					<td width=10 background="imagens/formDirMid.gif"></td>
				</tr>
				<tr>
					<td><img src="imagens/formEsqInf.gif" border=0 width=10 height=10></td>
					<td background="imagens/formMidInf.gif"></td>
					<td><img src="imagens/formDirInf.gif" border=0 width=10 height=10></td>
				</tr>
			</table>
		</td>
	</tr>
</table>

<script language="JavaScript">
function gerar_imagens(){
	if (pValidaGeracao()){
		if (confirm("Confirma a GERA��O do relat�rio?")){
			document.form.submit()
		} else {
			return false
		}
	}	
}

function pValidaGeracao(){
	
	var sErr = ""
	
	if (document.form.rdoOpcao[0].checked){
	
		if (Trim(form.txtNomeImagem.value) == "" && document.form.cboTipo.value == 0 && Trim(form.txtDataCadastroInicial.value) == "" && Trim(form.txtDataCadastroFinal.value) == "")
			sErr = "Preencha alguma das op��es dispon�veis para gera��o do relat�rio!"

		if (Trim(form.txtDataCadastroInicial.value) != "" || Trim(form.txtDataCadastroFinal.value) != ""){
	
			if (!IsDate(form.txtDataCadastroInicial.value))
				sErr = sErr + "Data de cadastro inicial inv�lida!\n"
			
			if (!IsDate(form.txtDataCadastroFinal.value))
				sErr = sErr + "Data de cadastro final inv�lida!\n"

			var dataCadIni = form.txtDataCadastroInicial.value
			var dataCadFim = form.txtDataCadastroFinal.value
	
			//A DATA FINAL N�O PODE SER INFERIOR � DATA INICIAL
			if ((dataCadFim.substring(6) + dataCadFim.substring(3,5) + dataCadFim.substring(0,2)) < (dataCadIni.substring(6) + dataCadIni.substring(3,5) + dataCadIni.substring(0,2)))
				sErr = sErr + "A data de cadastro final n�o pode ser inferior � data de cadastro inicial!\n"
				
		}

	}
	
	//VERIFICA SE FOI ENCONTRADO ALGUM ERRO NA VALIDA��O DO FORMUL�RIO
	if (sErr != ""){
		sErr = "Verifique os erros encontrados abaixo:\n\n" + sErr
		alert(sErr)	
		return false
	}else
		return true
}

</script>

</body>
</html>