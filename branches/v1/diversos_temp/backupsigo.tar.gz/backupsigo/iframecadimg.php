<?php
include_once ("funcoes.php");
include_once ("classes/Imagens.php");
include_once ("classes/ImagensPendencias.php");
include_once ("classes/ImagensDiarios.php");
/************************************************************************
 Empresa: Interagi Tecnologia

 Descri��o: cadastro de imagem 
	
 Releases (Data, respons�vel e descri��o [�ltimo release primeiro]):
	 23/04/2006 (Jean Moreira) 
		 Inclu�do este cabe�alho descrevendo a funcionalidade da p�gina
************************************************************************/

	if ($_GET['cat'] != "") { 
		$cat = $_GET['cat'];
		
		if ($_GET['id'] == "") {
			$numg = 0;					
		} else {					
			$numg = $_GET['id'];
		}
		
		switch($_GET['cat']) {
		
			case 1://cadsites 
				//include_once("classes/ImagensMunicipios.php");
				$oObj = new Imagens();
				$oObj->setNumgSite($numg);			
			break;	
			case 2:
				$vNumg = split("-",$numg);//indice 0 = numg_pendencia  indice 1 = numg_site
				$oObj = new ImagensPendencias();
				$oObj->setNumgPendencia($vNumg[0]);
				$oObj->setNumgSite($vNumg[1]);
			break;
			case 3:
				$vNumg = split("-",$numg);//indice 0 = numg_diario  indice 1 = numg_subatividade indice 2 = numg_site
				$oObj = new ImagensDiarios();
				$oObj->setNumgDiario($vNumg[0]);
				$oObj->setNumgSubatividade($vNumg[1]);
				$oObj->setNumgSite($vNumg[2]);
				
			break;		
		}
	} else {
		
		$oObj = new Imagens();
		$numg = $_GET['numg_id'];		
	
	}
	
	if (($_GET["cat"] != "") && ($_GET["id"] != "") && ($_GET["numg_foto"] != "")){
		$oObj->setNumgFoto($_GET["numg_id"]);
		$oObj->setNumgSite($_GET["id"]);		
		//$oObj->desvincular();		
	}
	
	$oResImgVinc = $oObj->consultarImagensVinculadas($_GET['id']);
	if(Erros::isError())MostraErros();
	
	
	
?>
<html>
<head>
<title>Sigo - Cadastro de Imagens</title>
<link href="estilos.css" rel="stylesheet" type="text/css">
<script language="JavaScript" src="funcoes.js" type="text/javascript"></script>
<style type="text/css">

#dhtmltooltip{
position: absolute;
width: 200px;
border: 1px solid black;
padding: 5px;
background-color: lightyellow;
visibility: hidden;
z-index: 100;
/*Remove below line to remove shadow. Below line should always appear last within this CSS*/
filter: progid:DXImageTransform.Microsoft.Shadow(color=gray,direction=135);
}

</style>
</head>
<body rightmargin="0" marginwidth="0" marginheight="0" leftmargin="0" bottommargin="0" topmargin="0" bgcolor="#FFFFFF">
<div id="dhtmltooltip"></div>

<script language=JavaScript>

/***********************************************
* Cool DHTML tooltip script- � Dynamic Drive DHTML code library (www.dynamicdrive.com)
* This notice MUST stay intact for legal use
* Visit Dynamic Drive at http://www.dynamicdrive.com/ for full source code
***********************************************/

var offsetxpoint=-60 //Customize x offset of tooltip
var offsetypoint=20 //Customize y offset of tooltip
var ie=document.all
var ns6=document.getElementById && !document.all
var enabletip=false
if (ie||ns6)
var tipobj=document.all? document.all["dhtmltooltip"] : document.getElementById? document.getElementById("dhtmltooltip") : ""

function ietruebody(){
	return (document.compatMode && document.compatMode!="BackCompat")? document.documentElement : document.body
}

function ddrivetip(thetext, thecolor, thewidth){
	if (ns6||ie){
		if (typeof thewidth!="undefined") tipobj.style.width=thewidth+"px"
		if (typeof thecolor!="undefined" && thecolor!="") tipobj.style.backgroundColor=thecolor
		tipobj.innerHTML=thetext
		enabletip=true
		return false
	}
}

function positiontip(e){
	if (enabletip){

		var curX=(ns6)?e.pageX : event.x+ietruebody().scrollLeft;
		var curY=(ns6)?e.pageY : event.y+ietruebody().scrollTop;
		//Find out how close the mouse is to the corner of the window
		var rightedge=ie&&!window.opera? ietruebody().clientWidth-event.clientX-offsetxpoint : window.innerWidth-e.clientX-offsetxpoint-20
		var bottomedge=ie&&!window.opera? ietruebody().clientHeight-event.clientY-offsetypoint : window.innerHeight-e.clientY-offsetypoint-20

		var leftedge=(offsetxpoint<0)? offsetxpoint*(-1) : -1000

		//if the horizontal distance isn't enough to accomodate the width of the context menu
		if (rightedge<tipobj.offsetWidth)
			//move the horizontal position of the menu to the left by it's width
			tipobj.style.left=ie? ietruebody().scrollLeft+event.clientX-tipobj.offsetWidth+"px" : window.pageXOffset+e.clientX-tipobj.offsetWidth+"px"
		else if (curX<leftedge)
			tipobj.style.left="5px"
		else
			//position the horizontal position of the menu where the mouse is positioned
			tipobj.style.left=curX+offsetxpoint+"px"

		//same concept with the vertical position
		if (bottomedge<tipobj.offsetHeight)
			tipobj.style.top=ie? ietruebody().scrollTop+event.clientY-tipobj.offsetHeight-offsetypoint+"px" : window.pageYOffset+e.clientY-tipobj.offsetHeight-offsetypoint+"px"
		else
			tipobj.style.top=curY+offsetypoint+"px"
			
		tipobj.style.visibility="visible"
	}
}

function hideddrivetip(){
	if (ns6||ie){
		enabletip=false
		tipobj.style.visibility="hidden"
		tipobj.style.left="-1000px"
		tipobj.style.backgroundColor=''
		tipobj.style.width=''
	}
}

document.onmousemove=positiontip

</script>	
<div style="overflow:auto;height:270px;">
<? if($_GET["nome_subatividade"] != ""){?>
<span class="normal11b">&nbsp;&nbsp;&nbsp;Imagens da Subatividade:&nbsp;<?=$_GET["nome_subatividade"]?></span>
<? }?>
	<? if ($oResImgVinc->getCount() > 0) { 	
		for ($i = 0; $i < $oResImgVinc->getCount(); $i++) { ?>		
			<div style="float:left;padding:10px;width:100px;height:100px;">
				<div style="height:80px;text-align:center;"><a href="javascript:visualizar(<?=$oResImgVinc->getValores($i,"numg_foto")?>)"><img border="1" style="border-color:#666666" alt=""  onMouseover="ddrivetip('<span class=normal11><strong><?=$oResImgVinc->getValores($i,"desc_foto")?></strong><br/>Clique para Ampliar</span>','white',250)" onMouseout="hideddrivetip()" src="thumbnail.php?numg_site=<?=$oResImgVinc->getValores($i,"numg_site")?>&arquivo=<?=$oResImgVinc->getValores($i,"nome_arquivo")?>&width=80&height=80"  border="0" /></a></div>
				<div style="text-align:center"><a href="javascript:vincular(<?=$oResImgVinc->getValores($i,"numg_foto")?>)" class="link-tab">editar</a></div>
			</div>
		<?   }	
	  } else {?>
	  	<div style="padding:100px;" class="destaque" align="center">�rea para visualiza��o das imagens vinculadas.</div>
	  <? }?>
	</div>
	<div align="center">
		<? if ($numg != 0) {?>
			<input name="btnVincular" type="button" value="Cadastrar Imagem" class="botao" onClick="vincular('')">&nbsp;<input name="btnAtualizar" type="button" value="Atualizar" class="botao" onClick="atualizar()">
		<? }?>
	</div>
<script language="JavaScript" type="text/javascript">
	function atualizar(){
		window.location.href = "iframecadimg.php?cat=<?=$cat?>&id=<?=$numg?>&nome_subatividade=<?=$_GET["nome_subatividade"]?>";
	}
	
	function editar(numg_foto){					
		url = "cadimg.php?cat=<?=$cat?>&id=<?=$numg?>&numg_foto=" + numg_foto
		window.open(url,"popupcadimg","directories=no,width=600,height=435,hotkeys=no,location=no,menubar=no,resizable=no,scrollbars=no,status=no,toolbar=no,copyhistory=no,screenX=0,screenY=0,top=" + (window.screen.availHeight/2-205) + ",left=" + (window.screen.availWidth/2-300) + '"');
	}
	
	function visualizar(tipo){
		window.open("visualizador.php?numg="+ tipo,"visualizador","status=no,menubar=no,toolbar=no")
		
	}
	
	
	function vincular(numg_foto){
		url = "gerenciadorimg.php?cat=<?=$cat?>&id=<?=$numg?>&numg_foto=" + numg_foto
		window.open(url,"popupcadimg","directories=no,width=600,height=435,hotkeys=no,location=no,menubar=no,resizable=no,scrollbars=no,status=no,toolbar=no,copyhistory=no,screenX=0,screenY=0,top=" + (window.screen.availHeight/2-205) + ",left=" + (window.screen.availWidth/2-300) + '"');
	} 
</script>
</body>
</html>
