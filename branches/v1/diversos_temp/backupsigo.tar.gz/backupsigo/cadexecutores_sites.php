<?php
include_once "funcoes.php";
include_once("classes/Sites.php");
include_once("classes/Fases.php");
include_once("classes/Municipios.php");
include_once("classes/Operadores.php");
include_once("classes/Atividades.php");
include_once("classes/Subatividades.php");
include_once("classes/Diarios.php");
include_once("classes/Empresas.php");
include_once("classes/Operadores.php");
include_once("classes/Executores.php");

/************************************************************************
'Empresa: Interagi Tecnologia

'Descri��o:

'Releases (Data, respons�vel e descri��o [�ltimo release primeiro]):
'25/03/2008 (Danilo Fernandes)
'Criada

'************************************************************************/

$CODG_FORMULARIO = "cadexecutores_sites";
$NOME_FORMULARIO = validarAcesso($CODG_FORMULARIO,$_SESSION["NUMG_OPERADOR"]);


$oSite = new Sites();
$oSubatividade = new Subatividades();
$oFase = new Fases();
$oAtividade = new Atividades();
$oDiario = new Diarios();
$oEmpresa = new Empresas();
$oOperador = new Operadores();
$oExecutores = new Executores();

$vFases = new Resultset();
$vSites = new Resultset();
$vSubatividades = new Resultset();
$vEmpresas = new Resultset();
$valorDiario = new Resultset();


$vSites = $oSite->consultarTodas();
//$vSubatividades = $oSubatividade->consultarTodas();
$vEmpresas = $oEmpresa->consultarEmpresas();

if (Erros::isError()) MostraErros();

if ($_GET["numg_site"] != "" || $_GET['numg_fase'] != "")   {

	$oSite->setarDados($_GET["numg_site"]);
	if (Erros::isError()) MostraErros();

	$vFases = $oFase->consultarDesblPorSite($_GET["numg_site"]);
	if (Erros::isError()) MostraErros();

	if($_GET['numg_fase'] != ""){
		$oFase->setarDados($_GET['numg_fase']);
		if (Erros::isError()) MostraErros();
	}

	if($_GET['numg_site'] != "" && $_GET['numg_fase'] != ""){
		$vSubatividades = $oExecutores->consultarExecutores($_GET['numg_site'],$_GET['numg_fase']);

	}
	if (Erros::isError()) MostraErros();

}
$bPesquisa = true;

if (Erros::isError()){
	MostraErros();
}




?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<title>::: SIGO :::</title>
<link href="estilos.css" rel="stylesheet" type="text/css">
<script type="text/javascript" src="javascripts/prototype.js"> </script>
<script language="JavaScript" src="funcoes.js"></script>
<script type="text/javascript" src="javascripts/populacombo.js"></script>
<script language="JavaScript">

/*
function validarMarcados(){
	numrVazios = 0;
	for(i=0; i<document.getElementById("form").elements.length; i++){
		if(document.getElementById("form").elements[i].type=="select"){
			if(document.getElementById("form").elements[i].value == ""){
				numrVazios ++;
				
			}
		}
	}
	return numrVazios;
}
*/
/*
function cadastrar_executores(){
	
	//if (document.form.numgSite.value == ""){
	if (pValidaGravacao()){
			document.form.txtFuncao.value = "cadastrar_executores"
			document.form.submit()
		}
	//}else{
	//	alert("Fun��o de CADASTRO n�o dispon�vel para este formul�rio!")
	//}
}
*/
function editar_executores(){
	if (document.form.numgSite.value != ""){
		if (pValidaGravacao()){
			document.form.txtFuncao.value = "editar_executores"
			document.form.submit()

		}
	}else{
		alert("Fun��o de EDI��O n�o dispon�vel para este formul�rio!")
	}
}


function pValidaGravacao(){

	var sErr = ""

	if(document.form.cboSite.value == ""){
		sErr = sErr + " Site\n"
	}

	if(document.form.cboFase.value == ""){
		sErr = sErr + "Fase\n"
	}


	//VERIFICA SE FOI ENCONTRADO ALGUM ERRO NA VALIDA��O DO FORMUL�RIO
	if (sErr != ""){
		sErr = "Verifique os erros encontrados abaixo:\n\n" + sErr
		alert(sErr)
		return false
	}else
	return true
}


function iniForm(){
	MontaFuncoes('<?=$CODG_FORMULARIO?>','<?=$NOME_FORMULARIO?>','<?=$oSite->getNumgSite()?>')
	AlteraTab(1,1)
}

</script>
</head>

<body onLoad="iniForm();validaMarcados()" rightmargin="0" marginwidth="0" marginheight="0" leftmargin="0" bottommargin="0" topmargin="0" bgcolor="#FFFFFF" >
<form method="post" action="pcadexecutores_sites.php" name="form" id="form" ENCTYPE="multipart/form-data"> 
<input name="numgSite" type="hidden" value="<?=$oSite->getNumgSite()?>"> 
<input name="txtFuncao" type="hidden" value="">
 
<input type=hidden name=numgDiario value="<?=$oDiario->getNumgDiario()?>">
<table border=0 width=100% align=center cellspacing=0 cellpadding=0>
	<tr>
		<td><img src="imagens/space.gif" border=0 height=10></td>
	</tr>
	<tr>
		<td align=center>
			<table border=0 width=600 cellspacing=0 cellpadding=0>
				<tr>
					<td><img src="imagens/formEsqSup.gif" border=0 width=10 height=10></td>
					<td background="imagens/formMidSup.gif"></td>
					<td><img src="imagens/formDirSup.gif" border=0 width=10 height=10></td>
				</tr>
				<tr valign=top>
					<td width=10 background="imagens/formEsqMid.gif"></td>
					<td>
						<table border=0 width=100% cellspacing=0 cellpadding=0 align=center background="imagens/formMid.gif">
						
							
							
							<!-- IN�CIO CAMPOS DO FORMUL�RIO  -->
							<?php if ($_GET["info"] != ""){?>
							<tr>
								<td colspan=2 align=center height=20 valign=middle class=normal11>
								<img src="imagens/icones/info.gif" border=0 align=absbottom>&nbsp;&nbsp;
								<?php 		
								switch ($_GET["info"]){
									case 1:
										echo "Cadastro realizado com sucesso";
										break;
									case 2:
										echo "Edi��o realizada com sucesso";
										break;
									case 3:
										echo "Exclus�o realizada com sucesso";
										break;
									case 4:
										echo "Libera��o realizada com sucesso";
										break;
									case 5:
										echo "Nenhum di�rio encontrado";
										break;

									} ?>
									

								</td>
							</tr>
							<?php }?>
									<tr>
								<td colspan=3>
									<table border=0 width=580 cellspacing=0 cellpadding=2>
										<tr>
											<td width=20% align=right class=normal11b>Site:</td>
											<TD width=80% align="left">
												<select name="cboSite" class="borda" id="cboSite" style="width:435px;" tabindex="12" onkeydown="setarFocus(this,'form',event)" onChange="window.location.href='cadexecutores_sites.php?numg_site=' + document.form.cboSite.value" >
													<? montaCombo($vSites,"numg_site","nome_site",$oSite->getNumgSite(),true); ?>
												</select>																
												</td>
										</tr>
										<tr>
											<td width=20% align=right class=normal11b>Fase:</td>
											<TD width=80% align="left">
											<select name="cboFase" class="borda" id="cboFase" style="width:435px;" tabindex="12" onkeydown="setarFocus(this,'form',event)" onChange="window.location.href='cadexecutores_sites.php?numg_site=' + <?=$_GET["numg_site"]?> + '&numg_fase=' + document.form.cboFase.value">
													<? montaCombo($vFases,"numg_fase","nome_fase",$oFase->getNumgFase(),true); ?>
												</select>																
											</td>
										</tr>
										<tr>
										<td height="10" colspan="4"><img src="imagens/spacer.gif" /></td>
									</tr>
								  </table>
								</td>
							</tr>
							<tr>
								<td height=10></td>
							</tr>
									<? if((($_GET['numg_site'] && $_GET['numg_fase']) || $_GET['numg_diario'] != "")){?>
									
									<tr> 
										<td colspan="4">
											<script language="JavaScript">	
											montaTabs(Array("executores - sites","","",""),1)
											</script>	
										</td> 
									</tr>
									<tr> 
										<td align="left" colspan="4">
											<div id="tab1">
													<table border="0" width="580" cellspacing="0" cellpadding="2" class="bordaEsqDirInf" > 
															<tr>
																<td ><img src="imagens/space.gif" border="0" height="5"></td>
															</tr>
														<tr>
															<td >
															
															<? $tituloAtividade = "";?>
															<? for ($i=0; $i<$vSubatividades->getCount(); $i++){?>
															<!-- IN�CIO DE UM CAMPO DE SUBATIVIDADE -->	
																	<table border="0" width="100%" cellspacing="0" cellpadding="2"> 	
																		<? if($tituloAtividade != $vSubatividades->getValores($i,"nome_atividade")){?>
																		<tr>
																			<td colspan="2"><img src="imagens/space.gif" height="5" /></td>
																		</tr>
																		<tr> 
																			<td width="30%"align="center" bgcolor="#F3F3F3" class="normal11"><strong><?=$vSubatividades->getValores($i,"nome_atividade")?></strong></td> 
																			<td width="25%"  align="center" bgcolor="#F3F3F3" class="normal11"><strong>&nbsp;</strong></td> 
																			
																		</tr>	
																		<? 
																		$tituloAtividade = $vSubatividades->getValores($i,"nome_atividade");
																			} ?>
																		<? if(($vSubatividades->getValores($i,"data_bloqueio")=="")or($vSubatividades->getValores($i,"data_bloqueio")!="" and $vSubatividades->getValores($i,"numg_empresa")!="")){?>
																		<tr> 
																			<td width="30%" align="right" class="<? if ($vSubatividades->getValores($i,"count_ok") == "0" && $vSubatividades->getValores($i,"data_nok") != "" ){echo "destaque";}else{echo "normal11";}?>"><?=$vSubatividades->getValores($i,"nome_subatividade");?></td> 
																			<td width="25%" align="left" class="normal11">
																				<select name="cboEmpresa<?=$vSubatividades->getValores($i,"numg_subatividade")?>" id="cboEmpresa<?=$vSubatividades->getValores($i,"numg_subatividade")?>" class=borda 
																					<?	if($vSubatividades->getValores($i,"numg_empresa")!="" and $vSubatividades->getValores($i,"data_bloqueio")!=""){
																							echo "disabled";
																						}
																					?>>
																					<? montaCombo($vEmpresas,"numg_empresa","nome_empresa",$vSubatividades->getValores($i,"numg_empresa"),true); ?><?=$vSubatividades->getValores($i,"numg_empresa") ?>
																				</select> 
																			</td> 
																			
																		</tr>
																		<? 
																			$vAuxNumgsSubativ[$i] = $vSubatividades->getValores($i,"numg_subatividade");
																		  }?>
																	</table>
																<?
																/*if($i == ($vSubatividades->getCount()-1)){
																	$sNumgsSubatividades .= $vSubatividades->getValores($i,"numg_subatividade");
																}else{
																	$sNumgsSubatividades .= $vSubatividades->getValores($i,"numg_subatividade") . "|";
																}*/
																

															}
															//reordena o vetor
															$vAuxNumgsSubativ = array_values($vAuxNumgsSubativ);
															
															for($i=0;$i<count($vAuxNumgsSubativ);$i++){
																if($i == (count($vAuxNumgsSubativ)-1)){
																	$sNumgsSubatividades .= $vAuxNumgsSubativ[$i];
																}else{
																	$sNumgsSubatividades .= $vAuxNumgsSubativ[$i] . "|";
																}
															}
															?>
															
															<input type="hidden" name="numgsSubatividades" id="numgsSubatividades" value="<?=$sNumgsSubatividades?>" />							
												</table>
										</div>		
							        </td>
								</tr>
				</table>
				<?}else{?>
			</table>
			<?}?>
					</td>
					<td width=10 background="imagens/formDirMid.gif"></td>
				</tr>
				<tr>
					<td><img src="imagens/formEsqInf.gif" border=0 width=10 height=10></td>
					<td background="imagens/formMidInf.gif"></td>
					<td><img src="imagens/formDirInf.gif" border=0 width=10 height=10></td>
				</tr>
			</table>
</form>
<? $oSite->free; ?>

</body>

<head>
<META HTTP-EQUIV="Pragma" CONTENT="no-cache">
<META HTTP-EQUIV="Expires" CONTENT="-1">
</head>
</html>