<?php
session_start();
header("Cache-control: private");
include_once ("classes/Formularios.php");
include_once ("classes/Resultset.php");
include ("funcoes.php");
/*************************************************************************
 Empresa: Interagi Tecnologia

 Descri��o: p�gina com os menus de atalho para os formul�rios de cadastro
 			e relat�rios do sistema. 
	
 Releases (Data, respons�vel e descri��o [�ltimo release primeiro]):
	 18/03/2008 (Thales A. Salvador) 
		 Inclu�do este cabe�alho descrevendo a funcionalidade da p�gina
						
'***********************************************************************/

/*
	if (empty($_SESSION["nuumg_operador"]) or $_SESSION["numg_operador"] == "") {
		header("Location:expirou.htm");
		exit;
	}
*/
	$oFormularios = new Formularios();
	$vFormularios = new Resultset();

	//ADMINISTRADOR GERAL
	if ($_SESSION["NUMG_OPERADOR"] == 1) {
		$vFormularios = $oFormularios->consultarFormsAdministrador();
	} else {
		$vFormularios = $oFormularios->consultarFormsOperador($_SESSION["NUMG_OPERADOR"]);
	}
	
	$oFormularios->free;
	
//echo $vFormularios->getCount();
//exit;
?>
<html>
<head>

<title>Sigo - Sistema de Gerenciamento de Obras</title>

<link href="estilos.css" rel="stylesheet" type="text/css">

<script type="text/javascript" language=JavaScript>
<!-- 

function AlteraPasta(img,status) {
	oImage = eval("document." + img)
	oImage.src = "imagens/pasta_" + status + ".gif"
}

function AlteraMenu(id) {

	<?php if ($vFormularios->getCount() > 0) {?>
		<?php for ($i=0;$i<$vFormularios->getCount();$i++) {?>
			<?php if ($i==0) {?>
				document.getElementById('menu<?php echo $vFormularios->getValores($i,"numr_agrupamento")?>').style.display = "none"
				AlteraPasta('img<?php echo $vFormularios->getValores(0,"numr_agrupamento")?>','fechada')
			<?php } else {?>
				<?php if ($vFormularios->getValores($i,"numr_agrupamento") != $vFormularios->getValores($i-1,"numr_agrupamento")) {?>
					document.getElementById('menu<?php echo $vFormularios->getValores($i,"numr_agrupamento") ?>').style.display = "none"
					AlteraPasta('img<?php echo $vFormularios->getValores($i,"numr_agrupamento") ?>','fechada')
				<?php }?>
			<?php }?>
		<?php }?>
	<?php }?>

	document.getElementById('menu' + id).style.display = "block"
	AlteraPasta('img' + id,'aberta')
	
    return false
    
}

//SOLICITA UMA CONFIRMA��O DO USU�RIO P/ SAIR DO SISTEMA
function ConfirmaSaida(){

	if (confirm("Tem certeza que deseja efetuar logoff?")){
		top.location.href = 'login.php?opt=1'
	}
}

// -->
</script>

<style type="text/css">

	<?php if ($vFormularios->getCount() > 0) {?>
		<?php for ($i=0;$i<$vFormularios->getCount();$i++) {?>
			<?php if ($i==0) {?>
				#menu<?php echo $vFormularios->getValores(0,"numr_agrupamento");?> {display:none; margin-left:5px}
			<?php } else {?>
				
				<?php if ($vFormularios->getValores($i,"numr_agrupamento") != $vFormularios->getValores($i-1,"numr_agrupamento")) {?>
					#menu<?php echo $vFormularios->getValores($i,"numr_agrupamento");?> {display:none; margin-left:5px} 
				<?php }?>
			
			<?php }?>
		<?php }?>
	<?php } ?>

	a:visited {color: #000000; text-decoration: none}
	a:hover {color: #4c4c4c; text-decoration: none}
	a:active {color: #4c4c4c; text-decoration: none}
	a:link {color: #000000; text-decoration: none}
	
</style>

<base target="conteudo">

</head>

<body onLoad="<?php if ($vFormularios->getCount() > 0) {?>AlteraMenu('<?php echo $vFormularios->getValores(0,"numr_agrupamento")?>')<?php }?>" topmargin="0" leftmargin="0" rightmargin="0" bottommargin="0" bgcolor="#ffffff">
<table border=0 cellspacing="0" width="100%" height=90% cellpadding="0" valign=top>
	<tr height=30 class=titulo11>
		<td bgcolor="#E8E8E8" class=bordaFrameInf>&nbsp;Menu de Navega��o</td>
		<td bgcolor="#E8E8E8" class=bordaFrameInf><a href="menu.php" target=menu class=link-net4u>&nbsp;<img src="imagens/icones/atualizar.gif" border=0 alt="Atualizar" align=absbottom></a>&nbsp;</td>
	</tr>
	<tr>
		<td colspan=2>
			<table border=0 cellspacing="0" width=100% height=100% cellpadding="0" valign=top align=center>
				<tr>
					<td><img src="imagens/space.gif" border=0 height=5></td>
				</tr>
				<tr valign=top>
					<td align=center valign=top>
						<table border=0 cellspacing="0" width=95% cellpadding="0" valign=top align=center>

							<tr>
								<td class=normal11><img src="imagens/pasta_fechada.gif" border=0>&nbsp;<a href="conteudo.php">SIGO</a></td>
							</tr>

					<?php if ($vFormularios->getCount() > 0) {?>
						<?php for ($i=0;$i<$vFormularios->getCount();$i++) {?>
							<?php if ($i==0) {?>
							<tr> 
								<td class=normal11>
									<img src="imagens/pasta_fechada.gif" border=0 name="img<?php echo $vFormularios->getValores($i,"numr_agrupamento");?>">&nbsp;<a href="javascript://" onClick="return AlteraMenu('<?php echo $vFormularios->getValores($i,"numr_agrupamento");?>')"><?php echo RetornaAgrupamento($vFormularios->getValores($i,"numr_agrupamento"));?></a>
									<span id="menu<?php echo $vFormularios->getValores($i,"numr_agrupamento");?>">
										<img src="imagens/L.gif" border=0>&nbsp;<a href="<?php echo $vFormularios->getValores($i,"codg_formulario");?>.php"><?php echo $vFormularios->getValores($i,"nome_formulario");?></a><br>
							<?php }else if ($vFormularios->getValores($i,"numr_agrupamento") != $vFormularios->getValores($i-1,"numr_agrupamento")) {?>
									</span>
								</td>
							</tr>
							<tr> 
								<td class=normal11>
									<img src="imagens/pasta_fechada.gif" border=0 name="img<?php echo $vFormularios->getValores($i,"numr_agrupamento");?>">&nbsp;<a href="javascript://" onClick="return AlteraMenu('<?php echo $vFormularios->getValores($i,"numr_agrupamento");?>')"><?php echo RetornaAgrupamento($vFormularios->getValores($i,"numr_agrupamento"));?></a>
									<span id="menu<?php echo $vFormularios->getValores($i,"numr_agrupamento");?>">
										<img src="imagens/L.gif" border=0>&nbsp;<a href="<?php echo $vFormularios->getValores($i,"codg_formulario");?>.php"><?php echo $vFormularios->getValores($i,"nome_formulario");?></a><br>
							<?php } else if ($i >= $vFormularios->getCount()) {?>
									</span>
								</td>
							</tr>
							<?php } else {?>
										<img src="imagens/L.gif" border=0>&nbsp;<a href="<?php echo $vFormularios->getValores($i,"codg_formulario");?>.php"><?php echo $vFormularios->getValores($i,"nome_formulario");?></a><br>
							<?php }?>
						<?php }?>
					<?php } ?>	
								
							<tr>
								<td class=normal11><img src="imagens/pasta_fechada.gif" border=0>&nbsp;<a href="javascript://" onClick="ConfirmaSaida()">Efetuar logoff</a></td>
							</tr>
						</table>
					</td>
				</tr>
				<tr>
					<td height=100%><img src="imagens/space.gif" border=0></td>
				</tr>
				<tr align="center">	
					<td><img src="imagens/logoSigo.jpg" alt="" /></td>
				</tr>	
			</table>
		</td>
	</tr>
</table>
<table border="0" cellspacing="0" width="100%" cellpadding="0" valign=top>
	<tr align=center>
		<td height=20 class="normal11">&copy; 2008<br><a href="http://www.interagi.com.br" class="link-tab" target="_blank">Interagi Tecnologia</a></td>
	</tr>
</table>

</body>
</html>
