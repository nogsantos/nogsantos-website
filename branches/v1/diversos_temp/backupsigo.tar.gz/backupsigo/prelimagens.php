<?php
include_once ("funcoes.php");
include_once ("classes/Imagens.php");

/************************************************************************
 Empresa: Interagi Tecnologia

 Descri��o:
	
 Releases (Data, respons�vel e descri��o [�ltimo release primeiro]):
	 05/12/2005 (Silas Junior) 
		 Inclu�do este cabe�alho descrevendo a funcionalidade da p�gina
************************************************************************/

	$oImg = new Imagens();
	
	$CODG_FORMULARIO = "prelimagens";
	$NOME_FORMULARIO = validarAcesso($CODG_FORMULARIO,$_SESSION["NUMG_OPERADOR"]);

	switch ($_POST["rdoOpcao"]){
		case 1:
		
			$opcoes = array($_SESSION["NUMG_MUNICIPIO"],$_POST["txtNomeImagem"],$_POST["cboTipo"],$_POST["txtDataCadastroInicial"],$_POST["txtDataCadastroFinal"]);
			
			$oResImg = $oImg->consultarImagens($opcoes);
			
			$sTitulo = 'Relat�rio de Imagens: ';
			
			if ($opcoes[1] != ""){
				$sTitulo .= 'Pelo<span class="destaque"> - pelo nome </span>';
			}
			
			if ($opcoes[2] != "0"){
				$sTitulo .= '<span class="destaque"> - pelo tipo </span>';
			}
			
			if ($opcoes[3] != "" && $opcoes[4] != ""){
				$sTitulo .= '<span class="destaque"> - pela dada </span>';
			}
			
			if(Erros::isError())MostraErros();
			break;
		
		case 2:
			$sTitulo = 'Relat�rio de Imagens: <span class="destaque">todas cadastradas</span>';
			$oResImg = $oImg->consultarPorMunicipio($_SESSION["NUMG_MUNICIPIO"]);
			
			if(Erros::isError())MostraErros();
			break;
		
		default:
			header("Location:relimagens.php");
	}

	if ($oResImg->getCount() <= 0) {
		header("Location:relimagens.php?info=1");
		exit;
	}
?>
<html>
<head>
<title>Sigo - Relat�rio de Imagens</title>
<link href="estilos.css" rel="stylesheet" type="text/css">
<style type="text/css">
div#hold	{ 
	position:relative; overflow:hidden;
	width:300px; height:300px; z-index:100
	}
div#wn	{ 
	position:absolute; 
	left:0px; top:0px; 
	width:300px; height:300px; 
	clip:rect(0px, 300px, 300px, 0px); 
	overflow:hidden;	
	z-index:1; 
	}
div#lyr1	{ 
	position:absolute; visibility:hidden; 
	left:0px; top:0px; 
	z-index:1; 
	}
.divThumb {
	height: 120px;
	overflow: auto;
	width: 570px;
	border: 0px solid #999999;
}

.bg_branco{
	color:#FFFFFF;
}
.bg_preto{
	color:#000000;
}

/* table containing images. adjust according to your images' sizes and numbers */
table#t1 { width:<?=$oResImg->getCount()*300?>px }
table#t1 td { width:300px;height:300px;vertical-align:middle; text-align:center }
</style>
<script src="js/dw_scrollObj.js" type="text/javascript"></script>
<script src="js/dw_glidescroll.js" type="text/javascript"></script>
<script type="text/javascript">

function initScrollLayer() { 
  var wndo = new dw_scrollObj('wn', 'lyr1', 't1');
  dw_scrollObj.GeckoTableBugFix('wn'); 
}
</script>
<script language="JavaScript" src="funcoes.js"></script>
<script language="JavaScript">
<!--

var controle = 0

function iniForm(){
	MontaFuncoes('<?=$CODG_FORMULARIO?>','<?=$NOME_FORMULARIO?>','1')
	//document.form.txtNomeGrupo.focus()
	colocaBorda(controle)
}

function MM_preloadImages() { //v3.0
  var d=document; if(d.images){ if(!d.MM_p) d.MM_p=new Array();
    var i,j=d.MM_p.length,a=MM_preloadImages.arguments; for(i=0; i<a.length; i++)
    if (a[i].indexOf("#")!=0){ d.MM_p[j]=new Image; d.MM_p[j++].src=a[i];}}
}

function MM_swapImgRestore() { //v3.0
  var i,x,a=document.MM_sr; for(i=0;a&&i<a.length&&(x=a[i])&&x.oSrc;i++) x.src=x.oSrc;
}

function MM_findObj(n, d) { //v4.01
  var p,i,x;  if(!d) d=document; if((p=n.indexOf("?"))>0&&parent.frames.length) {
    d=parent.frames[n.substring(p+1)].document; n=n.substring(0,p);}
  if(!(x=d[n])&&d.all) x=d.all[n]; for (i=0;!x&&i<d.forms.length;i++) x=d.forms[i][n];
  for(i=0;!x&&d.layers&&i<d.layers.length;i++) x=MM_findObj(n,d.layers[i].document);
  if(!x && d.getElementById) x=d.getElementById(n); return x;
}

function MM_swapImage() { //v3.0
  var i,j=0,x,a=MM_swapImage.arguments; document.MM_sr=new Array; for(i=0;i<(a.length-2);i+=3)
   if ((x=MM_findObj(a[i]))!=null){document.MM_sr[j++]=x; if(!x.oSrc) x.oSrc=x.src; x.src=a[i+2];}
}
function abrir (numg) {
	window.location.href = 'cadimg.php?form=<?=$_GET['form'] ?>&field=<?=$_GET['field'] ?>&id=<?=$_GET['id'] ?>&numg_imagem=' + numg
}
//-->
</script>
</head>
<body onLoad="iniForm();initScrollLayer()" rightmargin="0" marginwidth="0" marginheight="0" leftmargin="0" bottommargin="0" topmargin="0" bgcolor="#FFFFFF">
<table border=0 width=100% align=center cellspacing=0 cellpadding=0>
	<tr>
		<td class="normal11b" align="center" valign="middle" height="20"><?=$sTitulo?></td>
	</tr>	
	<tr>
		<td align=center><table border=0 width=600 cellspacing=0 cellpadding=0>
				<tr>
					<td><img src="imagens/formEsqSup.gif" border=0 width=10 height=10></td>
					<td background="imagens/formMidSup.gif"></td>
					<td><img src="imagens/formDirSup.gif" border=0 width=10 height=10></td>
				</tr>
				<tr valign=top>
					<td width=10 background="imagens/formEsqMid.gif"></td>
					<td>
						<table border=0 width=100% cellspacing=0 cellpadding=2 align=center background="imagens/formMid.gif">						
							<tr>
								<td>
									<div class="divThumb" id="divNaoVinc">
										<table border="0" cellpadding="0" cellspacing="7" width="100%">											
												<tr>													
													<td>
														<table border="0" cellpadding="0" cellspacing="0">
															<tr>				
																<td><input type="image" src="imagens/space.gif" id="img-1" /></td>
																<? 
																	if ($oResImg->getCount() > 0) { 														
																		for ($i = 0; $i < $oResImg->getCount(); $i++) { ?>																		
																				<td style="width:100;height:60"  id="thumb<?=$i?>" align="center" valign="middle" class="normal11"><img src="imagens/space.gif" width="10" alt=""><input type="image" src="thumbnail.php?arquivo=<?=$oResImg->getValores($i,"nome_imagem")?>&width=50&height=50" alt="<?=$oResImg->getValores($i,"nome_imagem")?>" onClick="scrolling(<?=$i?>)" onDblClick="abrir(<?=$oResImg->getValores($i,"numg_imagem")?>)" id="img<?=$i?>" /><img src="imagens/space.gif" width="10" alt=""></td>
																<?		}
																	} 													
																?>																
																<td><input type="image" src="imagens/space.gif" id="img<?=$oResImg->getCount()?>" /></td>
															</tr>
															<tr>			
																<td></td>													
																<? 
																	if ($oResImg->getCount() > 0) { 														
																		for ($i = 0; $i < $oResImg->getCount(); $i++) { ?>
																			<td align="center" valign="middle" class="normal11"><?=$oResImg->getValores($i,"nome_imagem")?></td>
																<?   	}
																	} 													
																?>		
																<td></td>														
															</tr>
														</table>
													</td>													
												</tr>											
										</table>
									</div>
								</td>
							</tr>
							<tr>
								<td align="center">
									 <a href="javascript:scrolling(0,'esquerda');"><img src="imagens/aro-lft.gif" alt="" border="0" /></a> 
    								 <a href="javascript:scrolling(0,'direita');"><img src="imagens/aro-rt.gif" alt="" border="0" /></a>
								</td>
							</tr>
							<tr>
								<td height="255" align="center" valign="middle">	
									<div id="hold">
									  <div id="wn">
										<div id="lyr1" class="content">
										<table id="t1" cellpadding="0" cellspacing="0" border="0">
										 <tr>
												<? 
													if ($oResImg->getCount() > 0) { 														
														for ($i = 0; $i < $oResImg->getCount(); $i++) { ?>
															<td align="center" valign="middle"><img src="thumbnail.php?arquivo=<?=$oResImg->getValores($i,"nome_imagem")?>&width=250&height=250" alt="<?=$oResImg->getValores($i,"nome_imagem")?>" style="border:2px solid" id="vis<?=$i?>" onDblClick="abrir(<?=$oResImg->getValores($i,"numg_imagem")?>)" /></td>
												<?   	}
													} 													
												?>	
										 </tr>
										</table>
										</div>
									  </div>  <!-- end wn div -->
									</div>	<!-- end hold div -->
								</td>
							</tr>							
						</table>
					</td>
					<td width=10 background="imagens/formDirMid.gif"></td>
				</tr>
				<tr>
					<td><img src="imagens/formEsqInf.gif" border=0 width=10 height=10></td>
					<td background="imagens/formMidInf.gif"></td>
					<td><img src="imagens/formDirInf.gif" border=0 width=10 height=10></td>
				</tr>
			</table></td>
	</tr>
</table>
<script language="JavaScript">
function imprimir_imagens(){
	window.print()
}



function vincular_imagem () {
	if (document.form.txtNumgId.value != ""){
		if (document.form["chkVincular[]"].value == ""){
			alert("Selecione uma Imagem na lista de Imagens n�o vinculadas.")
		}else{
			if (confirm("Confirma a VINCULA��O da(s) Imagem(s)?")){
				document.form.txtFuncao.value = "vincular_imagem"
				document.form.submit()
			}
		}
	}
}

function desvincular_imagem () {
	if (document.form.txtNumgId.value != ""){
		if (document.form["chkDesvincular[]"].value == ""){
			alert("Selecione uma Imagem na lista de Imagens vinculadas.")
		}else{
			if (confirm("Confirma a DESVINCULA��O da(s) Imagem(s)?")){
				document.form.txtFuncao.value = "desvincular_imagem"
				document.form.submit()
			}
		}
	}
}




function pValidaGravacao(){
	
	var sErr = ""
	
	//...
	
	//VERIFICA SE FOI ENCONTRADO ALGUM ERRO NA VALIDA��O DO FORMUL�RIO
	if (sErr != ""){
		sErr = "Verifique os erros encontrados abaixo:\n\n" + sErr
		alert(sErr)	
		return false
	}else
		return true
}

function colocaBorda(index){
	qtd = <?=$oResImg->getCount()?>
	
	for (i=0;i<qtd;i++)
	{
		document.getElementById("thumb"+i).style.border = '0px'
		
	}
	document.getElementById("thumb"+index).style.border = '3px solid #316AC5'
	
	if (index == 0){		
		document.getElementById("img"+(index-1)).focus()	
	} else {						
		document.getElementById("img"+(index+1)).focus()
	}
	
}


function scrolling(index,direcao){

	qtd = (<?=$oResImg->getCount()?>-1)
	
	if(direcao == "esquerda" && controle <= 0){
		controle = qtd
		rolagem = qtd *(-300)	
		dw_scrollObj.scrollBy('wn',rolagem,0)
		colocaBorda(controle)	
		return				
	}
	
	if(direcao == "direita" && controle >= qtd){		
		controle = 0
		rolagem = qtd *(+300)
		dw_scrollObj.scrollBy('wn',rolagem,0)
		colocaBorda(controle)
		return
	}
	
	if (direcao == "esquerda"){				
		dw_scrollObj.scrollBy('wn',300,0)
		controle = (controle - 1)		
		colocaBorda(controle)
		return
		
	} else if (direcao == "direita"){
		dw_scrollObj.scrollBy('wn',-300,0)
		controle = (controle + 1)
		colocaBorda(controle)
		return
	} else {		
		rolagem = (controle-index) *(300)
		dw_scrollObj.scrollBy('wn',rolagem,0)
		controle = index
		colocaBorda(controle)
		return
	}
}

</script>
</body>
</html>
