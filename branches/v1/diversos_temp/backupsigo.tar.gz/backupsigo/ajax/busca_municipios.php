<?
	include_once("../funcoes.php");
	include_once("../classes/Municipios.php");	
	
	$uf = $_GET["uf"];
	
	if ($uf != "") {		
		$oMunicipio = new Municipios();
		$oResult = new Resultset();
		
		$oResult = $oMunicipio->consultarPorUf($uf);
				
		try {
		if ($oResult->getCount() > 0) {
			$sAux = "[";
			
			for ($i=0; $i < $oResult->getCount(); $i++){
				$sAux = $sAux . "'" . $oResult->getValores($i,"numg_municipio") . "|" . $oResult->getValores($i,"nome_municipio") . "'";
				if ($i < $oResult->getCount()-1) {$sAux .= ",";}
			}
			
			$sAux = $sAux . "]";
		}
		} catch (Exception $e){
			echo "";
		}
		echo $sAux;
	} else {
		echo "";
	}

?>
