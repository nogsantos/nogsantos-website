<?
	include_once("../funcoes.php");
	include_once("../classes/Fases.php");	
	
	$funcao = $_GET["funcao"];
	
	switch($funcao){
		case "consultarPorSite":
			consultarPorSite($_GET["numg_site"]);
			break;
		default:
			echo "";
	}
	/**
	 * Data     : 16/04/2008
	 * Autor    : Rafael Santana
	 * Descri��o: consulta as fases de um site
	 */
	function consultarPorSite($numgSite) {
		
		if ($numgSite != "") {		
			
			$oFase = new Fases();
			$oResult = new Resultset();
				
			$oResult = $oFase->consultarPorSite($numgSite);
			if (Erros::isError()){echo "isError"; exit;}
			
			try {
				if (!empty($oResult)) {
					$sAux = "[";
					
					for ($i=0; $i < $oResult->getCount(); $i++){
						$sAux = $sAux . '"' . $oResult->getValores($i,"numg_fase") . "|" . $oResult->getValores($i,"nome_fase") . '"';
						if ($i < $oResult->getCount()-1) {$sAux .= ",";}
					}
					
					$sAux = $sAux . "]";
				}
			} catch (Exception $e){
				echo $e;
			}
			echo $sAux;
		} else {
			echo "";
		}
	} 
?>