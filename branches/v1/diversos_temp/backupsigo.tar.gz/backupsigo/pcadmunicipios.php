<?php 
include_once "funcoes.php";
include_once "classes/Municipios.php";
/************************************************************************
 Empresa: Interagi Tecnologia

 Descri��o: 
	
 Releases (Data, respons�vel e descri��o [�ltimo release primeiro]):
	 08/08/2005 (Silas Junior) 
		 Inclu�do este cabe�alho descrevendo a funcionalidade da p�gina
************************************************************************/


	switch ($_POST["txtFuncao"]){
	
		case "cadastrar_municipio":

			$oMunicipio = new Municipios;
			
			$oMunicipio->setNumgMunicipio(0);
			$oMunicipio->setNomeMunicipio($_POST["txtNomeMunicipio"]);
			$oMunicipio->setSiglUf($_POST["cboUf"]);
			$oMunicipio->setFlagCapital($_POST["chkFlagCapital"]);
			
			$oMunicipio->cadastrar();
			
			if(Erros::isError()) {
				MostraErros();
			}
			
			$numgMunicipio = $oMunicipio->getNumgMunicipio();
			
			unset($oMunicipio);
			
			header("Location: cadmunicipios.php?info=1&numg_municipio=".$numgMunicipio); exit;
		break;
								
		case "editar_municipio":
			
			$oMunicipio = new Municipios();
			
			$oMunicipio->setNumgMunicipio($_POST["txtNumgMunicipio"]);
			$oMunicipio->setNomeMunicipio($_POST["txtNomeMunicipio"]);
			$oMunicipio->setSiglUf($_POST["cboUf"]);
			$oMunicipio->setFlagCapital($_POST["chkFlagCapital"]);
			
			$oMunicipio->editar();
			
			if(Erros::isError()) {
				MostraErros();
			}
						
			$numgMunicipio = $oMunicipio->getNumgMunicipio();

			unset($oMunicipio);
			
			header("Location: cadmunicipios.php?info=2&numg_municipio=".$_POST["txtNumgMunicipio"]); exit;
		break;

		case "excluir_municipio":

			$oMunicipio = new Municipios();
			
			$oMunicipio->excluir($_POST["txtNumgMunicipio"]);
			
			if(Erros::isError()) {
				MostraErros();
			}

			unset($oMunicipio);
			
			header("Location: cadmunicipios.php?info=3"); exit;
		break;

		default:
			header("Location: cadmunicipios.php"); exit;
		break;									
	}

?>