<?
include_once "funcoes.php";
include_once "classes/Atividades.php";

/**
 * Empresa: Interagi Tecnologia
 * Descri��o:
 * Releases (Data, respons�vel e descri��o [�ltimo release primeiro]):
 *	 28/03/2008 (Danilo Fernandes) 
 *		 
 */

if (empty($_SESSION["NUMG_OPERADOR"]) || $_SESSION["NUMG_OPERADOR"] == ""){
	header("Location: expirou.htm"); exit;
}

switch ($_POST["txtFuncao"]){

	case "cadastrar_atividade":

		$oAtividade = new Atividades();
		
		$oAtividade->setNomeAtividade($_POST["nomeAtividade"]);
	
		$oAtividade->cadastrar();

		if (Erros::isError()){
			MostraErros();
		}else{
			header("Location: cadatividades.php?info=1"); exit;
		}

		break;

	case "editar_atividade":

		$oAtividade = new Atividades();
		
		$oAtividade->setNumgAtividade($_POST["numgAtividade"]);
		$oAtividade->setNomeAtividade($_POST["nomeAtividade"]);
		$oAtividade->editar();

		if (Erros::isError()){
			MostraErros();
		}else{
			header("Location: cadatividades.php?info=2&numg_atividade=" . $oAtividade->getNumgAtividade()); exit;
		}

		break;

	case "excluir_atividade":

		$oAtividade = new Atividades();

		$oAtividade->excluir($_POST["numgAtividade"]);

		if (Erros::isError()){
			MostraErros();
		}else{
			header("Location: cadatividades.php?info=3"); exit;
		}

		break;

	case "bloquear_atividade":

		$oAtividade = new Atividades();
		
		$oAtividade->setDatabloqueio(now());
		$oAtividade->setNumgOperadorbloqueio($_SESSION["NUMG_USUARIO"]);
		$oAtividade->bloquear();

		if (Erros::isError()){
			MostraErros();
		}else{
			header("Location: cadatividades.php?info=4&numg_atividade=" . $oAtividade->getNumgAtividade()); exit;
		}

		break;

	case "desbloquear_atividade":

		$oAtividade = new Atividades();
				
		$oAtividade->desbloquear();

		if (Erros::isError()){
			MostraErros();
		}else{
			header("Location: cadatividades.php?info=5&numg_atividade=" . $oAtividade->getNumgAtividade()); exit;
		}

		break;
		
	default:
		header("Location: cadativdades.php"); exit;
		break;
}


?>