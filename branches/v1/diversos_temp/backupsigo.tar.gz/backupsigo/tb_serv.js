var mmmmmmm=new Array();
var wmmwmmw=new Array();
var mwmmmwmm=0;
var mw=null;
var wwmwwww=null;
var mmm=null;
window.onload=mmw;
window.onunload=wwwmwwmw;

function mmw(){
    function mwwmww(wmmw,ww,wwwmwww,mwwmmwww){
		var wmwm;
		var wwww; 
		wwww="mmmmm("+ww.toString()+");";
		if(mwwmmwww==true){ 
			wwww=wwww+"mmmmmmm["+ww.toString()+"].focus();";
		} 
		wmwm="mmmmmmm[ww].document."+wmmw+" = function() {";
		if(wwwmwww==false)wmwm=wmwm+wwww;else wmwm=wmwm+"window.setTimeout('"+wwww+"', 100);";
		wmwm=wmwm+"}";
		eval(wmwm);
	}
	for(var wwwww=0;wwwww<G_numFields;wwwww++){ 
		wmmwmmw[wwwww]=document.all[G_strTEXTFieldName[wwwww]]; 
		if(G_fieldVisible[wwwww]==true && G_enableRichTextMode[wwwww]==true){ 
			if(browserVersion==5 && browserVersionDecimal==0)
				eval(G_strDHTMLFieldName[wwwww]+".document.designMode = \"on\";");  
			
			eval("mmmmmmm[wwwww]="+G_strDHTMLFieldName[wwwww]+";"); 
			mmmmmmm[wwwww].document.open("text/html","replace");
			mmmmmmm[wwwww].document.write("");
			mmmmmmm[wwwww].document.close();  
			var mwmmwmww=wwwwwm((wmmwmmw[wwwww].value).toString());
			if(G_currEditMode[wwwww]==MODE_DHTML){ 
				mmmmmmm[wwwww].document.body.innerHTML=mwmmwmww;
			}else{ 
				mmmmmmm[wwwww].document.body.innerText=mwmmwmww;wwwmmw(wwwww);
			} 
			mwwmww("onkeyup",wwwww,false,false);
			mwwmww("onkeydown",wwwww,false,false);
			mwwmww("onmouseup",wwwww,false,true);
			mwwmww("onmousedown",wwwww,false,true);
			mwwmww("onpaste",wwwww,false,true);
			mwwmww("oncut",wwwww,false,true);
			mwwmww("body.ondragend",wwwww,true,true);
			mwwmww("body.ondrop",wwwww,true,true); 
			mmmmmmm[wwwww].document.body.oncontextmenu=function(){return false;}; 
			if(browserVersion==5 && browserVersionDecimal==5)
				eval(G_strDHTMLFieldName[wwwww]+".document.body.contentEditable = true;");
			
			if(browserVersion>=6)
				eval(G_strDHTMLFieldName[wwwww]+".document.body.contentEditable = true;");
				
		}
		if(G_showToolbar[wwwww]==true && G_fieldVisible[wwwww]==true && G_enableRichTextMode[wwwww]==true){ 
			if(wwwww==0)
				wmwmwwwm(wwwww);
			else 
				wmwww(wwwww);
		}
	} 
	if(G_numFields>0)
		wmmwmmw[G_numFields-1].form.onsubmit=wwwm; 
	mmmmm(0);
}

function mmmmw(ww){
	if(G_currEditMode[ww]==MODE_DHTML){ 
		mmmmmmm[ww].document.body.innerText=mwwmwmmm(mmmmmmm[ww].document.body.innerHTML);
		G_currEditMode[ww]=MODE_TEXT;
		wwwmmw(ww);
		mmwwwwwm(G_strFieldCaption[ww].toLowerCase(),mmmmmmm[ww].document.body.innerText.length,G_maxLength[ww]);
	}else{ 
		mmmmmmm[ww].document.body.innerHTML=wwwwwm(mmmmmmm[ww].document.body.innerText);
		G_currEditMode[ww]=MODE_DHTML; 
		wmwmwwwm(ww); 
		mmmmm(ww);
		mmwwwwwm(G_strFieldCaption[ww].toLowerCase(),mmmmmmm[ww].document.body.innerHTML.length,G_maxLength[ww]);
	}
	mmmmmmm[ww].focus();
}

function mmwwwwwm(mmwmww,wmmmw,mwmwm){
	if(wmmmw>mwmwm){
		var wwwwwwww=wwwmwm.replace(new RegExp("\\%s1"),mmwmww);
		wwwwwwww=wwwwwwww.replace(new RegExp("\\%s2"),mwmwm.toString());
		wwwwwwww=wwwwwwww.replace(new RegExp("\\%s3"),wmmmw.toString());
		alert(wwwwwwww);
		return false;
	}else 
		return true;
} 

function wwwwmwww(ww,mmwmwwmm){
	var mmmwmw=mmmmmmm[ww].document.selection.createRange();
	var wmmmmmw=null;
	if(mmmwmw.parentElement!=null){ 
		wmmmmmw=mmmwmw.parentElement();
	}else{ 
		wmmmmmw=mmmwmw.item(0);
	} 
	
	while(wmmmmmw!=null && wmmmmmw.tagName!=mmwmwwmm){
		wmmmmmw=wmmmmmw.parentElement;
	}
	return wmmmmmw;
}


//******************************************************
// ABRE A JANELA PARA ENTRADA DOS PAR�METROS DAS TABELAS
//******************************************************
function PopUpTabela(ww){
	var vParamDefault=new Array();  //Par�metros padr�o
	var vParamUser=null;			//Par�metros fornecidos pelo usu�rio
	
	//PAR�METROS PADR�O
	vParamDefault["Rows"]=3;
	vParamDefault["Columns"]=3;
	vParamDefault["BorderWidth"]=1;
	vParamDefault["CellPadding"]=0;
	vParamDefault["CellSpacing"]=0; 
	vParamDefault["BGColor"]="#ffffff"; 
	
	vParamUser=showModalDialog(www,vParamDefault,"font-family:Verdana; font-size:12; dialogWidth:250px; dialogHeight:220px; help:no;");
	
	if(vParamUser){ 
		var sTabela="<TABLE WIDTH='75%' BGCOLOR='"+vParamUser["BGColor"]+"' CELLPADDING='"+vParamUser["CellPadding"]+"' CELLSPACING='"+vParamUser["CellSpacing"]+"' BORDER='"+vParamUser["BorderWidth"]+"'>\n";
		for(var wmm=0;wmm<vParamUser["Rows"];wmm++){
			sTabela=sTabela+"<TR>\n";
			for(var mwwwmwwm=0;mwwwmwwm<vParamUser["Columns"];mwwwmwwm++)
				sTabela=sTabela+"<TD>&nbsp;</TD>\n";
		}
		sTabela=sTabela+"</TR>\n</TABLE>\n"; 
		var mmmwmw=mmmmmmm[ww].document.selection.createRange();
		var mwwwmww=mmmmmmm[ww].document.selection.type;
		if(mwwwmww=="Control")
			mmmwmw.item(0).outerHTML=sTabela;
		else 
			mmmwmw.pasteHTML(sTabela);
	}
}

//*************************************
// ABRE A JANELA PARA SELE��O DA IMAGEM
//*************************************
function PopUpImagem(ww){

	var vParamDefault=new Array();  //Par�metros padr�o
	var vParamUser=null;			//Par�metros fornecidos pelo usu�rio
	
	//PAR�METROS PADR�O
	vParamDefault["alt"]='';
	vParamDefault["hspace"]=0;
	vParamDefault["src"]='';
	vParamDefault["align"]='left';
	vParamDefault["vspace"]=0;
	vParamDefault["border"]=0;
	vParamDefault["name"]='';
		
	vParamUser=showModalDialog(url_imagem,vParamDefault,"font-family:Verdana; font-size:12; dialogWidth:485px; dialogHeight:285px; help:no;");
	
	if(vParamUser){ 
		var sImagem="<IMG alt='" + vParamUser["alt"] + "' hspace='" + vParamUser["hspace"] + "' src='" + vParamUser["src"] + "' align='" + vParamUser["align"] + "' vspace='" + vParamUser["vspace"] + "' border='" + vParamUser["border"] + "' name='" + vParamUser["name"] + "'>\n";
		var mmmwmw=mmmmmmm[ww].document.selection.createRange();
		var mwwwmww=mmmmmmm[ww].document.selection.type;
		if(mwwwmww=="Control")
			mmmwmw.item(0).outerHTML=sImagem;
		else 
			mmmwmw.pasteHTML(sImagem);
	}
}

//***************************
// INSERE UMA LINHA NA TABELA
//***************************
function InsereLinha(ww){
	var wwmw=wwwwmwww(ww,"TABLE");
	if(wwmw){ 
		var wmwmmwm=wwwwmwww(ww,"TR");  
		var wmm;
		if(wmwmmwm)wmm=wmwmmwm.rowIndex;else wmm=-1; 
		var mwwmwm=wwmw.insertRow(wmm);   
		if(wmwmmwm)wmm=wmwmmwm.rowIndex;else wmm=0; 
		for(var wwwww=0;wwwww<wwmw.rows[wmm].cells.length;wwwww++){
			var mwwwwmww=mwwmwm.insertCell();
			mwwwwmww.innerHTML="&nbsp;";
		}
	}
}

//****************************
// INSERE UMA COLUNA NA TABELA
//****************************
function InsereColuna(ww){
	var wwmw=wwwwmwww(ww,"TABLE");
	if(wwmw){ 
		var mwwm=wwwwmwww(ww,"TD");  
		var mmwmmw;
		if(mwwm)mmwmmw=mwwm.cellIndex;else mmwmmw=-1; 
		for(var wwwww=0;wwwww<wwmw.rows.length;wwwww++){
			var mwwwwmww=wwmw.rows[wwwww].insertCell(mmwmmw);
			mwwwwmww.innerHTML="&nbsp;"
		}
	}
}

//****************************
// INSERE UMA C�LULA NA TABELA
//****************************
function InsereCelula(ww){
	var wwmw=wwwwmwww(ww,"TABLE");
	if(wwmw){ 
		var mwmwwmmw=wwwwmwww(ww,"TD"); 
		var wmwmmwm=wwwwmwww(ww,"TR");  
		var mmmww;
		if(mwmwwmmw)mmmww=mwmwwmmw.cellIndex;else mmmww=-1;
		var wmm;
		if(wmwmmwm)wmm=wmwmmwm.rowIndex;else wmm=wwmw.rows.length-1; 
		var mwwwwmww=wwmw.rows[wmm].insertCell(mmmww);
		mwwwwmww.innerHTML="&nbsp;"
	}
}

//***************************
// EXCLUI UMA LINHA NA TABELA
//***************************
function ExcluiLinha(ww){
	var wwmw=wwwwmwww(ww,"TABLE");
	if(wwmw){ 
		var wmwmmwm=wwwwmwww(ww,"TR");  
		var wmm;
		if(wmwmmwm)wmm=wmwmmwm.rowIndex;else wmm=""; 
		wwmw.deleteRow(wmm);
	}
}

//****************************
// EXCLUI UMA COLUNA NA TABELA
//****************************
function ExcluiColuna(ww){
	var wwmw=wwwwmwww(ww,"TABLE");
	if(wwmw){ 
		var mwwm=wwwwmwww(ww,"TD");  
		var mmwmmw;
		if(mwwm)mmwmmw=mwwm.cellIndex;else mmwmmw=""; 
		for(var wwwww=0;wwwww<wwmw.rows.length;wwwww++){
			wwmw.rows[wwwww].deleteCell(mmwmmw);
		}
	}
}

//****************************
// EXCLUI UMA C�LULA NA TABELA
//****************************
function ExcluiCelula(ww){
	var wwmw=wwwwmwww(ww,"TABLE");
	if(wwmw){ 
		var mwmwwmmw=wwwwmwww(ww,"TD"); 
		var wmwmmwm=wwwwmwww(ww,"TR");  
		var mmmww;
		if(mwmwwmmw)mmmww=mwmwwmmw.cellIndex;else mmmww="";
		var wmm;
		if(wmwmmwm)wmm=wmwmmwm.rowIndex;else wmm=0; 
		wwmw.rows[wmm].deleteCell(mmmww);
	}
} 

function mmmmmwm(){
	event.returnValue=false;
	event.cancelBubble=true;
	return false;
}

function wwwmwwmw(){ 
	if(mmm!=null)mmm.close();
}

function mmmmm(ww){  
	if(mwmmmwmm!=ww){
		for(var wwwww=0;wwwww<G_numFields;wwwww++){
			if(G_showToolbar[wwwww]==true && G_fieldVisible[wwwww]==true && G_enableRichTextMode[wwwww]==true){
				if(wwwww==ww)wmwmwwwm(wwwww);else wmwww(wwwww);
			}
		}
	}  
	if(G_currEditMode[ww]==MODE_TEXT){
		if(mmmmmmm[ww].document.body.innerHTML.indexOf("<")!=-1){
			var mwmmwmww=mmmmmmm[ww].document.body.innerHTML.replace(new RegExp("<(\\/)?(p|br)[^>]*>","gi"),"");
			if(mwmmwmww.indexOf("<")!=-1){
				mmmmmmm[ww].document.body.innerHTML=mmmmmmm[ww].document.body.innerHTML.replace(new RegExp("<(\\/)?(\\w)*(\\s)*[^>]*>","gi"),"");
			}
		}
	} 
	mwmmmwmm=ww; 
	if((G_currEditMode[ww]==MODE_DHTML)&&(G_showToolbar[ww]==true && G_fieldVisible[ww]==true && G_enableRichTextMode[ww]==true)){ 
		var wwmw;
		if(G_enableAdvancedTableControls[ww]==true){
			wwmw=wwwwmwww(ww,"TABLE");
		} 
		for(var wwwww=0;wwwww<wwm[ww].length;wwwww++){ 
			if(wwm[ww][wwwww].cmdType==wmmmwmm||wwm[ww][wwwww].cmdType==mmwwmwww){ 
				currStatus=mmmmmmm[ww].document.queryCommandState(wwm[ww][wwwww].cmdStr);
				currEnable=mmmmmmm[ww].document.queryCommandEnabled(wwm[ww][wwwww].cmdStr); 
				if(currEnable==false){
					if(wwm[ww][wwwww].className!="buttonDisabled")wwm[ww][wwwww].className="buttonDisabled";
				}
				else if(currStatus==false){if(wwm[ww][wwwww].className!="buttonUp")wwm[ww][wwwww].className="buttonUp";}
				else if(currStatus==true){if(wwm[ww][wwwww].className!="buttonDown")wwm[ww][wwwww].className="buttonDown";}}
				else if(wwm[ww][wwwww].cmdType==wmwmmmmm){
					if(wwm[ww][wwwww].cmdStr=="InsertTable"){ 
						if(wwm[ww][wwwww].className!="buttonUp")wwm[ww][wwwww].className="buttonUp";
					}else{
						if(wwmw){ 
							if(wwm[ww][wwwww].className!="buttonUp")wwm[ww][wwwww].className="buttonUp";
						}else{ 
							if(wwm[ww][wwwww].className!="buttonDisabled")wwm[ww][wwwww].className="buttonDisabled";
						}
					}
				}else{ 
					if(wwm[ww][wwwww].className!="buttonUp")wwm[ww][wwwww].className="buttonUp";
				}
			} 
			if(G_enableFontFaceControls[ww]==true)document.all["cmbFontName"+ww].selectedIndex=-1;
			if(G_enableFontSizeControls[ww]==true)document.all["cmbFontSize"+ww].selectedIndex=-1;
		}
	}


function wwwm(){
	var mwmwww=true;
	//if(checkFields()==false)return false;
	for(var wwwww=0;wwwww<G_numFields;wwwww++){  
		if(G_fieldVisible[wwwww]==true && G_enableRichTextMode[wwwww]==true){
			if(G_currEditMode[wwwww]==MODE_DHTML)
				wmmwmmw[wwwww].value=mwwmwmmm(mmmmmmm[wwwww].document.body.innerHTML);
			else{ 
				var mwmmwmww=mmmmmmm[wwwww].document.body.innerHTML.replace(new RegExp("<(\\/)?(p|br)[^>]*>","gi"),"");
				if(mwmmwmww.indexOf("<")!=-1){
					mmmmmmm[wwwww].document.body.innerHTML=mmmmmmm[wwwww].document.body.innerHTML.replace(new RegExp("<(\\/)?(\\w)*(\\s)*[^>]*>","gi"),"");
				}
				wmmwmmw[wwwww].value=mmmmmmm[wwwww].document.body.innerText;
			}
		}
		mwmwww=(mmwwwwwm(G_strFieldCaption[wwwww].toLowerCase(),wmmwmmw[wwwww].value.length,G_maxLength[wwwww])&& mwmwww);
	}
	return mwmwww;
}


//***************************
// FUN��O DE REDIRECIONAMENTO
//***************************
function wwwwmm(ww){
	if(wwmwwww){
		wwmwwww.onmouseout=null;
		var wwww=wwmwwww.cmdStr; 
		document.onmouseup=mw;
		mw=null;  
		if(wwmwwww.className=="buttonDown" &&(wwmwwww.cmdType==mmwwmwww||wwmwwww.cmdType==m||wwmwwww.cmdType==wmwmmmmm)){
			wwmwwww.className="buttonUp";
			mmmmmmm[ww].focus();
		} 
		if(wwmwwww.cmdType==m||wwmwwww.cmdType==wmwmmmmm||mmmmmmm[ww].document.queryCommandEnabled(wwww)==true){
			if((wwww=="ForeColor")||(wwww=="BackColor")){mmmmww(wwww);}
			else if(wwww=="InsertImage"){PopUpImagem(ww);mmmmmmm[ww].focus();}
			else if(wwww=="InsertTable"){PopUpTabela(ww);mmmmmmm[ww].focus();}
			else if(wwww=="InsertRow"){InsereLinha(ww);mmmmmmm[ww].focus();}
			else if(wwww=="InsertCol"){InsereColuna(ww);mmmmmmm[ww].focus();}
			else if(wwww=="InsertCell"){InsereCelula(ww);mmmmmmm[ww].focus();}
			else if(wwww=="DeleteRow"){ExcluiLinha(ww);mmmmmmm[ww].focus();}
			else if(wwww=="DeleteCol"){ExcluiColuna(ww);mmmmmmm[ww].focus();}
			else if(wwww=="DeleteCell"){ExcluiCelula(ww);mmmmmmm[ww].focus();}
			else{mmmmmmm[ww].document.execCommand(wwww,true);mmmmmmm[ww].focus();}
			
			mmmmm(ww);
		}
		wwmwwww=null;
	}
}


function mmmmmww(ww){ 
	if(event.button==1 && mwmmmwmm==ww){  
		if(event.srcElement.tagName=="DIV")
			wwmwwww=event.srcElement;
		else 
			wwmwwww=event.srcElement.parentElement;
		
		if(wwmwwww.className!="buttonDisabled" && wwmwwww.className!="buttonNoFocus"){ 
			wwmwwww.className="buttonDown";  
			mw=document.onmouseup;
			document.onmouseup=function(){wwwwmm(ww);};
			wwmwwww.onmouseout=mwwwmw;
		}else{
			wwmwwww==null;
		}
	}
	return false;
}

function mwwwmw(){
	if(wwmwwww){
		wwmwwww.onmouseout=null; 
		document.onmouseup=mw;
		mw=null;
		wwmwwww=null; 
		mmmmm(mwmmmwmm);
	}
}

function mwwwwmm(ww){
	var wmwwww=event.srcElement;
	if(wmwwww.selectedIndex!=-1){
		mmmmmmm[ww].document.execCommand("FontName",false,wmwwww.value);
		mmmmmmm[ww].focus(); 
		wmwwww.selectedIndex=-1;
	}
}

function mwm(ww){
	var wmwwww=event.srcElement;
	if(wmwwww.selectedIndex!=-1){
		mmmmmmm[ww].document.execCommand("FontSize",false,parseInt(wmwwww.value));
		mmmmmmm[ww].focus(); 
		wmwwww.selectedIndex=-1;
	}
} 

function wwwwwm(wmmmwmww){
	var mwmmwmww=wmmmwmww.replace(new RegExp("<<","g"),"&lt;&lt;").replace(new RegExp(">>","g"),"&gt;&gt;"); 
	mwmmwmww=mwmmwmww.replace(new RegExp("<(\\/)?(html|body|head|title)(\\s)*[^>]*>","gi"),""); 
	mwmmwmww=wwmwwmmm(mwmmwmww);
	return mwmmwmww;
}


function mwwmwmmm(mwmmwmww){
	var wmmmwmww;
	wmmmwmww=mwmmwmww.replace(new RegExp("&lt;&lt;","gi"),"<<").replace(new RegExp("&gt;&gt;","gi"),">>"); 
	wmmmwmww=wmmmwmww.replace(new RegExp("^<[pP]>(\\s)*(&nbsp;)*(\\s)*<\\/[pP]>$"),""); 
	wmmmwmww=wmmmwmww.replace(new RegExp("( *)\\<br\\>( *)","gi"),"<BR>\n");  
	wmmmwmww=wmmmwmww.replace(new RegExp(String.fromCharCode(8211),"g"),"&ndash;"); 
	wmmmwmww=wmmmwmww.replace(new RegExp(String.fromCharCode(8212),"g"),"&mdash;"); 
	wmmmwmww=wmmmwmww.replace(new RegExp(String.fromCharCode(8216),"g"),"&lsquo;"); 
	wmmmwmww=wmmmwmww.replace(new RegExp(String.fromCharCode(8217),"g"),"&rsquo;"); 
	wmmmwmww=wmmmwmww.replace(new RegExp(String.fromCharCode(8220),"g"),"&ldquo;"); 
	wmmmwmww=wmmmwmww.replace(new RegExp(String.fromCharCode(8221),"g"),"&rdquo;");
	return wmmmwmww;
} 


function wmwww(ww){
	if(document.all["TBA"+ww.toString()].className!="toolbarNoFocus"){
		document.all["TBA"+ww.toString()].className="toolbarNoFocus";
		if(document.all["TBB"+ww.toString()])document.all["TBB"+ww.toString()].className="toolbarNoFocus";
	}
	for(var wwwww=0;wwwww<wwm[ww].length;wwwww++){
		if(wwm[ww][wwwww].className!="buttonNoFocus")wwm[ww][wwwww].className="buttonNoFocus";
	} 
	
	if(G_enableShowHTMLControl[ww]==true){
		if(document.all["chkShowHTML"+ww.toString()].disabled!=true){
			document.all["chkShowHTML"+ww.toString()].disabled=true;
			document.all["lblShowHTML"+ww.toString()].className="textShowHTMLDisabled";
		}
	} 
	if(G_enableFontFaceControls[ww]==true){
		if(document.all["cmbFontName"+ww.toString()].disabled!=true){
			document.all["cmbFontName"+ww.toString()].disabled=true;
		}
	}
	if(G_enableFontSizeControls[ww]==true){
		if(document.all["cmbFontSize"+ww.toString()].disabled!=true){
			document.all["cmbFontSize"+ww.toString()].disabled=true;
		}
	}
}


function wmwmwwwm(ww){
	if(document.all["TBA"+ww.toString()].className!="toolbar"){
		document.all["TBA"+ww.toString()].className="toolbar";
		if(document.all["TBB"+ww.toString()])document.all["TBB"+ww.toString()].className="toolbar";
	} 
	if(G_enableShowHTMLControl[ww]==true){
		if(document.all["chkShowHTML"+ww.toString()].disabled!=false){
			document.all["chkShowHTML"+ww.toString()].disabled=false;
			document.all["lblShowHTML"+ww.toString()].className="textShowHTMLEnabled";
		}
	} 
	if(G_enableFontFaceControls[ww]==true){
		if(document.all["cmbFontName"+ww.toString()].disabled!=false){
			document.all["cmbFontName"+ww.toString()].disabled=false;
		}
	}
	if(G_enableFontSizeControls[ww]==true){
		if(document.all["cmbFontSize"+ww.toString()].disabled!=false){
			document.all["cmbFontSize"+ww.toString()].disabled=false;
		}
	}
	if(G_currEditMode[ww]==MODE_TEXT){ 
		wwwmmw(ww);
	}
}

function wwwmmw(ww){
	for(var wwwww=0;wwwww<wwm[ww].length;wwwww++){
		if(wwm[ww][wwwww].cmdType!=m){
			if(wwm[ww][wwwww].className!="buttonDisabled")wwm[ww][wwwww].className="buttonDisabled";
		}else{
			if(wwm[ww][wwwww].className!="buttonUp")wwm[ww][wwwww].className="buttonUp";
		}
	} 
	if(G_enableFontFaceControls[ww]==true){
		if(document.all["cmbFontName"+ww.toString()].disabled!=true){
			document.all["cmbFontName"+ww.toString()].disabled=true;
		}
	}
	if(G_enableFontSizeControls[ww]==true){
		if(document.all["cmbFontSize"+ww.toString()].disabled!=true){
			document.all["cmbFontSize"+ww.toString()].disabled=true;
		}
	}
} 


function mmwmw(mmmwm){
	mmm=null;
	if(mmmwm!=null)mmmmmmm[mwmmmwmm].document.execCommand(G_cmdGetColor,true,mmmwm);
	mmmmmmm[mwmmmwmm].focus();
}

//**********************************
// ABRE A JANELA PARA SELE��O DE COR
//**********************************
function mmmmww(wwww){
	if(mmm!=null){
		mmm.onunload="";
		mmm.close();mmm=null;
	}  
	var wwmwwm="0";
	window.currcolor=wwmwwm;
	mmm=window.open(mmmmmm,"getcolor","width=480,height=280,top=" + (window.screenTop + 130) + ",left=" + (window.screenLeft + 100));
	if(mmm){
		G_cmdGetColor=wwww;
		mmm.getcolorClose=mmwmw;
	}
} 

function mmmmmw(wwwwmwmm){
	return wwwwmwmm.replace(new RegExp("\\r?\\n","g"),"<BR>");
}

function mmwww(wwwwmwmm){
	var wwwwwwm; 
	wwwwwwm=wwwwmwmm.search(new RegExp("[\\S]",""));
	if(wwwwwwm!=-1)
		return wwwwmwmm.substring(0,wwwwwwm)+mmmmmw(wwwwmwmm.slice(wwwwwwm));
	else 
		return wwwwmwmm;
}


function mwwwwmmm(mmwwmm,wwwwmwmm){
	return mmwwmm+mmwww(wwwwmwmm);
}

function wwmwwmmm(mmwwwmwm){ 
	var wmwmwmw="";
	var wmwwwmmw=mmwwwmwm;
	var wwwwwwm=1;
	var mwwwm=new Array();
	function mwmwmw(wwmmww){
		return "!@#$ENCODED_BLOCK_NUMBER_"+wwmmww.toString()+"$#@!";
	}
	function mmmmwm(wwwwmwmm){
		var wwmmww;
		if(mwwwm.length){
			wwmmww=mwwwm.length;
		}else{
			wwmmww=0;
		}
		mwwwm[wwmmww]=wwwwmwmm;
		return mwmwmw(wwmmww);
	}
	function mmwmmmw(wmwmw,wmmmmwwm,mwwwwwm){
		var wmmwmm=wmwmw.slice(0,wmmmmwwm);
		wmmwmm=wmmwmm.replace(new RegExp("[\\r]?[\\n]?$",""),"");
		var mmmmwmw=wmwmw.slice(mwwwwwm,wmwmw.length);
		mmmmwmw=mmmmwmw.replace(new RegExp("^[\\r]?[\\n]?",""),"");
		var wwwwmwmm=wmwmw.slice(wmmmmwwm,mwwwwwm);
		return wmmwmm+mmmmwm(wwwwmwmm)+mmmmwmw;
	}
	function mmww(wmwmw){
		var wwwww=0;
		while(wwwww<mwwwm.length){
			var wmmwmww=wmwmw.indexOf(mwmwmw(wwwww));
			var mmmwwmw=mwmwmw(wwwww).length;
			var wmmwmm=wmwmw.slice(0,wmmwmww);
			var mmmmwmw=wmwmw.slice(wmmwmww+mmmwwmw,wmwmw.length);
			wmwmw=wmmwmm+mwwwm[wwwww]+mmmmwmw;wwwww=wwwww+1;
		}
		return wmwmw;
	}
	var mwmmm=new Array();
	var wmmwmmmm=new Array();
	mwmmm[0]="<script";
	wmmwmmmm[0]="</script>";
	mwmmm[1]="<!--";
	wmmwmmmm[1]="-->";
	var mwwmmmw=0;
	while(mwwmmmw<mwmmm.length){
		var wmmwm=0;
		var mmmwmm=0;
		while((wmmwm!=-1)&&(mmmwmm!=-1)){
			wmmwm=wmwwwmmw.toUpperCase().indexOf(mwmmm[mwwmmmw].toUpperCase());
			mmmwmm=wmwwwmmw.toUpperCase().indexOf(wmmwmmmm[mwwmmmw].toUpperCase())+wmmwmmmm[mwwmmmw].length;
			if((wmmwm!=-1)&&(mmmwmm!=(-1+wmmwmmmm[mwwmmmw].length))){
				wmwwwmmw=mmwmmmw(wmwwwmmw,wmmwm,mmmwmm);
			}
		}
		mwwmmmw=mwwmmmw+1;
	}
	if(wmwwwmmw.indexOf("<")!=-1){ 
		wmwmwmw=mmwww(wmwwwmmw.substring(0,wmwwwmmw.indexOf("<"))); 
		wmwwwmmw=wmwwwmmw.slice(wmwwwmmw.indexOf("<"));
	}else{
		wmwmwmw=mmwww(wmwwwmmw);
		wmwmwmw=mmww(wmwmwmw);
		return wmwmwmw;
	}  
	do{wwwwwwm=wmwwwmmw.search(new RegExp("(\\<[^\\>]*\\>)([^\\<]*)",""));
	if(wwwwwwm!=-1){
		var mmwmwwmm=wmwwwmmw.match(new RegExp("(\\<[^\\>]*\\>)([^\\<]*)",""))[1];
		var wmwwwww=wmwwwmmw.match(new RegExp("(\\<[^\\>]*\\>)([^\\<]*)",""))[2];
		wmwmwmw=wmwmwmw+wmwwwmmw.substring(0,wwwwwwm);
		wmwmwmw=wmwmwmw+mwwwwmmm(mmwmwwmm,wmwwwww);
		wmwwwmmw=wmwwwmmw.slice(wwwwwwm+mmwmwwmm.length+wmwwwww.length);
	}
}

while(wwwwwwm!=-1);
wmwmwmw=wmwmwmw+wmwwwmmw;
wmwmwmw=mmww(wmwmwmw);
return wmwmwmw;
}