<?php
include_once ("funcoes.php");
include_once ("classes/Operadores.php");
include_once ("classes/MunicipiosTuristicos.php");
/*********************************************************************************
 Empresa: Net4U Solu��es Internet e Intranet
 Cria��o: Rafael C�cero
 
 Descri��o: Formul�rio para altera��o de senha dos operadores.

 Releases (Data, respons�vel e descri��o [�ltimo release primeiro]):
	 03/07/2006 (Rafael C�cero) 
		 Inclu�do este cabe�alho descrevendo a funcionalidade desta p�gina
		
*********************************************************************************/

	//INICIALIZA AS SESSIONS
	$_SESSION["NUMG_OPERADOR"] = "";
	$_SESSION["NOME_OPERADOR"] = "";
	$_SESSION["NOME_COMPLETO"] = "";
	$_SESSION["DATA_ULTIMOACESSO"] = "";
	$_SESSION["NUMG_MUNICIPIO"] = "";
	$_SESSION["NOME_MUNICIPIO"] = "";
	
	$vAux = explode("|",$_POST["cboMunicipios"]);
	
	if ($_POST["txtNomeOperador"] != "" && $_POST["txtDescSenha"] != "")
	{
		$bOpen = true;

		$oOperadores = new Operadores;
		
		if ($_POST["txtNomeOperador"] == "admin")
			$oResult = $oOperadores->consultarPorNomeOperador($_POST["txtNomeOperador"]);
		else
			$oResult = $oOperadores->consultarPorMunNomeOpe($vAux[0],$_POST["txtNomeOperador"]);
			
		if (Erros::isError()) MostraErros();
	
		if ($oResult->getCount() == 0){
			header("Location: alterasenha.php?erro=1");
		}else{
			
			//VERIFICA SE A SENHA EST� CORRETA
			if (trim(Descriptografa($oResult->getValores(0,"desc_senha"))) != trim($_POST["txtDescSenha"])){
				header("Location: alterasenha.php?erro=3"); exit;
			//VERIFICA SE O OPERADOR EST� BLOQUEADO
			}elseif (!is_null($oResult->getValores(0,"data_bloqueio"))){
				header("Location: alterasenha.php?erro=2"); exit;
			}else{
				$_SESSION["NUMG_OPERADOR"] = $oResult->getValores(0,"numg_operador");
				$_SESSION["NOME_OPERADOR"] = strtolower($_POST["txtNomeOperador"]);
				$_SESSION["NOME_COMPLETO"] = $oResult->getValores(0,"nome_completo");
				$_SESSION["DATA_ULTIMOACESSO"] = $oResult->getValores(0,"data_ultimoacesso");
				$_SESSION["NUMG_MUNICIPIO"] = $vAux[0];
				$_SESSION["NOME_MUNICIPIO"] = $vAux[1];
				
				$oOperadores->editarSenha(array($oResult->getValores(0,"numg_operador"),$_POST["txtNovaSenha"]));
				
				$bOpen = true;
			}
		}
	}
	
	$oMunicipiosTur = new MunicipiosTur;
	
	$vMunicipios = $oMunicipiosTur->consultarMunicipiosTuristicos();
	if (Erros::isError()) MostraErros();
	
?>

<html>
<head>
<title>Sigo - Acesso Restrito</title>

<meta http-equiv="Content-Type" content="text/html;">

<LINK href="estilos.css" rel=stylesheet type=text/css>

<SCRIPT language=JavaScript src="funcoes.js"></SCRIPT>

<script language=JavaScript>
 
function Open(){
	<?php 
	if ($bOpen && $_GET["opt"] == ""){
	?>
		window.location.href = "gerenciador.php";
	<?php
	}
	?>
}
</script>

</head>

<body onLoad="Open();window.focus();document.form.txtNomeOperador.focus()" bgcolor="#f3f3f3" topmargin=0 leftmargin=0 rightmargin=0 bottommargin=0>

<table border="0" cellpadding="0" cellspacing="0" width="100%" height="100%" bgcolor="#f3f3f3" align=center valign=middle>
	<tr>
		<td valign=middle align=center>
					
			<TABLE border=0 bgcolor="#FFFFFF" width=228 height=230 cellspacing=0 cellpadding=0 class="borda">

				<FORM method="post" action="alterasenha.php" name="form" autocomplete=off>
				<input type=hidden name=txtTipoFuncao value="">
					<tr>
						<td valign="top"><img src="imagens/login_sistur.gif" border="0"></td>
					</tr>
					<tr>
						<td valign=top>
							<TABLE border=0 align=center cellspacing=0 cellpadding=0>
								<tr>
									<td class=destaque align=center height="20" colspan=3>
									<?php	
									//MENSAGENS DE ERRO
									if ($_GET["erro"] != "")
									{

										switch ($_GET["erro"]){
											case 1:
												echo "Operador n�o cadastrado!";
												break;
											case 2:
												echo "Este operador encontra-se bloqueado!";
												break;
											case 3:
												echo "Senha atual incorreta! Tente novamente.";
												break;
										}

									}
									?>
									</td>
								</tr>	
								<tr>
									<td></td>
									<td class=normal11b height="15">Munic�pio:</td>
									<td></td>
								</tr>
								<tr>
									<td></td>
									<td>
										<select name="cboMunicipios" class="borda" style="width:196">
											<?php 
											if (isset($vMunicipios)){
												if ($vMunicipios->getCount() > 0){
													for ($i=0; $i<$vMunicipios->getCount(); $i++){?>
													<option value="<?=$vMunicipios->getValores($i,"numg_municipio") . "|" . $vMunicipios->getValores($i,"nome_municipio")?>"><?=$vMunicipios->getValores($i,"nome_municipio")?>
												<?php }
												}	
											}?>
										</select>
									</td>
									<td></td>
								</tr>
								<tr>
									<td></td>
									<td class=normal11b height="15">Operador:</td>
									<td></td>
								</tr>
								<tr>
									<td></td>
									<td><INPUT type="text" name="txtNomeOperador" size=30 maxlength=20 class=borda tabindex=1></td>
									<td></td>
								</tr>
								<tr>
									<td></td>
									<td class=normal11b height="15">Senha atual:</td>
									<td></td>
								</tr>
								<tr>
									<td></td>
									<td><INPUT type="password" name="txtDescSenha" size=30 maxlength=8 class=borda tabindex=2></td>
									<td></td>
								</tr>
								<tr>
									<td></td>
									<td class=normal11b height="15">Nova senha:</td>
									<td></td>
								</tr>
								<tr>
									<td></td>
									<td><INPUT type="password" name="txtNovaSenha" size=30 maxlength=8 class=borda tabindex=3></td>
									<td></td>
								</tr>
								<tr>
									<td></td>
									<td class=normal11b height="15">Confirma senha:</td>
									<td></td>
								</tr>
								<tr>
									<td></td>
									<td><INPUT type="password" name="txtConfirmacao" size=30 maxlength=8 class=borda tabindex=4></td>
									<td></td>
								</tr>
								<tr>
									<td height=10></td>
								</tr>
								<tr>
									<td colspan=3 align=right>
										<TABLE border=0 width="100%" align=center cellspacing=0 cellpadding=0>
											<tr>
												<td width="40%" class="normal11"></td>
												<td width="60%" align="right">
													<input type=submit value="Alterar Senha" border=0 onClick="return ValidaForm(document.form)" class=botao tabindex="5">&nbsp;
													<input type=button value="  Voltar   " border=0 onClick="window.location.href='login.php'" class=botao tabindex="6">&nbsp;
												</td>
											</tr>
										</table>
									</td>
								</tr>
								<tr>
									<td height=10></td>
								</tr>
							</table>
						</td>
					</tr>
				</FORM>

			</table>		
		
		</td>
	</tr>
	
</table>

<script language="JavaScript">
<!--

//FUN��O PARA VALIDAR O NOME DE OPERADOR E A SENHA
function ValidaForm(form){
	
	if (Trim(form.txtNomeOperador.value) == ""){
		alert("Nome do operador inv�lido!")
		form.txtNomeOperador.focus()
		return false
	}

	if (Trim(form.txtDescSenha.value) == ""){
		alert("Senha inv�lida!")
		form.txtDescSenha.focus()
		return false
	}

	if (form.txtNovaSenha.value.length < 4){
		alert("Nova senha inv�lida! Informe uma senha com no m�nimo 4 caracteres.")
		form.txtNovaSenha.focus()
		return false
	}
	
	if (Trim(form.txtNovaSenha.value) != Trim(form.txtConfirmacao.value)){
		alert("Confirma��o da nova senha inv�lida!")
		form.txtConfirmacao.focus()
		return false
	}
	
}

//-->
</script>

</body>
</html>