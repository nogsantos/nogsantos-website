<?
include_once "funcoes.php";
include_once "classes/Empresas.php";
include_once "classes/Executores.php";

/**
 * Empresa: Interagi Tecnologia
 * Descri��o:
 * Releases (Data, respons�vel e descri��o [�ltimo release primeiro]):
 *	 09/06/2008 (Danilo Fernandes) 
 *		 
 */

if (empty($_SESSION["NUMG_OPERADOR"]) || $_SESSION["NUMG_OPERADOR"] == ""){
	header("Location: expirou.htm"); exit;
}

switch ($_POST["txtFuncao"]){

	case "cadastrar_executores":

		$oExecutores = new Executores();

		$vSub = explode("|",$_POST['numgsSubatividades']);
		
		$oExecutores->setNumgFase($_POST['cboFase']);
		$oExecutores->setNumgSite($_POST['cboSite']);
		//echo count($vSub)."<br>";
		

		for($i=0;$i<count($vSub);$i++){
			$vExec[$i][0] = $_POST["cboEmpresa".$i];//empresa
			$vExec[$i][1] = $vSub[$i];//subatividade
			//echo $vExec[$i][0]."<br>";
			//echo $vExec[$i][1]."<br>";
		}
		//exit();	
		$oExecutores->setVSubatividades($vExec);
		
		$oExecutores->cadastrar();


		if (Erros::isError()){
			MostraErros();
		}else{
			
			header("Location: cadexecutores_sites.php?info=1&numg_site=" . $oExecutores->getNumgSite()."&numg_fase=".$oExecutores->getNumgFase());  exit;
		}

		break;

	case "editar_executores":

		$oExecutores = new Executores();
		
		
		$vSub = explode("|",$_POST['numgsSubatividades']);
		
		$oExecutores->setNumgFase($_POST['cboFase']);
		$oExecutores->setNumgSite($_POST['cboSite']);
		//echo count($vSub)."<br>";
		

		for($i=0;$i<count($vSub);$i++){
			$vExec[$i][0] = $_POST["cboEmpresa".$vSub[$i]];//empresa
			$vExec[$i][1] = $vSub[$i];//subatividade
			//echo $vExec[$i][0]." |";
			//echo $vExec[$i][1]."<br>";
		}
		//exit();	
		$oExecutores->setVSubatividades($vExec);
		
		$oExecutores->editar();
		
		if (Erros::isError()){
			MostraErros();
		}else{
			header("Location: cadexecutores_sites.php?info=2&numg_site=" . $oExecutores->getNumgSite()."&numg_fase=".$oExecutores->getNumgFase());
			exit;
		}

		break;

	default:
		header("Location: cadexecutores_sites.php"); exit;
		break;
}


?>