<?
include_once "funcoes.php";
include_once "classes/Fases.php";

/**
 * Empresa: Interagi Tecnologia
 * Descri��o:
 * Releases (Data, respons�vel e descri��o [�ltimo release primeiro]):
 *	 26/03/2008 (Danilo Fernandes) 
 *		 
 */

if (empty($_SESSION["NUMG_OPERADOR"]) || $_SESSION["NUMG_OPERADOR"] == ""){
	header("Location: expirou.htm"); exit;
}

switch ($_POST["txtFuncao"]){

	case "cadastrar_fase":

		$oFase = new Fases();
		
		$oFase->setNomeFase($_POST['nomeFase']);
		$oFase->setNumgSite($_POST['numgSite']);

		$oFase->cadastrar();

		if (Erros::isError()){
			MostraErros();
		}else{
			header("Location: cadfases.php?info=1"); exit;
		}

		break;

	case "editar_fase":

		$oFase = new Fases();
		
		$oFase->setNumgFase($_POST['numgFase']);
		$oFase->setNomeFase($_POST['nomeFase']);
		$oFase->setNumgSite($_POST['numgSite']);

		$oFase->editar();

		if (Erros::isError()){
			MostraErros();
		}else{
			header("Location: cadfases.php?info=2&numg_fase=" . $oFase->getNumgFase()); exit;
		}

		break;

	case "excluir_fase":

		$oFase = new Fases();

		$oFase->excluir($_POST["numgFase"]);

		if (Erros::isError()){
			MostraErros();
		}else{
			header("Location: cadfases.php?info=3"); exit;
		}

		break;
		
		
		case "bloquear_fase":

		$oFase = new Fases();
		
		$oFase->setNumgFase($_POST['numgFase']);
		$oFase->setDataBloqueio(now());
		$oFase->setNumgOperadorBloq($_SESSION['NUMG_OPERADOR']);

		$oFase->bloquear();

		if (Erros::isError()){
			MostraErros();
		}else{
			header("Location: cadfases.php?info=1"); exit;
		}

		break;
		
		case "desbloquear_fase":

			$oFase = new Fases();
			
			$oFase->setNumgFase($_POST['numgFase']);
			
			$oFase->desbloquear();
			
			if (Erros::isError()){
				MostraErros();
			}else{ 
				header("Location: cadfases.php?info=1&numg_fase=" . $oFase->getNumgFase()); exit;
			}				
			
		break;
		
	default:
		header("Location: cadfases.php"); exit;
		break;
		
	
		
}


?>