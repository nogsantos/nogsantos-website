<?php 
include_once "funcoes.php";
include_once "classes/Pendencias.php";

/************************************************************************
 Empresa: Interagi Tecnologia

 Descri��o: 
	
 Releases (Data, respons�vel e descri��o [�ltimo release primeiro]):
	 04/08/2005 (Rafael C�cero) 
		 Inclu�do este cabe�alho descrevendo a funcionalidade da p�gina
************************************************************************/

	if (empty($_SESSION["NUMG_OPERADOR"]) || $_SESSION["NUMG_OPERADOR"] == ""){
		header("Location: expirou.htm"); exit;
	}
	
	
	switch ($_POST["txtFuncao"]){
	
		case "cadastrar_pendencia":
			
			$oPendencia = new Pendencias;
			
			$oPendencia->setNumgSite($_POST["cboSite"]);
			$oPendencia->setNumgFase($_POST["cboFase"]);
			$oPendencia->setdescProblema($_POST["descProblema"]);
			$oPendencia->setdescCausa($_POST["descCausa"]);
			$oPendencia->setNumgSubatividade($_POST['numgSubatividade']);
			$oPendencia->setDescSolucao1($_POST["descSolucao1"]);
			$oPendencia->setDescSolucao2($_POST["descSolucao2"]);
			$oPendencia->setDescSolucao3($_POST["descSolucao3"]);
			$oPendencia->setNumrSolucaoindic($_POST["numrSolucaoindic"]);
			$oPendencia->setNumgEmpresaresp($_POST["numgEmpresaresp"]);
			$oPendencia->setNumgOperadorcad($_SESSION["NUMG_OPERADOR"]);
			//$oPendencia->setDataCadastro(date("d/m/Y"));
						
			$oPendencia->cadastrar();
			
			if (Erros::isError()){
				MostraErros();
			}else{ 
				header("Location: cadpendencia.php?info=1&numg_pendencia=" . $oPendencia->getNumgPendencia()); exit;
				//header("Location: cadpendencia.php?info=1&numg_site=" . $oPendencia->getNumgSite()."&numg_fase=".$oPendencia->getNumgFase()); exit;
			}				

		break;
						
		case "editar_pendencia":
			
			$oPendencia = new Pendencias();
			
			$oPendencia->setNumgPendencia($_POST["numgPendencia"]);
			$oPendencia->setNumgSite($_POST["cboSite"]);
			$oPendencia->setNumgFase($_POST["cboFase"]);
			$oPendencia->setdescProblema($_POST["descProblema"]);
			$oPendencia->setdescCausa($_POST["descCausa"]);
			$oPendencia->setNumgSubatividade($_POST["numgSubatividade"]);
			$oPendencia->setDescSolucao1($_POST["descSolucao1"]);
			$oPendencia->setDescSolucao2($_POST["descSolucao2"]);
			$oPendencia->setDescSolucao3($_POST["descSolucao3"]);
			$oPendencia->setNumrSolucaoindic($_POST["numrSolucaoindic"]);
			$oPendencia->setNumgEmpresaresp($_POST["numgEmpresaresp"]);
			$oPendencia->setNumgOperadoralt($_SESSION["NUMG_OPERADOR"]);
			//$oPendencia->setDataUltimaalt(date("d/m/Y"));
			
			
			
			$oPendencia->editar();
			
			if (Erros::isError()){
				MostraErros();
			}else{ 
				header("Location: cadpendencia.php?info=2&numg_pendencia=" . $_POST["numgPendencia"]); exit;
			}				
			
		break;
						
		case "excluir_pendencia":
		
			$oPendencia = new Pendencias();
			
			
			$oPendencia->excluir($_POST["numgPendencia"]);
			
			if (Erros::isError()){
				MostraErros();
			}else{ 
				header("Location: cadpendencia.php?info=3&numg_pendencia=" . $_POST["cboPendencia"]); exit;
			}					
			
		break;

		case "baixar_pendencia":
			$oPendencia = new Pendencias();
			
			$oPendencia->setDataSolucao($_POST['dataSolucao']);
			$oPendencia->setDescSolucaoimpl($_POST['descSolImpl']);
			$oPendencia->setNumgEmpresaexec($_POST['numgEmpresaresp']);
			$oPendencia->setNumgPendencia($_POST['numgPendencia']);
			$oPendencia->setNumgOperadorbaixa($_SESSION["NUMG_OPERADOR"]);
			
			$oPendencia->baixarPendencia();
			
			if (Erros::isError()){
				MostraErros();
			}else{ 
				header("Location: cadpendencia.php?info=4&numg_pendencia=" . $_POST["numgPendencia"]); exit;
			}					
			
		break;
		
		case "liberar_pendencia":
			$oPendencia = new Pendencias();
			
			$oPendencia->setNumgPendencia($_POST['numgPendencia']);
			$oPendencia->setNumgOperadorlib($_SESSION["NUMG_OPERADOR"]);
			
			$oPendencia->liberar();
			
			if (Erros::isError()){
				MostraErros();
			}else{ 
				header("Location: cadpendencia.php?info=5&numg_pendencia=" . $_POST["numgPendencia"]); exit;
			}					
			
		break;
		
		

		default:
			header("Location: cadpendencia.php"); exit;
		break;									
	}

?>