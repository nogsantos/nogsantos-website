<? include_once "funcoes.php"; ?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<title>::: SIGO :::</title>
<link href="estilos.css" rel="stylesheet" type="text/css">
<script language="JavaScript" src="funcoes.js"></script>
<script language="JavaScript">
function iniForm(){	
	MontaFuncoes('<?=$CODG_FORMULARIO; ?>','<?=$NOME_FORMULARIO; ?>','<?=$_SESSION["NUMG_PENDENCIA"]?>')	
	AlteraTab(1,1)		
}

</script>
</head>

<body onLoad="iniForm()" rightmargin="0" marginwidth="0" marginheight="0" leftmargin="0" bottommargin="0" topmargin="0" bgcolor="#FFFFFF">
<form method="post" action="pcadpendencias.php" name="form"> 
	<input name="txtFuncao" type="hidden" value=""> 
			<!-- IN�CIO CAMPOS DO FORMUL�RIO  --> 
		<table>
			<tr> 
				<td> 
					<script language="JavaScript">										
						//montaTabs(Array("Identifica��o"),1)
					</script>
				</td> 
			</tr> 
			<tr>
				<td align="center" class="normal11">
					<strong>Site:</strong> <select name="cboSites" id="cboSites" class="borda"  >
								<option selected="selected" value="">Op��o de Site 1 &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</option>
								<option selected="selected" value="">Op��o de Site 2</option>
						   </select> 
				</td>
			</tr>
			<tr> 
				<td align="left">
					
					<div id="tab1"> 
							<table width="100%"  border="0" cellpadding="2" cellspacing="0" bgcolor="#FFFFFF" class="bordaEsqDirInf"> 
								<tr> 
									<td align="right" class="normal11">
										<strong>Atividade:</strong>
									</td> 
									<td colspan="3" >
										<span class="normal11" > 
											 <select name="cboAtividades" id="cboAtividades" class=borda  >
												<option selected="selected" value="">Atividade 1 </option>
												<option selected="selected" value="">Atividade 2</option>
											 </select>
										</span>
									</td> 
								</tr>
								<tr> 
									<td align="right" class="normal11">
										<strong>Descri��o do Problema:</strong>
									</td> 
									<td colspan="3" >
										<span class="normal11" > 
											 <textarea name="descProblema" id="descProblema" cols="45" rows="2" />
											 </textarea>
										</span>
									</td> 
								</tr> 
								<tr> 
									<td align="right" class="normal11">
										<strong>Descri��o da Causa:</strong>
									</td> 
									<td colspan="3" >
										<span class="normal11" > 
											 <textarea name="descCausa" id="descCausa" cols="45" rows="2" />
											 </textarea>
										</span>
									</td> 
								</tr> 
								<tr>
									<td align="right" class="normal11">
										<strong>Solu��o 1 :</strong>
									</td>
									<td colspan="3">
										<textarea name="descSol1" id="descSol1" cols="45" rows="2" />
										</textarea>
									</td>
								</tr>
								<tr>	
									<td align="right" class="normal11">
										Solu��o 2:
									</td>
									<td colspan="3">
										<textarea name="descSol2" id="descSol2" cols="45" rows="2" />
										</textarea> 
									</td>
								</tr>
								<tr>	
									<td align="right" class="normal11">
										Solu��o 3:
									</td>
									<td colspan="3">
										<textarea name="descSol3" id="descSol3" cols="45" rows="2" />
										</textarea> 
									</td>
								</tr>
								<tr>	
									<td align="right" class="normal11">
										<strong>Solu��o Indicada:</strong>
									</td>
									<td>
										<select name="cboTipoBts" id="cboTipoBts" class=borda  >
											<option selected="selected" value="">Solu��o 1</option>
											<option value="">Solu��o 2</option>
											<option value="">Solu��o 3</option>
										</select> 
									</td>
									<td align="right" class="normal11">
										<strong>Empresa Respons�vel:</strong>
									</td>
									<td>
										<select name="cboEmpresaResp" id="cboEmpresaResp" class=borda  >
											<option selected="selected" value="">Respons�vel 1</option>
											<option value="">Respons�vel 2</option>
											<option value="">Respons�vel 3</option>
										</select> 
									</td>
								</tr>
							</table> 
					   </div>		
					   <div id="tab2">
					   		<table>
								<tr>
									<td align="right" class="normal11">
										<strong>Solu��o Implantada:</strong>
									</td>
									<td colspan="2">
										<select name="cboSolImplantada" id="cboSolImplantada" class=borda  >
											<option selected="selected" value="">Solu��o Implantada 1<? for($i=0;$i<55;$i++){echo"&nbsp;";}?></option>
										</select> 
									</td>
								</tr>
								<tr>
									<td align="right" class="normal11">
										<strong>Empresa Executora:</strong>
									</td>
									<td colspan="2">
										<select name="cboSolImplantada" id="cboSolImplantada" class=borda  >
											<option selected="selected" value="">Empresa Executora 1<? for($i=0;$i<55;$i++){echo"&nbsp;";}?></option>
										</select> 
									</td>
								</tr>
								<tr>
									<td class="normal11" align="right">
										<strong>Data Solu��o:</strong>
									</td>
									<td>
										<input tabindex="13" type="text" maxlength="10" size="13" name="dataSolucao" id="dataSolucao" value="" onkeyup="isNumero(this)" onkeydown="setarFocus(this,'form',event)" onfocus="onFocusFormataData(this)" onblur="onBlurFormataData(this)" class="borda" />
										&nbsp;<img src="imagens/calendario/calendario.gif" onclick="displayCalendar(document.form.dataTermino,'dd/mm/yyyy',document.form.dataTermino)" />&nbsp;
									</td>
								</tr>
								
							</table>
					   </div> 						
				</td>
			</tr>
		</table> 
										
</form> 
</body>
</html>
