<?php
include_once "funcoes.php";
include_once "classes/Funcoes.php";
include_once "classes/Grupos.php";
/************************************************************************
 Empresa: Interagi Tecnologia

 Descri��o:
	
 Releases (Data, respons�vel e descri��o [�ltimo release primeiro]):
	 17/02/2005 (Rafael C�cero) 
		 Inclu�do este cabe�alho descrevendo a funcionalidade da p�gina
						
************************************************************************/
	
	$CODG_FORMULARIO = "cadfuncoes";
	$NOME_FORMULARIO = validarAcesso($CODG_FORMULARIO,$_SESSION["NUMG_OPERADOR"]);


	$oFuncoes = new Funcoes;
	
	if ($_GET["numg_funcao"] != ""){

		$oFuncoes->setarDadosFuncao($_GET["numg_funcao"]);
		if (Erros::isError()) MostraErros();
		
		if ($oFuncoes->getNumgFuncao() != ""){			
			
			//BUSCA AS FUN��ES CADASTRADAS PARA O FORMUL�RIO
			$vFuncoesForm = $oFuncoes->consultarFuncoesForm($oFuncoes->getNumgFormulario());
			if (Erros::isError()) MostraErros();
			
			$oGrupos = new Grupos;
			
			$vGruposDisponiveis = $oGrupos->consultarGruposNaoFuncao($oFuncoes->getNumgFuncao());
			if (Erros::isError()) MostraErros();	
			
			$vGruposFuncao = $oGrupos->consultarGruposFuncao($oFuncoes->getNumgFuncao());
			if (Erros::isError()) MostraErros();
			
			$oGrupos->free;
		
		}
	
	}else if ($_GET["numg_formulario"] != ""){
	
		//BUSCA AS FUN��ES CADASTRADAS PARA O FORMUL�RIO
		$vFuncoesForm = $oFuncoes->consultarFuncoesForm($_GET["numg_formulario"]);
		if (Erros::isError()) MostraErros();
	}


	$oFormularios = new Formularios;
	
	//BUSCA OS FORMUL�RIOS CADASTRADOS NO SISTEMA	
	$vFormularios = $oFormularios->consultarFormularios();
	if (Erros::isError()) MostraErros();				
	
	$oFormularios->free;
	
?>

<html>
<head>

<title>Sigo - Cadastro de Fun��es de Formul�rios</title>

<link href="estilos.css" rel="stylesheet" type="text/css">

<script type="text/javascript" src="javascripts/prototype.js"> </script>
<SCRIPT language=JavaScript src="funcoes.js"></SCRIPT>
<script type="text/javascript" src="javascripts/populacombo.js"></script>

<SCRIPT language=JavaScript>
function iniForm(){
	MontaFuncoes('<?=$CODG_FORMULARIO; ?>','<?=$NOME_FORMULARIO; ?>','<?=$oFuncoes->getNumgFuncao()?>')
	AlteraTab(1,2)
	AlteraBotao('<?=$oFuncoes->getNomeIcone()?>')
	document.form.cboFormularios.focus()
}

function AlteraBotao(nome) {
	oImage = eval("document.icone")
	if (nome != "")
		oImage.src = "imagens/botoes/" + nome
	else
		oImage.src = "imagens/space.gif"
}
</script>

</head>
<body onLoad="iniForm()" rightmargin="0" marginwidth="0" marginheight="0" leftmargin="0" bottommargin="0" topmargin="0" bgcolor="#FFFFFF">

<table border=0 width=100% align=center cellspacing=0 cellpadding=0>
	<tr>
		<td><img src="imagens/space.gif" border=0 height=10></td>
	</tr>
	<tr>
		<td align=center>
			<table border=0 width=600 cellspacing=0 cellpadding=0>
				<tr>
					<td><img src="imagens/formEsqSup.gif" border=0 width=10 height=10></td>
					<td background="imagens/formMidSup.gif"></td>
					<td><img src="imagens/formDirSup.gif" border=0 width=10 height=10></td>
				</tr>
				<tr valign=top>
					<td width=10 background="imagens/formEsqMid.gif"></td>
					<td>
						<table border=0 width=100% cellspacing=0 cellpadding=0 align=center background="imagens/formMid.gif">
						<form method="post" action="pcadfuncoes.php" name="form" id="form">
							<input type=hidden name=txtFuncao id="txtFuncao" value="">
							<input type=hidden name=txtNumgFuncao id="txtNumgFuncao" value="<?=$oFuncoes->getNumgFuncao()?>">
							
							<!-- IN�CIO CAMPOS DO FORMUL�RIO  -->
							<?php if ($_GET["info"] != ""){?>
							<tr>
								<td colspan=4 align=center height=20 valign=middle class=normal11>
								<img src="imagens/icones/info.gif" border=0 align=absbottom>&nbsp;&nbsp;
								<?php 		
									switch ($_GET["info"]){
										case 1:
											echo "Cadastro de fun��o realizado com sucesso";
											break;
										case 2:
											echo "Edi��o de dados realizada com sucesso";
											break;
										case 3:
											echo "Exclus�o de fun��o realizada com sucesso";
											break;
										case 4:
											echo "Bloqueio de fun��o realizada com sucesso";
											break;
										case 5:
											echo "Desbloqueio de fun��o realizada com sucesso";
											break;
										case 6:
											echo "Inclus�o de grupo para fun��o realizado com sucesso";
											break;
										case 7:
											echo "Exclus�o de grupo da fun��o realizado com sucesso";
											break;
									} ?>
								</td>
							</tr>
							<?php }?>				
							<tr>
								<td colspan=4>
									<table border=0 width=580 cellspacing=0 cellpadding=2>
										<tr>
											<td width=20% align=right class=normal11b>Formul�rio:</td>
											<TD width=80%>
												<select name=cboFormularios id="cboFormularios" class=borda style="width:435" onChange="window.location.href = 'cadfuncoes.php?numg_formulario=' + document.form.cboFormularios.value">
													<option value="">
													<?php 
													if ($vFormularios->getCount() > 0){
													for ($i=0; $i<$vFormularios->getCount(); $i++){?>
													<option value="<?=$vFormularios->getValores($i,"numg_formulario");?>" <?php if ($oFuncoes->getNumgFormulario() == $vFormularios->getValores($i,"numg_formulario") || $_GET["numg_formulario"] == $vFormularios->getValores($i,"numg_formulario")) echo "selected";?>><?=RetornaAgrupamento($vFormularios->getValores($i,"numr_agrupamento")) . " - " . $vFormularios->getValores($i,"nome_formulario");?>
													<?php }	}?>
												</select>
											</TD>
										</tr>
									</table>
								</td>
							</tr>
							<tr>
								<td height=10></td>
							</tr>
							<tr>
								<td colspan=4>
									<script language="JavaScript">										
										montaTabs(Array("Dados Gerais","Grupos de Acesso","",""),2)
									</script>
								</td>
							</tr>
							<tr>
								<td colspan=4>
									<div id="tab1">
									<table border=0 width=580 cellspacing=0 cellpadding=2 align=center class=bordaEsqDirInf>
										<tr>
											<td height=10></td>
										</tr>
										<tr>
											<td align=right class=normal11b>C�digo:</td>
											<TD colspan=3>
												<table border=0 width=100% cellspacing=0 cellpadding=0>
													<tr>
														<TD width=50%><INPUT type="text" name="txtCodgFuncao" id="txtCodgFuncao" value='<?=$oFuncoes->getCodgFuncao()?>' size=30 maxlength=50 class=borda onKeyPress="SetFocus(document.form.txtNomeFuncao)"></TD>
														<TD width=50%>
															<?php if ($oFuncoes->getDataCadastro() != "" && !is_null($oFuncoes->getDataCadastro())){?>
															<table border=0 width=202 cellspacing=0 cellpadding=0>
																<tr>
																	<td align=right class=normal11>cadastrado em: <b><?=$oFuncoes->getDataCadastro()?></b> [<?=$oFuncoes->getNomeOperadorCad()?>]</td>
																</tr>
															</table>
															<?php }?>
														</TD>
													</tr>
												</table>
											</td>
										</tr>
										<tr>
											<td align=right class=normal11b>Nome:</td>
											<TD colspan=3><INPUT type="text" name="txtNomeFuncao" id="txtNomeFuncao" value='<?=$oFuncoes->getNomeFuncao()?>' size=70 maxlength=50 class=borda onKeyPress="SetFocus(document.form.txtDescFuncao)"></TD>
										</tr>
										<tr valign=top>
											<td align=right class=normal11b>Descri��o:</td>
											<TD colspan=3><textarea name="txtDescFuncao" id="txtDescFuncao" rows=3 cols=69 class=borda onKeyUp="LimitaCampo(this,255)"><?=$oFuncoes->getDescFuncao()?></textarea></TD>
										</tr>
										<tr>
											<td width=20% align=right class=normal11b>�cone:</td>
											<TD colspan=3>
												<table border=0 width=437 cellspacing=0 cellpadding=0>
													<tr>
														<td width=50% class=normal11>
															<select name=cboIcones id="cboIcones" class=borda style="width:165" onChange="AlteraBotao(document.form.cboIcones.value)">
																<option value="">
																<option value="gravar.gif"			<?php if ($oFuncoes->getNomeIcone() == "gravar.gif") echo "selected"?>>gravar.gif
																<option value="excluir.gif"     	<?php if ($oFuncoes->getNomeIcone() == "excluir.gif") echo "selected"?>>excluir.gif
																<option value="bloquear.gif"    	<?php if ($oFuncoes->getNomeIcone() == "bloquear.gif") echo "selected"?>>bloquear.gif
																<option value="desbloquear.gif" 	<?php if ($oFuncoes->getNomeIcone() == "desbloquear.gif") echo "selected"?>>desbloquear.gif
																<option value="novo.gif"			<?php if ($oFuncoes->getNomeIcone() == "novo.gif") echo "selected"?>>novo.gif
																<option value="gerar.gif"			<?php if ($oFuncoes->getNomeIcone() == "gerar.gif") echo "selected"?>>gerar.gif
																<option value="imprimir.gif"		<?php if ($oFuncoes->getNomeIcone() == "imprimir.gif") echo "selected"?>>imprimir.gif
																<option value="gerar_cobranca.gif"	<?php if ($oFuncoes->getNomeIcone() == "gerar_cobranca.gif") echo "selected"?>>gerar_cobranca.gif
																<option value="gerar_arquivo.gif"	<?php if ($oFuncoes->getNomeIcone() == "gerar_arquivo.gif") echo "selected"?>>gerar_arquivo.gif
															</select>&nbsp;<img src="imagens/space.gif" border=0 name=icone align=absmiddle>
														</td>
														<td width=50% align=right class=normal11>Fun��o para Novo Registro<input type=checkbox name=chkFlagNovoRegistro id="chkFlagNovoRegistro" value=1 <?php if ($oFuncoes->getFlagNovoRegistro() == "t") echo "checked"?>></td>
													</tr>
												</table>
											</TD>
										</tr>
										<tr>
											<td class=normal11b align=right>Ordem:</td>
											<td colspan=3>
												<table border=0 width=437 cellspacing=0 cellpadding=0>
													<tr>
														<td width=50% class=normal11><INPUT type="text" name="txtNumrOrdem" id="txtNumrOrdem" value='<?=$oFuncoes->getNumrOrdem()?>' size=10 maxlength=2 class=borda onKeyPress="SetFocus(document.form.txtNumrOrdem)"></td>
														<td width=50% align=right class=normal11>Fun��o P�blica<input type=checkbox name=chkFlagPublica id="chkFlagPublica" value=1 <?php if ($oFuncoes->getFlagPublica() == "t") echo "checked"?>></td>
													</tr>
												</table>
											</td>
										</tr>
										<?php if ($oFuncoes->getDataBloqueio() != "" && !is_null($oFuncoes->getDataBloqueio())){?>
										<tr>
											<td></td>
											<td colspan=3 class=normal11><img src="imagens/icones/excla.gif" border=0 align=absbottom>&nbsp;Fun��o bloqueada em: <b><?=$oFuncoes->getDataBloqueio()?></b> [<?=$oFuncoes->getNomeOperadorBloq()?>]</td>
										</tr>
										<?php }?>
										<tr>
											<td height=10></td>
										</tr>
									</table>
									</div>

									<div id="tab2">
									<table border=0 width=580 cellspacing=0 cellpadding=2 align=center class=bordaEsqDirInf>
										<tr>
											<td height=10></td>
										</tr>
										<tr class=normal11b height=15>
											<td width=5%></td>
											<td width=45%>Grupos dispon�veis</td>
											<td width=45% align=right>Grupos de acesso a fun��o</td>
											<td width=5%></td>
										</tr>
										<tr>
											<td></td>
											<td>
												<select name="cboGruposDisponiveis[]" id="cboGruposDisponiveis[]" multiple class=borda size=9 style="width:230">
												<?php 
												if (isset($vGruposDisponiveis)){ 
													if ($vGruposDisponiveis->getCount() > 0){
														for ($i=0; $i<$vGruposDisponiveis->getCount(); $i++){?>
														<option value="<?=$vGruposDisponiveis->getValores($i,"numg_grupo")?>"><?=$vGruposDisponiveis->getValores($i,"nome_grupo")?>
													<?php }
													} 
												}?>
												</select>
											</td>
											<td align=right>
												<select name="cboGruposFuncao[]" id="cboGruposFuncao[]"  multiple class=borda size=9 style="width:230">
												<?php 
												if (isset($vGruposFuncao)){
													if ($vGruposFuncao->getCount() > 0){
														for ($i=0; $i<$vGruposFuncao->getCount(); $i++){?>
														<option value="<?=$vGruposFuncao->getValores($i,"numg_grupo")?>"><?=$vGruposFuncao->getValores($i,"nome_grupo")?>
													<?php }
													}	
												}?>
												</select>
											</td>
											<td></td>
										</tr>
										<tr>
											<td height=10></td>
										</tr>
									</table>
									</div>
								</td>
							</tr>
							<!-- FIM CAMPOS DO FORMUL�RIO  -->
							
						</form>
						</table>
					</td>
					<td width=10 background="imagens/formDirMid.gif"></td>
				</tr>
				<tr>
					<td><img src="imagens/formEsqInf.gif" border=0 width=10 height=10></td>
					<td background="imagens/formMidInf.gif"></td>
					<td><img src="imagens/formDirInf.gif" border=0 width=10 height=10></td>
				</tr>
			</table>
		</td>
	</tr>
	
	<?php 
	if (isset($vFuncoesForm)){
	if ($vFuncoesForm->getCount() > 0){?>
	<tr>
		<td>
			<table border=0 width=95% cellspacing=0 cellpadding=0 align=center>
				<tr>
					<td colspan=4 class=normal11 height=25 valign=bottom>Rela��o de Fun��es cadastradas para o Formul�rio:</td>
				</tr>
				<tr height=20 class=normal11b align=center>
					<td background="imagens/fundoBarraRelatorio.gif" width=25%>C�digo</td>
					<td background="imagens/fundoBarraRelatorio.gif" width=33%>Fun��o</td>
					<td background="imagens/fundoBarraRelatorio.gif" width=16%>Novo Registro?</td>
					<td background="imagens/fundoBarraRelatorio.gif" width=10%>P�blica?</td>
					<td background="imagens/fundoBarraRelatorio.gif" width=16%>Data Bloqueio</td>
				</tr>
				<?php for ($i=0; $i<$vFuncoesForm->getCount(); $i++){?>
				<tr height=20 <?php if ($i % 2 == 1){?>bgcolor="#E8E8E8"<?php }?> class=relatorio>
					<td><a href="cadfuncoes.php?numg_funcao=<?=$vFuncoesForm->getValores($i,"numg_funcao");?>" class=relatorio><?=$vFuncoesForm->getValores($i,"numr_ordem") . " - " . $vFuncoesForm->getValores($i,"codg_funcao");?></a></td>
					<td><?=$vFuncoesForm->getValores($i,"nome_funcao");?></td>
					<td align=center><?php if ($vFuncoesForm->getValores($i,"flag_novoregistro") == "t") echo "<span class=destaque>sim</span>"; else echo "n�o";?></td>
					<td align=center><?php if ($vFuncoesForm->getValores($i,"flag_publica") == "t") echo "<span class=destaque>sim</span>"; else echo "n�o";?></td>
					<td align=center><?=FormataData($vFuncoesForm->getValores($i,"data_bloqueio"));?></td>
				</tr>
				<?php }?>
				<tr height=20 <?php if (i % 2 == 1){?>bgcolor="#E8E8E8"<?php }?>>
					<td colspan=4 class=destaque>* Clique no c�digo da fun��o para edit�-la</td>
					<td class=normal11b align=right>TOTAL: <?=$vFuncoesForm->getCount(); ?></td>
				</tr>
			</table>
		</td>
	</tr>
	<?php } }?>
	<tr>
		<td><img src="imagens/space.gif" border=0 height=10></td>
	</tr>
</table>

<script language="JavaScript">
function novo_funcao(){
	window.location.href = '<?=$CODG_FORMULARIO;?>.php?numg_formulario=<?=$oFuncoes->getNumgFormulario()?>'
}

function cadastrar_funcao(){
	if (document.form.txtNumgFuncao.value == ""){
		if (pValidaGravacao()){
			
				document.form.txtFuncao.value = "cadastrar_funcao"
				document.form.submit()
			
		}
	}else{
		alert("Fun��o de CADASTRO n�o dispon�vel para este formul�rio!")
	}
	
}

function editar_funcao(){
	if (document.form.txtNumgFuncao.value != ""){
		if (pValidaGravacao()){
				document.form.txtFuncao.value = "editar_funcao"
				document.form.submit()

		}
	}else{ 
		alert("Fun��o de EDI��O n�o dispon�vel para este formul�rio!")
	}

}

function excluir_funcao(){
	if (document.form.txtNumgFuncao.value != ""){
		if (confirm("Confirma a EXCLUS�O da Fun��o?")){
			document.form.txtFuncao.value = "excluir_funcao"
			document.form.submit()
		}
	}else{ 
		alert("Fun��o de EXCLUS�O n�o dispon�vel para este formul�rio!")
	}
}

function bloquear_funcao(){
	<?php if ($oFuncoes->getDataBloqueio() == ""){?>
	if (document.form.txtNumgFuncao.value != ""){
			document.form.txtFuncao.value = "bloquear_funcao"
			document.form.submit()

	}else{ 
		alert("Fun��o de BLOQUEIO n�o dispon�vel para este formul�rio!")
	}
	<?php }else{?>
	alert("Fun��o de BLOQUEIO n�o dispon�vel! A fun��o j� encontra-se bloqueada.")
	<?php }?>

}

function desbloquear_funcao(){
	<?php if ($oFuncoes->getDataBloqueio() != ""){?>
	if (document.form.txtNumgFuncao.value != ""){
			document.form.txtFuncao.value = "desbloquear_funcao"
			document.form.submit()
		
	}else{ 
		alert("Fun��o de DESBLOQUEIO n�o dispon�vel para este formul�rio!")
	}
	<?php }else{?>
	alert("Fun��o de DESBLOQUEIO n�o dispon�vel! A fun��o j� encontra-se desbloqueada.")
	<?php }?>

}

function cadastrar_grupofunc(){	
	if ($F("txtNumgFuncao") != ""){
		if ($F("cboGruposDisponiveis[]") == ""){
			alert("Selecione um Grupo na lista de Grupos dispon�veis.");
			AlteraTab(2,2);
			$("cboGruposDisponiveis[]").focus();
		}else{
			
				$("txtFuncao").value = "cadastrar_grupofunc";
				$("form").submit();
			
		}
	}else{
		alert("Fun��o de CADASTRO DE GRUPO n�o dispon�vel para este formul�rio!");
	}	
}

function excluir_grupofunc(){
	if ($F("txtNumgFuncao") != ""){
		if ($F("cboGruposFuncao[]") == ""){
			alert("Selecione um Grupo na lista de Grupos de acesso a fun��o.");
			AlteraTab(2,2);
			$("cboGruposFuncao[]").focus();
		}else{
			
				$("txtFuncao").value = "excluir_grupofunc";
				$("form").submit();
			
		}
	}else{
		alert("Fun��o de CADASTRO DE GRUPO n�o dispon�vel para este formul�rio!");
	}
	
}

function pValidaGravacao(){
	
	var sErr = ""
	
	//...
	
	//VERIFICA SE FOI ENCONTRADO ALGUM ERRO NA VALIDA��O DO FORMUL�RIO
	if (sErr != ""){
		sErr = "Verifique os erros encontrados abaixo:\n\n" + sErr
		alert(sErr)	
		return false
	}else
		return true
}
</script>

<?php $oFuncoes->free;?>

</body>

<head>
<META HTTP-EQUIV="Pragma" CONTENT="no-cache">
<META HTTP-EQUIV="Expires" CONTENT="-1">
</head>

</html>