/**
 * PopulaCombo
 * @copyright � 2007, Jean Moreira
 * @author Jean Moreira
 * @version 1.0
 */

var PopulaCombo = Class.create();
PopulaCombo.prototype = {

	/**
	 * @param {Object} bindField ID of form element, or dom element,  to suggest on
	 * @param {String} URL of dictionary
	 * @param {Object} ID do campo do formul�rio ou do elemento DOM para resposta
	 * @param {Object} options
	 */
	initialize: function(comboBusca, action, comboResposta, options)
	{
		this.options = Object.extend({
			/**
			 * @param {Number} Number of options to display before scrolling
			 */
			size: 1,
			/**
			 * @param {String} CSS class name for autocomplete selector
			 */
			cssClass: null,
			/**
			 * @param {Object} JavaScript callback function to execute upon selection
			 */
			onSelect: null,
			/**
			 * @param {Number} minimum characters needed before an suggestion is executed
			 */
			threshold: 3,
			/**
			 * @param {Number} Time delay between key stroke and execution
			 */
			delay: .2,
			/**
			 * @param {Object} Objeto para filtrar a busca
			 */
			filtroField: null,
			/**
			 * @param {String} variavel que vai por get
			 */
			filtroParametro: "",
			/**
			 * @param {String} variavel que vai por get
			 */
			incluirOptVazia: false
		}, options);

		this.action = action;
		this.comboBusca = comboBusca;
		this.comboResposta = comboResposta;

		this._elements = {
			comboBusca: $(this.comboBusca),
			comboResposta: $(this.comboResposta),
			filtroField: $(this.options.filtroField)
		};

		if(!this._elements.comboBusca)
			alert('Falha campo [' + this.options.comboBusca + '] n�o encontrado no formul�rio!');

		if(!this._elements.comboResposta)
			alert('Falha campo [' + this.options.comboResposta + '] n�o encontrado no formul�rio!');
		
		if(!this.action)
			alert('URL de a��o n�o especificada!');		
		
		this._timeout = null;
		
		this.initialized = false;		
		
		Event.observe(window, 'load', this.draw.bind(this));
	},
	/**
	 * Initializes the UI components of the object
	 * @param {Object} e Event
	 */
	draw: function(e)
	{		
		if(this.initialized) return;		
		
		Event.observe(this._elements.comboBusca, 'change', this.suggest.bindAsEventListener(this));
		
		this.initialized = true;
	},

	hide: function(e)
	{
		//tenho que ver o que eu coloco aqui
	},

	show: function(e)
	{
		//tenho que ver o que eu coloco aqui
	},

	/**
	 * Removes the timeout function set by suggest
	 */
	_cancelTimeout: function()
	{
		if(!this._timeout) return;
		clearTimeout(this._timeout);
		this._timeout = null;
	},

	/**
	 * Triggers the suggest interaction
	 * @param {Object} e Event
	 */
	suggest: function(e)
	{
		this._cancelTimeout();
		
		if(this._elements.comboBusca.value == "") {
			//Retira a mensagem "Realizando a consulta..." na comboResposta
			this._elements.comboResposta.options.length = 0;
			return true;
		} else {
			this._timeout = setTimeout(this._sendRequest.bind(this), 1000 * this.options.delay);
		}

	},

	_sendRequest: function()
	{
		//Colaca a mensagem "Realizando a consulta..." na comboResposta
		this._elements.comboResposta.options.length = 0;
		var opt = new Option("Realizando a consulta...", "");
		document.all ? this._elements.comboResposta.add(opt) : this._elements.comboResposta.add(opt, null);
		
		var url = "";
		
		if(this._elements.filtroField == null){
			url = this.action + this._elements.comboBusca.value;
		} else {
			url = this.action + this._elements.comboBusca.value + "&" + this.options.filtroParametro + "=" + this._elements.filtroField.value;
		}

		this._request = new Ajax.Request(url, {
			onComplete: this._process.bind(this)
		});
		
	},
	/**
	 * Processes the resulting XML from a suggestion request, adds options to the suggestion box.
	 * @param {Object} objXML XML
	 */
	_process: function(obj)
	{
		try{			
			var suggestions=eval(obj.responseText);
		} catch(e){
			if(obj.responseText == "isError"){
				document.location.href = document.location.href;
			} else {
				alert("Populacombo: falha na execu��o da opera��o!");
				//alert("Erros: " + obj.responseText); //desmarque para debug
			}
			return false;
		}
				
		//Retira a mensagem "Realizando a consulta..." na comboResposta
		this._elements.comboResposta.options.length = 0;
		
		if(this.options.incluirOptVazia){
			var optVazia = new Option("", "");
			document.all ? this._elements.comboResposta.add(optVazia) : this._elements.comboResposta.add(optVazia, null);
		}
		
		for(i = 0; i < suggestions.length; i++)
		{		
			suggestion = unescape(suggestions[i]);
			suggestion = suggestion.split("|");

			var value = "";
			var text = "";
			
			//Pega o value que sempre � o primeiro do vetor
			value = suggestion[0];
			
			for(var j = 1; j < suggestion.length; j++)
				text += suggestion[j] + " - ";
			
			//retirando o " - " do final da string
			text = text.substring(0,text.length - 3);
			
			var opt = new Option(text, value);
			document.all ? this._elements.comboResposta.add(opt) : this._elements.comboResposta.add(opt, null);
		}
		
		if(this._elements.comboResposta.options.length)		
			this._elements.comboResposta.selectedIndex = 0;		
		else
			this.cancel();
	},

	/**
	 * Clears and hides the suggestion box.
	 * @param {Object} e Event
	 */
	cancel: function(e)
	{
		this._elements.comboResposta.options.length = 0;		
	}
};