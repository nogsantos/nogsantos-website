<html>
<head>
<title>FOTO</title>
<meta http-equiv="Content-Type" content="text/html;">
</head>
<body bgcolor="#ffffff" leftmargin="0" topmargin="0" bottommargin="0" rightmargin="0">
	<table align="center" cellpadding="0" cellspacing="0">
		<tr>
			<td><img src="<?php echo $_GET["img"];?>" alt=""></td>
		</tr>		
	</table>
</body>
</html>
