<?php
include_once "funcoes.php";
include_once "classes/Sites.php";
include_once("classes/Fases.php");
include_once("classes/Operadores.php");
include_once("classes/Executores.php");
/**
 * Empresa: Interagi Tecnologia
 * Descri��o:
 * Releases (Data, respons�vel e descri��o [�ltimo release primeiro]):
 *	 31/08/2008 (Danilo Fernanades) 
 *		 Inclu�do este cabe�alho descrevendo a funcionalidade da p�gina
 */

$CODG_FORMULARIO = "relexec";
$NOME_FORMULARIO = validarAcesso($CODG_FORMULARIO,$_SESSION["NUMG_OPERADOR"]);


$oOperador = new Operadores();
$oExecutores = new Executores();


$vExecutores = new Resultset();

$vExecutores = $oExecutores->consultarEmpresas();

$oOperador->setarDadosOperador($_SESSION["NUMG_OPERADOR"]);

?>

<html>
<head>

<title>SIGO - Relat�rio de Desempenho das Empresas Executoras</title>

<link href="estilos.css" rel="stylesheet" type="text/css">

<script language="JavaScript" src="funcoes.js"></script>

<script type="text/javascript" src="javascripts/prototype.js"> </script>
<script type="text/javascript" src="javascripts/funcoes.js"> </script>
<script type="text/javascript" src="javascripts/populacombo.js"></script>

<script language="JavaScript">
function iniForm(){
	MontaFuncoes('<?=$CODG_FORMULARIO?>','<?=$NOME_FORMULARIO?>','1')
	
}
</script>

</head>
<body onLoad="iniForm()" rightmargin="0" marginwidth="0" marginheight="0" leftmargin="0" bottommargin="0" topmargin="0" bgcolor="#FFFFFF">

<table border=0 width=100% align=center cellspacing=0 cellpadding=0>
	<tr>
		<td><img src="imagens/space.gif" border=0 height=10></td>
	</tr>
	<tr>
		<td align=center>
			<table border=0 width=600 cellspacing=0 cellpadding=0>
				<tr>
					<td><img src="imagens/formEsqSup.gif" border=0 width=10 height=10></td>
					<td background="imagens/formMidSup.gif"></td>
					<td><img src="imagens/formDirSup.gif" border=0 width=10 height=10></td>
				</tr>
				<tr valign=top>
					<td width=10 background="imagens/formEsqMid.gif"></td>
					<td>
						<table border=0 width=100% cellspacing=0 cellpadding=2 align=center background="imagens/formMid.gif">
						<form method="post" action="prelexec.php" name="form" id="form">
							<tr>
								<td height=30 valign=top class=normal11b>Crit�rios dispon�veis para gera��o do relat�rio:</td>
							</tr>
							<tr>
								<td align=center>
									<table border=0 width=90% cellspacing=0 cellpadding=2 align=center>
										<tr class=normal11b>
											<td><INPUT type='radio' name=rdoOpcao value="1" checked></td>
											<td colspan="2">1 - Relat�rio de N�o Conformidade da Executora</td>
										</tr>
										<tr height=30>
											<td width=5%>&nbsp;</td>
											<td width=50% class=normal11>Pela Empresa</td>
											<TD width=45%>
												<select tabindex="1" id="numgEmpresa" name="numgEmpresa" class="borda" style="width:300px">
													<? montaCombo($vExecutores,"numg_empresa","nome_empresa","",true);?>
												</select>
											</TD>
										</tr>
										<tr height=30>
											<td>&nbsp;</td>
											<td class=normal11>Pelo PER�ODO</td>
											<TD class=normal11>de&nbsp;&nbsp;
												<INPUT tabindex="4" type="text" name="dataCadastroInicial" size=15 maxlength=10 class=datavalor onBlur="onBlurFormataData(this)">&nbsp;&nbsp;&nbsp;a&nbsp;&nbsp;
												<INPUT tabindex="5" type="text" name="dataCadastroFinal" size=15 maxlength=10 class=datavalor onBlur="onBlurFormataData(this)">
											</TD>
										</tr>
									</table>
								</td>
							</tr>
						</table>
					</td>
					<td width=10 background="imagens/formDirMid.gif"></td>
				</tr>
				<tr>
					<td><img src="imagens/formEsqInf.gif" border=0 width=10 height=10></td>
					<td background="imagens/formMidInf.gif"></td>
					<td><img src="imagens/formDirInf.gif" border=0 width=10 height=10></td>
				</tr>
			</table>
		</td>
	</tr>
</table>

<script language="JavaScript">
function gerar_exec(){
	if (pValidaGeracao()){
		document.form.submit()
	}
}

function pValidaGeracao(){

	var sErr = ""

	if (Trim(form.numgEmpresa.value) == "" && Trim(form.numgEmpresa.value) == "" && Trim(form.dataCadastroInicial.value) == "" && Trim(form.dataCadastroFinal.value) == "" )
	sErr = "Preencha alguma das op��es dispon�veis para gera��o do relat�rio!\n"

	if (Trim(form.dataCadastroInicial.value) != "" || Trim(form.dataCadastroFinal.value) != ""){

		var dataCadIni = form.dataCadastroInicial.value
		var dataCadFim = form.dataCadastroFinal.value

		//A DATA FINAL N�O PODE SER INFERIOR � DATA INICIAL
		if ((dataCadFim.substring(6) + dataCadFim.substring(3,5) + dataCadFim.substring(0,2)) < (dataCadIni.substring(6) + dataCadIni.substring(3,5) + dataCadIni.substring(0,2)))
		sErr = sErr + "A data final n�o pode ser inferior � data inicial!\n"

	}


	//VERIFICA SE FOI ENCONTRADO ALGUM ERRO NA VALIDA��O DO FORMUL�RIO
	if (sErr != ""){
		sErr = "Verifique os erros encontrados abaixo:\n\n" + sErr
		alert(sErr)
		return false
	}else
	return true
}

</script>

</body>
</html>