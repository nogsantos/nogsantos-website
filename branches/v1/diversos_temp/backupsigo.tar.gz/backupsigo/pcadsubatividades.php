<?php 
include_once "funcoes.php";
include_once "classes/Subatividades.php";

/************************************************************************
 Empresa: Interagi Tecnologia

 Descri��o: 
	
 Releases (Data, respons�vel e descri��o [�ltimo release primeiro]):
	 04/08/2005 (Rafael C�cero) 
		 Inclu�do este cabe�alho descrevendo a funcionalidade da p�gina
************************************************************************/

	if (empty($_SESSION["NUMG_OPERADOR"]) || $_SESSION["NUMG_OPERADOR"] == ""){
		header("Location: expirou.htm"); exit;
	}
	
	switch ($_POST["txtFuncao"]){
	
		case "cadastrar_subatividade":
			
			$oSubatividade = new Subatividades;
			
			$oSubatividade->setNumgAtividade($_POST["cboAtividade"]);
			$oSubatividade->setNomeSubatividade($_POST["nomeSubatividade"]);
			
			
			$oSubatividade->cadastrar();
			
			if (Erros::isError()){
				MostraErros();
			}else{ 
				header("Location: cadsubatividades.php?info=1&numg_atividade=" . $oSubatividade->getNumgAtividade()); exit;
			}				

		break;
						
		case "editar_subatividade":
			
			$oSubatividade = new Subatividades;
			
			$oSubatividade->setNumgSubatividade($_POST["txtNumgSubatividade"]);
			$oSubatividade->setNumgAtividade($_POST["cboAtividade"]);
			$oSubatividade->setNomeSubatividade($_POST["nomeSubatividade"]);
			
			
			
			$oSubatividade->editar();
			
			if (Erros::isError()){
				MostraErros();
			}else{ 
				header("Location: cadsubatividades.php?info=2&numg_atividade=" . $_POST["cboAtividade"]."&numg_subatividade=" . $_POST["txtNumgSubatividade"]); exit;
			}				
			
		break;
						
		case "excluir_subatividade":
		
			$oSubatividade = new Subatividades;
			
			$oSubatividade->excluir($_POST["txtNumgSubatividade"]);
			
			if (Erros::isError()){
				MostraErros();
			}else{ 
				header("Location: cadsubatividades.php?info=3&numg_atividade=" . $_POST["cboAtividade"]); exit;
			}					
			
		break;
		
		case "bloquear_subatividade":
	
			$oSubatividade = new Subatividades;
			
			$oSubatividade->setNumgSubatividade($_POST["txtNumgSubatividade"]);
			$oSubatividade->setNumgAtividade($_POST["cboAtividade"]);
			$oSubatividade->setDatabloqueio(now());
			$oSubatividade->setNumgOperadorbloqueio($_SESSION["NUMG_OPERADOR"]);
			$oSubatividade->bloquear();
			
	
			if (Erros::isError()){
				MostraErros();
			}else{
				header("Location: cadsubatividades.php?info=4&numg_atividade=" . $_POST["cboAtividade"] ."&numg_subatividade=". $oSubatividade->getNumgSubatividade()); exit;
			}

		break;

	case "desbloquear_subatividade":

		$oSubatividade = new Subatividades;
				
		$oSubatividade->setNumgSubatividade($_POST["txtNumgSubatividade"]);
		$oSubatividade->setNumgAtividade($_POST["cboAtividade"]);
		$oSubatividade->desbloquear();

		if (Erros::isError()){
			MostraErros();
		}else{
			header("Location: cadsubatividades.php?info=5&numg_atividade=" . $_POST["cboAtividade"] ."&numg_subatividade=". $oSubatividade->getNumgSubatividade()); exit;
		}

		break;
		

		default:
			header("Location: cadsubatividades.php"); exit;
		break;									
	}

?>