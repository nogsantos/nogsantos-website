<?php
include_once "funcoes.php";
include_once "classes/Pendencias.php";
include_once "classes/Sites.php";
include_once "classes/Fases.php";
include_once "classes/Empresas.php";
include_once "classes/Subatividades.php";
include_once "classes/Operadores.php";

/************************************************************************
Empresa: Interagi Tecnologia

Descri��o:

Releases (Data, respons�vel e descri��o [�ltimo release primeiro]):
05/04/2005 (Augusto Rabelo)
Inclu�do este cabe�alho descrevendo a funcionalidade da p�gina

************************************************************************/

$CODG_FORMULARIO = "cadpendencia";
$NOME_FORMULARIO = validarAcesso($CODG_FORMULARIO,$_SESSION["NUMG_OPERADOR"]);

//Objeto das classes
$oSites = new Sites();
$oPendencia = new Pendencias();
$oFase = new Fases();
$oEmpresa = new Empresas();
$oSubatividade = new Subatividades();
$oOperador = new Operadores();

//Resultsets
$vEmpresas = new Resultset();
$vFases = new Resultset();
$vPendencias = new Resultset();
$vSites = new Resultset();
$vAtividades = new Resultset();

$vAtividades = $oSubatividade->consultarSubAtiv();

//Consultas Gerais
$vSites = $oSites->consultarTodas();
$vEmpresas = $oEmpresa->consultarEmpresas();


if ($_GET["numg_pendencia"] != "" ){

	$oPendencia->setarDados($_GET["numg_pendencia"]);
	
	if($oPendencia->getNumgFase() != ""){
		$vPendencias = $oPendencia->consultarPorSiteFase($oPendencia->getNumgSite(),$oPendencia->getNumgFase());
		
	}
	if (Erros::isError()) MostraErros();
	
	
}
if ($_GET["numg_site"] != "" || $oPendencia->getNumgSite() != ""){
		
	
	if($_GET['numg_fase'] != "" ){
		$vPendencias = $oPendencia->consultarPorSiteFase($_GET['numg_site'],$_GET['numg_fase']);
		if (Erros::isError()) MostraErros();
	}
	if($oPendencia->getNumgFase() != ""){
		$vPendencias = $oPendencia->consultarPorSiteFase($oPendencia->getNumgSite(),$oPendencia->getNumgFase());
		if (Erros::isError()) MostraErros();
	}

}
if($_GET["numg_site"] != ""){
	$vFases = $oFase->consultarDesblPorSite($_GET["numg_site"]);
}
if($oPendencia->getNumgSite() != ""){
	$vFases = $oFase->consultarDesblPorSite($oPendencia->getNumgSite());
}



?>
<html>
<head>
<title>Sigo - Cadastro de Pendencias </title>
<link href="estilos.css" rel="stylesheet" type="text/css">
<SCRIPT language=JavaScript src="prototype.js"></SCRIPT>
<SCRIPT language=JavaScript src="funcoes.js"></SCRIPT>

<SCRIPT language="JavaScript">

function novo_pendencia(){
	window.location.href = '<?=$CODG_FORMULARIO?>.php'
}

function cadastrar_pendencia(){
	if (document.form.numgPendencia.value == ""){
		if (pValidaGravacao()){
				document.form.txtFuncao.value = "cadastrar_pendencia"
				document.form.submit()
			
		}
	}else{
		alert("Fun��o de CADASTRO n�o dispon�vel para este formul�rio!")
	}

}

function editar_pendencia(){
	if (document.form.numgPendencia.value != ""){
		if (pValidaGravacao()){
				document.form.txtFuncao.value = "editar_pendencia"
				document.form.submit()
			
		}
	}else{
		alert("Fun��o de EDI��O n�o dispon�vel para este formul�rio!")
	}

}

function liberar_pendencia(){
	if (document.form.numgPendencia.value != ""){
			if (confirm("Confirma a LIBERA��O dos dados da Penc�ncia?")){
				document.form.txtFuncao.value = "liberar_pendencia"
				document.form.submit()
			}
	}else{
		alert("Fun��o de LIBERA��O n�o dispon�vel para este formul�rio!")
	}

}


function excluir_pendencia(){
	if (document.form.numgPendencia.value != ""){
		if (confirm("Confirma a EXCLUS�O da Pendencia?")){
			document.form.txtFuncao.value = "excluir_pendencia"
			document.form.submit()
		}
	}else{
		alert("Fun��o de EXCLUS�O n�o dispon�vel para este formul�rio!")
	}
}



function baixar_pendencia(){
	if (document.form.numgPendencia.value != ""){
		if (pValidaGravacao()){
			if (confirm("Confirma a Baixa da Pend�ncia?")){
				document.form.txtFuncao.value = "baixar_pendencia"
				document.form.submit()
			}
		}
	}else{
		alert("Fun��o de BAIXA DE PEND�NCIA n�o dispon�vel para este formul�rio!")
	}

}
function editar_baixa(){
	if (document.form.numgPendencia.value != ""){
		if (pValidaGravacao()){
				document.form.txtFuncao.value = "editar_baixa"
				document.form.submit()
			
		}
	}else{
		alert("Fun��o de Edi��o pend�ncia n�o dispon�vel para este formul�rio!")
	}

}

function pValidaGravacao(){

	var sErr = ""

	//...

	//VERIFICA SE FOI ENCONTRADO ALGUM ERRO NA VALIDA��O DO FORMUL�RIO
	if (sErr != ""){
		sErr = "Verifique os erros encontrados abaixo:\n\n" + sErr
		alert(sErr)
		return false
	}else
	return true
}

function iniForm(){	
	MontaFuncoes('<?=$CODG_FORMULARIO; ?>','<?=$NOME_FORMULARIO; ?>','<?=$oPendencia->getNumgPendencia()?>')	
	<? if($oPendencia->getNumgPendencia() == ""){?>
		AlteraTab(1,1)
	<? } else { ?>	
		AlteraTab(1,3)
	<? } ?>
}




function AlteraBotao(nome) {
	oImage = eval("document.icone")
	if (nome != "")
		oImage.src = "imagens/botoes/" + nome
	else
		oImage.src = "imagens/space.gif"
}
</script>
</head>
<body onLoad="iniForm()" rightmargin="0" marginwidth="0" marginheight="0" leftmargin="0" bottommargin="0" topmargin="0" bgcolor="#FFFFFF">
<table border=0 width=100% align=center cellspacing=0 cellpadding=0>
	<tr>
		<td><img src="imagens/space.gif" border=0 height=10></td>
	</tr>
	<tr>
		<td align=center><table border=0 width=600 cellspacing=0 cellpadding=0>
				<tr>
					<td><img src="imagens/formEsqSup.gif" border=0 width=10 height=10></td>
					<td background="imagens/formMidSup.gif"></td>
					<td><img src="imagens/formDirSup.gif" border=0 width=10 height=10></td>
				</tr>
				<tr valign=top>
					<td width=10 background="imagens/formEsqMid.gif"></td>
					<td><table border=0 width=100% cellspacing=0 cellpadding=0 align=center background="imagens/formMid.gif">
							<form method="post" action="pcadpendencias.php" id="form" name="form">
								<input type=hidden tabindex="0" name=txtFuncao id="txtFuncao"  value="">
								<input type=hidden tabindex="1" name=numgPendencia id="numgPendencia" value="<?=$oPendencia->getNumgPendencia()?>">
								<!-- IN�CIO CAMPOS DO FORMUL�RIO  -->
								<?php if ($_GET["info"] != ""){?>
								<tr>
									<td colspan=3 align=center height=20 valign=middle class=normal11><img src="imagens/icones/info.gif" border=0 align=absbottom>&nbsp;&nbsp;
										<?php 		
										switch ($_GET["info"]){
											case 1:
												echo "Cadastro realizado com sucesso";
												break;
											case 2:
												echo "Edi��o realizada com sucesso";
												break;
											case 3:
												echo "Exclus�o realizada com sucesso";
												break;
											case 4:
												echo "Baixa realizada com sucesso";
												break;
											case 5:
												echo "Libera��o realizada com sucesso";
												break;
										} ?>
									</td>
								</tr>
								<?php }?>
								
								<tr>
									<td colspan=3 align="left">
									<table width=580 border=0 align="left" cellpadding=0 cellspacing=0 >
										
										<tr>
											<td width=20% align=right class=normal11b>Site:&nbsp;</td>
											<TD width=80% colspan="2" class="normal11">
												<table cellpadding="0" cellspacing="0" border="0" width="100%">
													<tr>
														<td width="50%">
															<select name=cboSite class=borda tabindex="2" style="width:200px" onChange="window.location.href='cadpendencia.php?numg_site=' + document.form.cboSite.value">
																	<? if($_GET["numg_site"] != ""){
																		montaCombo($vSites,"numg_site","nome_site",$_GET["numg_site"],true);
																	}else{
																		montaCombo($vSites,"numg_site","nome_site",$oPendencia->getNumgSite(),true);
																  }?>
																</select>
														</td>
														<td align="right" class="normal11" width="50%">
															<?
																if ($_GET["numg_pendencia"] != "" ){
																	$oOperador->setarDadosOperador($oPendencia->getNumgOperadorcad());
																?>
																		cadastrado em: <b><?=FormataDataHora($oPendencia->getDataCadastro())?></b>&nbsp;[<?=$oOperador->getNomeOperador()?>]
																		
															<?	}
															?>
														</td>
													</tr>
												</table>
											</TD>
										</tr>
										<tr>
											<td height=5>
														</td>
										</tr>
										<tr>
											<td width=20% align=right class=normal11b>
												Fase:&nbsp;
											</td>
											<TD width=80%>
												<select name=cboFase class=borda tabindex="3" style="width:200" onChange="window.location.href='cadpendencia.php?numg_site=' + <?=$_GET["numg_site"]?> + '&numg_fase=' + document.form.cboFase.value">
													<? if($_GET["numg_fase" ]  != "" ){
															montaCombo($vFases,"numg_fase","nome_fase",$_GET["numg_fase"],true);
														}else{
															montaCombo($vFases,"numg_fase","nome_fase",$oPendencia->getNumgFase(),true);
														 }?>
												</select>
											</TD>
										</tr>																				
										<tr>
											<td height=10></td>
										</tr>
										
										
										<tr>
									  <tr>
										<td colspan=3>
										<? if( $oPendencia->getNumgPendencia() == ""){?>
											<script language="JavaScript">										
												montaTabs(Array("Dados Gerais","","",""),1)
											</script>
										<? } else {?>
											<script language="JavaScript">										
												montaTabs(Array("Dados Gerais","Baixar Pend�ncias","Imagens",""),3)
											</script>
										<? } ?>	
										</td>
							</tr>
							<tr>
								<td colspan=3>
									<div id="tab1">
										<table border="0" width="580" cellspacing="2" cellpadding="0" class="bordaEsqDirInf">
												<tr>
													<td>
														<br>	
													</td>
												</tr>
												<tr>
													<td  align=right valign="top" class=normal11b>Subatividade:&nbsp;</td>
													<TD colspan="3">
														<select name="numgSubatividade" id="numgSubatividade" tabindex="4" class=borda style="width:390px">
															<?php 
																if ($vAtividades->getCount() > 0) {
																		for ($i=0; $i<$vAtividades->getCount(); $i++) { ?>
																		<? if($vAtividades->getValores($i,"nome_atividade") != $vAtividades->getValores($i - 1,"nome_atividade") ) {?>
																				<optgroup label="<?=$vAtividades->getValores($i,"nome_atividade")?>">
																			<? } ?>		
																		<? if( $oPendencia->getNumgSubatividade() != ""){ 
																				if($vAtividades->getValores($i,"data_bloqueio")==""){?>
																					<option value="<?=$vAtividades->getValores($i,"numg_subatividade")?>" <?if($oPendencia->getNumgSubatividade() == $vAtividades->getValores($i,"numg_subatividade") ){echo "selected=selected";}?>><?=$vAtividades->getValores($i,"nome_subatividade")?></option>
																			<?	}else{
																					if($oPendencia->getNumgSubatividade() == $vAtividades->getValores($i,"numg_subatividade") ){?>
																					<option value="<?=$vAtividades->getValores($i,"numg_subatividade")?>" selected=selected><?=$vAtividades->getValores($i,"nome_subatividade")?>(Bloqueada)</option>
																			<?		}	
																				}
																			}else{
																				if($vAtividades->getValores($i,"data_bloqueio")==""){?>
																					<option value="<?=$vAtividades->getValores($i,"numg_subatividade")?>"><?=$vAtividades->getValores($i,"nome_subatividade")?></option>
																		<? 		}
																			}
																		} ?>
													          			<? if($vAtividades->getValores($i,"nome_atividade") != $vAtividades->getValores($i - 1,"nome_atividade") ) {?>	
													          				</optgroup>
													          			<? } ?>	
													    	<?php }	 ?>
														</select>
													</TD>
												</tr>
												<tr>
													<td align="right" valign="top" class="normal11"><strong>Descri��o do Problema:&nbsp;</strong> </td>
													<td><span class="normal11" >
														<textarea name="descProblema" id="descProblema" class="borda" rows="2" cols="65" tabindex="5"   onKeyDown="setarFocus(this,'form',event)"><?=$oPendencia->getDescProblema()?></textarea>
														</span> </td>
												</tr>
												<tr>
													<td align="right" valign="top" class="normal11"><strong>Descri��o da Causa:&nbsp;</strong> </td>
													<td colspan="2" ><span class="normal11" >
														<textarea name="descCausa" id="descCausa"  class="borda" tabindex="6" rows="2" cols="65"  onKeyDown="setarFocus(this,'form',event)"><?=$oPendencia->getDescCausa();?></textarea>
														</span> </td>
												</tr>
												<tr>
													<td align="right" valign="top" class="normal11"><strong>Solu��o 1: &nbsp;</strong> </td>
													<td colspan="3"><textarea name="descSolucao1" id="descSolucao1" tabindex="7" class="borda" rows="2" cols="65" onKeyDown="setarFocus(this,'form',event)"><?=$oPendencia->getDescSolucao1();?></textarea>
													</td>
												</tr>
												<tr>
													<td align="right" valign="top" class="normal11"> Solu��o 2:&nbsp; </td>
													<td colspan="3"><textarea name="descSolucao2" id="descSolucao2" tabindex="8" class="borda" rows="2" cols="65" ><?=$oPendencia->getDescSolucao2();?></textarea>
													</td>
												</tr>
												<tr>
													<td align="right" valign="top" class="normal11"> Solu��o 3:&nbsp; </td>
													<td colspan="3"><textarea name="descSolucao3" id="descSolucao3" tabindex="9" class="borda" rows="2" cols="65" ><?=$oPendencia->getDescSolucao3()?></textarea>
													</td>
												</tr>
												<tr>
													<td align="right" valign="top" class="normal11"><strong>Solu��o Indicada:&nbsp;</strong> </td>
													<td colspan="3">
														<select name="numrSolucaoindic" id="numrSolucaoindic" tabindex="10" class=borda  >
															<option value="1" <?if ($oPendencia->getNumrSolucaoindic() == 1){ echo "selected=selected";} ?>>Solu��o 1</option>
															<option value="2" <? if($oPendencia->getNumrSolucaoindic() == 2){ echo "selected = selected";} ?>>Solu��o 2</option>
															<option value="3" <? if($oPendencia->getNumrSolucaoindic() == 3 ){ echo "selected = selected"; }?>>Solu��o 3</option>
														</select>
													</td>
												</tr>
												<tr>
													<td  align=right valign="top" class=normal11b>Empresa Respons�vel:&nbsp;</td>
													<TD colspan="3">
														<select name=numgEmpresaresp tabindex="11" class=borda style="width:390px">
															<? montaCombo($vEmpresas,"numg_empresa","nome_empresa",$oPendencia->getNumgEmpresaresp(),true);	?>
														</select>
													</TD>
												</tr>
												<tr>
													<td height="5">
														
													</td>
												</tr>
									  </table>
													
								  </div>
													
							  </TD>
						</tr>												
						<tr>
							  <td colspan="3">
							 <? if ($oPendencia->getNumgPendencia() != ""){?> 
								<div id="tab2">
									<table width="580" cellspacing="2" cellpadding="0" class="bordaEsqDirInf">
										<tr>
											<td>
												<br>	
											</td>
										</tr>
										<tr>
											<td align=right valign="top" class=normal11b>
												Solu��o Implantada: 
											</td>
											<td>
												<textarea name="descSolImpl" id="descSolImpl"  class="borda" tabindex="12" rows="2" cols="65"  onKeyDown="setarFocus(this,'form',event)"><?=$oPendencia->getDescSolucaoimpl();?></textarea>
											</td>
										</tr>
										<tr>
											<td align=right valign="top" class=normal11b>
												Empresa Executora: 
											</td>
											<td>
												<select name=numgEmpresaexec id="numgEmpresaexec" tabindex="13" class=borda style="width:390px">
													<? montaCombo($vEmpresas,"numg_empresa","nome_empresa",$oPendencia->getNumgEmpresaexec(),true);	?>
												</select>
											</td>
										</tr>
										<tr>
											<td align=right valign="top" class=normal11b>
												Data Solu��o: 
											</td>
											<td>
												<input tabindex="14" class="borda" name="dataSolucao" type="text" class="normal11" id="dataSolucao" value="<?=FormataData($oPendencia->getDataSolucao())?>" maxlength="10" onKeyUp="FormataData('dataSolucao',event)"  />&nbsp;
												<br>
											</td>
										</tr>
										<tr>
											<td></td>
											<td class="normal11" align="right">
												<?
													if ($_GET["numg_pendencia"] != "" ){
														$oOperador->setarDadosOperador($oPendencia->getNumgOperadorbaixa());
														if($oPendencia->getDatabaixa() != ""){
													?>
															baixado em: <b><?=FormataDataHora($oPendencia->getDataBaixa())?></b>&nbsp;[<?=$oOperador->getNomeOperador()?>]
															
												<?		}
													}
												?>
											</td>
										</tr>
																									
									</table>
									
								</div>
								
							</td>
						</tr>
						<tr>
							<td colspan="3">
								<div id="tab3">
									<iframe name="iframe" src="iframecadimg.php?cat=2&id=<?=$oPendencia->getNumgPendencia()?>-<?=$oPendencia->getNumgSite()?>" frameborder="0" width="100%" height="300" scrolling="no" class="bordaEsqDirInf"></iframe>
								</div>
							</td>
						</tr>		
						<? } ?>	
					<?
					if ($_GET["numg_pendencia"] != "" ){
						$oOperador->setarDadosOperador($oPendencia->getNumgOperadoralt());
						if($oPendencia->getDataUltimaalt() != ""){
					?>	
							<tr>
								<td colspan=6 height=20 align=right class=normal11>
									�ltima altera��o: <b><?=FormataDataHora($oPendencia->getDataUltimaalt())?></b>&nbsp;[<?=$oOperador->getNomeOperador()?>]
											
								</td>
							</tr>
										
						<?		}
							}
						?>
							<?
							if ($_GET["numg_pendencia"] != "" ){ 
								$oOperador->setarDadosOperador($oPendencia->getNumgOperadorlib());
								if($oPendencia->getDataLiberacao() != ""){
							?>
							<tr>
								<td colspan=6 height=20 align=right class=normal11>
									libera��o: <b><?=FormataDataHora($oPendencia->getDataLiberacao())?></b>&nbsp;[<?=$oOperador->getNomeOperador()?>]
								</td>
							</tr>
						<?		}
									}
								?>			
				 </table>
											
			</form>
						</table></td>
					<td width=10 background="imagens/formDirMid.gif"></td>
				</tr>
				
				<tr>
					<td><img src="imagens/formEsqInf.gif" border=0 width=10 height=10></td>
					<td background="imagens/formMidInf.gif"></td>
					<td><img src="imagens/formDirInf.gif" border=0 width=10 height=10></td>
				</tr>
			</table></td>
	</tr>
	
	
	<?php 
	if (isset($vPendencias)){
	if ($vPendencias->getCount() > 0){?>
	<tr>
		<td><table border=0 width=600px cellspacing=0 cellpadding=0 align=center>
				<tr>
					<td colspan=3 class=normal11 height=25 valign=bottom>Rela��o de Pendencias cadastradas para Site:</td>
				</tr>
				<tr height=20 class=normal11b align=center>
					<td background="imagens/fundoBarraRelatorio.gif" align="left" width=15%>&nbsp;&nbsp;C�digo</td>
					<td background="imagens/fundoBarraRelatorio.gif"  align="left"width=38%>Data de Cadastro</td>
					<td background="imagens/fundoBarraRelatorio.gif"  align="left" width=38%>Data de Solu��o</td>
				</tr>
				<?php for ($i=0; $i<$vPendencias->getCount(); $i++){?>
				<tr height=20 <?php if ($i % 2 == 1){?>bgcolor="#E8E8E8"<?php }?> class=relatorio>
					<td><a href="cadpendencia.php?numg_site=<?=$vPendencias->getValores($i,"numg_site")?>&numg_fase=<?=$vPendencias->getValores($i,"numg_fase")?>&numg_pendencia=<?=$vPendencias->getValores($i,"numg_pendencia");?>" class=relatorio>
						&nbsp;&nbsp;<?=$vPendencias->getValores($i,"numg_pendencia");?>
						</a></td>
					<td align="left"><?=FormataData($vPendencias->getValores($i,"data_cadastro"));?></td>
					<td align="left"><?=FormataData($vPendencias->getValores($i,"data_solucao"));?></td>
				</tr>
				<?php }?>
				<tr height=20 <?php if (i % 2 == 1){?>bgcolor="#E8E8E8"<?php }?>>
					<td class=destaque  colspan="2">* Clique no c�digo da Pendencia para edit�-la</td>
					<td class=normal11b align=right>TOTAL:
						<?=$vPendencias->getCount(); ?></td>
				</tr>
			</table></td>
	</tr>
	<?php } }?>
	
	<tr>
		<td><img src="imagens/space.gif" border=0 height=10></td>
	</tr>
</table>
</tr>
</table>

<?php $oPendencia->free;?>
</body>
<head>
<META HTTP-EQUIV="Pragma" CONTENT="no-cache">
<META HTTP-EQUIV="Expires" CONTENT="-1">
</head>
</html>
