<?
include_once "funcoes.php";
include_once "classes/Diarios.php";

/**
 * Empresa: Interagi Tecnologia
 * Descri��o:
 * Releases (Data, respons�vel e descri��o [�ltimo release primeiro]):
 *	 10/04/2008 (Thales A. Salvador) 
 *		 
 */

if (empty($_SESSION["NUMG_OPERADOR"]) || $_SESSION["NUMG_OPERADOR"] == ""){
	header("Location: expirou.htm"); exit;
}

switch ($_POST["txtFuncao"]){

	
	case "buscar_diario":
		
		$oDiario = new Diarios();
		
		$oDiario->consultarPorSiteFaseData($_POST["cboSite"],$_POST["cboFase"],$_POST["dataDiario"]);
		
		if (Erros::isError()){
			MostraErros();
		}else{
			header("Location: caddiarios.php?numg_diario=" . $oDiario->getNumgDiario()); exit;
		}
		
		break;
		
	case "cadastrar_diario":

		$oDiario = new Diarios();
		
		$oDiario->setNumgSite($_POST["cboSite"]);
		$oDiario->setNumgFase($_POST["cboFase"]);
		$oDiario->setDataDiario($_POST["dataDiario"]);
		$oDiario->setNumgOperadorcad($_SESSION["NUMG_OPERADOR"]);
		//$oDiario->setDataCadastro(date("d/m/Y"));
	
		$oDiario->cadastrar();

		if (Erros::isError()){
			MostraErros();
		}else{
			header("Location: caddiarios.php?info=1&numg_diario=" . $oDiario->getNumgDiario()); exit;
		}

		break;

	case "editar_diario":

		$oDiario = new Diarios();
		
		$oDiario->setNumgDiario($_POST["numgDiario"]);
		$oDiario->setNumgSite($_POST["cboSite"]);
		$oDiario->setNumgFase($_POST["cboFase"]);
		$oDiario->setDataDiario($_POST["dataDiario"]);
		$oDiario->setNumgOperadoralt($_SESSION["NUMG_OPERADOR"]);
		//$oDiario->setDataUltimaalt(date("d/m/Y"));
		
		//Montando o vetor de Atividades do Di�rio
		$vNumgsSubatividades = split(",",$_POST["numgsSubatividades"]);
		for($i=0;$i<count($vNumgsSubatividades);$i++){
			$vAtivDiario[$i][0] = $vNumgsSubatividades[$i];//subatividade
			$vAtivDiario[$i][1] = $_POST["cboStatus".$vNumgsSubatividades[$i]]; //Status	
			$vAtivDiario[$i][2] = $_POST["descComentario".$vNumgsSubatividades[$i]]; //Coment�rio
		}
		$oDiario->setVSubatividades($vAtivDiario);
		
		$oDiario->editar();

		if (Erros::isError()){
			MostraErros();
		}else{
			header("Location: caddiarios.php?info=2&numg_diario=" . $oDiario->getNumgDiario()); exit;
		}

		break;

	case "excluir_diario":

		$oDiario = new Diarios();

		$oDiario->excluir($_POST["numgDiario"]);

		if (Erros::isError()){
			MostraErros();
		}else{
			header("Location: caddiarios.php?info=3"); exit;
		}
		
		break;

	case "liberar_diario":

		$oDiario = new Diarios();
		
		$oDiario->setNumgDiario($_POST["numgDiario"]);
		$oDiario->setNumgSite($_POST["cboSite"]);
		$oDiario->setNumgFase($_POST["cboFase"]);
		$oDiario->setDataDiario($_POST["dataDiario"]);
		$oDiario->setNumgOperadorlib($_SESSION["NUMG_OPERADOR"]);
				
		$oDiario->liberar();

		if (Erros::isError()){
			MostraErros();
		}else{
			header("Location: caddiarios.php?info=4&numg_diario=" . $oDiario->getNumgDiario()); exit;
		}

		break;


	default:
		header("Location: caddiarios.php"); exit;
		break;
}


?>