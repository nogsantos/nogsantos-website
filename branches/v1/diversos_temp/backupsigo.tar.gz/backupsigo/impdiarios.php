<? 
	include_once "funcoes.php"; 
	include_once("classes/Sites.php");
	include_once("classes/Diarios.php");
	include_once("classes/Fases.php");
	include_once("classes/Subatividades.php");
	include_once("classes/Operadores.php");
	
	
	$numgSite = $_GET["numg_site"];
	$numgDiario = $_GET["numg_diario"];
	$numgSubatividade = $_GET["numg_subatividade"];
	
	$oSite = new Sites();
	$oDiario = new Diarios();
	$oFase = new Fases();
	$oSubatividades = new Subatividades();
	$oOperador = new Operadores();
	
	$bFoto = false;
	
	if(!empty($numgDiario)){
		$oDiario->setarDados($numgDiario);
		$vSubatividades = $oDiario->consultarSubativ($numgDiario);
		
		if($oDiario->existemSubativCadastradas($numgDiario)){
			$bFoto = true;
		}
	}	
	$vSites = $oSite->consultarTodas();
	
	if(!empty($numgSite)){
		$vFases = $oFase->consultarDesblPorSite($numgSite);
	}elseif($oDiario->getNumgDiario() != ""){
		$vFases = $oFase->consultarDesblPorSite($oDiario->getNumgSite());
	}
	
	if(!empty($numgSubatividade)){
		$oSubatividades->setarDados($numgSubatividade);
	}
	
	
	
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<title>::: SIGO - Relat�rio de Di�rios :::</title>
<link href="estilos.css" rel="stylesheet" type="text/css">
<script language="JavaScript" src="funcoes.js"></script>

</head>

<body onLoad="window.print()" rightmargin="0" marginwidth="0" marginheight="0" leftmargin="0" bottommargin="0" topmargin="0" bgcolor="#FFFFFF">
<table border=0 width=100% align=center cellspacing=0 cellpadding=0>
	<tr>
		<td><img src="imagens/space.gif" border=0 height=10></td>
	</tr>
	<tr>
		<td align=center>
			<table border=0 width=600 cellspacing=0 cellpadding=0>
				<tr>
					<td><img src="imagens/formEsqSup.gif" border=0 width=10 height=10></td>
					<td background="imagens/formMidSup.gif"></td>
					<td><img src="imagens/formDirSup.gif" border=0 width=10 height=10></td>
				</tr>
				<tr valign=top>
					<td width=10 background="imagens/formEsqMid.gif"></td>
					<td>
						<table border=0 width=100% cellspacing=0 cellpadding=0 align=center background="imagens/formMid.gif">
						<form method="post" action="pcaddiarios.php" name="form">
							<input type=hidden name=txtFuncao value="">
							<input type=hidden name=numgDiario value="<?=$oDiario->getNumgDiario()?>">
							
							<!-- IN�CIO CAMPOS DO FORMUL�RIO  -->
							<?php if ($_GET["info"] != ""){?>
							<tr>
								<td colspan=2 align=center height=20 valign=middle class=normal11>
								<img src="imagens/icones/info.gif" border=0 align=absbottom>&nbsp;&nbsp;
								<?php 		
									switch ($_GET["info"]){
										case 1:
											echo "Cadastro realizado com sucesso";
											break;
										case 2:
											echo "Edi��o realizada com sucesso";
											break;
										case 3:
											echo "Exclus�o realizada com sucesso";
											break;
										case 4:
											echo "Libera��o realizada com sucesso";
											break;
										
									} ?>
								</td>
							</tr>
							<?php }?>				
							<tr>
								<td colspan=3>
									<table border=0 width=580 cellspacing=0 cellpadding=2>
										<tr>
											<td width=20% align=right class=normal11b>Site:</td>
											<TD width=80% align="left" class=normal11>
												<? if($oDiario->getNumgDiario() != ""){
														for ($i=0; $i<$vSites->getCount(); $i++){
															if($oDiario->getNumgSite() == $vSites->getValores($i,"numg_site")){
																echo $vSites->getValores($i,"nome_site");
																break;
															}
														}
													}?>	
											</TD>
										</tr>
										<tr>
											<td width=20% align=right class=normal11b>Fase:</td>
											<TD width=80% align="left" class=normal11>
												<? if($oDiario->getNumgDiario() != ""){
														for ($i=0; $i<$vFases->getCount(); $i++){
															if($oDiario->getNumgFase() == $vFases->getValores($i,"numg_fase")){
																echo $vFases->getValores($i,"nome_fase");
																break;
															}
														}
													}?>
											</TD>
										</tr>
										<tr>
											<td width=20% align=right class=normal11b>Data:</td>
										  	<TD width=80% align="left">
												<table cellpadding="0" cellspacing="0" border="0" width="100%">
													<tr>
														<td width="50%" class="normal11">
															<?=FormataData($oDiario->getDataDiario())?>
														</td>
														<td align="right" class="normal11" width="50%">
														<?
																if ($_GET["numg_diario"] != "" ){
																	$oOperador->setarDadosOperador($oDiario->getNumgOperadorcad());
																?>
																		cadastrado em: <b><?=FormataDataHora($oDiario->getDataCadastro())?></b>&nbsp;[<?=$oOperador->getNomeOperador()?>]
																		
															<?	}
															?>
														</td>
													</tr>
												</table>
											</TD>
										</tr>
									</table>
								</td>
							</tr>
							<tr>
								<td height=10></td>
							</tr>
							
							<? if($oDiario->getNumgDiario() != "" ){?>
							<tr>
								<td colspan=3>
									<div id="tab1">
												<table border="0" width="580" cellspacing="0" cellpadding="2"> 
													<tr>
														<td class="normal11" align="left">
															<table border="0" width="70%">
																<tr>
																	<td class="normal11b" align="right">NA:</td>
																	<td class="normal11" align="left">N�o se aplica</td>
																	<td class="normal11b" align="right">OK:</td>
																	<td class="normal11" align="left">OK</td>
																	<td class="normal11b" align="right">NI:</td>
																	<td class="normal11" align="left">N�o Iniciado</td>
																</tr>
																<tr>
																	<td class="normal11b" align="right">NOK:</td>
																	<td class="normal11" align="left">N�o OK</td>
																	<td class="normal11b" align="right">EC:</td>
																	<td class="normal11" align="left">Em Constru��o</td>
																</tr>
																<tr>
																	<td colspan=6 class="normal11" align="left"> &nbsp;&nbsp;&nbsp;&nbsp;*Itens em <span class="destaque"><b>vermelho</b></span> possuem um <b>NOK</b> anterior n�o resolvido.</td>
																</tr>
															</table>
															
															<? $tituloAtividade = ""; 
															for ($i=0; $i<$vSubatividades->getCount(); $i++){?>
															<!-- IN�CIO DE UM CAMPO DE SUBATIVIDADE -->	
															<table border="0" width="575" cellspacing="0" cellpadding="2"> 	
																<? if($tituloAtividade != $vSubatividades->getValores($i,"nome_atividade")){?>
																<tr>
																	<td colspan="3"><img src="imagens/space.gif" height="5" /><hr width="100%" size="1" /></td>
																</tr>
																<tr> 
																	<td width="30%" bgcolor="#F3F3F3" align="center" class="normal11"><strong><?=$vSubatividades->getValores($i,"nome_atividade")?></strong></td> 
																	<td width="10%" bgcolor="#F3F3F3" align="center" class="normal11"><strong>Status</strong></td> 
																	<td width="60%" bgcolor="#F3F3F3" align="center" class="normal11"><strong>Descri��o</strong></td> 
																</tr>	
																<? 
																	$tituloAtividade = $vSubatividades->getValores($i,"nome_atividade");
																	} ?>
																<? if(($vSubatividades->getValores($i,"data_bloqueio")=="")or($vSubatividades->getValores($i,"data_bloqueio")!="" and $_GET["bloqueadas"]=="true")){?>
																<tr> 
																	<td width="30%" align="right"  valign="top" class="<? if ($vSubatividades->getValores($i,"count_ok") == "0" && $vSubatividades->getValores($i,"data_nok") != "" ){echo "destaque";}else{echo "normal11";}?>"><?=$vSubatividades->getValores($i,"nome_subatividade");?><?if($vSubatividades->getValores($i,"data_bloqueio")!=""){ echo " (Bloqueada)";}?>:</td> 
																	<td width="10%" align="center"  valign="top" class="normal11b">
																		<?
																			switch($vSubatividades->getValores($i,"numr_status")){
																				case 1:
																					echo "NA";
																					break;
																				case 2:
																					echo "OK";
																					break;
																				case 3:
																					echo "NOK";
																					break;
																				case 4:
																					echo "EC";
																					break;
																				case 5:
																					echo "NI";
																					break;
																			}
																		?>
																	</td> 
																	<td width="60%" align="left" class="normal11"  valign="top">
																		<?=htmlspecialchars($vSubatividades->getValores($i,"desc_comentario"))?>
																	</td> 
																</tr>
																<?}?>
															</table>
															<!-- FIM DE UM CAMPO DE SUBATIVIDADE -->
															<? 
																	if($i == ($vSubatividades->getCount()-1)){
																		$sNumgsSubatividades .= $vSubatividades->getValores($i,"numg_subatividade");
																	}else{
																		$sNumgsSubatividades .= $vSubatividades->getValores($i,"numg_subatividade") . ",";
																	}
																} ?>
													  </td>
													</tr>
														
												</table>		 
												
										</div>
								<input type="hidden" name="numgsSubatividades" id="numgsSubatividades" value="<?=$sNumgsSubatividades?>" />
									<? if($_GET['aba'] == "2" ){ 	?>
									   <div id="tab2">
									   		<iframe name="iframe" src="iframecadimg.php?cat=3&id=<?=$oDiario->getNumgDiario()?>-<?=$numgSubatividade?>-<?=$oDiario->getNumgSite()?>&nome_subatividade=<?=$oSubatividades->getNomeSubatividade()?>" frameborder="0" width="100%" height="300" scrolling="no" class="bordaEsqDirInf"></iframe>
									   </div>
									 <? }?>
								</td>
							</tr>
							<!-- FIM CAMPOS DO FORMUL�RIO  -->
							<? }?>
						</form>
							<tr>
								<td colspan="6" class="normal11" align="right">
									<?
										if ($_GET["numg_diario"] != "" ){ 
											$oOperador->setarDadosOperador($oDiario->getNumgOperadoralt());
											if($oDiario->getDataUltimaalt() != ""){
										?>
												�ltima altera��o: <b><?=FormataDataHora($oDiario->getDataUltimaalt())?></b>&nbsp;[<?=$oOperador->getNomeOperador()?>]
												
									<?		}
										}
									?>
								</td>
							</tr>
							<tr>
								<td colspan="6" class="normal11" align="right">
									<?
										if ($_GET["numg_diario"] != "" ){ 
											$oOperador->setarDadosOperador($oDiario->getNumgOperadorlib());
											if($oDiario->getDataLiberacao() != ""){
										?>
												libera��o: <b><?=FormataDataHora($oDiario->getDataLiberacao())?></b>&nbsp;[<?=$oOperador->getNomeOperador()?>]
												
									<?		}
										}
									?>
								</td>
							</tr>
						</table>
					</td>
					<td width=10 background="imagens/formDirMid.gif"></td>
				</tr>
				<tr>
					<td><img src="imagens/formEsqInf.gif" border=0 width=10 height=10></td>
					<td background="imagens/formMidInf.gif"></td>
					<td><img src="imagens/formDirInf.gif" border=0 width=10 height=10></td>
				</tr>
			</table>
		</td>
	</tr>
	
	<tr>
		<td><img src="imagens/space.gif" border=0 height=10></td>
	</tr>
</table>
</body>
</html>
