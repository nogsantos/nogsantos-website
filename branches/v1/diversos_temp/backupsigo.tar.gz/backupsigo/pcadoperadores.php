<?php 
include_once "funcoes.php";
include_once "classes/Operadores.php";
include_once "classes/Grupos.php";
/************************************************************************
 Empresa: Interagi Tecnologia

 Descri��o: 
	
 Releases (Data, respons�vel e descri��o [�ltimo release primeiro]):
	 04/08/2005 (Rafael C�cero) 
		 Inclu�do este cabe�alho descrevendo a funcionalidade da p�gina
************************************************************************/

	if (empty($_SESSION["NUMG_OPERADOR"]) || $_SESSION["NUMG_OPERADOR"] == ""){
		header("Location: expirou.htm"); exit;
	}

	
	switch ($_POST["txtFuncao"]){ 
	 
		case "cadastrar_operador":
			
			$oOperador = new Operadores;
						
			$oOperador->setNomeOperador($_POST["txtNomeOperador"]);
			$oOperador->setNomeCompleto($_POST["txtNomeCompleto"]);
			$oOperador->setDescTipo($_POST["cboDescTipo"]);
			$oOperador->setDescSenha($_POST["txtDescSenha"]);
			$oOperador->setDescEmail($_POST["txtDescEmail"]);
			$oOperador->setFlagEmailPendencia($_POST["chkFlagEmailPendencia"]);
			$oOperador->setFlagEmailDiario($_POST["chkFlagEmailDiario"]);
			$oOperador->setNumgOperadorCad($_SESSION["NUMG_OPERADOR"]);
			
			$oOperador->cadastrar();
			
			if (Erros::isError()){
				MostraErros();
			}else{ 
				header("Location: cadoperadores.php?info=1&numg_operador=" . $oOperador->getNumgOperador()); exit;
			}				
			
		break;
			 
		case "editar_operador":
			
			$oOperador = new Operadores;
			
			$oOperador->setNumgOperador($_POST["txtNumgOperador"]);
			$oOperador->setNomeOperador($_POST["txtNomeOperador"]);
			$oOperador->setDescTipo($_POST["cboDescTipo"]);
			$oOperador->setNomeCompleto($_POST["txtNomeCompleto"]);
			$oOperador->setDescSenha($_POST["txtDescSenha"]);
			$oOperador->setDescEmail($_POST["txtDescEmail"]);
			$oOperador->setFlagEmailPendencia($_POST["chkFlagEmailPendencia"]);
			$oOperador->setFlagEmailDiario($_POST["chkFlagEmailDiario"]);
			$oOperador->setNumgOperadorAlt($_SESSION["NUMG_OPERADOR"]);
			
			$oOperador->editar();
			
			if (Erros::isError()){
				MostraErros();
			}else{ 
				header("Location: cadoperadores.php?info=2&numg_operador=" . $oOperador->getNumgOperador()); exit;
			}				
			
		break;

		case "excluir_operador":
		
			$oOperador = new Operadores;
			
			$oOperador->excluir($_POST["txtNumgOperador"]);
			
			if (Erros::isError()){
				MostraErros();
			}else{ 
				header("Location: cadoperadores.php?info=3"); exit;
			}				
			
		break;

		case "bloquear_operador":

			$oOperador = new Operadores;
			
			$oOperador->bloquear(array($_POST["txtNumgOperador"],$_SESSION["NUMG_OPERADOR"]));
			
			if (Erros::isError()){
				MostraErros();
			}else{ 
				header("Location: cadoperadores.php?info=4&numg_operador=" . $_POST["txtNumgOperador"]); exit;
			}				
			
		break;
					
		case "desbloquear_operador":	

			$oOperador = new Operadores;
			
			$oOperador->desbloquear($_POST["txtNumgOperador"]);
			
			if (Erros::isError()){
				MostraErros();
			}else{ 
				header("Location: cadoperadores.php?info=5&numg_operador=" . $_POST["txtNumgOperador"]); exit;
			}				
			
		break;

		case "cadastrar_grupoope":
		
			$vGruposDisponiveis = $_POST["cboGruposDisponiveis"];

			$oGrupos = new Grupos;	
			for ($i=0; $i<count($vGruposDisponiveis); $i++){
				$oGrupos->cadastrarOperadorGrupo(array($_POST["txtNumgOperador"],$vGruposDisponiveis[$i]));
			}

			if (Erros::isError()){
				MostraErros();
			}else{ 
				header("Location: cadoperadores.php?info=6&numg_operador=" . $_POST["txtNumgOperador"]); exit;
			}
			
		break;
			
		case "excluir_grupoope":

			$vGruposOperador = $_POST["cboGruposOperador"];

			$oGrupos = new Grupos;
			for ($i=0; $i<count($vGruposOperador); $i++){
				$oGrupos->excluirOperadorGrupo(array($_POST["txtNumgOperador"],$vGruposOperador[$i]));
			}

			if (Erros::isError()){
				MostraErros();
			}else{ 
				header("Location: cadoperadores.php?info=7&numg_operador=" . $_POST["txtNumgOperador"]); exit;
			}
			
		break;

		case "enviar_senha":

			$oOperador = new Operadores;
			
			$oOperador->enviarSenha($_POST["txtNumgOperador"]);
			
			if (Erros::isError()){
				MostraErros();
			}else{ 
				header("Location: cadoperadores.php?info=8&numg_operador=" . $_POST["txtNumgOperador"]); exit;
			}				
			
		break;
			
		default:		
			header("Location: cadoperadores.php"); exit;
		break;
	}
?>