<?php
include_once ('funcoes.php');

if (is_null($_GET['width'])) $_GET['width'] = 100;
if (is_null($_GET['height'])) $_GET['height'] = 100;

thumb($_GET['arquivo'],$_GET['width'],$_GET['height'],$_GET['numg_site']);	

function thumb ($arquivo,$maxwidth,$maxheight,$numg_site=NULL) {	
	
	if($numg_site){
		$path = "imagens/upload/".$numg_site."/";	
	} 
	
	if (!file_exists($path.$arquivo)){
		$path = "imagens/";
		$arquivo = "naodisponivel.jpg";		
	}	
	
	//comentado at� o pessoal do sebrae liberar a biblioteca de jpeg
	if (stristr($arquivo,'jpg')) $srcimage = imagecreatefromjpeg($path.$arquivo);
	if (stristr($arquivo,'jpeg')) $srcimage = imagecreatefromjpeg($path.$arquivo);	
	if (stristr($arquivo,'gif')) $srcimage = imagecreatefromgif($path.$arquivo);
	if (stristr($arquivo,'png')) $srcimage = imagecreatefrompng($path.$arquivo);
	
	$srcW = ImagesX($srcimage);
	$srcH = ImagesY($srcimage);
	$wdiff = $srcW - $maxwidth;
	$hdiff = $srcH - $maxheight;
	
	if ($wdiff > $hdiff) {
	 $newW = $maxwidth;
	  $aspect = ($newW/$srcW);
	  $newH = (int)($srcH * $aspect);
	} else {
	  $newH = $maxheight;
	  $aspect = ($newH/$srcH);
	  $newW = (int)($srcW * $aspect);
	}
	
	//$newimage = imagecreatetruecolor($newW,$newH);
	//$newimage = imagecreate($newW,$newH);
	
	//ImageCopyResampled($newimage,$srcimage,0,0,0,0,$newW,$newH,$srcW,$srcH);
	
	if (stristr($arquivo,'jpg') or stristr($arquivo,'jpeg')) {		
		$newimage = imagecreatetruecolor($newW,$newH);
		
		ImageCopyResampled($newimage,$srcimage,0,0,0,0,$newW,$newH,$srcW,$srcH);
		
		header("Content-type:image/jpeg");
		imagejpeg($newimage);
	}
	
	if (stristr($arquivo,'gif')) {
		$newimage = imagecreate($newW,$newH);
	
		imagecopyresampled($newimage,$srcimage,0,0,0,0,$newW,$newH,$srcW,$srcH);
		
		header("Content-type:image/gif");	
		imagegif($newimage);
	}
	
	if (stristr($arquivo,'png')) {
		$newimage = imagecreate($newW,$newH);
		
		ImageCopyResampled($newimage,$srcimage,0,0,0,0,$newW,$newH,$srcW,$srcH);
		
		header("Content-type:image/png");	
		imagegif($newimage);
	}
	
	imagedestroy($newimage);
}
?>