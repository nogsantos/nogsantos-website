<?php 
include_once "funcoes.php";
include_once('classes/Sites.php');
/************************************************************************
Empresa: Interagi Tecnologia

Descri��o:

Releases (Data, respons�vel e descri��o [�ltimo release primeiro]):
07/12/2005 (Silas Junior)
Inclu�do este cabe�alho descrevendo a funcionalidade da p�gina
************************************************************************/

if (empty($_SESSION["NUMG_OPERADOR"]) || $_SESSION["NUMG_OPERADOR"] == ""){
	header("Location: expirou.htm"); exit;
}


$cat = $_POST['txtCat'];
$numg_id = $_POST['txtNumgId'];

if ($cat != "") { //Seleciona a classe de imagem correspondente a categoria da entidade;

	switch($cat) {

		case 1://sites
		include_once("classes/Imagens.php");
		$oObj = new Imagens();
		$oObj->setNumgSite($_POST['numgSite']);

		break;

		case 2://pend�ncias
		include_once("classes/ImagensPendencias.php");
		$vNumg = split("-",$numg_id);//indice 0 = numg_pendencia  indice 1 = numg_site
		$nNumgPendencia = $vNumg[0];
		$oObj = new ImagensPendencias();
		$oObj->setNumgSite($_POST['numgSite']);
		$oObj->setNumgPendencia($nNumgPendencia);
		break;

		case 3://di�rios
		include_once("classes/ImagensDiarios.php");
		$vNumg = split("-",$numg_id);//indice 0 = numg_diario  indice 1 = numg_subatividade  indice 2 = numg_site
		$nNumgDiario = $vNumg[0];
		$nNumgSubatividade = $vNumg[1];
		$oObj = new ImagensDiarios();
		$oObj->setNumgSite($_POST['numgSite']);
		$oObj->setNumgDiario($nNumgDiario);
		$oObj->setNumgSubatividade($nNumgSubatividade);

		break;

	}

} else {

	include_once("classes/Imagens.php");
	$oObj = new Imagens();
	$oObj->setNumgSite($_POST['numgSite']);

}


switch ($_POST["txtFuncao"]){


	case "cadastrar_imagem":

		$oImagem = new Imagens();

		for($i=0;$i<5;$i++){
			if($_FILES['txtPath'.$i]['tmp_name'] != ""){
				$oImagem->setNumgSite($_POST['numgSite']);
				$oImagem->setNomeArquivo(strtolower(RetiraCaracEsp(basename($_FILES['txtPath'.$i]['name']))));
				$oImagem->setNumrTamanho($_FILES['txtPath'.$i]['size']);
				$oImagem->setNomeTmpImagem($_FILES['txtPath'.$i]['tmp_name']);
				$oImagem->setDescFoto($_POST["descFoto"]);
				$oImagem->setTipoArquivo($_FILES['txtPath'.$i]['type']);

				$oImagem->cadastrar();
				
				if (!empty($_POST['numgSite'])) 
				{
					Sites::atualizaUltimaAlteracao($_POST['numgSite']);
				}
			}
		}

		if(Erros::isError()) {
			MostraErros();
		}


		if ($numg_id != "") {

			$oObj->setNumgFoto($oImagem->getNumgFoto());


		}

		if(Erros::isError()) {
			MostraErros();
		}

		header("Location:cadimg.php?info=3&cat=".$cat."&id=".$numg_id."&numg_site=" . $oImagem->getNumgSite());
		exit;

		break;

	case "editar_imagem":

		$oImagem = new Imagens();

		$oImagem->setNumgFoto($_POST["txtNumgFoto"]);
		$oImagem->setDescFoto($_POST["descFoto"]);
		$oImagem->setNomeArquivo($_POST["nomeArquivo"]);
		$oImagem->setNumgSite($_POST['numgSite']);
		$oImagem->editar();
		if (!empty($_POST['numgSite'])) 
		{
			Sites::atualizaUltimaAlteracao($_POST['numgSite']);
		}

		if(Erros::isError()) {
			MostraErros();
		}

		header("Location:cadimg.php?info=4&cat=".$cat."&id=".$numg_id."&numg_foto=" .$_POST["txtNumgFoto"]."&numg_site=" . $oImagem->getNumgSite());
		exit;
		break;

	case "excluir_imagem":

		$oImagem = new Imagens();
		$oImagem->setarDadosImagem($_POST["txtNumgFoto"]);
		$oImagem->excluir($_POST["txtNumgFoto"]);

		if(Erros::isError()) {
			MostraErros();
		}

		unset($oImagem);

		header("Location:cadimg.php?info=5&cat=".$cat."&id=" . $numg_id ."&numg_site=" . $_POST["numgSite"]);
		exit;
		break;

	case "vincular_imagem":



		$vImgVinc = $_POST["cboDisp"];


		for ($i=0; $i<count($vImgVinc); $i++){

			$oObj->setNumgFoto($vImgVinc[$i]);
			$oObj->vincular();

		}


		if (Erros::isError()){
			MostraErros();
		}else{
			header("Location:cadimg.php?info=1&cat=" . $cat . "&id=". $numg_id); exit;
		}

		break;

	case "desvincular_imagem":

		$vImgDesvinc = $_POST["cboVinc"];


		for ($i=0; $i<count($vImgDesvinc); $i++){

			$oObj->setNumgFoto($vImgDesvinc[$i]);
			$oObj->desvincular();
		}

		if (Erros::isError()){
			MostraErros();
		}else{
			header("Location:cadimg.php?info=2&cat=" . $cat . "&id=". $numg_id); exit;
		}

		break;


	default:
		header("Location: cadimg.php"); exit;
		break;
}

?>