<?php
include_once "funcoes.php";
include_once("classes/Sites.php");
include_once("classes/Fases.php");
include_once("classes/Municipios.php");
include_once("classes/Operadores.php");

/************************************************************************
'Empresa: Interagi Tecnologia
'Descri��o:
'Releases (Data, respons�vel e descri��o [�ltimo release primeiro]):
'25/03/2008 (Danilo Fernandes)
'Criada
'************************************************************************/

$CODG_FORMULARIO = "cadsites";
$NOME_FORMULARIO = validarAcesso($CODG_FORMULARIO,$_SESSION["NUMG_OPERADOR"]);


$oSite = new Sites();
$oMunicipio = new Municipios();
$oFase = new Fases();
$oOperador = new Operadores();


$vFases = new Resultset();

$vFases = $oFase->consultarTodas();

if ($_GET["numg_site"] != "" ) {
    $oSite->setarDados($_GET["numg_site"]);

    if (Erros::isError())
        MostraErros();

    if($_GET["sigl_uf"] != "") {
        $siglUf = $_GET["sigl_uf"];
    }
    else {
        $siglUf = $oSite->getSiglUf();
    }

    $vSites = $oSite->consultarPorUF($siglUf);

    if (Erros::isError())
        MostraErros();

    $vMunicipios = $oMunicipio->consultarPorUf($siglUf);

    if (Erros::isError())
        MostraErros();

    $vArquivos = glob('imagens/upload/'.$oSite->getNumgSite().'/documentos/*.*');
    $CaminhoRelativo = 'imagens/upload/'.$oSite->getNumgSite().'/documentos/';

}
else {
    if($_GET["sigl_uf"] !="") {
        $siglUf = $_GET["sigl_uf"];
    }
    else {
        $siglUf = "GO";
    }

    $vMunicipios = $oMunicipio->consultarPorUf($siglUf);

    if (Erros::isError()) { MostraErros();};
    $vSites = $oSite->consultarPorUF($siglUf);
    if (Erros::isError()) MostraErros();
}


$bPesquisa = true;

if (Erros::isError()) {
    MostraErros();
}
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
    <head>
        <meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
        <title>::: SIGO :::</title>
        <link href="estilos.css" rel="stylesheet" type="text/css">
        <script type="text/javascript" src="javascripts/prototype.js"> </script>
        <script language="JavaScript" src="funcoes.js"></script>
        <script type="text/javascript" src="javascripts/populacombo.js"></script>
        <script language="JavaScript">
            function novo_site()
            {
                window.location.href = '<?=$CODG_FORMULARIO?>.php'
            }
            function cadastrar_site()
            {
                if (document.form.numgSite.value == "")
                {
                    if (pValidaGravacao())
                    {
                        document.form.txtFuncao.value = "cadastrar_site"
                        document.form.submit()
                    }
                }
                else
                {
                    alert("Fun��o de CADASTRO n�o dispon�vel para este formul�rio!")
                }
            }

            function editar_site()
            {
                if (document.form.numgSite.value != "")
                {
                    if (pValidaGravacao())
                    {
                        document.form.txtFuncao.value = "editar_site"
                        document.form.submit()

                    }
                }
                else
                {
                    alert("Fun��o de EDI��O n�o dispon�vel para este formul�rio!")
                }
            }

            function excluir_site()
            {
                if (document.form.numgSite.value != "")
                {
                    if (confirm("Confirma a EXCLUS�O do Site?"))
                    {
                        document.form.txtFuncao.value = "excluir_site"
                        document.form.submit()
                    }
                }
                else
                {
                    alert("Fun��o de EXCLUS�O n�o dispon�vel para este formul�rio!")
                }
            }

            function nova_fase()
            {
                window.location.href = '<?=$CODG_FORMULARIO?>.php?numg_site=<?=$_GET['numg_site']?>'
            }

            function cadastrar_fase()
            {
                if (document.form.numgFase.value == "" && document.form.numgSite.value != "")
                {
                    if (pValidaGravacao())
                    {
                        document.form.txtFuncao.value = "cadastrar_fase"
                        document.form.submit()
                    }
                }
                else
                {
                    alert("Fun��o de CADASTRO n�o dispon�vel para este formul�rio!")
                }
            }

            function pValidaGravacao()
            {
                var sErr = ""
                //VERIFICA SE FOI ENCONTRADO ALGUM ERRO NA VALIDA��O DO FORMUL�RIO
                if (sErr != "")
                {
                    sErr = "Verifique os erros encontrados abaixo:\n\n" + sErr
                    alert(sErr)
                    return false
                }
                else
                    return true
            }

            function cadastrar_documento()
            {
                if (document.form.txtPath.value != "" )
                {
                    document.form.txtFuncao.value = "cadastrar_documento"
                    document.form.submit()

                }
                else
                {
                    alert("Fun��o de CADASTRO n�o dispon�vel para este formul�rio!")
                }
            }

            //FUN��O PARA CONFIRMA��O DA EXCLUS�O DA DOCUMENTO
            function excluir_documento()
            {
                var i
                var j=0

                //DEVER� SER SELECIONADO AO MENOS UMA TAREFA PARA EXCLUS�O
                for (var i=0;i<document.form.elements.length;i++)
                {
                    var e = document.form.elements[i];

                    if ((e.id == 'chkNomeArquivo') && (e.checked))
                    {
                        j=j+1
                    }
                }

                if (j==0)
                {
                    alert("Nenhum Documento foi selecionada para exclus�o!");
                }
                else
                {
                    //PEDE UMA CONFIRMA��O DO USU�RIO
                    if (confirm("Tem certeza que deseja excluir o(s) documento(s) selecionado(s)?"))
                    {
                        document.form.txtFuncao.value = "excluir_documento"
                        document.form.submit()
                    }
                    else
                    {

                    }
                }
            }

            function LimpaCampos()
            {
                document.form.txtPath.value = ""
                document.form.txtPath.focus()
                return false
            }
            function MarcaCheck()
            {
                var i;
                for (var i=0;i<document.form.elements.length;i++)
                {
                    var e = document.form.elements[i];

                    if ((e.name != 'chkTop') && (e.type=='checkbox'))
                    {
                        e.checked = document.form.chkTop.checked;
                    }
                }
            }
            function carregaMunicipios(cboSiglUf)
            {
                var endereco;
                endereco =  'cadsites.php?numg_site=<?=$oSite->getNumgSite()?>&sigl_uf=' + cboSiglUf.value
                window.location.href=endereco
            }

            function iniForm()
            {
                MontaFuncoes('<?=$CODG_FORMULARIO?>','<?=$NOME_FORMULARIO?>','<?=$oSite->getNumgSite()?>')
<?if($_GET['numg_site'] == "" ) {?>
                        AlteraTab(1,1)
<?}
else {?>
    <?if( $_GET['aba'] == 'doc') {?>
                            AlteraTab(3,3)
    <?}
    else {?>
                            AlteraTab(1,3)
    <?}?>
<?}?>
                  }
        </script>
    </head>
    <body onLoad="iniForm()" rightmargin="0" marginwidth="0" marginheight="0" leftmargin="0" bottommargin="0" topmargin="0" bgcolor="#FFFFFF">
        <table border="0" width="100%" align="center" cellspacing="0" cellpadding="0">
            <tr>
                <td><img src="imagens/space.gif" border="0" height="10"></td>
            </tr>
            <tr>
                <td align="center">
                    <table border="0" width="600" cellspacing="0" cellpadding="0">
                        <tr>
                            <td><img src="imagens/formEsqSup.gif" border="0" width="10" height="10"></td>
                            <td background="imagens/formMidSup.gif"></td>
                            <td><img src="imagens/formDirSup.gif" border="0" width="10" height="10"></td>
                        </tr>
                        <tr valign="top">
                            <td width="10" background="imagens/formEsqMid.gif"></td>
                            <td>
                                <table border="0" width="580" cellspacing="0" cellpadding="0" align="center" background="imagens/formMid.gif">
                                        <!--<table cellspacing="0" cellpadding="0" >-->
                                    <form method="post" action="pcadsites.php" name="form" id="form" ENCTYPE="multipart/form-data">
                                        <input name="numgSite" type="hidden" tabindex="0" value="<?=$oSite->getNumgSite()?>">
                                        <input name="txtFuncao" type="hidden" tabindex="1" value="">
                                        <input name="txtCaminhoRelativo" type="hidden" tabindex="2" value="<?=$CaminhoRelativo?>" />
<? if ($_GET["info"] != "") { ?>
                                        <tr>
                                            <td colspan=3 background="#F5F7F7" align=center height=20 valign=middle class=normal11><img src="imagens/icones/info.gif" border=0 align=absbottom>&nbsp;&nbsp;
    <?
    switch ($_GET["info"]) {
        case 1:
            echo "Cadastro realizado com sucesso";
            break;
        case 2:
            echo "Edi��o de dados realizada com sucesso";
            break;
                                                case 3:
            echo "Exclus�o realizada com sucesso";
            break;
                                                    }
                                                    ?>
                                            </td>
                                        </tr>
                                                <? }else if (!$bPesquisa) { ?>
                                        <tr>
                                            <td colspan="4" align="center" height="20" valign="middle" class="normal11">
                                                <img src="imagens/icones/excla.gif" border="0" align="absbottom">&nbsp;&nbsp;Nenhum registro encontrado para a pesquisa
                                            </td>
                                        </tr>
                                                    <? } ?>
                                        <tr>
                                            <td colspan="4" align="center" class="normal11b">
									UF: 	<select name="siglUf" class="borda" tabindex="3" id="siglUf" style="width:100px;" tabindex="12" onkeydown="setarFocus(this,'form',event)" onchange="carregaMunicipios(this)" >
                                                    <option value=""></option>
                                                    <option value="AC"<? if ($siglUf=="AC") {echo 'selected="selected"';}?>>AC</option>
                                                    <option value="AL"<? if ($siglUf=="AL") {echo 'selected="selected"';}?>>AL</option>
                                                    <option value="AP"<? if ($siglUf=="AP") {echo 'selected="selected"';}?>>AP</option>
                                                    <option value="AM"<? if ($siglUf=="AM") {echo 'selected="selected"';}?>>AM</option>
                                                    <option value="BA"<? if ($siglUf=="BA") {echo 'selected="selected"';}?>>BA</option>
                                                    <option value="CE"<? if ($siglUf=="CE") {echo 'selected="selected"';}?>>CE</option>
                                                    <option value="DF"<? if ($siglUf=="DF") {echo 'selected="selected"';}?>>DF</option>
                                                    <option value="ES"<? if ($siglUf=="ES") {echo 'selected="selected"';}?>>ES</option>
                                                    <option value="GO"<? if ($siglUf=="GO" || $siglUf=="") {echo 'selected="selected"';}?>>GO</option>
                                                    <option value="MA"<? if ($siglUf=="MA") {echo 'selected="selected"';}?>>MA</option>
                                                    <option value="MT"<? if ($siglUf=="MT") {echo 'selected="selected"';}?>>MT</option>
                                                    <option value="MS"<? if ($siglUf=="MS") {echo 'selected="selected"';}?>>MS</option>
                                                    <option value="MG"<? if ($siglUf=="MG") {echo 'selected="selected"';}?>>MG</option>
                                                    <option value="PA"<? if ($siglUf=="PA") {echo 'selected="selected"';}?>>PA</option>
                                                    <option value="PB"<? if ($siglUf=="PB") {echo 'selected="selected"';}?>>PB</option>
                                                    <option value="PR"<? if ($siglUf=="PR") {echo 'selected="selected"';}?>>PR</option>
                                                    <option value="PE"<? if ($siglUf=="PE") {echo 'selected="selected"';}?>>PE</option>
                                                    <option value="PI"<? if ($siglUf=="PI") {echo 'selected="selected"';}?>>PI</option>
                                                    <option value="RJ"<? if ($siglUf=="RJ") {echo 'selected="selected"';}?>>RJ</option>
                                                    <option value="RN"<? if ($siglUf=="RN") {echo 'selected="selected"';}?>>RN</option>
                                                    <option value="RS"<? if ($siglUf=="RS") {echo 'selected="selected"';}?>>RS</option>
                                                    <option value="RO"<? if ($siglUf=="RO") {echo 'selected="selected"';}?>>RO</option>
                                                    <option value="RR"<? if ($siglUf=="RR") {echo 'selected="selected"';}?>>RR</option>
                                                    <option value="SC"<? if ($siglUf=="SC") {echo 'selected="selected"';}?>>SC</option>
                                                    <option value="SP"<? if ($siglUf=="SP") {echo 'selected="selected"';}?>>SP</option>
                                                    <option value="SE"<? if ($siglUf=="SE") {echo 'selected="selected"';}?>>SE</option>
                                                    <option value="TO"<? if ($siglUf=="TO") {echo 'selected="selected"';}?>>TO</option>
                                                </select>

                                            </td>
                                        </tr>
                                        <tr>
                                            <td height="10"><img src="imagens/spacer.gif" /></td>
                                        </tr>
                                        <tr>
                                            <td>
<? if($_GET["numg_site"] == "") {?>
                                                <script language="JavaScript">
                                                    montaTabs(Array("Sites","","",""),1)
                                                </script>
<?}else {?>
                                                <script language="JavaScript">
                                                    montaTabs(Array("Sites","Imagens","Documentos",""),3)
                                                </script>
<?}?>

                                            </td>
                                        </tr>
                                        <tr>
                                            <td align="left">
                                                <div id="tab1">
                                                    <table border="0" width="580" cellspacing="0" cellpadding="2" class="bordaEsqDirInf">
                                                        <tr>
                                                            <td colspan="6"><img src="imagens/space.gif" border="0" height="5"></td>
                                                        </tr>
                                                        <tr>
                                                            <td></td>
                                                            <td colspan="5" class="normal11" align="right">
<?
if ($_GET["numg_site"] != "" ) {
    $oOperador->setarDadosOperador($oSite->getNumgOperadorcad());
    ?>
																			cadastrado em: <b><?=FormataDataHora($oSite->getDataCadastro())?></b>&nbsp;[<?=$oOperador->getNomeOperador()?>]

<?	}
?>
                                                            </td>
                                                        </tr>
                                                        <tr>
                                                            <td align="right" class="normal11" >
                                                                <strong>Munic�pio:</strong>
                                                            </td>
                                                            <td colspan="5">
                                                                <select name="numgMunicipio" class="borda" tabindex="5" id="numgMunicipio" tabindex="13" style="width:435px" onkeydown="setarFocus(this,'form',event)" >
<? if ($_GET["sigl_uf"] != "") {
                                                                    montaCombo($vMunicipios,"numg_municipio","nome_municipio","",false);
                                                                }else {
    montaCombo($vMunicipios,"numg_municipio","nome_municipio",$oSite->getNumgMunicipio(),false);
}?>
                                                                </select>
                                                            </td>
                                                        </tr>
                                                        <tr>
                                                            <td align="right" class="normal11">
                                                                <strong>Nome:</strong>
                                                            </td>
                                                            <td colspan="5" >
                                                                <span class="normal11" >
                                                                    <input name="nomeSite" tabindex="6" type="text" class="borda" id="nomeSite" value="<?=$oSite->getNomeSite();?>" size="70" maxlength="20" onkeydown="setarFocus(this,'form',event)">
                                                                </span>
                                                            </td>
                                                        </tr>
                                                        <tr>
                                                            <td align="right" class="normal11">
																Tipo Site:
                                                            </td>
                                                            <td>
                                                                <select name="numrTipo" id="numrTipo" tabindex="7" class=bordaSite onkeydown="setarFocus(this,'form',event)"  >
                                                                    <option value="1" <? if ($oSite->getNumrTipo()== 1) {echo 'selected="selected"';}?>>GF</option>
                                                                    <option value="2" <? if ($oSite->getNumrTipo()== 2) {echo 'selected="selected"';}?>>RT</option>
                                                                </select>
                                                            </td>
                                                            <td align="right" class="normal11">
																Tipo Torre:
                                                            </td>
                                                            <td>
                                                                <select name="numrTipotorre" id="numrTipotorre" tabindex="8" class=bordaSite tabindex="3" onkeydown="setarFocus(this,'form',event)" >
                                                                    <option value="1" <? if ($oSite->getNumrTipotorre()== 1) {echo 'selected="selected"';}?>>Poste</option>
                                                                    <option value="2" <? if ($oSite->getNumrTipotorre()== 2) {echo 'selected="selected"';}?>>Estaiada</option>
                                                                    <option value="3" <? if ($oSite->getNumrTipotorre()== 3) {echo 'selected="selected"';}?>>Auto-sup</option>
                                                                    <option value="4" <? if ($oSite->getNumrTipotorre()== 4) {echo 'selected="selected"';}?> >RT</option>
                                                                </select>
                                                            </td>
                                                            <td align="right" class="normal11">
																Tipo Bts:
                                                            </td>
                                                            <td>
                                                                <select name="numrTipobts" id="numrTipobts" tabindex="9" class=bordaSite onkeydown="setarFocus(this,'form',event)" >
                                                                    <option value="1" <? if ($oSite->getNumrTipobts()==1) {echo 'selected="selected"';}?> >IN</option>
                                                                    <option value="2" <? if ($oSite->getNumrTipobts()==2) {echo 'selected="selected"';}?> >OUT</option>
                                                                </select>
                                                            </td>
                                                        </tr>
                                                        <tr>
                                                            <td align="right" class="normal11" valign="top">
																Detentora:
                                                            </td>
                                                            <td>
                                                                <select name="numrDetentora" id="numrDetentora" class=bordaSite tabindex="9" onkeydown="setarFocus(this,'form',event)" >
                                                                    <option value="" <? if ($oSite->getNumrDetentora()== "") {echo 'selected="selected"';}?>>&nbsp;</option>
                                                                    <option value="1" <? if ($oSite->getNumrDetentora()== 1) {echo 'selected="selected"';}?>>Vivo</option>
                                                                    <option value="2" <? if ($oSite->getNumrDetentora()== 2) {echo 'selected="selected"';}?>>Tim</option>
                                                                    <option value="3" <? if ($oSite->getNumrDetentora()== 3) {echo 'selected="selected"';}?>>Claro</option>
                                                                    <option value="4" <? if ($oSite->getNumrDetentora()== 4) {echo 'selected="selected"';}?>>Telemar</option>
                                                                    <option value="5" <? if ($oSite->getNumrDetentora()== 5) {echo 'selected="selected"';}?>>Oi</option>
                                                                    <option value="6" <? if ($oSite->getNumrDetentora()== 6) {echo 'selected="selected"';}?>>Embratel</option>
                                                                </select>
                                                            </td>
                                                            <td align="right" class="normal11">
																ID Detentora:
                                                            </td>
                                                            <td >
                                                                <span class="normal11" >
                                                                    <input name="numrIddetentora" tabindex="6" type="text" class="borda" id="numrIddetentora" value="<?=$oSite->getNumrIdDetentora()?>" size="9" maxlength="50" onkeydown="setarFocus(this,'form',event)">
                                                                </span>
                                                            </td>
                                                            <td align="right" class="normal11" valign="top">
																Constru��o:
                                                            </td>
                                                            <td >
                                                                <select name="numrConstrucao" id="numrConstrucao" class=bordaSite tabindex="10" onkeydown="setarFocus(this,'form',event)" >
                                                                    <option selected="selected" value="">&nbsp;</option>
                                                                    <option value="1" <? if ($oSite->getNumrConstrucao()== 1) {echo 'selected="selected"';}?>>Novo</option>
                                                                    <option value="2" <? if ($oSite->getNumrConstrucao()== 2) {echo 'selected="selected"';}?>>Reuso</option>
                                                                </select>
                                                            </td>

                                                        </tr>



                                                        <tr>
                                                            <td align="right" class="normal11" valign="top">
																Tipo de Liga��o:
                                                            </td>
                                                            <td>
                                                                <select name="numrLigacao" id="numrLigacao" class=bordaSite tabindex="11" onkeydown="setarFocus(this,'form',event)" >
                                                                    <option value="" <? if ($oSite->getNumrLigacao()== "") {echo 'selected="selected"';}?>>&nbsp;</option>
                                                                    <option value="1" <? if ($oSite->getNumrLigacao()== 1) {echo 'selected="selected"';}?>>BT</option>
                                                                    <option value="2" <? if ($oSite->getNumrLigacao()== 2) {echo 'selected="selected"';}?>>AT</option>
                                                                </select>
                                                            </td>
                                                            <td align="right" class="normal11">
																Unidade Consumidora:
                                                            </td>
                                                            <td >
                                                                <span class="normal11" >
                                                                    <input name="numrUndConsumidora" tabindex="12" type="text" class="borda" id="numrUndConsumidora" value="<?=$oSite->getNumrUndConsumidora()?>" size="9" maxlength="10" onkeydown="setarFocus(this,'form',event)">
                                                                </span>
                                                            </td>
                                                            <td align="right" class="normal11" valign="top">
																Tecnologia:
                                                            </td>
                                                            <td>
                                                                <select name="numrTecnologia" id="numrTecnologia" class=bordaSite tabindex="13" onkeydown="setarFocus(this,'form',event)" >
                                                                    <option selected="selected" value="">&nbsp;</option>
                                                                    <option value="1" <? if ($oSite->getNumrTecnologia()== 1) {echo 'selected="selected"';}?>>GSM</option>
                                                                    <option value="2" <? if ($oSite->getNumrTecnologia()== 2) {echo 'selected="selected"';}?>>WCDMA</option>
                                                                    <option value="3" <? if ($oSite->getNumrTecnologia()== 3) {echo 'selected="selected"';}?>>GSM + WCDMA</option>
                                                                </select>
                                                            </td>

                                                        </tr>


                                                        <tr>
                                                            <td align="right" class="normal11">
																Latitude:
                                                            </td>
                                                            <td>
                                                                <input name="descLatitude" type="text" class="borda" tabindex="14" id="descLatitude" value="<?=$oSite->getDescLatitude()?>" size="7" tabindex="12" maxlength="20" onkeyup="IsNumber(this);FormataCoordenadas(this,event)"  onkeydown="setarFocus(this,'form',event)" />
                                                            </td>
                                                            <td align="right" class="normal11">
																Longitude:
                                                            </td>
                                                            <td colspan=>
                                                                <input name="descLongitude" type="text" class="borda" id="descLongitude" value="<?=$oSite->getDescLongitude()?>" size="9" tabindex="13" maxlength="20" onkeyup="IsNumber(this);FormataCoordenadas(this,event);"   />
                                                            </td>
                                                            <td align="right" class="normal11">
																Altura Torre:
                                                            </td>
                                                            <td >
                                                                <input name="numrAlturaTorre" size="9" tabindex="14" type="text"  class="bordaSite" id="numrAlturaTorre" maxlength="6" value="<?=FormataValor($oSite->getNumrAlturaTorre())?>"   onkeyup="return IsDecimal(this);"  />
                                                            </td>
                                                        </tr>
                                                        <tr>
                                                            <td align="right" class="normal11">
																Regi�o:
                                                            </td>
                                                            <td colspan="5">
                                                                <select name="numrRegiao" id="numrRegiao" class=bordaSite tabindex="15" onkeydown="setarFocus(this,'form',event)" >
                                                                    <option value=""></option>
                                                                    <option value="1" <? if ($oSite->getNumrRegiao()== 1) {echo 'selected="selected"';}?>>NE1</option>
                                                                    <option value="2" <? if ($oSite->getNumrRegiao()== 2) {echo 'selected="selected"';}?> >NE2</option>
                                                                </select>
                                                            </td>
                                                        <tr>
                                                            <td align="right" class="normal11" valign="top">
																Periculosidade:
                                                            </td>
                                                            <td colspan="5">
                                                                <textarea name="descPericulosidade" id="descPericulosidade" tabindex="16" rows="2" cols="69" class="borda" tabindex="15" onkeydown="setarFocus(this,'form',event)" /><?=$oSite->getDescPericulosidade()?></textarea>
                                                            </td>
                                                        </tr>
                                                        <tr>
                                                            <td align="right" class="normal11" valign="top">
																Endere�o:
                                                            </td>
                                                            <td colspan="5">
                                                                <textarea name="descEndereco" id="descEndereco" rows="3" cols="69" tabindex="17" class="borda" onkeydown="setarFocus(this,'form',event)" ><?=$oSite->getDescEndereco()?></textarea>
                                                            </td>
                                                        </tr>
                                                        <tr>
                                                            <td align="right" class="normal11">
																	Ponto de Refer�ncia:
                                                            </td>
                                                            <td colspan="5">
                                                                <textarea name="descPontoRef" id="descPontoRef" rows="2" cols="69" class="borda" tabindex="18" onkeydown="setarFocus(this,'form',event)" /><?=$oSite->getDescPontoRef()?></textarea>
                                                            </td>
                                                        </tr>
                                                        <tr>
                                                            <td colspan="6"><img src="imagens/space.gif" border=0 height=5></td>
                                                        </tr>
                                                    </table>
                                                </div>
                                                                <? if($_GET['numg_site'] != "" ) { 	?>
                                                <div id="tab2">
                                                    <iframe name="iframe" src="iframecadimg.php?cat=1&id=<?=$oSite->getNumgSite()?>" frameborder="0" width="100%" height="300" scrolling="no" class="bordaEsqDirInf"></iframe>
                                                </div>
                                                <div id="tab3">
                                                    <table border=0 width=100% height=80 cellspacing=0 cellpadding=0 class="bordaEsqDirInf" background="#FFFFFF">
                                                        <tr>
                                                            <td height=20 ></td>
                                                            <td></td>
                                                        </tr>
                                                        <tr>
                                                            <td width=18% align=right class="normal11">Documento:</td>
                                                            <td width=82%><input type="file" tabindex="19" class="borda" size="33" name="txtPath"></td>
                                                        </tr>
    <?php if (!empty($vArquivos)) {?>
                                                        <tr>
                                                            <td colspan="2">

                                                                <table border=0 width=550 cellspacing=0 cellpadding=0 align=center style="padding-top:10px">
                                                                    <tr>
                                                                        <td colspan=4 class=normal11 height=25>Rela��o de arquivos cadastrados:</td>
                                                                    </tr>
                                                                    <tr>
                                                                        <td colspan="4">
                                                                            <table border=0 width=100% height=22 cellspacing=0 cellpadding=0 background="imagens/fundoBarraRelatorio.gif" >
                                                                                <tr class=titulo_form>
                                                                                    <td width="5%"><input type="checkbox" name="chkTop" onClick="MarcaCheck()"></td>
                                                                                    <td width="60%" align="left" class="normal11b"  >NOME ARQUIVO</td>
                                                                                    <td width="15%" class="normal11b"  >TAMANHO</td>
                                                                                    <td width="20%" class="normal11b">DATA</td>
                                                                                </tr>
                                                                            </table>
                                                                        </td>
                                                                    </tr>
        <?php for ($i=0; $i < count($vArquivos); $i++) {?>
                                                                    <tr height=20 <?php if ($i % 2 == 1) {?>bgcolor="#EEEEEE"<?php }?>>
                                                                        <td width="5%"><input type="checkbox" name="chkNomeArquivo[]" id="chkNomeArquivo" value="<?=$vArquivos[$i]?>"></td>
                                                                        <td class="normal11" width="60%"><a href="<?=$vArquivos[$i]?>" target="_blank" class="relatorio"><?=basename($vArquivos[$i])?></a></td>
                                                                        <td class="normal11" width="15%" align="center"><?=retornaTamanhoArquivo(filesize($vArquivos[$i]))?></td>
                                                                        <td class="normal11" width="20%" align="right"><?=date('d/m/Y H:i:s', filectime($vArquivos[$i]))?></td>
                                                                    </tr>
        <?php }?>
                                                                    <tr height=20 <?php if($i % 2 == 1) {?>bgcolor="#EEEEEE"<?php }?>>
                                                                        <td colspan="3"  width="80%" class="destaque">* Para excluir um arquivo selecione na lista e clique no bot�o excluir.</td>
                                                                        <td width="20%"  align="right" class="normal11b">TOTAL: <?=count($vArquivos)?></td>
                                                                    </tr>
                                                                </table>
                                                                <br/>
                                                            </td>
                                                        </tr>
    <?php }?>
                                                    </table>


                                                </div>
<? }?> 					
                                            </td>
                                        </tr>
                                    </form>
                                    <tr>
                                        <td colspan="6" class="normal11" align="right">
                                                        <?
if ($_GET["numg_site"] != "" ) {
    $oOperador->setarDadosOperador($oSite->getNumgOperadoralt());
    if($oSite->getDataUltimaalt() != "") {
        ?>
                                            &Uacute;ltima altera&ccedil;&atilde;o: <b><?=FormataDataHora($oSite->getDataUltimaalt())?></b>&nbsp;[<?=$oOperador->getNomeOperador()?>]

    <?		}
}
?>
                                        </td>
                                    </tr>
                                </table>

                            </td>
                            <td width="10" background="imagens/formDirMid.gif"></td>
                        </tr>
                        <tr>
                            <td><img src="imagens/formEsqInf.gif" border="0" width="10" height="10"></td>
                            <td background="imagens/formMidInf.gif"></td>
                            <td><img src="imagens/formDirInf.gif" border="0" width="10" height="10"></td>
                        </tr>
                    </table>


<?php 
if (isset($vSites)) {
    if ($vSites->getCount() > 0) {?>
            <tr>
                <td >
                    <table border=0 width="600" cellspacing=0 cellpadding=0 align=center>
                        <tr>
                            <td colspan=2 class=normal11 height=25 valign=bottom>Rela��o dos sites do estado <span class="destaque"><strong><?=$siglUf?></strong></span> cadastrados:</td>
                        </tr>
                        <tr height=20 class=normal11b align=center>
                            <td background="imagens/fundoBarraRelatorio.gif" width=15%>Nome</td>
                            <td background="imagens/fundoBarraRelatorio.gif" width=45%>Data de Cadastro</td>
                        </tr>
                            <?php for ($i=0; $i<$vSites->getCount(); $i++) {?>
                        <tr height=20 <?php if ($i % 2 == 1) {?>bgcolor="#E8E8E8"<?php }?> class=relatorio>
                            <td><a href="cadsites.php?numg_site=<?=$vSites->getValores($i,"numg_site");?>" class="relatorio"><?=$vSites->getValores($i,"nome_site");?></a></td>
                            <td align="center"><?=FormataData($vSites->getValores($i,"data_cadastro"));?></td>
                        </tr>
        <?php }?>
                        <tr height=20 <?php if ($i % 2 == 1) {?>bgcolor="#E8E8E8"<?php }?>>
                            <td class=destaque>* Clique no nome da site para edit�-lo</td>
                            <td class=normal11b align=right>TOTAL: <?=$vSites->getCount(); ?></td>
                        </tr>
                    </table>
                </td>
            </tr>
    <?php } }?>
            <tr>
                <td><img src="imagens/space.gif" border=0 height=10></td>
            </tr>
        </table>

<? $oSite->free; ?>

    </body>

    <head>
        <META HTTP-EQUIV="Pragma" CONTENT="no-cache">
        <META HTTP-EQUIV="Expires" CONTENT="-1">
    </head>
</html>