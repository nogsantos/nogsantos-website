<?php
include_once "funcoes.php";
include_once "classes/Atividades.php";
include_once "classes/Subatividades.php";
include_once "classes/Funcoes.php";
include_once "classes/Grupos.php";

/************************************************************************
 Empresa: Interagi Tecnologia

 Descri��o:
	
 Releases (Data, respons�vel e descri��o [�ltimo release primeiro]):
	 17/02/2005 (Rafael C�cero) 
		 Inclu�do este cabe�alho descrevendo a funcionalidade da p�gina
						
************************************************************************/
	
	$CODG_FORMULARIO = "cadsubatividades";
	$NOME_FORMULARIO = validarAcesso($CODG_FORMULARIO,$_SESSION["NUMG_OPERADOR"]);

		
	$oSubatividades = new Subatividades () ;
	$vSubatividades = new Resultset ();
	
	
	if ($_GET["numg_subatividade"] != ""){

		$oSubatividades->setarDados($_GET["numg_subatividade"]);
		if (Erros::isError()) MostraErros();
		
		if ($oSubatividades->getNumgSubatividade() != ""){			
			
			//BUSCA AS SUBATIVIDADES CADASTRADAS PARA O FORMUL�RIO
			$vSubatividades = $oSubatividades->consultarPorAtividade($oSubatividades->getNumgAtividade());
			if (Erros::isError()) MostraErros();
			
					
		}
	
	}elseif ($_GET["numg_atividade"] != ""){
	
		$vSubatividades = $oSubatividades->consultarPorAtividade($_GET["numg_atividade"]);
		//BUSCA AS SUBATIVIDADES CADASTRADAS PARA O FORMUL�RIO
		
		if (Erros::isError()) MostraErros();
	}


	$oAtividades = new Atividades();
	
	//BUSCA ATIVIDADES CADASTRADAS NO SISTEMA	
	$vAtividades = $oAtividades->consultarAtividades();
	if (Erros::isError()) MostraErros();				
	
	$oAtividades->free;
	
?>

<html>
<head>

<title>Sigo - Cadastro de SubAtividades de Atividades</title>

<link href="estilos.css" rel="stylesheet" type="text/css">

<SCRIPT language=JavaScript src="funcoes.js"></SCRIPT>

<SCRIPT language=JavaScript>
function iniForm(){
	MontaFuncoes('<?=$CODG_FORMULARIO; ?>','<?=$NOME_FORMULARIO; ?>','<?=$oSubatividades->getNumgSubatividade()?>')
	AlteraTab(1,1)
	document.form.cboAtividades.focus()
}

function AlteraBotao(nome) {
	oImage = eval("document.icone")
	if (nome != "")
		oImage.src = "imagens/botoes/" + nome
	else
		oImage.src = "imagens/space.gif"
}
</script>

</head>
<body onLoad="iniForm()" rightmargin="0" marginwidth="0" marginheight="0" leftmargin="0" bottommargin="0" topmargin="0" bgcolor="#FFFFFF">

<table border=0 width=100% align=center cellspacing=0 cellpadding=0>
	<tr>
		<td><img src="imagens/space.gif" border=0 height=10></td>
	</tr>
	<tr>
		<td align=center>
			<table border=0 width=600 cellspacing=0 cellpadding=0>
				<tr>
					<td><img src="imagens/formEsqSup.gif" border=0 width=10 height=10></td>
					<td background="imagens/formMidSup.gif"></td>
					<td><img src="imagens/formDirSup.gif" border=0 width=10 height=10></td>
				</tr>
				<tr valign=top>
					<td width=10 background="imagens/formEsqMid.gif"></td>
					<td>
						<table border=0 width=100% cellspacing=0 cellpadding=0 align=center background="imagens/formMid.gif">
						<form method="post" action="pcadsubatividades.php" name="form">
							<input type=hidden name=txtFuncao value="">
							<input type=hidden name=txtNumgSubatividade value="<?=$oSubatividades->getNumgSubatividade()?>">
							<input type=hidden name=txtDataBloqueio value="<?=$oSubatividades->getDatabloqueio()?>">
							
							<!-- IN�CIO CAMPOS DO FORMUL�RIO  -->
							<?php if ($_GET["info"] != ""){?>
							<tr>
								<td colspan=2 align=center height=20 valign=middle class=normal11>
								<img src="imagens/icones/info.gif" border=0 align=absbottom>&nbsp;&nbsp;
								<?php 		
									switch ($_GET["info"]){
										case 1:
											echo "Cadastro realizado com sucesso";
											break;
										case 2:
											echo "Edi��o realizada com sucesso";
											break;
										case 3:
											echo "Exclus�o realizada com sucesso";
											break;
										case 4:
											echo "Bloqueio realizado com sucesso";
											break;
										case 5:
											echo "Desbloqueio realizado com sucesso";
											break;
										
									} ?>
								</td>
							</tr>
							<?php }?>				
							<tr>
								<td colspan=3>
									<table border=0 width=580 cellspacing=0 cellpadding=2>
										<tr>
											<td width=20% align=right class=normal11b>Atividades:</td>
											<TD width=80%>
												<select name=cboAtividade class=borda style="width:435" onChange="window.location.href='cadsubatividades.php?numg_atividade=' + document.form.cboAtividade.value">
												<? if($_GET["numg_atividade"] != ""){
													montaCombo($vAtividades,"numg_atividade","nome_atividade",$_GET["numg_atividade"],true);
												 }else{ 
													montaCombo($vAtividades,"numg_atividade","nome_atividade",$oSubatividades->getNumgAtividade(),true);
												  }?>	
												</select>
												
											</TD>
										</tr>
									</table>
								</td>
							</tr>
							<tr>
								<td height=10></td>
							</tr>
							<tr>
								<td colspan=3>
									<script language="JavaScript">										
										montaTabs(Array("Dados Gerais","","",""),1)
									</script>
								</td>
							</tr>
							<tr>
								<td colspan=3>
									<div id="tab1">
												<table border="0" width="580" cellspacing="0" cellpadding="2" class="bordaEsqDirInf"> 
														<tr>
															<td><img src="imagens/space.gif" border="0" height="5"></td>
														</tr>
														<tr> 
															<td align="right" class="normal11">
																<strong>Nome:</strong>
															</td> 
															<td colspan="5" >
																<span class="normal11" > 
																	<input name="nomeSubatividade" tabindex="1" type="text" class="borda" id="nomeSubatividade" value="<?=$oSubatividades->getNomeSubatividade();?>" size="72" maxlength="50" onKeyDown="setarFocus(this,'form',event)"> 
																</span>
															</td> 
														</tr>
														<tr>
															<td>
																<img src="imagens/space.gif" border=0 height=10>
															</td>
														</tr>
												</table>		 
											</div>
									
								</td>
							</tr>
							<!-- FIM CAMPOS DO FORMUL�RIO  -->
							
						</form>
						</table>
					</td>
					<td width=10 background="imagens/formDirMid.gif"></td>
				</tr>
				<tr>
					<td><img src="imagens/formEsqInf.gif" border=0 width=10 height=10></td>
					<td background="imagens/formMidInf.gif"></td>
					<td><img src="imagens/formDirInf.gif" border=0 width=10 height=10></td>
				</tr>
			</table>
		</td>
	</tr>
	
	<?php 
	if (isset($vSubatividades)){
	if ($vSubatividades->getCount() > 0){?>
	<tr>
		<td>
			<table border=0 width=600px cellspacing=0 cellpadding=0 align=center>
				<tr>
					<td colspan=2 class=normal11 height=25 valign=bottom>Rela��o de Subatividades cadastradas para Atividade:</td>
				</tr>
				<tr height=20 class=normal11b align=center>
					<td background="imagens/fundoBarraRelatorio.gif" width=10%>C�digo</td>
					<td background="imagens/fundoBarraRelatorio.gif" width=70%>SubAtividade</td>
					<td background="imagens/fundoBarraRelatorio.gif" width=20%>Bloqueio</td>
					
				</tr>
				
				<?php for ($i=0; $i<$vSubatividades->getCount(); $i++){?>
				<tr height=20 <?php if ($i % 2 == 1){?>bgcolor="#E8E8E8"<?php }?> class=relatorio>
					<td align="center"><a href="cadsubatividades.php?numg_subatividade=<?=$vSubatividades->getValores($i,"numg_subatividade");?>" class=relatorio><?=$vSubatividades->getValores($i,"numg_subatividade");?></a></td>
					<td><?=$vSubatividades->getValores($i,"nome_subatividade");?></td>
					<td><?=FormataData($vSubatividades->getValores($i,"data_bloqueio"))." ".$vSubatividades->getValores($i,"nome_operador");?></td>
					
				</tr>
				<?php }?>
				<tr height=20 <?php if (i % 2 == 1){?>bgcolor="#E8E8E8"<?php }?>>
					<td colspan="2">
					<table cellpadding="0" cellspacing="0" width="100%">
						<tr>
							<td class=destaque colspan=2>* Clique no c�digo da subatividade para edit�-la</td>
							<td class=normal11b align=right>TOTAL: <?=$vSubatividades->getCount(); ?></td>
						</tr>
					</table>
					</td>
				</tr>
			</table>
		</td>
	</tr>
	<?php } }?>
	<tr>
		<td><img src="imagens/space.gif" border=0 height=10></td>
	</tr>
</table>

<script language="JavaScript">
function novo_subatividade(){
<? if($_GET["numg_atividade"] != ""){?>
	window.location.href = '<?=$CODG_FORMULARIO?>.php?numg_atividade=<?=$_GET["numg_atividade"]?>'
<? }else{ ?>
	window.location.href = '<?=$CODG_FORMULARIO?>.php?numg_atividade=<?=$oSubatividades->getNumgAtividade()?>'
<?  }?>
	
}

function cadastrar_subatividade(){
	if (document.form.txtNumgSubatividade.value == ""){
		if (pValidaGravacao()){
			document.form.txtFuncao.value = "cadastrar_subatividade"
				document.form.submit()
			
		}
	}else{
		alert("Fun��o de CADASTRO n�o dispon�vel para este formul�rio!")
	}
	
}

function editar_subatividade(){
	if (document.form.txtNumgSubatividade.value != ""){
		if (pValidaGravacao()){
				document.form.txtFuncao.value = "editar_subatividade"
				document.form.submit()
			
		}
	}else{ 
		alert("Fun��o de EDI��O n�o dispon�vel para este formul�rio!")
	}

}

function excluir_subatividade(){
	if (document.form.txtNumgSubatividade.value != ""){
		if (confirm("Confirma a EXCLUS�O da Subatividade?")){
			document.form.txtFuncao.value = "excluir_subatividade"
			document.form.submit()
		}
	}else{ 
		alert("Fun��o de EXCLUS�O n�o dispon�vel para este formul�rio!")
	}
}

function cadastrar_gruposubatividade(){
	if (document.form.txtNumgSubatividade.value != ""){
		if (document.form("cboGruposDisponiveis[]").value == ""){
			alert("Selecione um Grupo na lista de Grupos dispon�veis.")
			AlteraTab(2,2)
			document.form("cboGruposDisponiveis[]").focus()
		}else{
				document.form.txtFuncao.value = "cadastrar_gruposubatividade"
				document.form.submit()
			
		}
	}else{
		alert("Fun��o de CADASTRO DE GRUPO n�o dispon�vel para este formul�rio!")
	}
	
}

function excluir_gruposubatividade(){
	if (document.form.txtNumgSubatividade.value != ""){
		if (document.form("cboGruposSubatividade[]").value == ""){
			alert("Selecione um Grupo na lista de Grupos de acesso a subatividade.")
			AlteraTab(2,2)
			document.form("cboGruposSubatividade[]").focus()
		}else{
				document.form.txtFuncao.value = "excluir_gruposubatividade"
				document.form.submit()
			
		}
	}else{
		alert("Fun��o de CADASTRO DE GRUPO n�o dispon�vel para este formul�rio!")
	}
	
}

function bloquear_subatividade(){
	if (document.form.txtNumgSubatividade.value != ""){
		if (pValidaGravacao()){
				document.form.txtFuncao.value = "bloquear_subatividade"
				document.form.submit()
			
		}
	}else{ 
		alert("Fun��o de BLOQUEIO n�o dispon�vel para este formul�rio!")
	}

}


function desbloquear_subatividade(){
	if (document.form.txtNumgSubatividade.value != ""){
		if (pValidaGravacao()){
				document.form.txtFuncao.value = "desbloquear_subatividade"
				document.form.submit()
			
		}
	}else{ 
		alert("Fun��o de DESBLOQUEIO n�o dispon�vel para este formul�rio!")
	}

}

function pValidaGravacao(){
	
	var sErr = ""
	
	//...
	
	//VERIFICA SE FOI ENCONTRADO ALGUM ERRO NA VALIDA��O DO FORMUL�RIO
	if (sErr != ""){
		sErr = "Verifique os erros encontrados abaixo:\n\n" + sErr
		alert(sErr)	
		return false
	}else
		return true
}
</script>

<?php $oSubatividades->free;?>

</body>

<head>
<META HTTP-EQUIV="Pragma" CONTENT="no-cache">
<META HTTP-EQUIV="Expires" CONTENT="-1">
</head>

</html>